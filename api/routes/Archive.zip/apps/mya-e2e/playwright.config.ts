import { getConfig } from '@utility-e2e';

const config = getConfig({
  appNameRef: 'mya',
  timeout: 300000,
  projects: [
    {
      name: 'CoreAndVisual',
      grep: [ /@CoreTest/, /@VisualCheck/ ],
      use: { channel: 'chrome' },
    },
    {
      name: 'CoreOnly',
      grep: [ /@CoreTest/ ],
      use: { channel: 'chrome' },
    },
    {
      name: 'BrandingVisualChecks',
      grep: [ /@BrandingVisualCheck/ ],
      use: { channel: 'chrome' },
    },
  ],
});

export default config;
