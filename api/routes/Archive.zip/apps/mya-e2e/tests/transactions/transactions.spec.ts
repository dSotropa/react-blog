import { expect, test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AuthenticationPage } from '../../models/authentication';
import { HomePageMya } from '../../pageobjects/homepage-mya.po';

test.describe.parallel('Core Functionality', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let homePageMya: HomePageMya;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    homePageMya = new HomePageMya(page);
  });

  test('Perform smoke test of transactions @CoreTest', async () => {
    await authenticationPage.navigate();
    await homePageMya.transactionTab.click();
    await homePageMya.assertElementVisible(homePageMya.transactionTable);
    await expect(homePageMya.transactionTable).toContainText('Management Charge');
    await expect(homePageMya.transactionTable).toContainText('£');
    await expect(homePageMya.transactionTable).toContainText('Date');
    await expect(homePageMya.transactionTable).toContainText('Transaction type');
    await expect(homePageMya.transactionTable).toContainText('Amount');

    await expect(homePageMya.transactionFilter).toContainText('All transaction types');
  });

  test('Compare the transactions page to its baseline with feature card @VisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate();
    const pageName = 'Transactions page with feature card';

    await homePageMya.transactionTab.click();
    await homePageMya.assertElementVisible(homePageMya.transactionTable);
    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Compare the transactions page to its baseline no feature card @VisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate('product', 'decumulationNoPrizeDraw');
    const pageName = 'Transactions page no feature card';

    await homePageMya.transactionTab.click();
    await homePageMya.assertElementVisible(homePageMya.transactionTable);
    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  afterAllHook(test);
});
