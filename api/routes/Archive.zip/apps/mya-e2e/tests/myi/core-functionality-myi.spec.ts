import { test, expect } from '@playwright/test';
import { AccessibilityFunctions } from '@utility-e2e';

import { AvailableFundsPage } from '../../pageobjects/available-funds-page.po';
import { AuthenticationPage } from '../../models/authentication';
import { BasePage } from '../../models/basepage';
import { FundDetails } from '../../pageobjects/fund-details.po';
import { Investments } from '../../pageobjects/investments.po';
import { MyiContributionPage } from '../../pageobjects/myi-my-existing-holding-page.po';
import { RiskAndRewardPage } from '../../pageobjects/risk-and-rewards-page.po';
import { YourSummaryPage } from '../../pageobjects/your-summary-page.po';
import { MyFutureContributionPage } from '../../pageobjects/myi-my-future-contributions-page.po';

test.describe.parallel('Core Functionality For MYI', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let investmentsPage: Investments;
  let fundDetailsPage: FundDetails;
  let availableFundsPage: AvailableFundsPage;
  let myiContributionPage: MyiContributionPage;
  let riskAndRewardsPage: RiskAndRewardPage;
  let yourSummaryPage: YourSummaryPage;
  let myiFutureContributionsPage: MyFutureContributionPage;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    investmentsPage = new Investments(page);
    fundDetailsPage = new FundDetails(page);
    availableFundsPage = new AvailableFundsPage(page);
    myiContributionPage = new MyiContributionPage(page);
    riskAndRewardsPage = new RiskAndRewardPage(page);
    yourSummaryPage = new YourSummaryPage(page);
    myiFutureContributionsPage = new MyFutureContributionPage(page);
  });

  test('Check accessibility for Browse available funds @CoreTest @Accessibility', async ({
    page,
  }) => {
    await authenticationPage.navigate('product/investments', 'regularContributionsLSP');
    await investmentsPage.browseFundsBtn.click();
    await investmentsPage.assertUrlContains('/available-funds');
    expect(await page.title()).toBe('Browse funds - Workplace Pensions');
    await new AccessibilityFunctions(page).injectAxe();
  });

  test('Check accessibility for Change allocation page @CoreTest @Accessibility', async ({
    page,
  }) => {
    await authenticationPage.navigate('product/investments', 'regularContributionsLSP');
    await investmentsPage.changeAllocationsButton.click();
    await investmentsPage.assertUrlContains('/change-allocations');
    expect(await page.title()).toBe('Change allocations - Workplace Pensions');
    await new AccessibilityFunctions(page).injectAxe();
  });

  test('User with regular contributions invested in LSP → switch and redirect into fund @CoreTest', async ({
    page,
  }) => {
    await authenticationPage.navigate('product/investments', 'regularContributionsLSP');
    await investmentsPage.browseFundsBtn.click();
    await investmentsPage.landGDistributionTrustLink.click();
    await fundDetailsPage.addFundButton.click();
    await fundDetailsPage.assertElementVisible(fundDetailsPage.addFundModal);
    await fundDetailsPage.browseMoreFundsModalButton.click();

    await availableFundsPage.assertElementVisible(
      availableFundsPage.availableFundsIntroduction,
    );

    await availableFundsPage.allocationsButton.click();

    await fundDetailsPage.assertElementVisible(
      fundDetailsPage.changeAllocationsIntroduction,
    );

    await fundDetailsPage.selectChangeAllocationsButton.click();

    await myiContributionPage.clearTable(
      myiContributionPage.regularContributionsTableRows,
    );

    await myiContributionPage.regularContributionsTableRows.nth(4).fill('100');
    await myiContributionPage.confirmButton.click();

    await myiContributionPage.assertElementVisible(
      myiContributionPage.updateFutureRegularContributionsMessage,
    );

    await myiContributionPage.assertElementVisible(
      myiContributionPage.myiFuturePageHeading,
    );

    await myiContributionPage.copyFromCurrentInvestmentsButton.click();
    await myiFutureContributionsPage.confirmButton.click();
    await riskAndRewardsPage.confirmButton.click();
    await yourSummaryPage.assertElementVisible(yourSummaryPage.pageHeading);
    await yourSummaryPage.importantInformationCheckbox.click();
    await yourSummaryPage.confirmButton.click();

    await myiContributionPage.assertElementVisible(
      myiContributionPage.confirmationPageHeading,
    );
  });

  test('User with regular contributions invested in fund → switch and redirect into LSP @CoreTest', async ({
    page,
  }) => {
    await authenticationPage.navigate(
      'product/investments',
      'regularContributionsOnlyMYI',
    );

    await investmentsPage.browseFundsBtn.click();
    await investmentsPage.landGEuropeanIndexTrustLink.click();
    await fundDetailsPage.addFundButton.click();
    await fundDetailsPage.assertElementVisible(fundDetailsPage.addFundModal);
    await fundDetailsPage.goToAllocationsModalButton.click();

    await fundDetailsPage.assertElementVisible(
      fundDetailsPage.changeAllocationsIntroduction,
    );

    await fundDetailsPage.selectChangeAllocationsButton.click();

    await myiContributionPage.clearTable(
      myiContributionPage.regularContributionsTableRows,
    );

    await myiContributionPage.regularContributionsTableRows.nth(2).fill('100');
    await myiContributionPage.confirmButton.click();
    await myiFutureContributionsPage.skipThisStepButton.click();
    await riskAndRewardsPage.confirmButton.click();
    await yourSummaryPage.assertElementVisible(yourSummaryPage.pageHeading);
    await yourSummaryPage.importantInformationCheckbox.click();
    await yourSummaryPage.confirmButton.click();

    await myiContributionPage.assertElementVisible(
      myiContributionPage.confirmationPageHeading,
    );
  });

  test('User with regular contributions invested in funds → add LSP → go back and add a new fund @CoreTest', async ({
    page,
  }) => {
    await authenticationPage.navigate(
      'product/investments',
      'regularContributionsInvestedInFundsMYI',
    );

    await investmentsPage.browseFundsBtn.click();
    await investmentsPage.landGEuropeanTrustLink.click();
    await fundDetailsPage.addFundButton.click();
    await fundDetailsPage.assertElementVisible(fundDetailsPage.addFundModal);
    await fundDetailsPage.goToAllocationsModalButton.click();
    await fundDetailsPage.selectChangeAllocationsButton.click();

    await myiContributionPage.clearTable(
      myiContributionPage.regularContributionsTableRows,
    );

    await myiContributionPage.regularContributionsTableRows.nth(2).fill('100');
    await myiContributionPage.confirmButton.click();
    await myiFutureContributionsPage.skipThisStepButton.click();
    await myiFutureContributionsPage.manageYourInvestmentsBreadcrumb.click();
    await investmentsPage.landGDistributionTrustLink.click();
    await fundDetailsPage.addFundButton.click();
    await fundDetailsPage.assertElementVisible(fundDetailsPage.addFundModal);
    await fundDetailsPage.goToAllocationsModalButton.click();
    await myiFutureContributionsPage.backButton.click();
    await fundDetailsPage.backButton.click();
    await availableFundsPage.backButton.click();
    await riskAndRewardsPage.backButton.click();
    await myiFutureContributionsPage.backButton.click();

    expect(await page.title()).toBe(
      'Current investments allocation - Workplace Pensions',
    );

    await myiContributionPage.clearTable(
      myiContributionPage.regularContributionsTableRows,
    );

    await myiContributionPage.regularContributionsTableRows.nth(3).fill('100');
    await myiContributionPage.confirmButton.click();
    await myiFutureContributionsPage.copyFromCurrentInvestmentsButton.click();
    await myiContributionPage.confirmButton.click();
    await riskAndRewardsPage.confirmButton.click();
    await yourSummaryPage.assertElementVisible(yourSummaryPage.pageHeading);
    await yourSummaryPage.importantInformationCheckbox.click();
    await yourSummaryPage.confirmButton.click();

    await myiContributionPage.assertElementVisible(
      myiContributionPage.confirmationPageHeading,
    );
  });
});
