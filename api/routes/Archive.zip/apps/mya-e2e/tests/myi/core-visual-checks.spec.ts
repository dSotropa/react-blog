import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AuthenticationPage } from '../../models/authentication';
import { HomePageMya } from '../../pageobjects/homepage-mya.po';
import { Investments } from '../../pageobjects/investments.po';
import { FundDetails } from '../../pageobjects/fund-details.po';
import { MyiContributionPage } from '../../pageobjects/myi-my-existing-holding-page.po';
import { RiskAndRewardPage } from '../../pageobjects/risk-and-rewards-page.po';
import { YourSummaryPage } from '../../pageobjects/your-summary-page.po';
import { AvailableFundsPage } from '../../pageobjects/available-funds-page.po';

test.describe.parallel('Core Functionality For MYI', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let homePageMya: HomePageMya;
  let investmentsPage: Investments;
  let fundDetailsPage: FundDetails;
  let myiContributionPage: MyiContributionPage;
  let riskAndRewardsPage: RiskAndRewardPage;
  let yourSummaryPage: YourSummaryPage;
  let availableFundsPage: AvailableFundsPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    homePageMya = new HomePageMya(page);
    investmentsPage = new Investments(page);
    fundDetailsPage = new FundDetails(page);
    myiContributionPage = new MyiContributionPage(page);
    riskAndRewardsPage = new RiskAndRewardPage(page);
    yourSummaryPage = new YourSummaryPage(page);
    availableFundsPage = new AvailableFundsPage(page);
  });

  test.fixme('Available funds journey @VisualChecks', async ({ page }) => {
    await authenticationPage.navigate('product', 'wholePot');
    const pageName1 = 'Available funds page';
    const pageName2 = 'Change allocations page';
    const pageName3 = 'Current investments allocation - view by contribution page';
    const pageName4 = 'Current investments allocation - view whole pot';
    const pageName5 = 'Future regular contributions allocation page - LSP message';
    const pageName6 = 'Risk and reward page';
    const pageName7 = 'All contributions summary page';
    const pageName8 = 'Future regular contributions allocation page';
    const pageName9 = 'Separate contributions summary page';
    const pageName10 = 'Confirmation page';

    await homePageMya.investmentsTab.click();
    await investmentsPage.browseFundsBtn.click();
    await visualFunctions.eyesCheck(pageName1, page);

    await investmentsPage.fixedInterestTrustLink.click();
    await fundDetailsPage.addFundButton.click();
    await fundDetailsPage.assertElementVisible(fundDetailsPage.addFundModal);
    await fundDetailsPage.goToAllocationsModalButton.click();

    await fundDetailsPage.assertElementVisible(
      fundDetailsPage.changeAllocationsIntroduction,
    );

    await visualFunctions.eyesCheck(pageName2, page);

    await fundDetailsPage.selectChangeAllocationsButton.click();
    await myiContributionPage.radioViewByContributionTypeInput.click();
    await myiContributionPage.assertElementVisible(myiContributionPage.pageHeading);
    await visualFunctions.eyesCheck(pageName3, page);

    await myiContributionPage.radioViewWholePotLabel.click();

    await myiContributionPage.assertElementVisible(
      myiContributionPage.allContributionsTable,
    );

    await visualFunctions.eyesCheck(pageName4, page);

    await myiContributionPage.clearTable(myiContributionPage.allContributionsTableTrows);
    await myiContributionPage.allContributionsTableTrows.nth(3).fill('100');
    await myiContributionPage.confirmButton.click();

    await myiContributionPage.assertElementVisible(
      myiContributionPage.myiFuturePageHeading,
    );

    await visualFunctions.eyesCheck(pageName5, page);

    await myiContributionPage.skipThisStepButton.click();
    await riskAndRewardsPage.assertElementVisible(riskAndRewardsPage.pageHeading);
    await visualFunctions.eyesCheck(pageName6, page);

    await riskAndRewardsPage.confirmButton.click();
    await yourSummaryPage.assertElementVisible(yourSummaryPage.pageHeading);
    await visualFunctions.eyesCheck(pageName7, page);

    await riskAndRewardsPage.manageYourInvestmentsBreadcrumb.click();
    await investmentsPage.landGEuropeanIndexTrustLink.click();
    await fundDetailsPage.addFundButton.click();
    await fundDetailsPage.assertElementVisible(fundDetailsPage.addFundModal);
    await fundDetailsPage.goToAllocationsModalButton.click();
    await myiContributionPage.backButton.click();
    await fundDetailsPage.backButton.click();
    await availableFundsPage.backButton.click();
    await yourSummaryPage.editAllocationsButton.click();
    await myiContributionPage.radioViewByContributionTypeInput.click();

    await myiContributionPage.clearTable(
      myiContributionPage.regularContributionsTableRows,
    );

    await myiContributionPage.regularContributionsTableRows.nth(4).fill('100');
    await myiContributionPage.confirmButton.click();

    await myiContributionPage.assertElementVisible(
      myiContributionPage.myiFuturePageHeading,
    );

    await myiContributionPage.copyFromCurrentInvestmentsButton.click();
    await myiContributionPage.assertElementNotVisible(myiContributionPage.successMessage);
    await visualFunctions.eyesCheck(pageName8, page);

    await myiContributionPage.confirmButton.click();
    await riskAndRewardsPage.confirmButton.click();
    await yourSummaryPage.assertElementVisible(yourSummaryPage.pageHeading);
    await visualFunctions.eyesCheck(pageName9, page);

    await yourSummaryPage.importantInformationCheckbox.click();
    await yourSummaryPage.confirmButton.click();

    await myiContributionPage.assertElementVisible(
      myiContributionPage.confirmationPageHeading,
    );

    await visualFunctions.eyesCheck(pageName10, page);
  });

  afterAllHook(test);
});
