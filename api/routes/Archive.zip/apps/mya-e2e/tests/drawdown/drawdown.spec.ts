import { expect, test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AuthenticationPage } from '../../models/authentication';
import { FullDrawdown } from '../../pageobjects/full-drawdown.po';

test.describe.parallel('Core FullDrawdown', () => {
  let basePage: BasePage;
  let fullDrawDownPage: FullDrawdown;
  let authenticationPage: AuthenticationPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    fullDrawDownPage = new FullDrawdown(page);
  });

  test('Compare the drawdown product summary page to its baseline @VisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate('product', 'fullDrawdown');
    const pageName = 'Full drawdown pension summary';

    await visualFunctions.eyesCheck(pageName, page);
  });

  test('Manage your investments card present for IBM users @CoreTest', async () => {
    await authenticationPage.navigate('product', 'fullDrawdownIbm');
    await fullDrawDownPage.assertElementVisible(fullDrawDownPage.manageYourInvestment);

    await expect(fullDrawDownPage.manageYourInvestment).toContainText(
      fullDrawDownPage.manageYourInvestmentHeading,
    );

    await expect(fullDrawDownPage.manageYourInvestmentLink).toHaveCount(1);
  });

  afterAllHook(test);
});
