import { expect, test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AuthenticationPage } from '../../models/authentication';
import { ProductPage } from '../../pageobjects/product-page.po';
import { RetirementAgePage } from '../../pageobjects/retirement-age.po';
import { CommonPage } from '../../pageobjects/common.po';

test.describe.parallel('Accessing my personal information', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let productPage: ProductPage;
  let retirementAgePage: RetirementAgePage;
  let commonPage: CommonPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    productPage = new ProductPage(page);
    retirementAgePage = new RetirementAgePage(page);
    commonPage = new CommonPage(page);
  });

  test('Perform smoke test of update retirement age @CoreTest', async ({ page }) => {
    await authenticationPage.navigate('product/retirement-age');
    await retirementAgePage.updateAge.click();

    await retirementAgePage.assertElementVisible(
      retirementAgePage.noSameAgeNotificationMessage,
    );

    await retirementAgePage.enterRetirementAgeValue('77');
    await retirementAgePage.updateAge.click();
    await retirementAgePage.assertElementVisible(retirementAgePage.confirmationMessage);
    await commonPage.assertElementVisible(commonPage.backToSummaryBtn);
    await retirementAgePage.assertElementNotVisible(retirementAgePage.featureCard);

    await authenticationPage.navigate('logged-out');

    await expect(authenticationPage.logoutMessage).toContainText(
      authenticationPage.logoutConfirmText,
    );

    await authenticationPage.assertElementVisible(authenticationPage.logBackInButton);
  });

  test('Retirement age journey @VisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product/retirement-age');
    const pageName1 = 'Retirement age page';
    const pageName2 = 'Retirement age confirmation page';

    await visualFunctions.eyesCheck(pageName1, page);

    // update retirement age with a valid value
    await retirementAgePage.updateAge.click();

    await retirementAgePage.assertElementVisible(
      retirementAgePage.noSameAgeNotificationMessage,
    );

    await retirementAgePage.enterRetirementAgeValue('77');
    await retirementAgePage.updateAge.click();
    await retirementAgePage.assertElementVisible(retirementAgePage.confirmationMessage);
    await visualFunctions.eyesCheck(pageName2, page);
  });

  afterAllHook(test);
});
