import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AuthenticationPage } from '../../models/authentication';
import { CommonPage } from '../../pageobjects/common.po';

test.describe.parallel('Branding Visual Checks D to H', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let commonPage: CommonPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    commonPage = new CommonPage(page);
  });

  test('Debenhams branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'debenhamsTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Debenhams stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Emtelle branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'emtelleTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Emtelle stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Greggs branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'greggsTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Greggs stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('GMG branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'gmgTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'GMG stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  afterAllHook(test);
});
