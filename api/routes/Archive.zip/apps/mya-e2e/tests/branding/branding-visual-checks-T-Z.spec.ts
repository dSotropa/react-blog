import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AuthenticationPage } from '../../models/authentication';
import { CommonPage } from '../../pageobjects/common.po';

test.describe.parallel('Branding Visual Checks T to Z', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let commonPage: CommonPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    commonPage = new CommonPage(page);
  });

  test('Tesco branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'tescoTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Tesco stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Weatherbys branded stylesheet is added @BrandingVisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate('product', 'weatherbysTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Weatherbys stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  afterAllHook(test);
});
