import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AuthenticationPage } from '../../models/authentication';
import { CommonPage } from '../../pageobjects/common.po';

test.describe.parallel('Branding Visual Checks I to M', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let commonPage: CommonPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    commonPage = new CommonPage(page);
  });

  test('IBM branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'ibmGroupTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'IBM stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('IBM M Plan branded stylesheet is added @BrandingVisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate('product', 'ibmMPlanTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'IBM M Plan stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('IPL branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'iplTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'IPL stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Kingfisher branded stylesheet is added @BrandingVisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate('product', 'kingfisherTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Kingfisher stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('M Group branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'mGroupTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'M-Group stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('M&S AVC branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'marksAndSpencerAVCTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Marks-and-spencer-avc stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('M&S branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'marksAndSpencerTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Marks-and-spencer Bank';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  afterAllHook(test);
});
