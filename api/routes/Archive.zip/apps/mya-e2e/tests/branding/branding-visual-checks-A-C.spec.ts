import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AuthenticationPage } from '../../models/authentication';
import { CommonPage } from '../../pageobjects/common.po';

test.describe.parallel('Branding Visual Checks A to C', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let commonPage: CommonPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    commonPage = new CommonPage(page);
  });

  test('Accenture branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'accentureMainCategory');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Accenture stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('AG Barr branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'agBarrTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'AG-Barr stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Amazon branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'amazonTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Amazon stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Arcadia branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'arcadiaTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Arcadia stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Asda branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'asdaTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Asda stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Barclays branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'barclaysTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Barclays stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Barclays - drawdown eligible branded stylesheet is added @BrandingVisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate(
      'product/retirement-options',
      'decumulationBarclaysTheme',
    );

    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Barclays - drawdown eligible stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Co-op Bank branded stylesheet is added @BrandingVisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate('product', 'coOpBankTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Co-op Bank';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Co-op Bank AVC branded stylesheet is added @BrandingVisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate('product', 'coOpBankAVCTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Co-op-bank-avc stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Co-op Group branded stylesheet is added @BrandingVisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate('product', 'coOpGroupTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Co-op-group stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Companion Care branded stylesheet is added @BrandingVisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate('product', 'companionCareTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Companion-care stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Colliers branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'colliersTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Colliers stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  afterAllHook(test);
});
