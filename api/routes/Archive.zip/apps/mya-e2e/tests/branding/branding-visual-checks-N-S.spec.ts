import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AuthenticationPage } from '../../models/authentication';
import { CommonPage } from '../../pageobjects/common.po';

test.describe.parallel('Branding Visual Checks N to S', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let commonPage: CommonPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    commonPage = new CommonPage(page);
  });

  test('National Grid branded stylesheet is added @BrandingVisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate('product', 'nationalGridTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'National Grid stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Natwest branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'natwestTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Natwest stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Norcros branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'norcrosTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Norcros stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('NEXT branded stylesheet is added @BrandingVisualCheck', async ({ page }) => {
    await authenticationPage.navigate('product', 'nextTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'NEXT Bank';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Pets at Home branded stylesheet is added @BrandingVisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate('product', 'petsAtHomeTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'Pets-at-home stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('SAUL Start branded stylesheet is added @BrandingVisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate('product', 'saulStartTheme');
    await commonPage.assertElementVisible(commonPage.lgCardTitle);
    const pageName = 'SAUL Start stylesheet';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  afterAllHook(test);
});
