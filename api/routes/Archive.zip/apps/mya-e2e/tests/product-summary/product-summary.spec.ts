import { expect, test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AuthenticationPage } from '../../models/authentication';
import { HomePageMya } from '../../pageobjects/homepage-mya.po';
import { Investments } from '../../pageobjects/investments.po';
import { Documents } from '../../pageobjects/documents.po';

test.describe.parallel('Core pension plan', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let homePageMya: HomePageMya;
  let investmentsPage: Investments;
  let documentsPage: Documents;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    homePageMya = new HomePageMya(page);
    investmentsPage = new Investments(page);
    documentsPage = new Documents(page);
  });

  test('Smoke test homepage with nom ben, transfer in, pension video permissions @CoreTest', async () => {
    await authenticationPage.navigate();
    await homePageMya.assertElementVisible(homePageMya.pensionAccountNumber);
    await homePageMya.assertElementVisible(homePageMya.transferInLink);
    await homePageMya.assertElementVisible(homePageMya.nomBenLink);
    await homePageMya.assertElementVisible(homePageMya.pensionVideoLink);

    await expect(homePageMya.pensionAccountNumber).toContainText(
      homePageMya.pensionAccountText,
    );

    await expect(homePageMya.transferInLink).toBeVisible();
    await expect(homePageMya.nomBenLink).toBeVisible();
    await expect(homePageMya.pensionVideoLink).toBeVisible();
  });

  test('Compare the product summary page to its baseline with feature card @VisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate();
    const pageName = 'Product summary page with feature card';

    await homePageMya.assertElementVisible(homePageMya.pensionAccountNumber);
    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Compare the product summary page to its baseline no feature card @VisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate('product', 'decumulationNoPrizeDraw');
    const pageName = 'Product summary page no feature card';

    await homePageMya.assertElementVisible(homePageMya.pensionAccountNumber);
    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('No permission for transfer in @CoreTest', async () => {
    await authenticationPage.navigate('product', 'cannotTransferIn');
    await homePageMya.assertElementNotVisible(homePageMya.transferInLink);

    await expect(homePageMya.transferInLink).toBeHidden();
  });

  test('No permission for nominate beneficiaries @CoreTest', async () => {
    await authenticationPage.navigate('product', 'cannotNominateBeneficiaries');
    await homePageMya.assertElementNotVisible(homePageMya.nomBenLink);

    await expect(homePageMya.nomBenLink).toBeHidden();
  });

  test('No permission for pension video @CoreTest', async () => {
    await authenticationPage.navigate('product', 'noPensionVideo');
    await homePageMya.assertElementNotVisible(homePageMya.pensionVideoLink);

    await expect(homePageMya.pensionVideoLink).toBeHidden();
  });

  afterAllHook(test);
});
