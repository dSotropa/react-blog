import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AuthenticationPage } from '../../models/authentication';

test.describe.parallel('Accessing my personal information', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
  });

  test('Video Statement @VisualCheck', async ({ page }) => {
    // navigate directly to video statement page
    await authenticationPage.navigate(
      'product/video-statement',
      'decumulationWppWithMATPack',
    );

    const pageName = 'Video statement page';

    await visualFunctions.eyesCheck(pageName, page);
  });

  afterAllHook(test);
});
