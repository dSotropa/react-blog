import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AuthenticationPage } from '../../models/authentication';
import { HomePageMya } from '../../pageobjects/homepage-mya.po';
import { Investments } from '../../pageobjects/investments.po';
import { Documents } from '../../pageobjects/documents.po';

test.describe.parallel('Core Mastertrust', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let homePageMya: HomePageMya;
  let investmentsPage: Investments;
  let documentsPage: Documents;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    homePageMya = new HomePageMya(page);
    investmentsPage = new Investments(page);
    documentsPage = new Documents(page);
  });

  test('Perform smoke test of investments page @CoreTest', async () => {
    await authenticationPage.navigate();

    await homePageMya.investmentsTab.click();
    await investmentsPage.assertElementVisible(investmentsPage.browseFundsBtn);
    await investmentsPage.assertElementVisible(investmentsPage.fundCentreLink);
    await investmentsPage.assertElementVisible(investmentsPage.retirementPlannerLink);
  });

  test('Perform smoke test of investments page for Master Trust @CoreTest', async () => {
    await authenticationPage.navigate('product', 'decumulationMasterTrustWithMATPack');

    await homePageMya.investmentsTab.click();
    await investmentsPage.assertElementVisible(investmentsPage.browseFundsBtn);
    await investmentsPage.assertElementVisible(investmentsPage.masterTrustLink);
    await investmentsPage.assertTextExists('The Legal & General Mastertrust');
  });

  test('Compare the investments page to its baseline with feature card @VisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate();
    const pageName = 'Investments page with feature card';

    await homePageMya.investmentsTab.click();
    await investmentsPage.assertElementVisible(investmentsPage.browseFundsBtn);
    await investmentsPage.assertElementVisible(investmentsPage.fundCentreLink);
    await investmentsPage.assertElementVisible(investmentsPage.retirementPlannerLink);
    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Compare the investments page to its baseline no feature card @VisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate('product', 'decumulationNoPrizeDraw');
    const pageName = 'Investments page no feature card';

    await homePageMya.investmentsTab.click();
    await investmentsPage.assertElementVisible(investmentsPage.browseFundsBtn);
    await investmentsPage.assertElementVisible(investmentsPage.fundCentreLink);
    await investmentsPage.assertElementVisible(investmentsPage.retirementPlannerLink);
    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  afterAllHook(test);
});
