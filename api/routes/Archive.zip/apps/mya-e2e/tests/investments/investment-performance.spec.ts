import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AuthenticationPage } from '../../models/authentication';
import { HomePageMya } from '../../pageobjects/homepage-mya.po';
import { Investments } from '../../pageobjects/investments.po';
import { InvestmentPerformance } from '../../pageobjects/investment-performance.po';

test.describe.parallel('Core InvestmentPerformance', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let homePageMya: HomePageMya;
  let investmentsPage: Investments;
  let investmentPerformancePage: InvestmentPerformance;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    homePageMya = new HomePageMya(page);
    investmentsPage = new Investments(page);
    investmentPerformancePage = new InvestmentPerformance(page);
  });

  test('Compare the investment performance page to its baseline @VisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate();
    const pageName = 'Investment performance page';

    await homePageMya.investmentsTab.click();
    await investmentsPage.investmentPerformanceButton.click();

    await investmentPerformancePage.assertElementVisible(
      investmentPerformancePage.fundPerformanceTable,
    );

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  afterAllHook(test);
});
