import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AuthenticationPage } from '../../models/authentication';
import { HomePageMya } from '../../pageobjects/homepage-mya.po';
import { Investments } from '../../pageobjects/investments.po';
import { FundDetails } from '../../pageobjects/fund-details.po';

test.describe.parallel('Core Functionality with Visual Checks One', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let homePageMya: HomePageMya;
  let investmentsPage: Investments;
  let fundDetailsPage: FundDetails;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    homePageMya = new HomePageMya(page);
    investmentsPage = new Investments(page);
    fundDetailsPage = new FundDetails(page);
  });

  test('Compare the LSP fund details page to its baseline @VisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate();
    const pageName1 = 'LSP fund details page';
    const pageName2 = 'LSP timeline table';

    await homePageMya.investmentsTab.click();
    await investmentsPage.assertElementVisible(investmentsPage.fundCentreLink);
    await investmentsPage.viewProfileLink.click();
    await fundDetailsPage.assertElementVisible(fundDetailsPage.profileFactsheetLink);
    await visualFunctions.eyesCheck(pageName1, page, { layoutBreakpoints: true });

    await fundDetailsPage.lspTimelineSwitch.click();
    await fundDetailsPage.assertElementVisible(fundDetailsPage.fundPerformanceTable);
    await visualFunctions.eyesCheck(pageName2, page, { layoutBreakpoints: true });
  });

  test('Compare the fund details page to its baseline @VisualCheck', async ({ page }) => {
    await authenticationPage.navigate();
    const pageName1 = 'Fund details page';
    const pageName2 = 'Fund performance table';

    await homePageMya.investmentsTab.click();
    await investmentsPage.viewFundLink.click();
    await fundDetailsPage.assertElementVisible(fundDetailsPage.fundPerformanceChart);
    await visualFunctions.eyesCheck(pageName1, page, { layoutBreakpoints: true });

    await fundDetailsPage.fundPerformanceSwitch.click();
    await fundDetailsPage.assertElementVisible(fundDetailsPage.fundPerformanceTable);
    await visualFunctions.eyesCheck(pageName2, page, { layoutBreakpoints: true });
  });

  afterAllHook(test);
});
