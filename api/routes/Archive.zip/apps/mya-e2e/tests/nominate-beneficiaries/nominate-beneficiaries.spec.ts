import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AuthenticationPage } from '../../models/authentication';
import { Beneficiaries } from '../../pageobjects/beneficiaries.po';

test.describe.parallel('Core Functionality', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let beneficiariesPage: Beneficiaries;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    beneficiariesPage = new Beneficiaries(page);
  });

  // should be adjusted after the journey is complete and the confirmation page is ready after MWS-619 development
  test('Perform smoke test of nominate beneficiaries @CoreTest', async () => {
    await authenticationPage.navigateForScenario({
      path: 'product/beneficiaries/name-your-beneficiaries',
      queryParams: [ 'setRequestStatus=nomBenEmptyList' ],
    });

    // add 2 beneficiaries
    await beneficiariesPage.completeBeneficiariesForm(2);
    await beneficiariesPage.beneficiariesContinueBtn.click();
  });

  // it will need to be adjusted after the journey development is complete and the confirmation page is ready after MWS-619 development
  test('Nominate beneficiaries journey @VisualCheck @CoreTest', async ({ page }) => {
    const pageName1 = 'Beneficiaries page';

    await authenticationPage.navigate('product/beneficiaries/name-your-beneficiaries');
    await beneficiariesPage.assertElementVisible(beneficiariesPage.beneficiariesAddBtn);
    await beneficiariesPage.beneficiariesAddBtn.click();

    await visualFunctions.eyesCheck(pageName1, page);
  });

  afterAllHook(test);
});
