import { expect, test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { ErrorPage } from '../../pageobjects/error-page.po';
import { AuthenticationPage } from '../../models/authentication';
import { HomePageMya } from '../../pageobjects/homepage-mya.po';
import { BasePage } from '../../models/basepage';

test.describe.parallel('Accessing error page', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let homePageMya: HomePageMya;
  let errorPage: ErrorPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    errorPage = new ErrorPage(page);
    homePageMya = new HomePageMya(page);
  });

  test('Compare the error page to its baseline @VisualCheck', async ({ page }) => {
    await errorPage.navigate();
    const pageName = 'MYA error page';

    await visualFunctions.eyesCheck(pageName, page);
  });

  test('Perform smoke test of error page - Core Functionality @CoreTest', async () => {
    await errorPage.navigate();

    await errorPage.assertElementVisible(errorPage.cardTitle);
    await errorPage.assertElementVisible(errorPage.tryAgainButton);
    await errorPage.assertElementVisible(errorPage.contactUsLink);
  });

  test('Retry to go back to the main page after one of the core API calls have failed @CoreTest', async () => {
    // should create an object for keeping track of all the custom query params by feature
    await authenticationPage.navigateForScenario({
      queryParams: [ 'setRequestStatus=appUrlsDataFetchingError' ],
    });

    await errorPage.assertElementVisible(errorPage.cardTitle);
    await errorPage.assertElementVisible(errorPage.tryAgainButton);
    await errorPage.assertElementVisible(errorPage.contactUsLink);

    await errorPage.tryAgainButton.click();

    await homePageMya.assertElementVisible(homePageMya.pensionAccountNumber);

    await expect(homePageMya.pensionAccountNumber).toContainText(
      homePageMya.pensionAccountText,
    );
  });

  afterAllHook(test);
});
