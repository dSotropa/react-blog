import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AuthenticationPage } from '../../models/authentication';
import { HomePageMya } from '../../pageobjects/homepage-mya.po';
import { Documents } from '../../pageobjects/documents.po';
import { Beneficiaries } from '../../pageobjects/beneficiaries.po';

test.describe.parallel('Accessing my personal information', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let homePageMya: HomePageMya;
  let documentsPage: Documents;
  let beneficiariesPage: Beneficiaries;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    homePageMya = new HomePageMya(page);
    documentsPage = new Documents(page);
    beneficiariesPage = new Beneficiaries(page);
  });

  test('Compare the logged out page to its baseline @VisualCheck', async ({ page }) => {
    // navigate directly to logout page
    await authenticationPage.navigate('logged-out');
    const pageName = 'MYA Logout Page';

    await visualFunctions.eyesCheck(pageName, page);
  });

  afterAllHook(test);
});
