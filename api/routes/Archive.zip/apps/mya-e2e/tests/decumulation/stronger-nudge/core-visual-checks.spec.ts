import test from '@playwright/test';
import { expect } from '@playwright/test';
import { VisualFunctions } from '@utility-e2e';

import { AuthenticationPage } from '../../../models/authentication';
import { BasePage } from '../../../models/basepage';
import { RetirementOptionsPage } from '../../../pageobjects/retirement-options-page.po';

test.describe.parallel('Core Functionality with Visual Checks For Stronger Nudge', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let visualFunctions: VisualFunctions;
  let retirementOptionsPage: RetirementOptionsPage;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    retirementOptionsPage = new RetirementOptionsPage(page);
  });

  test('Lump sum journey - stronger nudge - user wants to book a free appointment @VisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate(
      'product/retirement-options',
      'decumulationWppWithMATPack',
    );

    await retirementOptionsPage.lumpsumplink.click();
    await retirementOptionsPage.continueJourney.click();
    await retirementOptionsPage.allYourPensionPot.click();
    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Things to consider - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Consider Pension Wise guidance - lump sum journey - Workplace Pensions',
    );

    const pageName1 = 'Consider Pension Wise guidance - lump sum journey';

    await visualFunctions.eyesCheck(pageName1, page);
    await retirementOptionsPage.pensionWiseYes.click();
    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Book with Pension Wise - lump sum journey - Workplace Pensions',
    );

    const pageName2 = 'Book with Pension Wise - lump sum journey';

    await visualFunctions.eyesCheck(pageName2, page);
  });

  test('Lump sum journey - stronger nudge - user does not want to book a free appointment @VisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate(
      'product/retirement-options',
      'decumulationWppWithMATPack',
    );

    await retirementOptionsPage.lumpsumplink.click();
    await retirementOptionsPage.continueJourney.click();
    await retirementOptionsPage.allYourPensionPot.click();
    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Things to consider - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.continueJourney.click();
    const pageName1 = 'Consider Pension Wise guidance - lump sum journey';

    await visualFunctions.eyesCheck(pageName1, page);
    await retirementOptionsPage.pensionWiseNo.click();
    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Consider independent financial advice - lump sum journey - Workplace Pensions',
    );

    const pageName2 = 'financial adviser page';

    await visualFunctions.eyesCheck(pageName2, page);
    await retirementOptionsPage.pensionAdviserFormYes.click();
    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Find an independent financial adviser - lump sum journey - Workplace Pensions',
    );

    const pageName3 = 'independent financial adviser page';

    await visualFunctions.eyesCheck(pageName3, page);
  });

  test('Lump sum journey - stronger nudge - user had guidance or advice @VisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate(
      'product/retirement-options',
      'decumulationWppWithMATPack',
    );

    await retirementOptionsPage.lumpsumplink.click();
    await retirementOptionsPage.continueJourney.click();
    await retirementOptionsPage.allYourPensionPot.click();
    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Things to consider - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Consider Pension Wise guidance - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.pensionWiseGuidanceOption.click();
    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Consider further guidance - lump sum journey - Workplace Pensions',
    );

    const pageName1 = 'consider further guidance or advice page';

    await visualFunctions.eyesCheck(pageName1, page);
    await retirementOptionsPage.appointmentLink.click();

    expect(await page.title()).toBe(
      'Book with Pension Wise - lump sum journey - Workplace Pensions',
    );

    await page.goBack();

    expect(await page.title()).toBe(
      'Consider further guidance - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.findFinancialAdviserLink.click();

    expect(await page.title()).toBe(
      'Find an independent financial adviser - lump sum journey - Workplace Pensions',
    );
  });

  test('Lump sum journey - stronger nudge - user had guidance or advice from independent financial advice page @VisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate(
      'product/retirement-options',
      'decumulationWppWithMATPack',
    );

    await retirementOptionsPage.lumpsumplink.click();
    await retirementOptionsPage.continueJourney.click();
    await retirementOptionsPage.allYourPensionPot.click();
    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Things to consider - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Consider Pension Wise guidance - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.pensionWiseNo.click();
    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Consider independent financial advice - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.finacialAdviserHadGuidance.click();
    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Consider further guidance - lump sum journey - Workplace Pensions',
    );
  });

  test('Lump sum journey - Scenario: Lump sum journey - stronger nudge - partial lump sum @VisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate(
      'product/retirement-options',
      'decumulationWppWithMATPack',
    );

    await retirementOptionsPage.lumpsumplink.click();
    await retirementOptionsPage.continueJourney.click();
    await retirementOptionsPage.withdrawTextBox.fill('2000');
    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Things to consider - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Consider Pension Wise guidance - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.pensionWiseGuidanceOption.click();
    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Consider further guidance - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Lifetime allowance questions - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.backToPreviousJourneyPage.click();

    expect(await page.title()).toBe(
      'Consider further guidance - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.backToPreviousJourneyPage.click();

    expect(await page.title()).toBe(
      'Consider Pension Wise guidance - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.pensionWiseNo.click();
    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Consider independent financial advice - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.finacialAdviserHadGuidance.click();
    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Consider further guidance - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Lifetime allowance questions - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.backToPreviousJourneyPage.click();

    expect(await page.title()).toBe(
      'Consider further guidance - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.backToPreviousJourneyPage.click();

    expect(await page.title()).toBe(
      'Consider independent financial advice - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.pensionAdviserFormNo.click();
    await retirementOptionsPage.continueJourney.click();

    expect(await page.title()).toBe(
      'Lifetime allowance questions - lump sum journey - Workplace Pensions',
    );

    await retirementOptionsPage.backToPreviousJourneyPage.click();

    expect(await page.title()).toBe(
      'Consider independent financial advice - lump sum journey - Workplace Pensions',
    );
  });
});
