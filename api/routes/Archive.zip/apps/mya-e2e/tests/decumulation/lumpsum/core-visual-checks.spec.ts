import test from '@playwright/test';
import { VisualFunctions } from '@utility-e2e';

import { HomePageMya } from '../../../pageobjects/homepage-mya.po';
import { AuthenticationPage } from '../../../models/authentication';
import { BasePage } from '../../../models/basepage';

test.describe.parallel('Core Functionality with Visual Checks For Lump Sum', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let homePageMya: HomePageMya;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    homePageMya = new HomePageMya(page);
  });

  test.fixme(
    'Lump sum journey - full to partial- Part1 @VisualCheck',
    async ({ page }) => {
      await authenticationPage.navigate(
        'product/retirement-options',
        'decumulationWppWithMATPack',
      );

      await homePageMya.lumpsumplink.click();

      const pageName1 = 'lump sum important information page';

      await visualFunctions.eyesCheck(pageName1, page);
      await homePageMya.continueJourney.click();
      await homePageMya.lumpSumWithdrawCalculatorAllPotCheckbox.click();

      const pageName2 = 'lump sum withdraw calculator page';

      await visualFunctions.eyesCheck(pageName2, page);
      await homePageMya.continueJourney.click();

      const pageName3 = 'lump sum things to consider page';

      await visualFunctions.eyesCheck(pageName3, page);
      await homePageMya.continueJourney.click();

      const pageName4 = 'pension wise page';

      await visualFunctions.eyesCheck(pageName4, page);
      await homePageMya.pensionWiseGuidanceOption.click();
      await homePageMya.continueJourney.click();

      const pageName5 = 'consider further guidance or advice page';

      await visualFunctions.eyesCheck(pageName5, page);
      await homePageMya.continueJourney.click();

      const pageName6 = 'lump sum compliance questions page';

      await visualFunctions.eyesCheck(pageName6, page);
      await homePageMya.setYesOrNoToAllQuestions(homePageMya.segmentButtonYes);
      await homePageMya.continueJourney.click();

      const pageName7 = 'lump sum LTA compliance questions page';

      await visualFunctions.eyesCheck(pageName7, page);
      await homePageMya.setYesOrNoToAllQuestions(homePageMya.segmentButtonNo);
      await homePageMya.continueJourney.click();
      await homePageMya.editButton.click();

      const pageName8 = 'lump sum personal details modal';

      await visualFunctions.eyesCheck(pageName8, page);
    },
  );

  test('Lump sum journey - full to partial- Part2 @VisualCheck', async ({ page }) => {
    await authenticationPage.navigate(
      'product/retirement-options',
      'decumulationWppWithMATPack',
    );

    await homePageMya.lumpsumplink.click();

    await homePageMya.continueJourney.click();
    await homePageMya.lumpSumWithdrawCalculatorAllPotCheckbox.click();

    await homePageMya.continueJourney.click();

    await homePageMya.continueJourney.click();

    await homePageMya.pensionWiseGuidanceOption.click();
    await homePageMya.continueJourney.click();

    await homePageMya.continueJourney.click();

    await homePageMya.setYesOrNoToAllQuestions(homePageMya.segmentButtonYes);
    await homePageMya.continueJourney.click();

    await homePageMya.setYesOrNoToAllQuestions(homePageMya.segmentButtonNo);
    await homePageMya.continueJourney.click();
    await homePageMya.editButton.click();

    await homePageMya.cancelButton.click();

    const pageName1 = 'lump sum personal details page';

    await visualFunctions.eyesCheck(pageName1, page);
    await homePageMya.continueJourney.click();
    await homePageMya.fillBankDetailsForm('Test Name', '111111', '12345678');

    const pageName2 = 'lump sum bank details page';

    await visualFunctions.eyesCheck(pageName2, page);
    await homePageMya.continueJourney.click();

    const pageName3 = 'lump sum bank details confirmation page';

    await visualFunctions.eyesCheck(pageName3, page);
    await homePageMya.continueJourney.click();
    await homePageMya.illustrationCheckbox.click();

    const pageName4 = 'lump sum illustration page';

    await visualFunctions.eyesCheck(pageName4, page);
    await homePageMya.continueJourney.click();
    await homePageMya.declarationCheckbox.click();

    const pageName5 = 'lump sum declaration page';

    await visualFunctions.eyesCheck(pageName5, page);
    await homePageMya.continueJourney.click();

    const pageName6 = 'lump sum confirmation page';

    await visualFunctions.eyesCheck(pageName6, page);
    await homePageMya.backToPensionSummary.click();
    await homePageMya.retirementTab.click();

    const pageName7 = 'retirement options WIP message';

    await visualFunctions.eyesCheck(pageName7, page, { layoutBreakpoints: true });
  });
});
