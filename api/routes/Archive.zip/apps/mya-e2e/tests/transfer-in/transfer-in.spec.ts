import { expect, test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AuthenticationPage } from '../../models/authentication';
import { ProductPage } from '../../pageobjects/product-page.po';
import { TransferInPage } from '../../pageobjects/transfer-in.po';
import { CommonPage } from '../../pageobjects/common.po';

test.describe.parallel('Core Functionality', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let productPage: ProductPage;
  let transferInPage: TransferInPage;
  let commonPage: CommonPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    productPage = new ProductPage(page);
    transferInPage = new TransferInPage(page);
    commonPage = new CommonPage(page);
  });

  test('Perform smoke test of transfer in page @CoreTest', async () => {
    await authenticationPage.navigate();
    await productPage.assertElementVisible(productPage.transferInButton);
    await authenticationPage.navigate('product/transfer-in');
    await transferInPage.assertElementVisible(transferInPage.sendToMyEmailAddress);
    await transferInPage.assertElementVisible(transferInPage.sendToMyPostalAddress);
    await transferInPage.assertElementVisible(transferInPage.requestTransferInPackBtn);
    await commonPage.assertElementVisible(commonPage.backToSummaryBtn);
  });

  test('Changing preferences for transfer in pack @VisualCheck', async ({ page }) => {
    await authenticationPage.navigate();
    const pageName1 = 'Transfer in page';
    const pageName2 = 'Transfer in confirmation page';

    await productPage.assertElementVisible(productPage.transferInButton);
    await productPage.transferInButton.click();
    await visualFunctions.eyesCheck(pageName1, page);

    await transferInPage.sendToMyEmailAddress.click();
    await transferInPage.requestTransferInPackBtn.click();
    await transferInPage.assertElementVisible(transferInPage.tiConfitmationIntro);

    await expect(transferInPage.tiConfitmationIntro).toContainText(
      'Thank you for requesting a transfer in pack',
    );

    await visualFunctions.eyesCheck(pageName2, page);
  });

  afterAllHook(test);
});
