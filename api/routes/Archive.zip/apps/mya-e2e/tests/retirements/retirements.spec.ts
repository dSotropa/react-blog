import test from '@playwright/test';
import { VisualFunctions } from '@utility-e2e';

import { AuthenticationPage } from '../../models/authentication';
import { BasePage } from '../../models/basepage';

test.describe.parallel('Core Functionality with Visual Checks For Lump Sum', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
  });

  test('Compare the retirement options page to its baseline with feature card @VisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate(
      'product/retirement-options',
      'decumulationWppWithMATPack',
    );

    const pageName = 'Retirement options page with feature card';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Compare the retirement options page to its baseline no feature card @VisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate(
      'product/retirement-options',
      'decumulationNoPrizeDraw',
    );

    const pageName = 'Retirement options page no feature card';

    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });
});
