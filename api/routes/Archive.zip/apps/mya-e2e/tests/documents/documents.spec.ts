import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AuthenticationPage } from '../../models/authentication';
import { HomePageMya } from '../../pageobjects/homepage-mya.po';
import { Documents } from '../../pageobjects/documents.po';

test.describe.parallel('Accessing my personal information', () => {
  let basePage: BasePage;
  let authenticationPage: AuthenticationPage;
  let homePageMya: HomePageMya;
  let documentsPage: Documents;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    authenticationPage = basePage.authenticationPage;
    homePageMya = new HomePageMya(page);
    documentsPage = new Documents(page);
  });

  test('Compare the documents page to its baseline with feature card @VisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate();
    const pageName = 'Documents page with feature card';

    await homePageMya.documentsTab.click();
    await documentsPage.assertElementVisible(documentsPage.documentsTabPanel);
    await documentsPage.assertElementVisible(documentsPage.documentsTable);
    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Compare the documents page to its baseline no feature card @VisualCheck', async ({
    page,
  }) => {
    await authenticationPage.navigate('product', 'decumulationNoPrizeDraw');
    const pageName = 'Documents page no feature card';

    await homePageMya.documentsTab.click();
    await documentsPage.assertElementVisible(documentsPage.documentsTabPanel);
    await documentsPage.assertElementVisible(documentsPage.documentsTable);
    await visualFunctions.eyesCheck(pageName, page, { layoutBreakpoints: true });
  });

  test('Perform smoke test of documents @CoreTest', async () => {
    await authenticationPage.navigate();

    await homePageMya.documentsTab.click();
    await documentsPage.assertElementVisible(documentsPage.documentsTabPanel);
    await documentsPage.assertElementVisible(documentsPage.documentsTable);
  });

  afterAllHook(test);
});
