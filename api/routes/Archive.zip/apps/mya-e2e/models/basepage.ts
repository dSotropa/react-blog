import { Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

import { AuthenticationPage } from './authentication';

export class BasePage extends PageFunctions {
  readonly authenticationPage: AuthenticationPage;

  constructor(page: Page) {
    super(page);
    this.authenticationPage = new AuthenticationPage(page);
  }
}
