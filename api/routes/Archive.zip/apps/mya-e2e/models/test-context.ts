module.exports = {
  // global variables for sharing across steps files
  featureCardWidth: '',
  currentRetirementAge: '',
  currentRetirementDate: '',
  loggedIn: '',
  loggedOut: '',
  accountHash: '',
  graphQLDataLoaded: '',
  mockingEnabled: '',
};
