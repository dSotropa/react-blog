import { Locator, Page } from '@playwright/test';
import { MOCK_ENV, PageFunctions } from '@utility-e2e';

// eslint-disable-next-line @nrwl/nx/enforce-module-boundaries
import { testUsers } from '../../mya-mock-server/src/apollo/resolvers/test-users';

interface NavigationConfiguration {
  path?: string;
  user?: string;
  waitForPageToLoad?: boolean;
  // each param should be provided as 'key=value'
  queryParams?: Array<string>;
}

export class AuthenticationPage extends PageFunctions {
  testContext = require('../models/test-context');
  readonly page: Page;
  readonly overviewDetails: Locator;
  readonly logoutMessage: Locator;
  readonly logBackInButton: Locator;

  readonly accountDetailsOverviewRoute = '#/account-details/overview';
  readonly logoutConfirmText = ' You\'ve successfully logged out ';

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.overviewDetails = page.locator('.account-details-overview');
    this.logoutMessage = page.locator('.lg-primary-message');
    this.logBackInButton = page.locator('[id=lo-log-back-in-btn]');
  }

  setUser(user = 'singleContributionOnly'): void {
    this.testContext.accountHash = testUsers[user].accountHash;
  }

  async navigate(
    path = 'product',
    user?: string,
    waitForPageToLoad = true,
  ): Promise<void> {
    return await this.navigateToPage({ path, user, waitForPageToLoad });
  }

  // used as a way for testing specific scenario or edge case by providing custom params which are being read and processed by the mock server
  async navigateForScenario(config: NavigationConfiguration): Promise<void> {
    return await this.navigateToPage(config);
  }

  private async navigateToPage({
    path = 'product',
    user,
    waitForPageToLoad,
    queryParams,
  }: NavigationConfiguration): Promise<void> {
    await this.page.goto(MOCK_ENV);

    if (waitForPageToLoad) {
      await this.waitForPageToLoad();
    }

    this.setUser(user);

    const additionalQueryParams = queryParams
      ? `&${queryParams.join('&')}`
      : '';

    await this.page.goto(
      `${MOCK_ENV}${path}?productId=${this.testContext.accountHash}${additionalQueryParams}`,
    );

    await this.waitForPageToLoad();
  }
}
