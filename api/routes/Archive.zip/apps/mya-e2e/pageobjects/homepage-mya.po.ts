import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class HomePageMya extends PageFunctions {
  readonly page: Page;
  readonly pensionAccountNumber: Locator;
  readonly transferInLink: Locator;
  readonly nomBenLink: Locator;
  readonly pensionVideoLink: Locator;
  readonly transactionTab: Locator;
  readonly transactionTable: Locator;
  readonly investmentsTab: Locator;
  readonly documentsTab: Locator;
  readonly startDate: Locator;
  readonly endDate: Locator;
  readonly transactionFilter: Locator;
  readonly pensionAccountText = 'Pension account number 2568556031';
  readonly lumpsumplink: Locator;
  readonly continueJourney: Locator;
  readonly lumpSumWithdrawCalculatorAllPotCheckbox: Locator;
  readonly pensionWiseGuidanceOption: Locator;
  readonly segmentButtonYes: Locator;
  readonly segmentButtonNo: Locator;
  readonly editButton: Locator;
  readonly cancelButton: Locator;
  readonly accountName: Locator;
  readonly accountSortcode: Locator;
  readonly accountNumber: Locator;
  readonly illustrationCheckbox: Locator;
  readonly declarationCheckbox: Locator;
  readonly backToPensionSummary: Locator;
  readonly retirementTab: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.pensionAccountNumber = page.locator('.pension-account-number');
    this.transferInLink = page.locator('[id=transfer-in-btn]');
    this.nomBenLink = page.locator('[id=manage-beneficiaries-btn]');
    this.pensionVideoLink = page.getByRole('link', { name: 'Your pension video' });
    this.transactionTab = page.locator('[id=tab-label-transactions]');
    this.transactionTable = page.locator('[id=tab-panel-transactions]');
    this.investmentsTab = page.locator('[id=tab-label-investments]');
    this.documentsTab = page.locator('[id=tab-label-documents]');
    this.startDate = page.locator('[id=transactions-from-filter]');
    this.endDate = page.locator('[id=transactions-from-filter]');
    this.transactionFilter = page.locator('[id=transactions-type-filter]');
    this.lumpsumplink = page.locator('[data-bdd-id=ro-lump-sum-btn]');
    this.continueJourney = page.locator('[data-bdd-id=footer-btn-right]');

    this.lumpSumWithdrawCalculatorAllPotCheckbox = page.locator(
      '[data-bdd-id=wc-all-pot-checkbox]',
    );

    this.pensionWiseGuidanceOption = page.locator(
      '[data-bdd-id=pension-wise-had-guidance]',
    );

    this.segmentButtonYes = page.locator('[data-bdd-id=segment-button-yes]');
    this.segmentButtonNo = page.locator('[data-bdd-id=segment-button-no]');
    this.editButton = page.locator('[data-bdd-id=pd-modal-trigger]');
    this.cancelButton = page.locator('[data-bdd-id=pd-modal-close]');
    this.accountName = page.locator('[data-bdd-id=input-account-name]');
    this.accountNumber = page.locator('[data-bdd-id=input-account-number]');
    this.accountSortcode = page.locator('[data-bdd-id=input-account-sortcode]');
    this.illustrationCheckbox = page.locator('[data-bdd-id=illustration-checkbox]');
    this.declarationCheckbox = page.locator('[data-bdd-id=declaration-checkbox]');
    this.backToPensionSummary = page.locator('[variant=primary-dark]');
    this.retirementTab = page.locator('[id=tab-label-retirement]');
  }

  async setYesOrNoToAllQuestions(yesOrNoButton: Locator) {
    const numberOfButtons = yesOrNoButton.count();

    for (let i = 0; i < (await numberOfButtons); i++) {
      await yesOrNoButton.nth(i).click();
    }
  }

  async fillBankDetailsForm(accountname: string, sortcode: string, number: string) {
    await this.accountName.type(accountname);
    await this.accountSortcode.type(sortcode);
    await this.accountNumber.type(number);
  }
}
