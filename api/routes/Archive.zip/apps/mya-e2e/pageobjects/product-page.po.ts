import { PageFunctions } from '@utility-e2e';
import { Page, Locator } from '@playwright/test';

export class ProductPage extends PageFunctions {
  readonly page: Page;
  readonly transferInButton: Locator;
  readonly documentsTable: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.transferInButton = page.locator('[id=transfer-in-btn]');
    this.documentsTable = page.locator('[data-bdd-id=docs-table]');
  }
}
