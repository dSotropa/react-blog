import { PageFunctions } from '@utility-e2e';
import { Page, Locator } from '@playwright/test';

export class MyFutureContributionPage extends PageFunctions {
  readonly page: Page;
  readonly skipThisStepButton: Locator;
  readonly backButton: Locator;
  readonly manageYourInvestmentsBreadcrumb: Locator;
  readonly copyFromCurrentInvestmentsButton: Locator;
  readonly confirmButton: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.skipThisStepButton = page.locator('[data-bdd-id=skip-this-step]');
    this.backButton = page.locator('[data-bdd-id=back]');

    this.manageYourInvestmentsBreadcrumb = page.locator(
      '[data-bdd-id=manage-your-investments]',
    );

    this.copyFromCurrentInvestmentsButton = page.locator(
      '[data-bdd-id=copy-from-current-investments]',
    );

    this.confirmButton = page.locator('[data-bdd-id=confirm]');
  }
}
