import { PageFunctions } from '@utility-e2e';
import { Page, Locator } from '@playwright/test';

export class FundDetails extends PageFunctions {
  readonly page: Page;
  readonly profileFactsheetLink: Locator;
  readonly lspTimelineSwitch: Locator;
  readonly fundPerformanceTable: Locator;
  readonly fundPerformanceChart: Locator;
  readonly fundPerformanceSwitch: Locator;
  readonly addFundButton: Locator;
  readonly addFundModal: Locator;
  readonly goToAllocationsModalButton: Locator;
  readonly changeAllocationsIntroduction: Locator;
  readonly selectChangeAllocationsButton: Locator;
  readonly backButton: Locator;
  readonly browseMoreFundsModalButton: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.profileFactsheetLink = page.locator('[data-bdd-id=view-factsheet-lsp]');
    this.lspTimelineSwitch = page.locator('[data-bdd-id=timeline-view-switch] > label');

    this.fundPerformanceTable = page
      .locator('[data-bdd-id=performance-table-view]')
      .first();

    this.fundPerformanceChart = page.locator('[data-bdd-id=fund-chart]');

    this.fundPerformanceSwitch = page.locator(
      '[data-bdd-id=performance-view-switch] > label',
    );

    this.addFundButton = page.locator('[data-bdd-id=add-fund]');
    this.addFundModal = page.locator('[id=lg-modal-header-fund-details-modal]');
    this.goToAllocationsModalButton = page.locator('[data-bdd-id=go-to-allocations]');

    this.changeAllocationsIntroduction = page.locator(
      '[data-bdd-id=change-allocations-introduction]',
    );

    this.selectChangeAllocationsButton = page.locator(
      'button[data-bdd-id=select-change-allocations-button]',
    );

    this.backButton = page.locator('[data-bdd-id=back]');
    this.browseMoreFundsModalButton = page.locator('[data-bdd-id=go-to-available-funds]');
  }
}
