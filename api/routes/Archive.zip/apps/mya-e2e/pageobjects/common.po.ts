import { PageFunctions } from '@utility-e2e';
import { Page, Locator } from '@playwright/test';

export class CommonPage extends PageFunctions {
  readonly page: Page;
  readonly backToSummaryBtn: Locator;
  readonly lgCardTitle: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.backToSummaryBtn = page.locator('text=Back to summary');
    this.lgCardTitle = page.locator('.lg-hero-card-header__title');
  }
}
