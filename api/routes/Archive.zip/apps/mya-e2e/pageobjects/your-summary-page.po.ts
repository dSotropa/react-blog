import { PageFunctions } from '@utility-e2e';
import { Page, Locator } from '@playwright/test';

export class YourSummaryPage extends PageFunctions {
  readonly page: Page;
  readonly pageHeading: Locator;
  readonly editAllocationsButton: Locator;
  readonly importantInformationCheckbox: Locator;
  readonly confirmButton: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.pageHeading = page.locator('[data-bdd-id=review]');
    this.editAllocationsButton = page.locator('[data-bdd-id=editAllocations]');

    this.importantInformationCheckbox = page.locator(
      '[data-bdd-id=important-information-checkbox]',
    );

    this.confirmButton = page.locator('[data-bdd-id=confirm]');
  }
}
