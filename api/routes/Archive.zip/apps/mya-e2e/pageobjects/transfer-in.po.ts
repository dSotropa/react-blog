import { PageFunctions } from '@utility-e2e';
import { Page, Locator } from '@playwright/test';

export class TransferInPage extends PageFunctions {
  readonly page: Page;
  readonly sendToMyEmailAddress: Locator;
  readonly sendToMyPostalAddress: Locator;
  readonly requestTransferInPackBtn: Locator;
  readonly tiConfitmationIntro: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.sendToMyEmailAddress = page.locator('[data-bdd-id=transfer-in-email] > label');
    this.sendToMyPostalAddress = page.locator('[data-bdd-id=transfer-in-postal] > label');

    this.requestTransferInPackBtn = page.locator(
      '[data-bdd-id=ti-request-transfer-in-pack]',
    );

    this.tiConfitmationIntro = page.locator('[data-bdd-id=ti-confirmation]');
  }
}
