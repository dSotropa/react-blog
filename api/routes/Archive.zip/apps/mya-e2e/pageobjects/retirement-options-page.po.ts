import { PageFunctions } from '@utility-e2e';
import { Page, Locator } from '@playwright/test';

export class RetirementOptionsPage extends PageFunctions {
  readonly page: Page;
  readonly lumpsumplink: Locator;
  readonly continueJourney: Locator;
  readonly allYourPensionPot: Locator;
  readonly pensionWiseYes: Locator;
  readonly pensionWiseNo: Locator;
  readonly pensionAdviserFormYes: Locator;
  readonly pensionWiseGuidanceOption: Locator;
  readonly appointmentLink: Locator;
  readonly findFinancialAdviserLink: Locator;
  readonly finacialAdviserHadGuidance: Locator;
  readonly withdrawTextBox: Locator;
  readonly backToPreviousJourneyPage: Locator;
  readonly pensionAdviserFormNo: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.lumpsumplink = page.locator('[data-bdd-id=ro-lump-sum-btn]');
    this.continueJourney = page.locator('[data-bdd-id=footer-btn-right]');
    this.allYourPensionPot = page.locator('[data-bdd-id=wc-all-pot-checkbox]');
    this.pensionWiseYes = page.locator('[data-bdd-id=pension-wise-yes]');
    this.pensionWiseNo = page.locator('[data-bdd-id=pension-wise-no]');
    this.pensionAdviserFormYes = page.locator('[data-bdd-id=financial-adviser-yes]');

    this.pensionWiseGuidanceOption = page.locator(
      '[data-bdd-id=pension-wise-had-guidance]',
    );

    this.appointmentLink = page.locator('[data-bdd-id=appointment-link]');

    this.findFinancialAdviserLink = page.locator(
      '[data-bdd-id=find-financial-adviser-link]',
    );

    this.finacialAdviserHadGuidance = page.locator(
      '[data-bdd-id=financial-adviser-had-guidance]',
    );

    this.withdrawTextBox = page.locator('[data-bdd-id=wc-text-field]');
    this.backToPreviousJourneyPage = page.locator('[data-bdd-id=footer-btn-left]');
    this.pensionAdviserFormNo = page.locator('[data-bdd-id=financial-adviser-no]');
  }
}
