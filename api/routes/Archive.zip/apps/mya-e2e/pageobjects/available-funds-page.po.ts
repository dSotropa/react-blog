import { PageFunctions } from '@utility-e2e';
import { Page, Locator } from '@playwright/test';

export class AvailableFundsPage extends PageFunctions {
  readonly page: Page;
  readonly backButton: Locator;
  readonly availableFundsIntroduction: Locator;
  readonly allocationsButton: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.backButton = page.locator('[data-bdd-id=back]');

    this.availableFundsIntroduction = page.locator(
      '[data-bdd-id=available-funds-introduction]',
    );

    this.allocationsButton = page.locator('[data-bdd-id=allocations]');
  }
}
