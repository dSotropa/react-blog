import { PageFunctions } from '@utility-e2e';
import { Page, Locator } from '@playwright/test';

export class RetirementAgePage extends PageFunctions {
  readonly page: Page;
  readonly updateAge: Locator;
  readonly noSameAgeNotificationMessage: Locator;
  readonly retirementAgeYears: Locator;
  readonly confirmationMessage: Locator;
  readonly updateRetirementAge: Locator;
  readonly featureCard: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.updateAge = page.locator('[data-bdd-id=submit-new-retirement-age] > span');

    this.noSameAgeNotificationMessage = page.locator(
      '[data-bdd-id=notification-rd-no-same-age]',
    );

    this.retirementAgeYears = page.locator('[id=lg-input-0]');
    this.confirmationMessage = page.locator('[data-bdd-id=all-done]');
    this.updateRetirementAge = page.locator('[data-bdd-id=submit-new-retirement-age]');
    this.featureCard = page.locator('.feature-card');
  }

  async enterRetirementAgeValue(value: string) {
    await this.retirementAgeYears.fill(value);
    await this.page.keyboard.press('Tab');
  }
}
