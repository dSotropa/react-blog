import { PageFunctions } from '@utility-e2e';
import { Page, Locator } from '@playwright/test';

export class MyiContributionPage extends PageFunctions {
  readonly page: Page;
  readonly radioViewByContributionTypeInput: Locator;
  readonly pageHeading: Locator;
  readonly radioViewWholePotLabel: Locator;
  readonly allContributionsTable: Locator;
  readonly confirmButton: Locator;
  readonly myiFuturePageHeading: Locator;
  readonly allContributionsTableTrows: Locator;
  readonly skipThisStepButton: Locator;
  readonly backButton: Locator;
  readonly regularContributionsTableRows: Locator;
  readonly copyFromCurrentInvestmentsButton: Locator;
  readonly confirmationPageHeading: Locator;
  readonly updateFutureRegularContributionsMessage: Locator;
  readonly successMessage: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;

    this.radioViewByContributionTypeInput = page.locator(
      '[data-bdd-id=view-by-contribution-type]',
    );

    this.pageHeading = page.locator('[data-bdd-id=myi-existing-heading]');
    this.radioViewWholePotLabel = page.locator('[data-bdd-id=view-whole-pot] > label');
    this.allContributionsTable = page.locator('[data-bdd-id=all-contributions-heading]');
    this.confirmButton = page.locator('[data-bdd-id="confirm"]');

    this.myiFuturePageHeading = page.locator(
      '[data-bdd-id=future-regular-contributions-allocation]',
    );

    this.allContributionsTableTrows = page.locator(
      '[data-bdd-id="all-contributions-table"] tbody tr input',
    );

    this.skipThisStepButton = page.locator('[data-bdd-id=skip-this-step]');
    this.backButton = page.locator('[data-bdd-id=back]');

    this.regularContributionsTableRows = page.locator(
      '[data-bdd-id="regular-contributions"] tbody tr input',
    );

    this.copyFromCurrentInvestmentsButton = page.locator(
      '[data-bdd-id=copy-from-current-investments]',
    );

    this.confirmationPageHeading = page.locator('[data-bdd-id=all-done]');

    this.updateFutureRegularContributionsMessage = page.locator(
      '[data-bdd-id=update-future-regular-contributions-message]',
    );

    this.successMessage = page.locator('.lg-variant--success');
  }

  async clearTable(inputField: Locator) {
    const numberOfFields = await inputField.count();

    for (let i = 0; i < numberOfFields; i++) {
      await inputField.nth(i).fill('');
    }
  }
}
