import { MOCK_ENV, PageFunctions } from '@utility-e2e';
import { Page, Locator } from '@playwright/test';

export class ErrorPage extends PageFunctions {
  readonly page: Page;
  readonly tryAgainButton: Locator;
  readonly cardTitle: Locator;
  readonly contactUsLink: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;

    this.tryAgainButton = page.locator('[id=error-try-again-btn]');
    this.cardTitle = page.locator('[class=card-title]');

    this.contactUsLink = page.locator(
      '[href="https://www.legalandgeneral.com/contact-us/pensions-and-annuities/"]',
    );
  }

  async navigate(path = 'error', waitForPageToLoad = true): Promise<void> {
    await this.page.goto(MOCK_ENV);

    if (waitForPageToLoad) {
      await this.waitForPageToLoad();
    }

    await this.page.goto(`${MOCK_ENV}${path}`);

    await this.waitForPageToLoad();
  }
}
