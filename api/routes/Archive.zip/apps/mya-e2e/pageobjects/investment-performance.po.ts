import { PageFunctions } from '@utility-e2e';
import { Page, Locator } from '@playwright/test';

export class InvestmentPerformance extends PageFunctions {
  readonly page: Page;
  readonly fundPerformanceTable: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;

    this.fundPerformanceTable = page
      .locator('[data-bdd-id=performance-table-view]')
      .first();
  }
}
