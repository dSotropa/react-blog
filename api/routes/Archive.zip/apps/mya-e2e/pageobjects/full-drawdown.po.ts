import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class FullDrawdown extends PageFunctions {
  readonly page: Page;
  readonly manageYourInvestment: Locator;
  readonly manageYourInvestmentHeading = 'Manage your investments';
  readonly manageYourInvestmentLink: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.manageYourInvestment = page.getByTestId('manage-investment');

    this.manageYourInvestmentLink = page.getByRole('link', {
      name: 'manage your investments',
    });
  }
}
