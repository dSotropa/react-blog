import { PageFunctions } from '@utility-e2e';
import { Page, Locator } from '@playwright/test';

export class Investments extends PageFunctions {
  readonly page: Page;
  readonly browseFundsBtn: Locator;
  readonly fundCentreLink: Locator;
  readonly retirementPlannerLink: Locator;
  readonly viewProfileLink: Locator;
  readonly viewFundLink: Locator;
  readonly masterTrustLink: Locator;
  readonly fixedInterestTrustLink: Locator;
  readonly landGEuropeanIndexTrustLink: Locator;
  readonly landGDistributionTrustLink: Locator;
  readonly changeAllocationsButton: Locator;
  readonly landGEuropeanTrustLink: Locator;
  readonly investmentPerformanceButton: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.browseFundsBtn = page.locator('[data-bdd-id=browse-available-funds]');
    this.fundCentreLink = page.locator('text=View funds');
    this.retirementPlannerLink = page.locator('[href="https://landgmya.ctc.uk.com"]');
    this.viewProfileLink = page.locator('[data-bdd-id=view-lsp]').first();
    this.viewFundLink = page.locator('[data-bdd-id=view-fund]').first();

    this.masterTrustLink = page.locator(
      '[href="https://www.legalandgeneral.com/workplace/mastertrust/"]',
    );

    this.fixedInterestTrustLink = page.locator('text=L&G Fixed Interest Trust');
    this.landGEuropeanIndexTrustLink = page.locator('text=L&G European Index Trust');
    this.landGDistributionTrustLink = page.locator('text=L&G Distribution Trust');
    this.changeAllocationsButton = page.locator('[data-bdd-id=change-allocations]');
    this.landGEuropeanTrustLink = page.locator('text=L&G European Trust');

    this.investmentPerformanceButton = page.locator(
      '[data-bdd-id=investment-performance]',
    );
  }
}
