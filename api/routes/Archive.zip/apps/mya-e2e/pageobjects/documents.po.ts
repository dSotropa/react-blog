import { PageFunctions } from '@utility-e2e';
import { Page, Locator } from '@playwright/test';

export class Documents extends PageFunctions {
  readonly page: Page;
  readonly documentsTabPanel: Locator;
  readonly documentsTable: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.documentsTabPanel = page.locator('[id=tab-panel-documents]');
    this.documentsTable = page.locator('[data-bdd-id=docs-table]');
  }
}
