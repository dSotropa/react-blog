import { PageFunctions } from '@utility-e2e';
import { Page, Locator } from '@playwright/test';

export class RiskAndRewardPage extends PageFunctions {
  readonly page: Page;
  readonly pageHeading: Locator;
  readonly confirmButton: Locator;
  readonly manageYourInvestmentsBreadcrumb: Locator;
  readonly backButton: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.pageHeading = page.locator('[data-bdd-id=risk-and-reward]');
    this.confirmButton = page.locator('[data-bdd-id=confirm]');

    this.manageYourInvestmentsBreadcrumb = page.locator(
      '[data-bdd-id=manage-your-investments]',
    );

    this.backButton = page.locator('[data-bdd-id=back]');
  }
}
