import { PageFunctions } from '@utility-e2e';
import { Page, Locator } from '@playwright/test';

export class Beneficiaries extends PageFunctions {
  readonly page: Page;
  readonly beneficiariesAddBtn: Locator;
  readonly beneficiariesContinueBtn: Locator;
  readonly pageTitle: Locator;
  readonly fundSharePercentages: Locator;
  readonly secondFundSharePercentages: Locator;
  readonly setFundShareContinueBtn: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.beneficiariesAddBtn = page.locator('[id=add-nominee-btn]');
    this.beneficiariesContinueBtn = page.locator('[data-bdd-id=footer-btn-continue]');
    this.pageTitle = page.locator('.hero-card-title');
    // TODO: cleanup after the MWS-619 development
    this.fundSharePercentages = page.locator('[data-bdd-id=fundSharePercentage-0]');
    this.secondFundSharePercentages = page.locator('[data-bdd-id=fundSharePercentage-1]');
    this.setFundShareContinueBtn = page.locator('[id=sfs-continue-btn]');
  }

  public getTitle(beneficiaryNumber = 0): Locator {
    return this.page.locator(`[data-bdd-id="title-${beneficiaryNumber}"]`);
  }

  public getFirstName(beneficiaryNumber = 0): Locator {
    return this.page.locator(`[data-bdd-id="firstName-${beneficiaryNumber}"]`);
  }

  public getSurname(beneficiaryNumber = 0): Locator {
    return this.page.locator(`[data-bdd-id="surname-${beneficiaryNumber}"]`);
  }

  public getBirthDate(beneficiaryNumber = 0): Locator {
    return this.page.locator(`[data-bdd-id="birthDate-${beneficiaryNumber}"]`);
  }

  public getRelationToPolicyHolder(beneficiaryNumber = 0): Locator {
    return this.page.locator(
      `[data-bdd-id="relationToPolicyHolder-${beneficiaryNumber}"]`,
    );
  }

  public getShareSameAddressTrue(beneficiaryNumber = 1): Locator {
    return this.page.locator(
      `[data-bdd-id="shared-address-true-${beneficiaryNumber}"] > label`,
    );
  }

  async completeBeneficiariesForm(
    numberOfBeneficiares = 1,
    makeIncomplete = false,
    failingUser = false,
  ) {
    for (let beneficiary = 0; beneficiary < numberOfBeneficiares; beneficiary++) {
      if (beneficiary !== 0) {
        await this.beneficiariesAddBtn.click();
      }

      const surname = failingUser
        ? 'fail'
        : 'Testing';

      if (!makeIncomplete) {
        await this.getTitle(beneficiary).selectOption('Mr');
      }

      await this.getFirstName(beneficiary).click();
      await this.getFirstName(beneficiary).type('Test');
      await this.getSurname(beneficiary).click();
      await this.getSurname(beneficiary).type(surname);
      await this.getBirthDate(beneficiary).type('01/01/1980');
      await this.getRelationToPolicyHolder(beneficiary).selectOption('Son');
      await this.getShareSameAddressTrue(beneficiary).click();
    }
  }

  async setFundSharePercentages(percentageToSet: string) {
    if (await this.fundSharePercentages.isVisible()) {
      await this.fundSharePercentages.fill(percentageToSet);
    }

    if (await this.secondFundSharePercentages.isVisible()) {
      await this.secondFundSharePercentages.fill(percentageToSet);
    }
  }
}
