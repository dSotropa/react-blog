/* eslint-disable no-console */

const fs = require('fs-extra');
const path = require('path');

/*
 The angular-cli doesn't add a hash to the css files with 'lazy: true' specified
 (in our case the only file with the hash is the "landg" one).

 See issue: https://github.com/angular/angular-cli/issues/12552.

 This post-build script generates a timestamp for cache busting these files.
 This means they are refreshed on each new build, not based on their contents
*/

const filePath = '../../dist/apps/mya/';
const files = fs.readdirSync(filePath);
const cssFiles = files.filter(cssFile => /.\.css$/gi.test(cssFile));
const landgCss = cssFiles.find(cssFile => /landg.*\.(css)/gi.test(cssFile));
const timestamp = Date.now();

console.log('Starting PostBuild script');

try {
  fs.writeJsonSync(`${filePath}cssBuild.json`, { timestamp });
} catch (e) {
  console.error('PostBuild: Failed to write timestamp to cssBuild.json', e);
}

cssFiles.forEach(cssFile => {
  const fileName = path.parse(cssFile).name;
  const fileExt = path.parse(cssFile).ext;

  if (cssFile !== landgCss) {
    try {
      fs.renameSync(
        `${filePath}${cssFile}`,
        `${filePath}${fileName}.${timestamp}${fileExt}`,
      );

      console.log(
        `PostBuild: Renamed ${filePath}${cssFile} to ${filePath}${fileName}.${timestamp}${fileExt}`,
      );
    } catch (e) {
      console.error(`PostBuild: Failed to rename ${fileName} theme file`, e);
    }
  }
});

fs.copyFile(`${filePath}assets/favicons/landg.ico`, `${filePath}favicon.ico`, err => {
  if (err) {
    console.log('PostBuild: Failed to create favicon.ico');
    throw err;
  } else {
    console.log('PostBuild: Create favicon.ico');
  }
});
