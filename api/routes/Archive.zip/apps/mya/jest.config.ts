/* eslint-disable */
export default {
  coverageDirectory: '../../reports/unit-tests/mya',
  preset: '../../jest.preset.js',
};
