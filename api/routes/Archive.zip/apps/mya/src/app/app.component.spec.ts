import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Title } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { Store } from '@ngrx/store';
import { of } from 'rxjs';
import {
  anything,
  deepEqual,
  instance,
  mock,
  verify,
  when,
} from '@typestrong/ts-mockito';

import { CmsIconsInjectorService } from '@mya/services';
import { WindowService } from '@libs/shared/utility-service-window';
import {
  AccountSummaryService,
  AnalyticsService,
} from '@libs/mya/shared/utility-services';
import {
  AccountSummariesSelectors,
  ContributionDetailSelectors,
  CustomerProfileSelectors,
  UiActions,
  UiSelectors,
} from '@libs/mya/shared/utility-state';
import {
  accountsSummariesMock,
  contributionDetailMock,
  customerProfileMock,
  TrackingData,
} from '@libs/mya/shared/utility-data';

import { AppComponent } from './app.component';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let storeMock: Store<{}>;
  let analyticsServiceMock: AnalyticsService;
  let titleServiceMock: Title;
  let cmsIconsInjectorServiceMock: CmsIconsInjectorService;
  let accountSummaryServiceMock: AccountSummaryService;
  let windowServiceMock: WindowService;
  const accountDataMock = accountsSummariesMock.data.getAccountsSummaries[0];
  const customerProductData: TrackingData = {
    myAccountProductDetails: 'test',
    myAccountProductCode: 'test',
    myAccountPolicyNumber: 'test',
    myAccountSchemeId: 'test',
    myAccountProductSchemeName: 'test',
    myAccountProductCategory: 'test',
    myAccountProductValuation: 'test',
    myAccountProductLastContribution: 'test',
    myAccountProductLastSingleContribution: 'test',
    myAccountHasComplexCharges: true,
  };

  beforeEach(waitForAsync(() => {
    storeMock = mock(Store);
    accountSummaryServiceMock = mock(AccountSummaryService);
    analyticsServiceMock = mock(AnalyticsService);
    titleServiceMock = mock(Title);
    cmsIconsInjectorServiceMock = mock(CmsIconsInjectorService);
    windowServiceMock = mock(WindowService);

    TestBed.configureTestingModule({
      declarations: [ AppComponent ],
      providers: [
        { provide: AnalyticsService, useValue: instance(analyticsServiceMock) },
        {
          provide: CmsIconsInjectorService,
          useValue: instance(cmsIconsInjectorServiceMock),
        },
        { provide: Store, useValue: instance(storeMock) },
        { provide: Title, useValue: instance(titleServiceMock) },
        { provide: WindowService, useValue: instance(windowServiceMock) },
        {
          provide: AccountSummaryService,
          useValue: instance(accountSummaryServiceMock),
        },
      ],
      imports: [ RouterTestingModule, HttpClientTestingModule ],
    }).compileComponents();

    fixture = TestBed.createComponent(AppComponent);

    when(storeMock.select(UiSelectors.selectPageTitleState)).thenReturn(
      of('A page title'),
    );

    when(storeMock.select(AccountSummariesSelectors.selectAccountSummary)).thenReturn(
      of(accountDataMock),
    );

    when(
      storeMock.select(ContributionDetailSelectors.selectContributionDetail),
    ).thenReturn(of(contributionDetailMock));

    when(storeMock.select(CustomerProfileSelectors.selectCustomerProfile)).thenReturn(
      of(customerProfileMock),
    );

    when(accountSummaryServiceMock.getTrackingData(anything(), anything())).thenReturn(
      customerProductData,
    );

    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create the app', () => {
    fixture.detectChanges();

    expect(component).toBeTruthy();
  });

  it('should dispatch an action', () => {
    verify(storeMock.dispatch(deepEqual(UiActions.idleTimeout()))).once();
  });

  it('should call the analytics service #initScript function', () => {
    verify(analyticsServiceMock.initScript()).once();
  });

  it('should select the selectPageTitleState', () => {
    verify(storeMock.select(UiSelectors.selectPageTitleState)).once();
  });

  it('should call the cms icons injector service #init function', () => {
    verify(cmsIconsInjectorServiceMock.init()).once();
  });

  it('should call the title service #setTitle function', () => {
    component['store'].select(UiSelectors.selectPageTitleState).subscribe(() => {
      verify(titleServiceMock.setTitle('A page title - Workplace Pensions')).once();
    });
  });

  it('should track the customer details', () => {
    verify(analyticsServiceMock.customerTrack(anything())).once();
  });
});
