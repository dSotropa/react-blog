import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { A11yModule } from '@angular/cdk/a11y';
import { RouterModule } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { ApolloModule } from 'apollo-angular';
import {
  LgAccordionModule,
  LgBrandIconModule,
  LgButtonModule,
  LgFeatureToggleModule,
  LgFooterModule,
  LgGridModule,
  LgHeadingModule,
  LgMarginModule,
  LgPaddingModule,
} from '@legal-and-general/canopy';

@NgModule({
  imports: [
    ApolloModule,
    CommonModule,
    HttpClientModule,
    ReactiveFormsModule,
    A11yModule,
    RouterModule,
    LgFeatureToggleModule,
    LgHeadingModule,
    LgBrandIconModule,
    LgGridModule,
    LgButtonModule,
    LgFooterModule,
    LgPaddingModule,
    LgAccordionModule,
    LgMarginModule,
  ],
  providers: [ CookieService ],
})
export class SharedModule {}
