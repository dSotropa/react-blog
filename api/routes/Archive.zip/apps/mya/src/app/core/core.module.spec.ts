import { LgBrandIconRegistry, LgIconRegistry } from '@legal-and-general/canopy';
import { mock } from '@typestrong/ts-mockito';

import { CoreModule } from '@mya/core/core.module';

describe('CoreModule', () => {
  let coreModule: CoreModule;

  beforeEach(() => {
    const lgBrandIconRegistryMock = mock(LgBrandIconRegistry);
    const lgIconRegistryMock = mock(LgIconRegistry);

    coreModule = new CoreModule(lgBrandIconRegistryMock, lgIconRegistryMock, undefined);
  });

  it('should create an instance', () => {
    expect(coreModule).toBeTruthy();
  });
});
