import { NgModule, Optional, SkipSelf } from '@angular/core';
import { APP_BASE_HREF, CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { StoreModule } from '@ngrx/store';
import { RouterStateSerializer, StoreRouterConnectingModule } from '@ngrx/router-store';
import { of } from 'rxjs';
import {
  lgBrandIconErrorInBrowser,
  LgBrandIconModule,
  LgBrandIconRegistry,
  lgBrandIconThumbsUp,
  LgButtonModule,
  LgCardModule,
  LgFeatureToggleConfig,
  LgFeatureToggleModule,
  LgGridModule,
  LgHeaderModule,
  LgHeadingModule,
  LgHideAtModule,
  lgIconChevronDown,
  lgIconExit,
  LgIconModule,
  lgIconProfile,
  LgIconRegistry,
  LgKebabCasePipeModule,
  LgMarginModule,
  LgModalModule,
  LgPaddingModule,
  LgPageModule,
  LgPrimaryMessageModule,
  LgShowAtModule,
} from '@legal-and-general/canopy';

import {
  AccountSummariesEffects,
  ApplicationUrlsEffects,
  ContributionDetailEffects,
  coreRoutes,
  CustomerProfileEffects,
  ErrorStateContainerComponent,
  FiltersEffects,
  FundsEffects,
  InvestmentsEffects,
  LoggedOutContainerComponent,
  MainWrapperContainerComponent,
  PensionWiseAppointmentEffects,
  PermissionsEffects,
  RouterEffects,
  UiEffects,
  UtilityHeaderComponent,
  UtilityHeaderContainerComponent,
  WizardsEffects,
  WorkInProgressEffects,
} from '@mya/core';
import { GraphQLModule } from '@libs/mya/shared/utility-graphql';
import { SharedModule } from '@mya/shared/shared.module';
import { WindowService } from '@libs/shared/utility-service-window';
import { environment } from '@libs/shared/utility-config-loader';
import { RouterCustomSerializer, sharedReducers } from '@libs/mya/shared/utility-state';
import { MyaSharedFeatureToolTipModule } from '@libs/mya/shared/feature-tool-tip';
import { MyaSharedUiModule } from '@libs/mya/shared/ui';
import { MyaSharedUtilityPipesModule } from '@libs/mya/shared/utility-pipes';
import { MyaSharedFeatureFeatureCardsModule } from '@libs/mya/shared/feature-feature-cards';
import { SharedFeatureSurveyModule } from '@libs/shared/feature-survey';
import { getBaseHref } from '@libs/shared/utility-helpers';
import { AuthGuard, USE_SHARED_AUTH_TOKEN_REFRESH } from '@libs/shared/utility-auth';

const components: Array<any> = [
  UtilityHeaderComponent,
  UtilityHeaderContainerComponent,
  ErrorStateContainerComponent,
  LoggedOutContainerComponent,
  MainWrapperContainerComponent,
];

@NgModule({
  imports: [
    CommonModule,
    LgIconModule,
    LgHeadingModule,
    LgHeaderModule,
    HttpClientModule,
    StoreModule.forRoot(sharedReducers, {
      initialState: {
        router: {
          state: {
            url: window.location.pathname,
            params: {},
            queryParams: {},
          },
          navigationId: 0,
        },
      },
    }),
    SharedModule,
    MyaSharedUtilityPipesModule,
    EffectsModule.forRoot([
      AccountSummariesEffects,
      ContributionDetailEffects,
      CustomerProfileEffects,
      FiltersEffects,
      FundsEffects,
      InvestmentsEffects,
      RouterEffects,
      UiEffects,
      WizardsEffects,
      PermissionsEffects,
      WorkInProgressEffects,
      ApplicationUrlsEffects,
      PensionWiseAppointmentEffects,
    ]),
    RouterModule.forRoot(coreRoutes, {
      anchorScrolling: 'enabled',
    }),
    environment.config.production
      ? []
      : StoreDevtoolsModule.instrument(),
    GraphQLModule,
    StoreRouterConnectingModule.forRoot({
      serializer: RouterCustomSerializer,
      stateKey: 'routerReducer',
    }),
    LgFeatureToggleModule.forRoot({
      useFactory: () => of(environment.config.featureToggles as LgFeatureToggleConfig),
    }),
    LgBrandIconModule,
    LgMarginModule,
    LgGridModule,
    LgButtonModule,
    LgCardModule,
    LgHideAtModule,
    LgModalModule,
    LgPrimaryMessageModule,
    LgPageModule,
    LgPaddingModule,
    LgShowAtModule,
    LgKebabCasePipeModule,
    MyaSharedFeatureFeatureCardsModule,
    MyaSharedFeatureToolTipModule,
    MyaSharedUiModule,
    SharedFeatureSurveyModule,
  ],
  declarations: components,
  exports: [ ...components, RouterModule ],
  providers: [
    AuthGuard,
    { provide: RouterStateSerializer, useClass: RouterCustomSerializer },
    {
      provide: APP_BASE_HREF,
      useFactory: getBaseHref,
      deps: [ WindowService ],
    },
    { provide: USE_SHARED_AUTH_TOKEN_REFRESH, useValue: true },
  ],
})
export class CoreModule {
  constructor(
    private brandIconRegistry: LgBrandIconRegistry,
    private iconRegistry: LgIconRegistry,
    @Optional() @SkipSelf() parentModule: CoreModule,
  ) {
    if (parentModule) {
      throw new Error('CoreModule is already loaded. Import it in the AppModule only');
    }

    this.brandIconRegistry.registerBrandIcon([
      lgBrandIconErrorInBrowser,
      lgBrandIconThumbsUp,
    ]);

    this.iconRegistry.registerIcons([ lgIconChevronDown, lgIconProfile, lgIconExit ]);
  }
}
