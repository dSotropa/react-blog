import { Routes } from '@angular/router';
import { FeatureToggleGuard } from '@legal-and-general/canopy';

import {
  ErrorStateContainerComponent,
  LoggedOutContainerComponent,
  MainWrapperContainerComponent,
} from '@mya/core/containers';
import {
  IsAccumulationGuard,
  IsDrawdownGuard,
  ProductQueryParamGuard,
} from '@mya/guards';
import { AuthGuard } from '@libs/shared/utility-auth';

export const coreRoutes: Routes = [
  {
    path: '',
    component: MainWrapperContainerComponent,
    canActivate: [ AuthGuard ],
    canActivateChild: [ AuthGuard ],
    children: [
      {
        path: '',
        redirectTo: 'product',
        pathMatch: 'full',
      },
      {
        path: 'product',
        canActivate: [ ProductQueryParamGuard, IsAccumulationGuard ],
        loadChildren: (): Promise<any> =>
          import('../product/product.module').then(m => m.ProductModule),
        data: {
          breadcrumb: 'productOverview',
        },
      },
      {
        path: 'full-drawdown',
        canActivate: [ ProductQueryParamGuard, FeatureToggleGuard, IsDrawdownGuard ],
        loadChildren: (): Promise<any> =>
          import('../full-drawdown/full-drawdown.module').then(
            m => m.FullDrawdownComponentModule,
          ),
        data: {
          contentPath: 'pages.fullDrawdown',
          featureToggle: 'fullDrawdown',
          breadcrumb: 'productOverview',
        },
      },
    ],
  },
  {
    path: 'error',
    component: ErrorStateContainerComponent,
    data: {
      contentPath: 'pages.error',
      breadcrumb: 'error',
    },
  },
  {
    path: 'logged-out',
    component: LoggedOutContainerComponent,
    data: {
      contentPath: 'pages.loggedOut',
      breadcrumb: 'loggedOut',
    },
  },
  {
    path: '**',
    redirectTo: '/product',
  },
];
