import { Component, OnDestroy, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Store } from '@ngrx/store';
import { combineLatest, fromEvent, Subscription } from 'rxjs';
import { filter, skip } from 'rxjs/operators';
import * as moment from 'moment';

import { CmsIconsInjectorService } from '@mya/services';
import { WindowService } from '@libs/shared/utility-service-window';
import {
  AccountSummaryService,
  AnalyticsService,
} from '@libs/mya/shared/utility-services';
import { ConfigLoaderService } from '@libs/shared/utility-config-loader';
import {
  AccountSummariesSelectors,
  ContributionDetailSelectors,
  CustomerProfileSelectors,
  UiActions,
  UiSelectors,
} from '@libs/mya/shared/utility-state';
import { dateFormats } from '@libs/mya/shared/utility-data';
import { cookieConsentChangedEvent } from '@libs/shared/utility-data';

@Component({
  selector: 'wp-root',
  templateUrl: './app.component.html',
})
export class AppComponent implements OnInit, OnDestroy {
  private subscriptions: Array<Subscription> = [];
  constructor(
    private accountSummaryService: AccountSummaryService,
    private analyticsService: AnalyticsService,
    private configLoaderService: ConfigLoaderService,
    private cmsIconsInjectorService: CmsIconsInjectorService,
    private store: Store<{}>,
    private titleService: Title,
    private windowService: WindowService,
  ) {}

  ngOnInit(): void {
    this.store.dispatch(UiActions.idleTimeout());
    this.analyticsService.initScript();

    this.subscriptions.push(
      // Everytime the cookie consent changes the app reloads to stop the chosen scripts from running
      fromEvent(document, cookieConsentChangedEvent)
        .pipe(skip(2))
        .subscribe(() => {
          this.windowService.getWindow().location.reload();
        }),

      combineLatest([
        this.store.select(AccountSummariesSelectors.selectAccountSummary),
        this.store.select(ContributionDetailSelectors.selectContributionDetail),
        this.store.select(CustomerProfileSelectors.selectCustomerProfile),
      ])
        .pipe(
          filter(
            ([ accountSummary, contributionDetail, customerDetails ]) =>
              !!accountSummary && !!contributionDetail && !!customerDetails,
          ),
        )
        .subscribe(([ accountSummary, contributionDetail, customerDetails ]) => {
          const productData = this.accountSummaryService.getTrackingData(
            accountSummary,
            contributionDetail,
          );

          this.analyticsService.customerTrack({
            dob: moment(customerDetails.dateOfBirth).format(dateFormats.UK_DATE),
            gender: customerDetails.gender,
            ...productData,
          });
        }),
    );

    this.store.select(UiSelectors.selectPageTitleState).subscribe(title => {
      this.titleService.setTitle(`${title} - Workplace Pensions`);
    });

    this.cmsIconsInjectorService.init();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }
}
