import { Routes } from '@angular/router';
import { FeatureToggleGuard } from '@legal-and-general/canopy';

export const fullDrawdownRoutes: Routes = [
  {
    path: '',
    loadChildren: (): Promise<any> =>
      import('./fd-summary/fd-summary.module').then(m => m.FdSummaryComponentModule),
    canActivate: [ FeatureToggleGuard ],
    canActivateChild: [ FeatureToggleGuard ],
    canLoad: [ FeatureToggleGuard ],
    data: {
      featureToggle: 'fullDrawdown',
    },
  },
  {
    path: '',
    loadChildren: () =>
      import('./fd-page-frame/fd-page-frame.module').then(mod => mod.FdPageFrameModule),
  },
  {
    path: '**',
    redirectTo: '',
  },
];
