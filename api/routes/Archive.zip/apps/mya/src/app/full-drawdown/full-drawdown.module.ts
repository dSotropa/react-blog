import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { LgFeatureToggleModule } from '@legal-and-general/canopy';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';

import { FdTransactionsEffects, FdTransactionsFeature } from '@libs/mya/transactions-full-drawdown/utility';

import { fullDrawdownRoutes } from './full-drawdown.routes';

@NgModule({
  imports: [
    CommonModule,
    LgFeatureToggleModule,
    RouterModule.forChild(fullDrawdownRoutes),
    EffectsModule.forFeature([ FdTransactionsEffects ]),
    StoreModule.forFeature(
      FdTransactionsFeature.FD_TRANSACTIONS_FEATURE_KEY,
      FdTransactionsFeature.fdTransactionsReducer,
    ),
  ],
})
export class FullDrawdownComponentModule {}
