import { Routes } from '@angular/router';
import { FeatureToggleGuard } from '@legal-and-general/canopy';

import { ManageBeneficiariesFeatureToggleGuard } from '@libs/mya/manage-beneficiaries/utility';
import { ghostTypes } from '@libs/mya/shared/utility-data';

/* istanbul ignore next */
export const productRoutes: Routes = [
  {
    path: '',
    loadChildren: (): Promise<any> =>
      import('./product-summary/product-summary.module').then(
        m => m.ProductSummaryModule,
      ),
  },
  {
    path: 'decumulation',
    loadChildren: (): Promise<any> =>
      import('./decumulation/decumulation.module').then(m => m.DecumulationModule),
    canActivate: [ FeatureToggleGuard ],
    canActivateChild: [ FeatureToggleGuard ],
    canLoad: [ FeatureToggleGuard ],
    data: {
      featureToggle: 'decumulation',
    },
  },
  {
    path: 'retirement-age',
    loadChildren: (): Promise<any> =>
      import('@libs/mya/retirement-age/feature-shell').then(
        m => m.MyaRetirementAgeFeatureShellModule,
      ),
    data: {
      ghostType: ghostTypes.HALF_WIDTH_WITH_ASIDE,
      breadcrumb: 'retirementAge',
    },
  },
  {
    path: 'transfer-in',
    loadChildren: (): Promise<any> =>
      import('@libs/mya/transfer-in/feature-shell').then(
        m => m.MyaTransferInFeatureShellModule,
      ),
    data: {
      ghostType: ghostTypes.FULL_WIDTH,
      breadcrumb: 'transferIn',
    },
  },
  {
    path: 'beneficiaries',
    loadChildren: (): Promise<any> =>
      import('@libs/mya/manage-beneficiaries/feature-shell').then(
        m => m.MyaManageBeneficiariesFeatureShellModule,
      ),
    canMatch: [ ManageBeneficiariesFeatureToggleGuard ],
  },
  {
    path: 'beneficiaries',
    loadChildren: (): Promise<any> =>
      import('./beneficiaries/beneficiaries.module').then(m => m.BeneficiariesModule),
    data: {
      ghostType: ghostTypes.HALF_WIDTH_WITH_ASIDE,
    },
  },
  {
    path: 'investments/manage',
    loadChildren: (): Promise<any> =>
      import('./investments/manage-investments.module').then(
        m => m.ManageInvestmentsModule,
      ),
    canActivate: [ FeatureToggleGuard ],
    canActivateChild: [ FeatureToggleGuard ],
    canLoad: [ FeatureToggleGuard ],
    data: {
      featureToggle: 'manageInvestments',
      ghostType: ghostTypes.FULL_WIDTH,
    },
  },
  {
    path: 'video-statement',
    loadChildren: (): Promise<any> =>
      import('@libs/mya/video-statement/feature-shell').then(
        m => m.MyaVideoStatementFeatureShellModule,
      ),
    canActivate: [ FeatureToggleGuard ],
    canActivateChild: [ FeatureToggleGuard ],
    canLoad: [ FeatureToggleGuard ],
    data: {
      featureToggle: 'videoStatement',
      ghostType: ghostTypes.HALF_WIDTH_WITH_ASIDE,
      breadcrumb: 'videoStatement',
      contentPath: 'pages.videoStatement',
    },
  },
  {
    path: 'accenture-contributions',
    loadChildren: (): Promise<any> =>
      import('@libs/mya/accenture-contributions/feature-shell').then(
        m => m.MyaAccentureContributionsFeatureShellModule,
      ),
    canActivate: [ FeatureToggleGuard ],
    canActivateChild: [ FeatureToggleGuard ],
    canLoad: [ FeatureToggleGuard ],
    data: {
      featureToggle: 'newAccentureChangeContributionsJourney',
      breadcrumb: 'accentureContribution',
      contentPath: 'pages.accentureContribution',
    },
  },
];
