import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import { AvailableFundsEffects, SuspendedFundsEffects } from '@mya/product/store';
import { SharedModule } from '@mya/shared/shared.module';
import { PotPerformanceEffects, potPerformanceReducer } from '@mya/investments/store';
import { myiReducer } from '@mya/investments/store/myi';
import { originalMyiBenefitsReducer } from '@mya/investments/store/original-myi-benefits';

import { productRoutes } from './product.routes';
import { productReducers } from './store';

const featureStores = [
  StoreModule.forFeature('addedFunds', productReducers.addedFunds),
  StoreModule.forFeature('availableFunds', productReducers.availableFunds),
  StoreModule.forFeature('manageInvestments', myiReducer),
  StoreModule.forFeature('originalMyiBenefits', originalMyiBenefitsReducer),
  StoreModule.forFeature('potPerformance', potPerformanceReducer),
  StoreModule.forFeature('suspendedFunds', productReducers.suspendedFunds),
];

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    ReactiveFormsModule,
    RouterModule.forChild(productRoutes),
    EffectsModule.forFeature([
      PotPerformanceEffects,
      AvailableFundsEffects,
      SuspendedFundsEffects,
    ]),
    ...featureStores,
  ],
})
export class ProductModule {}
