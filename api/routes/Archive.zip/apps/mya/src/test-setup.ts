import 'jest-preset-angular/setup-jest';
import { TestBed } from '@angular/core/testing';
import { jest } from '@jest/globals';

import { FundHelpers } from '@mya/helpers/fund/fund.helpers';
import TickerHelper from '@mya/helpers/ticker/ticker.helper';

// Removes messages that pollute the console
window.console.error = jest.fn();
window.console.warn = jest.fn();

export interface SpyObject {
  [key: string]: jest.Mock<any>;
}

export const createSpyObj = (baseName: string, methodNames: Array<string>): SpyObject => {
  const obj: Record<string, any> = {};

  methodNames.forEach((element, index, arr) => {
    obj[arr[index]] = jest.fn();
  });

  return obj;
};

/*
 This file (test-setup.ts) is used as a configuration file by the jest.config.js for all the tests
 This is where we can mock DOM related features that are missing from JSDOM
 */

import 'test-setup-mocks';

/*
 Needed to mock the modules and functions which reach the infamous `import.meta.url` syntax
 Both the module and the function that instantiates the worker need to be mocked to completely
 bypass the import.meta.url parts
 */

jest.mock('./app/helpers/ticker/ticker-meta-helper.ts', () => {});
TickerHelper.setUpWorker = jest.fn().mockReturnValue(new Worker('')) as any;

jest.mock('./app/helpers/fund/fund-meta-helper.ts', () => {});
FundHelpers['setupWorker'] = jest.fn().mockReturnValue(new Worker('')) as any;

type CompilerOptions = Partial<{
  providers: Array<any>;
  useJit: boolean;
  preserveWhitespaces: boolean;
}>;
export type ConfigureFn = (testBed: typeof TestBed) => void;

export const configureTests = (
  configure: ConfigureFn,
  compilerOptions: CompilerOptions = {},
) => {
  const compilerConfig: CompilerOptions = {
    preserveWhitespaces: false,
    ...compilerOptions,
  };

  const configuredTestBed = TestBed.configureCompiler(compilerConfig);

  configure(configuredTestBed);

  return configuredTestBed.compileComponents().then(() => configuredTestBed);
};
