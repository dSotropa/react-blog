/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

// SAFETY WORKER - it will unregister the service worker (DWP-8004).

self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(self.clients.claim());

  self.registration.unregister().then(() => {
    console.warn('NGSW Safety Worker - unregistered old service worker');
  });
});
