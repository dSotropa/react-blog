import * as express from 'express';

import { generateAgencies, generateUsers } from '../../helpers';

const users = generateUsers(100);
const agencies = generateAgencies(100);

export function setupForgeRockMocks(server: express.Application): void {
  server.get('/openidm/managed/alpha_user', (req, res) => {
    console.log('OPENIDM MANAGED ALPHA USER SEARCH');

    const request = {
      totalPageResultPolicy: req.query['_totalPagedResultsPolicy'] as string,
      pageSize: req.query['_pageSize'] as string,
      sortKeys: req.query['_sortKeys'] as string,
      fields: req.query['_fields'] as string,
      queryFilter: req.query['_queryFilter'] as string,
    };

    const responseData = {
      pagedResultsCookie: '1',
      remainingPagedResults: 0,
      result: users,
      resultCount: request.pageSize,
      totalPagedResults: users.length,
      totalPagedResultsPolicy: 'EXACT',
    };

    res.status(200).send(responseData);
  });

  server.get('/openidm/managed/alpha_organization', (req, res) => {
    console.log('OPENIDM MANAGED ALPHA ORGANIZATION SEARCH');

    const request = {
      totalPageResultPolicy: req.query['_totalPagedResultsPolicy'] as string,
      pageSize: req.query['_pageSize'] as string,
      sortKeys: req.query['_sortKeys'] as string,
      fields: req.query['_fields'] as string,
      queryFilter: req.query['_queryFilter'] as string,
    };

    const responseData = {
      pagedResultsCookie: 'AAAAAAABlFA=',
      remainingPagedResults: -1,
      result: agencies,
      resultCount: request.pageSize,
      totalPagedResults: agencies.length,
      totalPagedResultsPolicy: 'ESTIMATE',
    };

    res.status(200).send(responseData);
  });
}
