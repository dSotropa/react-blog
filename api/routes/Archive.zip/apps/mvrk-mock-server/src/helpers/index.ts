import { faker } from '@faker-js/faker/locale/en_GB';

export function getRandomValue<T>(collection: Array<T>): T {
  const randomIndex = Math.floor(Math.random() * collection.length);

  return collection[randomIndex];
}

export function generateAgencies(numberOfAgencies) {
  const advisers = [];

  for (let i = 0; i < numberOfAgencies; i++) {
    const frnNumber = faker.random.numeric(8);
    const agencyNumber = faker.random.numeric(7);
    const principalFrn = faker.random.numeric(8);
    const masterAgencyNumber = faker.random.numeric(7);
    const name = faker.random.alphaNumeric(15);
    const masterAgencyName = faker.random.alphaNumeric(15);
    const partyId = faker.random.alphaNumeric(7);
    const address = {
      line1: 'line 1',
      postCode: `${faker.random.alpha(2).toUpperCase()}1 5${faker.random
        .alpha(2)
        .toUpperCase()}`,
    };

    const statusDesc = getRandomValue<string>([ 'Live', 'Suspended', 'Terminated', '' ]);

    advisers.push({
      frnNumber,
      number: agencyNumber,
      principalFrn,
      masterAgencyNumber,
      name,
      masterAgencyName,
      partyId,
      statusDesc,
      address,
      _id: i,
      _rev: String(i),
    });
  }

  return advisers;
}

export function generateUsers(numberOfUsers) {
  const users = [];

  for (let i = 0; i < numberOfUsers; i++) {
    const givenName = faker.name.firstName();
    const surname = faker.name.lastName();
    const userName = faker.internet.userName(givenName, surname);
    const mail = faker.internet.email(givenName, surname);
    const memberOfOrgIDs = faker.datatype.number({ min: 10, max: 100 });
    const telephoneNumber = faker.phone.number();
    const accountStatus = faker.datatype.boolean()
      ? 'active'
      : 'inactive';

    users.push({
      givenName,
      sn: surname,
      userName,
      mail,
      memberOfOrgIDs,
      telephoneNumber,
      accountStatus,
      frIndexedString1: String(i),
      _id: i,
      _rev: String(i),
    });
  }

  return users;
}
