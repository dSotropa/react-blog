import {
  actAsProxy,
  getPort,
  getServers,
  setupListener,
} from '@libs/shared/utility-mock-server';

import { setupExpressMocks } from './express';

(() => {
  const appRefName = 'mvrk';
  const servers = getServers(appRefName);
  const port: number = getPort();

  if (!actAsProxy) {
    setupExpressMocks({
      server: servers.http,
      port,
      appRefName,
    });
  }

  setupListener({
    appRefName,
    servers,
    port,
    routes: [ '/advisers/*' ],
  });
})();
