import { test as base } from '@playwright/test';

import { DrawdownActivityPage } from '../pageobjects/drawdown/drawdown-activity.page';
import { DrawdownMakeWithdrawalPage } from '../pageobjects/drawdown/drawdown-make-withdrawal.page';
import { DrawdownWithdrawalsPage } from '../pageobjects/drawdown/drawdown-withdrawals.page';
import { FundDetailPage as FundDetailsPage } from '../pageobjects/shared/fund-details.page';
import { MultiFundPage as MultiFundPage } from '../pageobjects/shared/multifund.page';
import { DrawdownPathwaySwitchPage } from '../pageobjects/drawdown/drawdown-pathway-switch.page';
import { FundSwitchPage } from '../pageobjects/shared/fund-switch.page';
import { InvestmentsPage } from '../pageobjects/shared/investments.page';
import { IsaActivityPage } from '../pageobjects/isa/isa-activity.page';
import { IsaTopUpPage } from '../pageobjects/isa/isa-top-up.page';
import { IsaTransferPage } from '../pageobjects/isa/isa-transfer.page';
import { IsaWithdrawalPage } from '../pageobjects/isa/isa-withdrawal.page';
import { PaymentsPage } from '../pageobjects/shared/payments.page';
import { IsaRegularPaymentConfirmModal } from '../pageobjects/isa/isa-regular-payment-confirm-modal.page';
import { RegularPaymentDoneModal } from '../pageobjects/isa/isa-regular-payment-done-modal.page';
import { IsaSetupRegularContributionPage } from '../pageobjects/isa/isa-setup-regular-contribution.page';
import { IsaStartRegularPaymentPage } from '../pageobjects/isa/isa-start-regular-payment.page';
import { StopDirectDebitConfirmModal } from '../pageobjects/shared/stop-direct-debit-confirm-modal.page';
import { StopDirectDebitDoneModal } from '../pageobjects/shared/stop-direct-debit-done-modal.page';
import { LgppSetupDirectDebitPage } from '../pageobjects/lgpp/lgpp-setup-direct-debit.page';
import { LgppActivityPage } from '../pageobjects/lgpp/lgpp-activity.page';
import { LgppMoveToDrawdownPage } from '../pageobjects/lgpp/lgpp-move-to-drawdown.page';
import { LgppPensionDetailsPage } from '../pageobjects/lgpp/lgpp-pension-details.page';
import { LgppTransferInPensionPage } from '../pageobjects/lgpp/lgpp-transfer-in-pension.page';
import { OssMainPage } from '../pageobjects/oss-main.page';
import { DocumentsPage } from '../pageobjects/shared/documents.page';
import { FeesAndChargesPage } from '../pageobjects/shared/fees-and-charges.page';
import { PulsePage } from '../pageobjects/shared/pulse.page';
import { LgppAmendDirectDebitPage } from '../pageobjects/lgpp/lgpp-amend-direct-debit.page';
import { ChangeInvestmentsPage } from '../pageobjects/shared/change-investments.page';
import { LgppPensionTopUpPage } from '../pageobjects/lgpp/lgpp-pension-topup.page';
import { BarclaysPaymentPage } from '../pageobjects/shared/barclays-payment.page';
export interface TestOptions {
  skipVisualChecks: boolean;
}

// Additional options that we can pass in the config file via projects. For example
// const config = {
//   ...
//   projects: [
//     {
//       name: 'Local',
//       use: {
//         channel: 'chrome',
//         skipVisualChecks: true,
//       },
//
const baseWithOptions = base.extend<TestOptions>({
  skipVisualChecks: [ false, { option: true } ],
});

// Create fixtures out of the page object, so we can pass them into tests rather than new them up
export const test = baseWithOptions.extend<{
  // Base pages
  ossMainPage: OssMainPage;

  // Shared pages
  barclaysPaymentPage: BarclaysPaymentPage;
  changeInvestmentsPage: ChangeInvestmentsPage;
  documentsPage: DocumentsPage;
  feesAndChargesPage: FeesAndChargesPage;
  fundDetailsPage: FundDetailsPage;
  multiFundPage: MultiFundPage;
  fundSwitchPage: FundSwitchPage;
  investmentsPage: InvestmentsPage;
  paymentsPage: PaymentsPage;
  pulsePage: PulsePage;
  stopDirectDebitConfirmModal: StopDirectDebitConfirmModal;
  stopDirectDebitDoneModal: StopDirectDebitDoneModal;

  // Drawdown
  drawdownActivityPage: DrawdownActivityPage;
  drawdownMakeWithdrawalPage: DrawdownMakeWithdrawalPage;
  drawdownPathwaySwitchPage: DrawdownPathwaySwitchPage;
  drawdownWithdrawalsPage: DrawdownWithdrawalsPage;

  // ISA
  isaActivityPage: IsaActivityPage;
  isaRegularPaymentConfirmModal: IsaRegularPaymentConfirmModal;
  isaRegularPaymentDoneModal: RegularPaymentDoneModal;
  isaSetupRegularContributionPage: IsaSetupRegularContributionPage;
  isaStartRegularPaymentPage: IsaStartRegularPaymentPage;
  isaTopUpPage: IsaTopUpPage;
  isaTransferPage: IsaTransferPage;
  isaWithdrawalPage: IsaWithdrawalPage;

  // LGPP
  lgppActivityPage: LgppActivityPage;
  lgppAmendDirectDebitPage: LgppAmendDirectDebitPage;
  lgppMoveToDrawdownPage: LgppMoveToDrawdownPage;
  lgppPensionDetailsPage: LgppPensionDetailsPage;
  lgppPensionTopUpPage: LgppPensionTopUpPage;
  lgppSetupDirectDebitPage: LgppSetupDirectDebitPage;
  lgppTransferInPensionPage: LgppTransferInPensionPage;
}>({
  ossMainPage: async ({ page }, use) => {
    await use(new OssMainPage(page));
  },

  // Shared
  barclaysPaymentPage: async ({ page }, use) => {
    await use(new BarclaysPaymentPage(page));
  },
  changeInvestmentsPage: async ({ page }, use) => {
    await use(new ChangeInvestmentsPage(page));
  },
  documentsPage: async ({ page }, use) => {
    await use(new DocumentsPage(page));
  },
  feesAndChargesPage: async ({ page }, use) => {
    await use(new FeesAndChargesPage(page));
  },
  fundDetailsPage: async ({ page }, use) => {
    await use(new FundDetailsPage(page));
  },
  multiFundPage: async ({ page }, use) => {
    await use(new MultiFundPage(page));
  },
  fundSwitchPage: async ({ page }, use) => {
    await use(new FundSwitchPage(page));
  },
  investmentsPage: async ({ page }, use) => {
    await use(new InvestmentsPage(page));
  },
  paymentsPage: async ({ page }, use) => {
    await use(new PaymentsPage(page));
  },
  pulsePage: async ({ page }, use) => {
    await use(new PulsePage(page));
  },
  stopDirectDebitConfirmModal: async ({ page }, use) => {
    await use(new StopDirectDebitConfirmModal(page));
  },
  stopDirectDebitDoneModal: async ({ page }, use) => {
    await use(new StopDirectDebitDoneModal(page));
  },

  // Drawdown
  drawdownActivityPage: async ({ page }, use) => {
    await use(new DrawdownActivityPage(page));
  },
  drawdownMakeWithdrawalPage: async ({ page }, use) => {
    await use(new DrawdownMakeWithdrawalPage(page));
  },
  drawdownPathwaySwitchPage: async ({ page }, use) => {
    await use(new DrawdownPathwaySwitchPage(page));
  },
  drawdownWithdrawalsPage: async ({ page }, use) => {
    await use(new DrawdownWithdrawalsPage(page));
  },

  // ISA
  isaActivityPage: async ({ page }, use) => {
    await use(new IsaActivityPage(page));
  },
  isaRegularPaymentConfirmModal: async ({ page }, use) => {
    await use(new IsaRegularPaymentConfirmModal(page));
  },
  isaRegularPaymentDoneModal: async ({ page }, use) => {
    await use(new RegularPaymentDoneModal(page));
  },
  isaSetupRegularContributionPage: async ({ page }, use) => {
    await use(new IsaSetupRegularContributionPage(page));
  },
  isaStartRegularPaymentPage: async ({ page }, use) => {
    await use(new IsaStartRegularPaymentPage(page));
  },
  isaTopUpPage: async ({ page }, use) => {
    await use(new IsaTopUpPage(page));
  },
  isaTransferPage: async ({ page }, use) => {
    await use(new IsaTransferPage(page));
  },
  isaWithdrawalPage: async ({ page }, use) => {
    await use(new IsaWithdrawalPage(page));
  },

  // LGP
  lgppActivityPage: async ({ page }, use) => {
    await use(new LgppActivityPage(page));
  },
  lgppAmendDirectDebitPage: async ({ page }, use) => {
    await use(new LgppAmendDirectDebitPage(page));
  },
  lgppMoveToDrawdownPage: async ({ page }, use) => {
    await use(new LgppMoveToDrawdownPage(page));
  },
  lgppPensionDetailsPage: async ({ page }, use) => {
    await use(new LgppPensionDetailsPage(page));
  },
  lgppPensionTopUpPage: async ({ page }, use) => {
    await use(new LgppPensionTopUpPage(page));
  },
  lgppSetupDirectDebitPage: async ({ page }, use) => {
    await use(new LgppSetupDirectDebitPage(page));
  },
  lgppTransferInPensionPage: async ({ page }, use) => {
    await use(new LgppTransferInPensionPage(page));
  },
});
