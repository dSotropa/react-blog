module.exports = {
  // global variables for sharing across steps files
  accountHash: '',
};
