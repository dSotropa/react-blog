import { Page } from '@playwright/test';

import { BasePage } from '../base.page';

export class StopDirectDebitConfirmModal extends BasePage {
  readonly modal = this.page.locator('h1:has-text("Stop your Direct Debit")');
  readonly backBtn = this.page.locator('button:has-text("Back")').last();
  readonly confirmBtn = this.page.locator('text="Confirm"').nth(1);

  constructor(page: Page) {
    super(page);
  }
}
