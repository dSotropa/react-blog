import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
export class ChangeInvestmentsPage extends BasePage {
  readonly overview = {
    heading: this.page.locator('text=You have two ways to invest your'),
    simpleFunds: {
      viewOptionsBtn: this.page.locator(
        'text=Your current selection Simple fund choiceBased on your risk appetite, choose fro >> button',
      ),
    },
    sutainableFunds: {
      whatIsBtn: this.page.locator('text=What is a sustainable fund?'),
      overlay: this.page.locator('.fullscreen-overlay__content'),
      closeBtn: this.page.locator('[aria-label="Close"]'),
    },
  };

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/change-investments/**');
    await this.overview.heading.waitFor();
  }
}
