import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
export class PulsePage extends BasePage {
  readonly backToSummaryBtn = this.page.locator('[data-test="sub-header-mobile"]');
  readonly banChristmasOption = this.page.locator(
    'label:has-text("Ban Christmas Glasses")',
  );
  readonly submitBtn = this.page.locator('text=Submit vote');
  readonly thankYouMessage = this.page.locator('text=Thank you for your vote');

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/pulse/**');
    await this.submitBtn.waitFor();
  }
}
