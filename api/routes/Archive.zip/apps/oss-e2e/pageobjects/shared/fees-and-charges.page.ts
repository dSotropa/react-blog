import { Page } from '@playwright/test';

import { BasePage } from '../base.page';

export class FeesAndChargesPage extends BasePage {
  readonly backToSummaryBtn = this.page.locator('[data-test="sub-header-mobile"]');

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/fees-charges/**');
    await this.page.locator('text=Your fees and charges').waitFor();
  }
}
