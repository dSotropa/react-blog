import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
export class InvestmentsPage extends BasePage {
  readonly changeInvestmentPathway = this.page.locator(
    'button.start-switch-pathway-journey',
  );
  readonly investmentPathwayDetail = this.page.locator(
    '[id="PathwayDetailsModalComponent"]',
  );
  readonly investmentPathwayCloseBtn = this.page.locator('[data-test="close-modal"]');
  readonly investmentPathwayFundLink = this.page.locator(
    '.investment-pathway__fund-name',
  );
  readonly fundTileHeader = this.page.locator('h2.fund__name');
  readonly backToSummaryBtn = this.page.locator('[data-test="sub-header-mobile"]');

  readonly investmentAvailableSoonMsg = this.page.locator(
    'text=Investment will be available soon',
  );

  readonly isaAllowanceTopUpBtn = this.page.locator(
    'lg-isa-allowance-sidebar >> text=Top up',
  );

  readonly withdrawBtn = this.page.locator('text=Withdraw');

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/investments/**');
    await this.page.locator('[data-test="overview"] >> text=Your investments').waitFor();
    await this.backToSummaryBtn.waitFor();
  }
}
