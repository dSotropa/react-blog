import { Page } from '@playwright/test';

import { BasePage } from '../base.page';

export class BarclaysPaymentPage extends BasePage {
  readonly heading = this.page.locator(
    'text=Please enter your debit card details Your debit card must include your name and ',
  );
  readonly cancelBtn = this.page
    .frameLocator('iframe')
    .last()
    .locator('input[alt="Cancel \\(Alt\\[\\+Shift\\]\\+C\\)"]')
    .first();
  readonly investSecurlyBtn = this.page
    .frameLocator('iframe')
    .last()
    .locator('text=Invest securely')
    .first();
  readonly errorWhenProcessingOption = this.page
    .frameLocator('iframe')
    .last()
    .locator('#ERROR_WHEN_PROCESSING')
    .first();

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.heading.waitFor();
  }
}
