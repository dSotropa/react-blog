import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
import { IsaRegularPayrollPaymentsEditor } from '../isa/isa-regular-payroll-patments-editor.page';

export class PaymentsPage extends BasePage {
  readonly backToSummaryBtn = this.page.locator('[data-test="sub-header-mobile"]');
  readonly stopRegularPaymentsBtn = this.page.locator(
    '[aria-label="stop your regular payments"]',
  );
  readonly amendRegularPaymentsBtn = this.page.locator(
    '[aria-label="Change your regular payments"]',
  );
  readonly amendDirectDebitsBtn = this.page.locator(
    '[aria-label="Amend your Direct Debit"]',
  );
  readonly startRegularPaymentsBtn = this.page.locator('text=Start regular payments');
  readonly topUpBtn = this.page.locator(
    'lg-display-payment-isa button:has-text("Top up")',
  );
  readonly stopPaymentsBtn = this.page.locator('[aria-label="Stop your Direct Debit"]');

  readonly regularPaymentEditor = this.page.locator('.regular-payment');
  readonly amountInput = this.page.locator('input[type="number"]');
  readonly amountRequiredValidationError = this.page.locator(
    'text=Please enter £20 or more',
  );
  readonly amountMinValidationError = this.page.locator(
    'text=Please enter a minimum of £20',
  );
  readonly amountMaxValidationError = this.page.locator(
    'text=We can\'t accept regular payments over £4,000',
  );
  readonly amendPaymentsReviewButton = this.page.locator('text="Review"');
  readonly amendPaymentsCancelButton = this.page.locator('form >> text=Cancel');
  readonly monthlyPaymentsDate = this.page.locator(
    'select[name="\\\'monthly-payment-date\\\'"]',
  );

  readonly changePaymentsBtn = this.page.locator('text=Change');

  // Regular payroll payments editor
  readonly regularPayrollPaymentsEditor = new IsaRegularPayrollPaymentsEditor(this.page);

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/payments/**');
    await this.page.locator('text=Your payments').waitFor();
  }
}
