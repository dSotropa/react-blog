import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
export class MultiFundPage extends BasePage {
  readonly backToSummaryBtn = this.page.locator('[data-test="sub-header-mobile"]');

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/multifund-options/**');
    await this.page.locator('text=Funds available to you').waitFor();
  }
}
