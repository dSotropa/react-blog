import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
export class FundDetailPage extends BasePage {
  readonly backToSummaryBtn = this.page.locator('[data-test="sub-header-mobile"]');

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/fund/**');
    await this.page.locator('text=Fund detail').waitFor();
  }
}
