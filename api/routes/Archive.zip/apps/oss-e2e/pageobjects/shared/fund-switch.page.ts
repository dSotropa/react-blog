import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
export class FundSwitchPage extends BasePage {
  readonly basicsOfRiskBtn = this.page.locator('button:has-text("The basics of risk")');

  readonly entryStep = {
    heading: this.page.locator(
      'text=Our five funds offer a different balance of risk and potential reward. Before ch',
    ),
    cancelBtn: this.page.locator('text=Cancel'),
    continueBtn: this.page.locator('text=Continue'),
    mediumRiskBtn: this.page.locator('text=Medium').nth(1),
    mediumRiskHeading: this.page.locator(
      'h2:has-text("Multi-Index 5 Fund - Medium Risk")',
    ),
    higherRiskBtn: this.page.locator('text=Higher').nth(1),
    higherRiskHeading: this.page.locator(
      'h2:has-text("Multi-Index 7 Fund - Higher Risk")',
    ),
    selectFundAlert: this.page.locator(
      'lg-alert:has-text("Please select a fund / risk level to change funds")',
    ),
    tabs: {
      details: {
        heading: this.page.locator('text=Investment split'),
      },
      performance: {
        btn: this.page.locator('button[role="tab"]:has-text("Performance")'),
        heading: this.page.locator('text=Fund Performance'),
      },
    },
  };

  // Understanding Investment Risk modal
  readonly undestandingRiskModal = {
    heading: this.page.locator('text=Understanding Investment Risk'),
    closeBtn: this.page.locator('button:has-text("Close")'),
  };

  readonly reviewStep = {
    heading: this.page.locator('text=Please review and confirm the details below'),
    backBtn: this.page.locator('text=Back'),
    confirmBtn: this.page.locator('button:has-text("Confirm change of funds")'),
  };

  readonly allDoneStep = {
    successMessage: this.page.locator('text=All done'),
    errorMessage: this.page.locator('text=Oops, something went wrong'),
    backToDashboardBtn: this.page.locator('text=Back to my dashboard'),
  };

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/fund-switch/**');
    await this.entryStep.heading.waitFor();
    await this.entryStep.cancelBtn.waitFor();
    await this.entryStep.continueBtn.waitFor();
  }
}
