import { Page } from '@playwright/test';

import { BasePage } from '../base.page';

export class StopDirectDebitDoneModal extends BasePage {
  readonly modal = this.page.locator('[aria-label="Stop Direct Debit Result"]');
  readonly gotItBtn = this.page.locator('text=Got it');

  constructor(page: Page) {
    super(page);
  }
}
