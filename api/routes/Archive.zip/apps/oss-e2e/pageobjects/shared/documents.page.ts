import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
export class DocumentsPage extends BasePage {
  readonly backToSummaryBtn = this.page.locator('[data-test="sub-header-mobile"]');
  readonly termsAndConditionsLink = this.page.locator('text=Terms and conditions');
  readonly keyInvestorInfoDocumentLink = this.page.locator(
    'text=Key investor information document',
  );
  readonly documentsAvailableSoonMsg = this.page.locator(
    'text=Documents will be available soon',
  );

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/documents/**');
    await this.page.locator('[data-test="overview"] >> text=Your documents').waitFor();
  }
}
