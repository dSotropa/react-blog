import { Page } from '@playwright/test';
import { MOCK_ENV, PageFunctions } from '@utility-e2e';

// eslint-disable-next-line @nrwl/nx/enforce-module-boundaries
import { testUsers } from '../../../oss-mock-server/src/test-users';

const WAIT_FOR_GHOST = 5000;

export class AuthenticationPage extends PageFunctions {
  testContext = require('../../models/test-context');
  readonly page: Page;

  constructor(page: Page) {
    super(page);
    this.page = page;
  }

  setUser(user: string): Array<string> {
    this.testContext.accountHash = testUsers[user].accountHash;

    return [ testUsers[user].username, testUsers[user].accountHash ];
  }

  assignCorrectUser(userRequired: string): Array<string> {
    return this.setUser(userRequired);
  }

  async navigate(user: string, waitForPageToLoad = true): Promise<void> {
    await this.page.goto(MOCK_ENV);

    await this.page.goto(`${MOCK_ENV}/activity/${testUsers[user].accountHash}`);

    if (waitForPageToLoad) {
      await this.waitForPageToLoad();
    }

    await this.page.waitForTimeout(WAIT_FOR_GHOST);

    await this.page.locator('.overview__ghost').first().waitFor({
      state: 'hidden',
    });
  }
}
