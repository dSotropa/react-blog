import { Page } from '@playwright/test';

import { BasePage } from '../base.page';

export class DrawdownMakeWithdrawalPage extends BasePage {
  readonly cancelBtn = this.page.locator('text=Cancel');
  readonly continueBtn = this.page.locator('text=Continue');
  readonly confirmWithdrawalBtn = this.page.locator('text=Confirm withdrawal');
  readonly withdrawalAmountInput = this.page.locator('input#amount');
  readonly withdrawalAmountMinError = this.page.locator(
    'text=Minimum withdrawal amount is £1',
  );
  readonly gotItBtn = this.page.locator('text=Got it');
  readonly insufficientFundsError = this.page.locator(
    'text=Insufficient funds available. Please enter a maximum of £1,423.91',
  );

  constructor(page: Page) {
    super(page);
  }

  async selectAllOptions(option: 'Yes' | 'No' = 'Yes') {
    await this.getRiskWarningOption('RetirementOptionsProvidersCheck', option).click();
    await this.getRiskWarningOption('PensionWiseGuidanceReceived', option).click();
    await this.getRiskWarningOption('FinancialAdviceReceived', option).click();
    await this.getRiskWarningOption('PensionWithdrawInvestCheck', option).click();
    await this.getRiskWarningOption('PensionPlanTaxConfirmed', option).click();
    await this.getRiskWarningOption('LumpSumFlexibilityCheck', option).click();
    await this.getRiskWarningOption('PensionPlanLifeIncomeExpected', option).click();
    await this.getRiskWarningOption('PensionPlanHealthAware', option).click();
    await this.getRiskWarningOption('PensionPlanDependentsFinance', option).click();
    await this.getRiskWarningOption('PensionInflationImpactCheck', option).click();
    await this.getRiskWarningOption('PensionStateBenefitRiskCheck', option).click();
    await this.getRiskWarningOption('PensionPlanDebtRiskCheck', option).click();
    await this.getRiskWarningOption('InvestmentScamAware', option).click();
  }

  getRiskWarningOption(
    id:
      | 'RetirementOptionsProvidersCheck'
      | 'PensionWiseGuidanceReceived'
      | 'FinancialAdviceReceived'
      | 'PensionWithdrawInvestCheck'
      | 'PensionPlanTaxConfirmed'
      | 'LumpSumFlexibilityCheck'
      | 'PensionPlanLifeIncomeExpected'
      | 'PensionPlanHealthAware'
      | 'PensionPlanDependentsFinance'
      | 'PensionInflationImpactCheck'
      | 'PensionStateBenefitRiskCheck'
      | 'PensionPlanDebtRiskCheck'
      | 'InvestmentScamAware',
    option: 'Yes' | 'No',
  ) {
    return this.page.locator(`#${id} >> text="${option}"`);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/adhoc-withdrawal/**');
    await this.page.locator('h1:has-text("Make a withdrawal")').waitFor();
  }
}
