import { Page } from '@playwright/test';

import { OssMainPage } from '../oss-main.page';
export class DrawdownActivityPage extends OssMainPage {
  readonly manageRetirementDropDown = this.page.locator('[text="Manage retirement"]');
  readonly retirementDropdownItems = this.page.locator(
    '.dropdown-menu lg-dropdown-menu-item',
  );

  // Investments tile
  readonly investmentPathwayLink = this.page.locator(
    '.investment-pathway__pathway-title a',
  );
  readonly sterlingCorpBondIndexFundLink = this.page.locator(
    'a:text("Sterling Corporate Bond Index Fund")',
  );
  readonly changeInvestmentPathway = this.page.locator(
    'button.start-switch-pathway-journey',
  );

  // Withdrawals tile
  readonly makeWithdrawalBtn = this.page.locator('text=Make a withdrawal');
  readonly stopRegularIncomeBtn = this.page.locator('text=Stop regular income');
  readonly stopRegularIncomeModal = this.page.locator(
    '[id="stopRegularIncomeConfirmationModal"]',
  );

  // Confirm and all done modals
  readonly investmentPathwayDetailModal = this.page.locator(
    'text=Investment pathway detail',
  );
  readonly investmentPathwayDetailCloseBtn = this.page.locator(
    '[data-test="close-modal"]',
  );
  readonly confirmBtn = this.page.locator('text=Confirm');
  readonly gotItBtn = this.page.locator('text=Got it');
  readonly stopRegularIncomeResultModal = this.page.locator(
    '[id="stopRegularIncomeResultModal"]',
  );

  constructor(page: Page) {
    super(page);
  }

  getWidget(widgetName: string) {
    return this.page.locator(`[aria-label="${widgetName}"] h2`);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/activity/**');
    await this.page.locator('text=Retirement account').waitFor();
  }
}
