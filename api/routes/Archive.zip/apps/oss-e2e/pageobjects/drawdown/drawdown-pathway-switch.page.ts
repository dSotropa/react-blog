import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
export class DrawdownPathwaySwitchPage extends BasePage {
  readonly cancelBtn = this.page.locator('text=Cancel');
  readonly continueBtn = this.page.locator('text=Continue');
  readonly backBtn = this.page.locator('button:has-text("Back")');

  readonly accordion = this.page.locator('.lg-accordion__heading-toggle');
  readonly accordionOpen = this.page.locator('.lg-accordion__heading-toggle--active');
  readonly unreadErrorAlert = this.page.locator(
    'text="Please read your unread options and then select an Investment Pathway"',
  );

  readonly noPlanNext5Years = this.page.locator('[id="title-GB00B8VZ3F59"]');
  readonly startIncomeNext5Years = this.page.locator('[id="title-GB00B88Y0217"]');
  readonly takeMoneyNext5Years = this.page.locator('[id="title-GB00BKGR3H21"]');

  readonly takeOutMoneySelectBtn = this.page.locator('[for="select-GB00BKGR3H21"]');
  readonly investmentsPathwayBackBtn = this.page.locator('button:has-text("Back")');
  readonly confirmChangeOfPathWay = this.page.locator(
    'button:has-text("Confirm change of pathway")',
  );

  readonly backToMyDashboard = this.page.locator('text=Back to My Dashboard');

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/pathway-switch/**');
    await this.page.locator('h1:has-text("Change your investment pathway")').waitFor();
    await this.cancelBtn.waitFor();
    await this.continueBtn.waitFor();
    await this.accordion.waitFor();
  }
}
