import { Page } from '@playwright/test';

import { BasePage } from './base.page';

/**
 * Main wrapper page for OSS.
 */
export class OssMainPage extends BasePage {
  // Header
  readonly menuItems = this.page.locator('[id="primary-nav"] a');
  readonly breadcrumbContainer = this.page.locator('.breadcrumb-container');

  // Common tiles, used for ISA, Pension and Drawdown
  readonly investmentsTile = {
    tile: this.page.locator(
      '[aria-label="Investments"] [data-test="widget-title"] >> text=Investments',
    ),
    multiIndex3FundLink: this.page.locator('text=Multi-Index 3 Fund'),
    changeInvestmentsBtn: this.page.locator('button:has-text("Change investments")'),
  };

  readonly documentsTile = this.page.locator('span:has-text("Documents")');
  readonly thePulseTile = this.page.locator('text="The Pulse"');

  // Footer links
  readonly accessibilityLink = this.page.locator(
    '[href="https://www.legalandgeneral.com/log-in/shared-pages/footer-links/accessibility.html"]',
  );
  readonly legalInformationLink = this.page.locator(
    '[href="https://www.legalandgeneral.com/log-in/shared-pages/footer-links/legal.html"]',
  );
  readonly cookiePolicyLink = this.page.locator(
    '[href="https://www.legalandgeneral.com/privacy-policy/cookies.html"]',
  );
  readonly privacyPolicyLink = this.page.locator(
    '[href="https://www.legalandgeneral.com/privacy-policy"]',
  );
  readonly securityInformationLink = this.page.locator(
    '[href="https://www.legalandgeneral.com/log-in/shared-pages/footer-links/security.html"]',
  );
  readonly navFooterLGLogo = this.page.locator('.lg-footer-logo__img');

  constructor(page: Page) {
    super(page);
  }
}
