import { Locator, Page } from '@playwright/test';
import { AccessibilityFunctions, PageFunctions, VisualFunctions } from '@utility-e2e';

import { AuthenticationPage } from './shared/authentication.page';

/**
 * Base class for all page objects
 */
export class BasePage extends PageFunctions {
  readonly authenticationPage: AuthenticationPage;

  // Elements with known accesibility issues. These will be addressed in
  // https://legalandgeneral.atlassian.net/browse/PI-408
  readonly IgnoreElements = [
    // ARIA tooltip nodes must have an accessible name (IsaAllowanceSidebarComponent)
    'id="remaining-allowance-for-this-tax-year-info"',

    // Elements must have sufficient color contrast
    'ng-star-inserted',
    'class="btn btn-cta"',
    'class="review-dd__item-term"',
    'class="title-stop"',
    'class="heading"',
    'href="https://test.myaccount.platform.landg.com"',
    'class=lg-primary-nav-item lg-primary-nav-item--active',
    'id="StopRegularIncomeConfirmationComponent"',
    'data-test="sub-header-mobile"',
    'id="PathwayDetailsModalComponent"',
    'class="modal-content__title"',
    'class="modal-content__detail"',
    'aria-current="page"',
    'class="fieldset-label"',
    'class="title"',
    'class="title-bank-details"',
    'class="title-dd"',
    '>Amount</dt>',
    'class="summary__title"',
    '>Bringing all of your ISAs together in one place c',
    'Important considerations</h2>',
    'class="risk-question',
    'class="h3">Your tax free cash</h2>',
    '>Your tax free cash</h2>',
    '<span>',
    'btn-chevron"> Start a transfer </button>',
    '<p>View your drawdown illustration here</p>',
    '<p> If you choose to have us send the ISA transfer form by post it takes 5 working days to process and send out to you. If this is ok, click below or return to the previous screen where you can download and print the form yourself. </p>',
    '<p>View your drawdown illustration here</p>',
    'class="regular-payment-info__active-dd-title',
    'class="understanding-risk__investment-content"',
    'class="invested-pathway__intro"',
    'class="pathway__warning"',
    'There is nearly £20 billion of unclaimed pensions from',
    'Find your old and lost pensions',
    'tabindex="0">Please wait</h1>',
    'class="summary__switch-title">Changing from:</h3>',
    '> As you start your pension drawdown, you can take a lump sum of 25% from your pot. </p>',
    'class="summary__switch-title">Switching from:</h3>',
    'class="form-label',
    '>Change regular contribution</span>',
    '<h1 class="centre">All done</h1>',
    'id="title-GB00B8VZ3F59"',
    'class="step-heading">Your Pension Wise appointment</h2>',
    '>Total value</span>',
    '<p>Before you start your application have your pension details ready.',
    'class="appointment-page__text">',
    '>Start regular income</span>',
    '>Multi-Index 3 Fund facts</span>',

    // Other
    'regular-payment-info__active-dd-about',
    'aria-label="Change your regular payments"',
    'class="h4">For your consideration:</h2>',
    'id="paymentConfirmationDialog"',
    '>£1,130.00</span>',
    '<dl _ngcontent',
    'class="direct-debit-detail-label"',
    'type="text" autocomplete="off" aria-autocomplete="list"',
    'id="total-value-info"',
    'id="lifetime-allowance-and-final-salary-pensions-info"',
  ];

  constructor(page: Page) {
    super(page);
    this.authenticationPage = new AuthenticationPage(page);
  }

  /**
   * Helper function to click a button after a short delay.
   * Playwright is supposed to wait for buttons to be ready before clicking them, but it does not always work
   * @param locator The locator for the button to click
   * @param delay The time to wait before clicking. Defaults to 500ms;
   */
  async clickButton(locator: Locator, delay = 500) {
    await this.page.waitForTimeout(delay);
    await locator.waitFor();
    await locator.click({ delay });
  }

  /**
   * Performs acessibility and visual checks on the page
   * @param delay Optional delay in millisenconds (default 1000) before performing the checks. Useful when checking pages with animations and we need to wait for the animation to complete
   */
  async accessibilityCheck(delay = 1000): Promise<void> {
    await this.page.waitForTimeout(delay);
    await new AccessibilityFunctions(this.page, this.IgnoreElements).injectAxe();
  }

  /**
   * Performs acessibility and visual checks on the page
   * @param visualFunctions The instance of the visual functions class
   * @param pageName The name of the page (title) to be displayed in appliTools.
   * @param skipVisualChecks Optional flag (default false) to indicate whether visual checks should be skipped. Useful when running tests locally.
   * @param delay Optional delay in millisenconds (default 2s000) before performing the checks. Useful when checking pages with animations and we need to wait for the animation to complete
   */
  async pageCheck(
    visualFunctions: VisualFunctions,
    pageName: string,
    skipVisualChecks: boolean,
    delay = 2000,
  ): Promise<void> {
    await this.accessibilityCheck(delay);

    if (!skipVisualChecks) {
      await visualFunctions.eyesCheck(pageName, this.page, {});
    }
  }
}
