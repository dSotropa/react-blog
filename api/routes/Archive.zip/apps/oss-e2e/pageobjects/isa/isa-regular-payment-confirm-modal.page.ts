import { Page } from '@playwright/test';

import { BasePage } from '../base.page';

export class IsaRegularPaymentConfirmModal extends BasePage {
  readonly modal = this.page.locator('text=Please confirm your regular payment');
  readonly backButton = this.page.locator('button:text("Back")').nth(1);
  readonly confirmBtn = this.page.locator('button:text("Confirm")').nth(1);

  constructor(page: Page) {
    super(page);
  }
}
