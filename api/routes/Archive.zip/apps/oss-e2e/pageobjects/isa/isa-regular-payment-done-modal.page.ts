import { Page } from '@playwright/test';

import { BasePage } from '../base.page';

export class RegularPaymentDoneModal extends BasePage {
  readonly modal = this.page.locator('text=All done');
  readonly backToDashboardBtn = this.page
    .locator('button:text("Back to my dashboard")')
    .nth(1);
  readonly gotItBtn = this.page.locator('text=Got it').nth(1);
  readonly errorLabel = this.page.locator('text=Oops, something went wrong');

  constructor(page: Page) {
    super(page);
  }
}
