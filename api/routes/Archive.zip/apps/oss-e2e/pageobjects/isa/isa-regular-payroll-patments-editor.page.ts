import { Page } from '@playwright/test';

import { BasePage } from '../base.page';

export class IsaRegularPayrollPaymentsEditor extends BasePage {
  readonly reviewBtn = this.page.locator('text=Review');
  readonly input = this.page.locator('id=regularPaymentValue');
  readonly amountOption = this.page.locator('label:has-text("£")').first();
  readonly percentOption = this.page.locator('label:has-text("%")').first();
  readonly minPercentError = this.page.locator('text=Please enter at least 1%');
  readonly maxPercentError = this.page.locator('text=Please enter a maximum of 100%');
  readonly minAmountError = this.page.locator(
    'text="Please enter £20 or more for regular payments"',
  );
  readonly maxAmountError = this.page.locator('text="Please enter a maximum of £20,000"');
  constructor(page: Page) {
    super(page);
  }
}
