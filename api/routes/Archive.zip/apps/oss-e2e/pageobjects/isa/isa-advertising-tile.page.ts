import { Page } from '@playwright/test';

import { BasePage } from '../base.page';

export class IsaAdvertisingTilePage extends BasePage {
  readonly heading = this.page.locator(
    'text=Top up your ISA before the tax year ends in 22 days.',
  );
  readonly topUpBtn = this.page.locator('[aria-label="Top Up"]');

  constructor(page: Page) {
    super(page);
  }
}
