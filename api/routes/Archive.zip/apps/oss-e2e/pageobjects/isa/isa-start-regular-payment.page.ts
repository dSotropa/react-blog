import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
export class IsaStartRegularPaymentPage extends BasePage {
  readonly backBtn = this.page.locator('text=Back');
  readonly reviewBtn = this.page.locator('text=Review');
  readonly submitBtn = this.page.locator('text=Submit');
  readonly gotItBtn = this.page.locator('text=Got it');

  readonly minAmountError = this.page.locator(
    'div[role="alert"]:has-text("Please enter £20 or more for regular payments")',
  );
  readonly minPercentError = this.page.locator('text=Please enter at least 1%');
  readonly amountBtn = this.page.locator('label:has-text("£")');
  readonly percentBtn = this.page.locator('label:has-text("%")');
  readonly amountInput = this.page.locator('id=regularPaymentValue');

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/start-regular-payment/**');

    await this.page
      .locator(
        'text=Manage and update your regular payments deducted from your net salary',
      )
      .waitFor();
  }
}
