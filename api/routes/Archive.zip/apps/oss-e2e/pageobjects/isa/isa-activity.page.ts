import { Page } from '@playwright/test';

import { OssMainPage } from '../oss-main.page';

import { IsaAdvertisingTilePage } from './isa-advertising-tile.page';
import { IsaRegularPayrollPaymentsEditor } from './isa-regular-payroll-patments-editor.page';

export class IsaActivityPage extends OssMainPage {
  // Payments tile
  readonly paymentsTile = this.page.locator(
    '[aria-label="Payments"] [data-test="widget-title"] >> text=Payments',
  );
  readonly startRegularPaymentsBtn = this.page.locator(
    'button:has-text("Start regular payments")',
  );
  readonly stopRegularPaymentsBtn = this.page.locator(
    '[aria-label="stop your regular payments"]',
  );
  readonly pausePaymentsBtn = this.page.locator(
    '[aria-label="pause your regular payments"]',
  );
  readonly topUpBtn = this.page.locator('button:has-text("Top up your ISA")');
  readonly changePaymentsBtn = this.page.locator('text=Change');
  readonly startIsaTransferBtn = this.page.locator(
    'button:has-text("Start an ISA transfer")',
  );
  readonly withdrawFromIsaBtn = this.page.locator(
    'button:has-text("Withdraw from your ISA")',
  );
  readonly regularPayrollPaymentsEditor = new IsaRegularPayrollPaymentsEditor(this.page);

  // Pause payments confirm modal
  readonly pausePaymentsModal = this.page.locator(
    '[aria-label="pause your regular payments"]',
  );
  readonly pausePaymentsModalCancelBtn = this.page.locator('text=Cancel').nth(1);
  readonly pausePaymentsModalConfirmlBtn = this.page.locator('text=Confirm').nth(2);

  // Pause payments all done modal
  readonly gotItBtn = this.page.locator('text=Got it').nth(1);

  // Investments tile
  readonly investmentAvailableSoonMsg = this.page.locator(
    'text=Investment will be available soon',
  );
  readonly viewInvestmentOptionsBtn = this.page.locator(
    'button:has-text("View investment options")',
  );

  // Documents tile
  readonly documentsAvailableSoonMsg = this.page
    .locator('[aria-label="Documents"] div:has-text("Documents will be available soon")')
    .nth(1);

  // Other tiles
  readonly feesAndChargesTile = this.page.locator('span:has-text("Fees and charges")');

  readonly manageIsaButton = this.page.locator('button:has-text("Manage ISA")');

  // ISA Allowance widget
  readonly isaAllowanceTopUpBtn = this.page.locator(
    'lg-isa-allowance-sidebar >> text=Top up',
  );

  // Dropdown
  readonly manageIsaDropdownItems = this.page.locator(
    '.dropdown-menu lg-dropdown-menu-item',
  );
  readonly startRegularPaymentsMenuBtn = this.page.locator(
    'button[role="menuitem"]:has-text("Start regular payments")',
  );

  // Isa transfer overlay
  readonly isaTransferOverlay = this.page.locator(
    'text=How does the transfer process work?',
  );
  readonly isaTransferContinueBtn = this.page.locator('text=Continue');

  readonly advertisingTile: IsaAdvertisingTilePage = new IsaAdvertisingTilePage(
    this.page,
  );

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/activity/**');
    await this.page.locator('text=ISA overview').waitFor();
  }
}
