import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
export class IsaTopUpPage extends BasePage {
  readonly backBtn = this.page.locator('text=Back');
  readonly nextBtn = this.page.locator('text=Next');
  readonly reviewBtn = this.page.locator('text=Review');

  readonly byDebitCardButton = this.page.locator('text=By debit card');
  readonly byPayrollBtn = this.page.locator('text=By payroll');
  readonly amountInput = this.page.locator('input[type="number"]');
  readonly paymentMethodRequiredError = this.page.locator(
    'text=Please select a top up payment method',
  );
  readonly amountRequiredError = this.page.locator('text=Please enter £1 or more');
  readonly wholeNumberError = this.page.locator('text=Please enter a whole number');
  readonly maxAmountError = this.page.locator('text=Please enter a maximum of £18,870');

  // Review page
  readonly reviewPageHeading = this.page.locator('text=Review your Top up details');
  readonly topUpBtn = this.page.locator('text=Top up £1,000');
  readonly topUpBtnFailScenario = this.page.locator('text=Top up £666');

  // All done page
  readonly allDoneStep = {
    allDoneMessage: this.page.locator('text=All done'),
    errorMessage: this.page.locator('text=Oops, something went wrong'),
    backToDashboardBtn: this.page.locator('text=Back to my dashboard'),
    gotItBtn: this.page.locator('text=Got it'),
    feedbackBtn: this.page.getByRole('button', { name: 'Feedback' }),
    feedbackSurveyCloseBtn: this.page.getByRole('img', { name: 'Close' }),
  };

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/isa-top-up/**');
    await this.page.locator('h1:has-text("Top up your ISA")').waitFor();
    await this.backBtn.waitFor();
    await this.nextBtn.waitFor();
  }
}
