import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
export class IsaTransferPage extends BasePage {
  readonly backBtn = this.page.locator('text=Back');
  readonly startTransferBtn = this.page.locator('text=Start an ISA transfer');
  readonly continueBtn = this.page.locator('text=Continue');

  // Isa details page
  readonly isaDetailsHeading = this.page.locator('text=Your ISA details');
  readonly acountProviderInput = this.page.locator('input[role="combobox"]');
  readonly accountNumberInput = this.page.locator('[aria-label="Account number"]');
  readonly accountProviderError = this.page.locator('text=Please enter a valid provider');
  readonly accountNumberError = this.page.locator('text=Please enter an account number');

  // Print, sign and post page
  readonly printPage = this.page.locator('text=Print, sign and post your form');
  readonly sendByPostBtn = this.page.locator('text=Send form to me by post');

  // Confirm modal
  readonly confirmModal = this.page.locator(
    'text=Are you sure you want the form sent by post?',
  );
  readonly cancelBtn = this.page.locator('text=Cancel');
  readonly sendInPostBtn = this.page.locator('text=Send in the post');

  // Transfer being prepared page
  readonly transferBeingPerparedPage = this.page.locator(
    'text=The transfer form is being prepared',
  );
  readonly backToDashboardBtn = this.page.locator('text=Back to my dashboard');

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/isa-transfer-in/**');
    await this.page.locator('text=Important information').waitFor();
    await this.backBtn.waitFor();
    await this.startTransferBtn.waitFor();
  }
}
