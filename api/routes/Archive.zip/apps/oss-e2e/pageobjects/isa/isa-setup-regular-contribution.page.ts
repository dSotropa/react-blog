import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
export class IsaSetupRegularContributionPage extends BasePage {
  readonly isaBreadcrumb = this.page.locator('button:has-text("ISA")');
  readonly backBtn = this.page.locator('text=Back');
  readonly continueBtn = this.page.locator('text=Continue');

  // Monthly direct debit step
  readonly monthlyDirectDebitHeader = this.page.locator(
    'text=Monthly Direct Debit Payment',
  );
  readonly amountInput = this.page.locator('input[type="number"]');
  readonly amountRequiredError = this.page.locator('text=Please enter £20 or more');
  readonly amountMinError = this.page.locator('text=Please enter a minimum of £20');
  readonly amountWholeNumberError = this.page.locator('text=Please enter a whole number');
  readonly amountMaxError = this.page.locator(
    'text=We can\'t accept regular payments over £4,000',
  );
  readonly amountRequiredBtn = this.page.locator('text=Amount required');
  readonly addBtn = this.page.locator('text=Add £120 every month');
  readonly addBtnFailScenario = this.page.locator('text=Add £1,002 every month');

  // Enter direct debit details step
  readonly directDebitDetailsHeader = this.page.locator(
    'text=Please enter your Direct Debit details',
  );
  readonly sortCode1Input = this.page.locator(
    '[aria-label="first two characters of your sort code"]',
  );
  readonly sortCode2Input = this.page.locator(
    '[aria-label="second two characters of your sort code"]',
  );
  readonly sortCode3Input = this.page.locator(
    '[aria-label="third two characters of your sort code"]',
  );
  readonly sortCodeError = this.page.locator('text=Please enter a 6 digit sort code');
  readonly accountNumberInput = this.page.locator('id=bank-account-number');
  readonly accountNumberError = this.page.locator(
    'text=Please enter an 8 digit account number',
  );
  readonly dateSelect = this.page.locator('select[name="monthly-payment-date"]');
  readonly dateError = this.page.locator('text=Please enter a date');

  // Review direct debit details step
  readonly reviewdirectDebitDetailsHeader = this.page.locator(
    'text=Please review your Direct Debit details',
  );
  readonly confirmCheckbox = this.page.locator(
    'text=I confirm I am the account holder and the only person required to authorise debi',
  );
  readonly confirmMonthlyPmtBtn = this.page.locator('text=Confirm monthly payment');
  readonly allDoneMessage = this.page.locator('text=All done');
  readonly errorMessage = this.page.locator('text=Oops, something went wrong');
  readonly backToDashboarBtn = this.page.locator('text=Back to my dashboard');

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/direct-debit/**');

    await this.page
      .locator(
        'text=All the normal Direct Debit safeguards and guarantees apply when you setup an in',
      )
      .waitFor();

    await this.backBtn.waitFor();
    await this.continueBtn.waitFor();
  }
}
