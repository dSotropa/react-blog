import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
export class IsaWithdrawalPage extends BasePage {
  readonly nextBtn = this.page.locator('button:has-text("Next")');
  readonly backBtn = this.page.locator('button:has-text("Back")');

  readonly amountInput = this.page.locator('input[type="number"]');
  readonly amountMinError = this.page.locator('text=Please enter £1 or more');
  readonly amountMaxError = this.page.locator(
    'text=Maximum amount to be withdrawn is 90% of your current ISA value. If you wish to take more, please click "Withdraw full amount"',
  );
  readonly amountWholeNumberError = this.page.locator('text=Please enter a whole number');
  readonly fullAmountCheckbox = this.page.locator('text=Withdraw full amount');
  readonly importantInformationAlert = this.page.locator('text=Important information:');

  // Review page
  readonly reviewPageHeading = this.page.locator(
    'text=Review your withdrawal amount and bank details',
  );
  readonly withdraw99Btn = this.page.locator('text=Withdraw £99');
  readonly withdraw666Btn = this.page.locator('text=Withdraw £666');
  readonly withdrawFullBtn = this.page.locator('text=Withdraw full balance');

  // All done page
  readonly allDoneMessage = this.page.locator('text=All done');
  readonly errorMessage = this.page.locator('text=Oops, something went wrong');
  readonly backToDashboardBtn = this.page.locator('text=Back to my dashboard');

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/isa-withdrawal/**');
    await this.page.locator('h1:has-text("Withdraw from your ISA")').waitFor();
  }
}
