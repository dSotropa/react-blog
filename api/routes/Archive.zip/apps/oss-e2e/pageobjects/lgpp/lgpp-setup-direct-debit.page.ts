import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
export class LgppSetupDirectDebitPage extends BasePage {
  readonly personalPensionBreadcrumb = this.page.locator(
    'button:has-text("Personal Pension")',
  );
  readonly continueBtn = this.page.locator('text=Continue');
  readonly backBtn = this.page.locator('text=Back');

  readonly overview = {
    heading: this.page
      .locator(
        '#journeyOverview div:has-text("All the normal Direct Debit safeguards and guarantees apply when you setup an in")',
      )
      .first(),
  };

  readonly paymentStep = {
    heading: this.page.locator('text=Monthly Direct Debit Payment'),
    amountInput: this.page.locator('input[type="number"]'),
    amountRequiredError: this.page.locator('text=Please enter £1 or more'),
    amountMinError: this.page.locator('text=Please enter a minimum of £1'),
    amountWholeNumberError: this.page.locator('text=Please enter a whole number'),
    amountWithTopupParagraph: this.page.locator('.amount-with-tax-top-up'),
    addBtn: this.page.locator('button[type=submit]'),
  };

  readonly directDebitDetailsStep = {
    heading: this.page.locator('text=Please enter your Direct Debit details'),
    sortCodeInput1: this.page.locator(
      '[aria-label="first two characters of your sort code"]',
    ),
    sortCodeInput2: this.page.locator(
      '[aria-label="second two characters of your sort code"]',
    ),
    sortCodeInput3: this.page.locator(
      '[aria-label="third two characters of your sort code"]',
    ),
    sortCodeRequiredError: this.page.locator('text=Please enter a 6 digit sort code'),
    accountNumberInput: this.page.locator('#bank-account-number'),
    accountNumberRequiredError: this.page.locator(
      'text=Please enter an 8 digit account number',
    ),
    bankNameMessage: this.page.locator('text=BARCLAYS BANK PLC'),
    monthlyPaymentDateSelect: this.page.locator('select[name="monthly-payment-date"]'),
    monthlPaymentDateRequiredError: this.page.locator('text=Please enter a date'),
    confirmCheckbox: this.page.locator(
      'text=I confirm I am the account holder and the only person required to authorise debi',
    ),
    confirmRequiredError: this.page.locator(
      'text=Please confirm you are the account holder',
    ),
  };

  readonly reviewStep = {
    heading: this.page.locator('text=Please review your Direct Debit details'),
    confirmBtn: this.page.locator('text=Confirm monthly payment'),
  };

  readonly allDoneStep = {
    successMessage: this.page.locator('text=All done'),
    errorMessage: this.page.locator('text=Oops, something went wrong'),
    backToDashboardtn: this.page.locator('text=Back to my dashboard'),
  };

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/direct-debit/**');
    await this.overview.heading.waitFor();
    await this.personalPensionBreadcrumb.waitFor();
  }
}
