import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
export class LgppAdvertisingTilePage extends BasePage {
  readonly pauseBtn = this.page.locator('button:has-text("Stop Animation")');

  readonly suatainableFunds = {
    heading: this.page.locator('text=Are our sustainable funds right for you?').nth(1),
  };

  readonly taxYearEnd = {
    heading: this.page
      .locator('text=Top up your Pension before the tax year ends in 22 days')
      .nth(1),
    topUpBtn: this.page.locator('[aria-label="Top Up"]'),
  };

  readonly simplifyYourPension = {
    heading: this.page.locator('text=Simplify your pension saving').nth(1),
    howATransferWorksBtn: this.page.locator('[aria-label="How a transfer works"]'),
    startTransferBtn: this.page.locator('text=Start a transfer'),
    infoPage: this.page.locator(
      'text=Simplify your pension saving Hello Eden, if you\'ve got pensions with different p',
    ),
  };
  readonly findLostPensions = {
    heading: this.page.locator('text=Find your lost and old pensions').nth(1),
    startTracingBtn: this.page.locator('text=Start tracing').nth(1),
    howTracingWorksBtn: this.page.locator('[aria-label="How tracing works"]'),
    infoPage: this.page.locator(
      'text=Find your old and lost pensions Hello Eden.There is nearly £20 billion of unclai',
    ),
  };

  constructor(page: Page) {
    super(page);
  }

  readonly tileBtn = (option: number) =>
    this.page.locator(`button[role="tab"]:has-text("advertisingTile ${option}")`);

  async initialiseAndPause() {
    // Pause the advertising carousel so we can get consistent results for visual checks
    await this.pauseBtn.click();
    await this.tileBtn(1).click();
  }
}
