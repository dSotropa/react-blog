import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
export class LgppMoveToDrawdownPage extends BasePage {
  readonly personalPensionBreadcrumb = this.page.locator(
    'button:has-text("Personal Pension")',
  );
  readonly cancelBtn = this.page.locator('button:has-text("Cancel")');
  readonly backBtn = this.page.locator('text=Back');
  readonly continueBtn = this.page.locator('text=Continue');
  readonly continueBtn2 = this.page.locator('[data-test="continue"]');

  readonly whatYouNeedToKnowStep = {
    heading: this.page.locator('text=What you need to know'),
    keyFeaturesLink: this.page.locator(
      '[href="https://www.legalandgeneral.com/landg-assets/personal/retirement/_resources/documents/your-retirement-income/key-features/q59826.pdf"]',
    ),
    termsAndConditionsLink: this.page.locator(
      '[href="https://www.legalandgeneral.com/landg-assets/personal/retirement/_resources/documents/your-retirement-income/terms-and-conditions/q59984.pdf"]',
    ),
  };

  readonly pensionWiseStep = {
    heading: this.page.locator('h2:has-text("Your Pension Wise appointment")'),
    appointmentSelect: this.page.locator('select'),
    infoMessage: this.page
      .locator(
        'form div:has-text("The decisions you make about your pension pot are important and the free guidanc")',
      )
      .nth(1),
  };

  readonly importantConsiderationsStep = {
    heading: this.page.locator('text=Important considerations'),
    validationError: this.page.locator('text=Please select an answer'),
    option: (index: number, yesOrNo: 'Yes' | 'No') =>
      this.page.locator(`label:has-text("${yesOrNo}")`).nth(index),
  };

  readonly taxFreeCashStep = {
    heading: this.page.locator('h2:has-text("Your tax free cash")'),
    checkbox: this.page.locator('text=I have read the above'),
    validationError: this.page.locator(
      'text=Please confirm that you have read the above',
    ),
  };

  readonly investmentPathwaysStep = {
    heading: this.page.locator('text=Your investment pathways'),
    validationError: this.page.locator(
      'text=Please read your unread options and then select an Investment Pathway',
    ),
    option1: this.page.locator(
      'text=I have no plans to touch my money in the next 5 years',
    ),
    option2: this.page.locator(
      'button:has-text("I plan to use my money to setup a guaranteed income (annuity) within the next 5 ")',
    ),
    option3: this.page.locator(
      'text=I plan to start taking my money as a long-term income within the next 5 years',
    ),
    option4: this.page.locator(
      'text=I plan to take out all my money within the next 5 years',
    ),
    select4: this.page.locator(
      'text=I plan to take out all my money within the next 5 years read Select >> label',
    ),
    paragraph4: this.page.locator(
      'text=This option supports people who expect to withdraw their entire drawdown account',
    ),
  };

  readonly incomeOptionsStep = {
    heading: this.page.locator('text=Your income options'),
    amountInput: this.page.locator('input[type="text"]'),
    frequencySelect: this.page.locator(
      'text=How often? Monthly Quarterly Half yearly Annually >> select',
    ),
    daySelect: this.page.locator(
      'text=Day of the month1st2nd3rd4th5th6th7th8th9th10th11th12th13th14th15th16th17th18th1 >> select',
    ),
    option1No: this.page.locator('label:has-text("No")').first(),
    option2No: this.page.locator('label:has-text("No")').nth(1),
    warningMessage: this.page.locator(
      'text=Once you have taken your tax-free cash, any further money you take will count to',
    ),
  };

  readonly pensionsMillionaireStep = {
    heading: this.page.locator('text=Are you a pensions millionaire?'),
    validationError: this.page.locator('text=Please select an answer'),
    message: this.page.locator(
      'text=We\'ll contact you to take additional information about your pensions and their c',
    ),
    option: (index: number, yesOrNo: 'Yes' | 'No') =>
      this.page.locator(`label:has-text("${yesOrNo}")`).nth(index),
  };

  readonly importantConsiderations2Step = {
    heading: this.page.locator('text=Important considerations'),
    option: (index: number, yesOrNo: 'Yes' | 'No') =>
      this.page.locator(`label:has-text("${yesOrNo}")`).nth(index),
  };

  readonly summaryStep = {
    heading: this.page.locator('text=Your summary'),
    validationError: this.page.locator(
      'text=Please confirm that you have read the above',
    ),
    checkbox: this.page.locator('text=My details are correct and I want to invest'),
  };

  readonly beforeAppplyStep = {
    heading: this.page.locator('text=My details are correct and I want to invest'),
    sortCodeInput1: this.page.locator(
      '[aria-label="first two characters of your sort code"]',
    ),
    sortCodeInput2: this.page.locator(
      '[aria-label="second two characters of your sort code"]',
    ),
    sortCodeInput3: this.page.locator(
      '[aria-label="third two characters of your sort code"]',
    ),
    sortCodeRequiredError: this.page.locator('text=Please enter a 6 digit sort code'),
    accountNumberInput: this.page.locator('#bank-account-number'),
    accountNumberRequiredError: this.page.locator(
      'text=Please enter an 8 digit account number',
    ),
    bankNameMessage: this.page.locator('text=BARCLAYS BANK PLC'),
  };

  readonly requestReceivedStep = {
    heading: this.page.locator('text=We’ve received your request'),
    phoneLink: this.page.locator('[href="tel:03456780020"]'),
  };

  readonly allDoneStep = {
    successText: this.page.locator('text=All done'),
    errorText: this.page.locator(
      'text=Unfortunately, we’ve not been able to process your request to move to drawdown, ',
    ),
  };

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/move-to-drawdown/**');
    await this.page.locator('h1:has-text("Apply for drawdown")').waitFor();
    await this.page.locator('text=What you need to know').waitFor();
    await this.personalPensionBreadcrumb.waitFor();
  }
}
