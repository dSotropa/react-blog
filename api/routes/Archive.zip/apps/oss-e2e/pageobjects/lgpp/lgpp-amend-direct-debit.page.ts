import { Page } from '@playwright/test';

import { LgppSetupDirectDebitPage } from './lgpp-setup-direct-debit.page';

export class LgppAmendDirectDebitPage extends LgppSetupDirectDebitPage {
  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/direct-debit/**');
    await this.paymentStep.heading.waitFor();
    await this.paymentStep.addBtn.waitFor();
    await this.backBtn.waitFor();
    await this.paymentStep.addBtn.waitFor();
  }
}
