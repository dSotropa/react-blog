import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
export class LgppPensionTopUpPage extends BasePage {
  readonly backBtn = this.page.locator('text=Back');

  readonly entryStep = {
    addBtn: this.page.locator('button[type=submit]'),
    amountInput: this.page.locator('input[type="number"]'),
    amountRequiredError: this.page.locator('text=Please enter £1 or more'),
    amountMinError: this.page.locator('text=Please enter a minimum of £1'),
    amountMaxError: this.page.locator('text=Please enter a maximum of £999,999'),
    personalDebitCardOption: this.page.locator('text=Personal debit card'),
    businessDebitCardOption: this.page.locator('text=Business debit card'),
    businessDebitCardAlert: this.page.locator(
      'text=You can only make a payment from this card if you are a company director or shar',
    ),
    wholeNumberError: this.page.locator('text=Please enter a whole number'),
  };

  readonly companyDetailsStep = {
    heading: this.page.locator('text=Add your company details'),
    crnInput: this.page.locator('input[type="string"]'),
    crnRequiredError: this.page.getByText('Company registration number is required'),
    crnMinLenghError: this.page.getByText(
      'Company registration number must be exactly 8 characters',
    ),
    crnNotRecognisedError: this.page.getByText(
      'Company registration number not recognised',
    ),
    crnGenericError: this.page.getByText(
      'Oops, something went wrong. We are sorry for any inconvenience, please try again',
    ),
    companyDetailsAlert: this.page.locator('lg-alert'),
    checkDetailsBtn: this.page.locator('text=Check details'),
    continueBtn: this.page.getByRole('button', { name: 'Continue' }),
  };

  readonly allDoneStep = {
    successMessage: this.page.locator('text=All done'),
    errorMessage: this.page.locator('text=Oops, something went wrong'),
    backToDashboardBtn: this.page.locator('text=Back to my dashboard'),
    feedbackBtn: this.page.getByRole('button', { name: 'Feedback' }),
    gotItBtn: this.page.locator('text=Got it'),
    feedbackSurveyCloseBtn: this.page.getByRole('img', { name: 'Close' }),
  };

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/pension-top-up/**');
    await this.page.waitForSelector('h1:has-text("Top up your Pension")');
    await this.page.waitForSelector('text=Make a one-off payment from your debit card');
    await this.entryStep.addBtn.waitFor();
    await this.backBtn.waitFor();
  }
}
