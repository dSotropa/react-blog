import { Page } from '@playwright/test';

import { BasePage } from '../base.page';
export class LgppTransferInPensionPage extends BasePage {
  readonly personalPensionBreadcrumb = this.page.locator(
    'button:has-text("Personal Pension")',
  );
  readonly backBtn = this.page.locator('text=Back');
  readonly continueBtn = this.page.locator('text=Continue');

  readonly yourDetails = {
    heading: this.page.locator('text=Your pension details'),
    accordianToggleBtn: this.page.locator('button:has-text("toggle")'),
    accordianContent: this.page.locator('#accordion-content-0'),
    valueInput: this.page.locator('[aria-label="Estimated value"]'),
    valueRequiredError: this.page.locator('text=Please enter a value'),
    valueMinError: this.page.locator(
      'text=We can only accept pension transfers of £1 or more',
    ),
    providerInput: this.page.locator('input[role="combobox"]'),
    providerRequiredError: this.page.locator('text=Please enter a valid provider'),
    policyNumberInput: this.page.locator('[aria-label="Policy number"]'),
    policyNumberReqiredError: this.page.locator('text=Please enter a policy number'),
  };

  readonly review = {
    heading: this.page.locator('text=Review your pension details'),
    editBtn: this.page.locator('[data-test="edit-pension-details"]'),
    confirmTransferBtn: this.page.locator('text=Confirm transfer'),
  };

  readonly allDone = {
    successMessage: this.page.locator('text=All done'),
    backToDashboardBtn: this.page.locator('button:has-text("Back to my dashboard")'),
  };

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/existing-transfer-in/**');
    await this.page.locator('h1:has-text("Transfer in a pension")').waitFor();
    await this.page.locator('text=Important information').waitFor();
    await this.backBtn.waitFor();
    await this.personalPensionBreadcrumb.waitFor();
  }
}
