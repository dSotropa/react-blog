import { Page } from '@playwright/test';

import { OssMainPage } from '../oss-main.page';

import { LgppAdvertisingTilePage } from './lgpp-advertising-tile.page';
export class LgppActivityPage extends OssMainPage {
  readonly paymentsTile = {
    tile: this.page.locator(
      '[aria-label="Payments"] [data-test="widget-title"] >> text=Payments',
    ),
    amendDirectDebitBtn: this.page.locator('[aria-label="Amend your Direct Debit"]'),
    startRegularContributionBtn: this.page.locator(
      'button:has-text("Set up regular contribution")',
    ),
    stopPaymentsBtn: this.page.locator('[aria-label="Stop your Direct Debit"]'),
    topUpPensionBtn: this.page.locator('button:has-text("Top up your Pension")'),
  };
  readonly pensionDetailsTile = this.page.locator('text=Pension details');
  readonly retirementOptionsTile = this.page
    .locator('[aria-label="Retirement options"] div:has-text("Retirement options")')
    .nth(1);
  readonly retirementOptionsNotification = this.page.locator(
    'text=New retirement options available You are now eligible to access the money in you',
  );
  readonly retirementOptionsOverlay = {
    heading: this.page.locator('text=Retirement options for using your pension pot'),
    closeBtn: this.page.locator('[aria-label="Close"]'),
    leaveItWhereItIsBtn: this.page.locator(
      'text=Leave it where it is You don’t have to start taking money from your pension pot ',
    ),
    pensionDrawdown: {
      heading: this.page.locator('text=Pension Drawdown Get a flexible income'),
      applyBtn: this.page.locator('[aria-label="apply online for a pension drawdown"]'),
      packRequiredText: this.page.locator(
        '#ineligibilityReason >> text=Before you can make a withdrawal from your pension you need to have received a p',
      ),
      packWaitingText: this.page.locator(
        '#ineligibilityReason >> text=Your new pack will arrive in 3-5 working days, you can\'t apply for drawdown unti',
      ),
      unableToStartDrawdownText: this.page.locator(
        '#ineligibilityReason >> text=Sorry, you\'re unable to start your drawdown application as you have a transactio',
      ),
    },
    applyForDrawdownBtn: this.page.locator(
      '[aria-label="apply online for a pension drawdown"]',
    ),
    pensionAnnuityBtn: this.page.locator(
      'text=Pension Annuity Get a guaranteed income for life',
    ),
    fixedTermBtn: this.page.locator(
      'text=Fixed Term Retirement Plan Get a guaranteed income for a set period with a lump ',
    ),
    cashOutBtn: this.page.locator(
      'text=Cash-Out Retirement Plan Get a guaranteed income for a set period',
    ),
    cashInBtn: this.page.locator(
      'text=Cashing in your pension pot Take all of your money out in one go',
    ),
    messagePopup: {
      requestPackText: this.page.locator(
        'p:has-text("Before you can make a withdrawal from your pension you need to have received a p")',
      ),
      packRequestedText: this.page.locator('text=A new pack has been requested.'),
      packAlreadyRequestedText: this.page.locator(
        'div[role="status"] >> text=Your new pack will arrive in 3-5 working days, you can\'t apply for drawdown unti',
      ),
      unableToStartDrawdownText: this.page.locator(
        'p:has-text("Sorry, you\'re unable to start your drawdown application as you have a transactio")',
      ),
      requestPackBtn: this.page.locator('text=Request pack'),
      getSupportLink: this.page.locator(
        '[href="https://test.myaccount.platform.landg.com/#/mailbox"]',
      ),
      dismissBtn: this.page.locator('[aria-label="Dismiss message"]'),
    },
  };

  readonly managePensions = {
    dropdownBtn: this.page.locator('button:has-text("Manage Pension")'),
    dropdownitems: this.page.locator('.dropdown-menu lg-dropdown-menu-item'),
    transferInBtn: this.page.locator('button[role="menuitem"]:has-text("Transfer in")'),
  };

  readonly advertisingTile: LgppAdvertisingTilePage = new LgppAdvertisingTilePage(
    this.page,
  );

  constructor(page: Page) {
    super(page);
  }

  async waitForPageToLoad() {
    await this.page.waitForURL('**/activity/**');
    await this.page.waitForSelector('h1:has-text("Pension overview")');
    await this.managePensions.dropdownBtn.waitFor();

    // Pause the advertising carousel so we can get consistent results for visual checks
    await this.advertisingTile.initialiseAndPause();
  }

  async waitForOverlayToLoad() {
    await this.page
      .locator('text=Retirement options for using your pension pot')
      .waitFor();
  }
}
