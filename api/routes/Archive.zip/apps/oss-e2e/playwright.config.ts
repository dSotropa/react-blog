import { getConfig } from '@utility-e2e';

const config = getConfig({
  appNameRef: 'oss',
  projects: [
    {
      name: 'CI',
      retries: 1,
      timeout: 180000,
      use: {
        skipVisualChecks: false,
      },
    },
    {
      name: 'Local',
      retries: 0,
      use: {
        skipVisualChecks: true,
      },
    },
    {
      name: 'LocalWip',
      grep: [ /@wip/i ],
      retries: 0,
      use: {
        headless: false,
        skipVisualChecks: true,
      },
    },
  ],
  timeout: 90000,
});

export default config;
