import { expect } from '@playwright/test';

import { test } from '../models/test-base';

test.describe.parallel('OSS main page', () => {
  test.beforeEach(async ({ ossMainPage }) => {
    // Using a drawdown login here but could be any of the main OSS products as they all share the same main wrapper
    await ossMainPage.authenticationPage.navigate('Drawdown');
  });

  test('Check header navigation', async ({ ossMainPage }) => {
    await expect(ossMainPage.menuItems).toContainText([
      'Home',
      'Mailbox',
      'Rewards',
      'Help & Support',
    ]);

    expect(await ossMainPage.menuItems.nth(0).getAttribute('href')).toContain(
      'myaccount.platform.landg.com',
    );

    expect(await ossMainPage.menuItems.nth(1).getAttribute('href')).toContain(
      '/#/mailbox',
    );

    expect(await ossMainPage.menuItems.nth(2).getAttribute('href')).toContain(
      '/#/rewards',
    );

    expect(await ossMainPage.menuItems.nth(3).getAttribute('href')).toContain(
      '/#/support',
    );
  });

  test('Check footer links', async ({ ossMainPage }) => {
    await ossMainPage.accessibilityLink.waitFor();
    await ossMainPage.legalInformationLink.waitFor();
    await ossMainPage.cookiePolicyLink.waitFor();
    await ossMainPage.privacyPolicyLink.waitFor();
    await ossMainPage.securityInformationLink.waitFor();
    await ossMainPage.navFooterLGLogo.waitFor();
  });
});
