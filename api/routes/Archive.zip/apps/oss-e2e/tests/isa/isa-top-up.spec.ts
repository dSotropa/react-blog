import { expect } from '@playwright/test';
import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('ISA Top-Up', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ isaActivityPage }) => {
    await isaActivityPage.authenticationPage.navigate('User3_ISA');
    await isaActivityPage.waitForPageToLoad();
  });

  test('ISA payroll top-up', async ({
    isaActivityPage,
    isaTopUpPage,
    investmentsPage,
    paymentsPage,
    skipVisualChecks,
  }) => {
    // Check the top up button on the payments tile
    await isaActivityPage.topUpBtn.click();
    await isaTopUpPage.waitForPageToLoad();
    await isaTopUpPage.pageCheck(visualFunctions, 'ISA Top up page', skipVisualChecks);
    await isaTopUpPage.clickButton(isaTopUpPage.backBtn);
    await isaActivityPage.waitForPageToLoad();

    // Check the top up button on the ISA allowance widget
    await isaActivityPage.isaAllowanceTopUpBtn.click();
    await isaTopUpPage.waitForPageToLoad();
    await isaTopUpPage.clickButton(isaTopUpPage.backBtn);
    await isaActivityPage.waitForPageToLoad();

    // Check the top up button on the investments tile
    await isaActivityPage.investmentsTile.tile.click();
    await investmentsPage.waitForPageToLoad();
    await investmentsPage.isaAllowanceTopUpBtn.click();
    await isaTopUpPage.waitForPageToLoad();
    await isaTopUpPage.clickButton(isaTopUpPage.backBtn);
    await investmentsPage.waitForPageToLoad();
    await investmentsPage.backToSummaryBtn.click();
    await isaActivityPage.waitForPageToLoad();

    // Check the top up button on the payments tile
    await isaActivityPage.paymentsTile.click();
    await paymentsPage.waitForPageToLoad();
    await paymentsPage.topUpBtn.click();
    await isaTopUpPage.waitForPageToLoad();

    // Check validation errors
    await isaTopUpPage.nextBtn.click();
    await isaTopUpPage.paymentMethodRequiredError.waitFor();
    await isaTopUpPage.amountRequiredError.waitFor();
    await isaTopUpPage.byPayrollBtn.click();
    await isaTopUpPage.amountInput.fill('0');
    await isaTopUpPage.amountRequiredError.waitFor();
    await isaTopUpPage.amountInput.fill('100.5');
    await isaTopUpPage.wholeNumberError.waitFor();
    await isaTopUpPage.amountInput.fill('19000');
    await isaTopUpPage.maxAmountError.waitFor();

    // Continue and review
    await isaTopUpPage.amountInput.fill('1000');
    await expect(isaTopUpPage.maxAmountError).not.toBeVisible();
    await isaTopUpPage.clickButton(isaTopUpPage.reviewBtn);
    await isaTopUpPage.reviewPageHeading.waitFor();

    await isaTopUpPage.pageCheck(
      visualFunctions,
      'ISA Top up page - review',
      skipVisualChecks,
    );

    // All done
    await isaTopUpPage.topUpBtn.click();
    await isaTopUpPage.allDoneStep.allDoneMessage.waitFor();
    await isaTopUpPage.allDoneStep.backToDashboardBtn.click();
    await paymentsPage.waitForPageToLoad();
  });

  test('ISA payroll top-up failure', async ({ isaActivityPage, isaTopUpPage }) => {
    await isaActivityPage.topUpBtn.click();
    await isaTopUpPage.waitForPageToLoad();
    await isaTopUpPage.byPayrollBtn.click();
    await isaTopUpPage.amountInput.fill('666');
    await isaTopUpPage.clickButton(isaTopUpPage.reviewBtn);
    await isaTopUpPage.topUpBtnFailScenario.click();
    await isaTopUpPage.allDoneStep.errorMessage.waitFor();
    await isaTopUpPage.clickButton(isaTopUpPage.allDoneStep.gotItBtn);
    await isaActivityPage.waitForPageToLoad();
  });

  test('ISA debit card top-up', async ({
    isaActivityPage,
    isaTopUpPage,
    barclaysPaymentPage,
  }) => {
    await isaActivityPage.topUpBtn.click();
    await isaTopUpPage.waitForPageToLoad();
    await isaTopUpPage.byDebitCardButton.click();
    await isaTopUpPage.amountInput.fill('1000');
    await isaTopUpPage.nextBtn.click();
    await barclaysPaymentPage.waitForPageToLoad();
    await barclaysPaymentPage.clickButton(barclaysPaymentPage.investSecurlyBtn);
    await isaTopUpPage.allDoneStep.allDoneMessage.waitFor();
    await isaTopUpPage.allDoneStep.backToDashboardBtn.click();
    await isaActivityPage.waitForPageToLoad();
  });

  test('ISA debit card top-up failure', async ({
    isaActivityPage,
    isaTopUpPage,
    barclaysPaymentPage,
  }) => {
    await isaActivityPage.topUpBtn.click();
    await isaTopUpPage.waitForPageToLoad();
    await isaTopUpPage.byDebitCardButton.click();
    await isaTopUpPage.amountInput.fill('100');
    await isaTopUpPage.nextBtn.click();
    await barclaysPaymentPage.waitForPageToLoad();
    await barclaysPaymentPage.errorWhenProcessingOption.check();
    await barclaysPaymentPage.investSecurlyBtn.click();
    await isaTopUpPage.allDoneStep.errorMessage.waitFor();
    await isaTopUpPage.clickButton(isaTopUpPage.allDoneStep.gotItBtn);
    await isaActivityPage.waitForPageToLoad();
  });

  test('D2C ISA debit card top-up Feedback', async ({
    isaActivityPage,
    isaTopUpPage,
    barclaysPaymentPage,
  }) => {
    await isaActivityPage.authenticationPage.navigate('ISA_User_can_switch_funds');
    await isaActivityPage.waitForPageToLoad();
    await isaActivityPage.topUpBtn.click();
    await isaTopUpPage.waitForPageToLoad();
    await isaTopUpPage.byDebitCardButton.click();
    await isaTopUpPage.amountInput.fill('1000');
    await isaTopUpPage.nextBtn.click();
    await barclaysPaymentPage.waitForPageToLoad();
    await barclaysPaymentPage.clickButton(barclaysPaymentPage.investSecurlyBtn);
    await isaTopUpPage.allDoneStep.allDoneMessage.waitFor();
    await isaTopUpPage.allDoneStep.feedbackBtn.click();
    await isaTopUpPage.allDoneStep.feedbackSurveyCloseBtn.click();
    await isaTopUpPage.allDoneStep.backToDashboardBtn.click();
    await isaActivityPage.waitForPageToLoad();
  });

  afterAllHook(test);
});
