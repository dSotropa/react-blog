import { expect } from '@playwright/test';
import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('ISA edit & stop regular payments', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ isaActivityPage }) => {
    await isaActivityPage.authenticationPage.navigate('ISA_LEAVER_with_a_regular');
  });

  test('Main page accessibility and visual checks', async ({
    isaActivityPage,
    skipVisualChecks,
  }) => {
    await isaActivityPage.waitForPageToLoad();

    await isaActivityPage.pageCheck(
      visualFunctions,
      'ISA activity page - user with regular payments',
      skipVisualChecks,
    );
  });

  test('Manage ISA button has the correct options', async ({ isaActivityPage }) => {
    await isaActivityPage.manageIsaButton.click();

    await expect(isaActivityPage.manageIsaDropdownItems).toContainText([
      'Top up your ISA',
      'Stop payments',
      'Change regular contribution',
      'Start an ISA transfer',
      'View investment options',
    ]);
  });

  test('Stop direct debit payments tab', async ({
    isaActivityPage,
    paymentsPage,
    stopDirectDebitConfirmModal,
    stopDirectDebitDoneModal,
    skipVisualChecks,
  }) => {
    // Navigate to payments and click the button
    await isaActivityPage.paymentsTile.click();
    await paymentsPage.waitForPageToLoad();

    await paymentsPage.pageCheck(
      visualFunctions,
      'ISA payments page - user with regular payments',
      skipVisualChecks,
    );

    await paymentsPage.stopRegularPaymentsBtn.click();

    // Confirm
    await stopDirectDebitConfirmModal.modal.waitFor();

    await stopDirectDebitConfirmModal.pageCheck(
      visualFunctions,
      'ISA stop regular payments confirm modal',
      skipVisualChecks,
    );

    await stopDirectDebitConfirmModal.confirmBtn.click();

    // Done
    await stopDirectDebitDoneModal.modal.waitFor();
    await stopDirectDebitDoneModal.gotItBtn.click();

    await stopDirectDebitConfirmModal.pageCheck(
      visualFunctions,
      'ISA stop regular payments all done modal',
      skipVisualChecks,
    );

    await expect(stopDirectDebitDoneModal.modal).not.toBeVisible();
  });

  test('Stop direct debit payments tile', async ({
    isaActivityPage,
    stopDirectDebitConfirmModal,
    stopDirectDebitDoneModal,
  }) => {
    // Click the button
    await isaActivityPage.stopRegularPaymentsBtn.click();

    // Confirm
    await stopDirectDebitConfirmModal.modal.waitFor();
    await stopDirectDebitConfirmModal.confirmBtn.click();

    // Done
    await stopDirectDebitDoneModal.modal.waitFor();
    await stopDirectDebitDoneModal.gotItBtn.click();
    await expect(stopDirectDebitDoneModal.modal).not.toBeVisible();
  });

  test('Edit direct debit payments tab', async ({
    isaActivityPage,
    paymentsPage,
    isaRegularPaymentConfirmModal,
    isaRegularPaymentDoneModal,
    skipVisualChecks,
  }) => {
    await isaActivityPage.paymentsTile.click();
    await paymentsPage.waitForPageToLoad();

    // Amend then cancel
    await paymentsPage.amendRegularPaymentsBtn.click();
    await paymentsPage.regularPaymentEditor.waitFor();

    await paymentsPage.pageCheck(
      visualFunctions,
      'ISA amend payments editor',
      skipVisualChecks,
    );

    await paymentsPage.amendPaymentsCancelButton.click();
    await paymentsPage.amendRegularPaymentsBtn.waitFor();

    // Amend with validation errors
    await paymentsPage.amendRegularPaymentsBtn.click();
    await paymentsPage.amountInput.fill('');
    await paymentsPage.amountRequiredValidationError.waitFor();
    await paymentsPage.amountInput.fill('11');
    await paymentsPage.amountMinValidationError.waitFor();
    await paymentsPage.amountInput.fill('4011');
    await paymentsPage.amountMaxValidationError.waitFor();

    // Amend then cancel
    await paymentsPage.amountInput.fill('110');
    await paymentsPage.monthlyPaymentsDate.selectOption('16');
    await paymentsPage.amendPaymentsReviewButton.click();
    await isaRegularPaymentConfirmModal.modal.waitFor();

    await isaRegularPaymentConfirmModal.pageCheck(
      visualFunctions,
      'ISA amend regular payments confirm modal',
      skipVisualChecks,
    );

    await isaRegularPaymentConfirmModal.backButton.click();
    await expect(isaRegularPaymentConfirmModal.modal).not.toBeVisible();

    // Amend then save
    await paymentsPage.amendPaymentsReviewButton.click();
    await isaRegularPaymentConfirmModal.confirmBtn.click();
    await isaRegularPaymentDoneModal.modal.waitFor();

    await isaRegularPaymentDoneModal.pageCheck(
      visualFunctions,
      'ISA amend regular payments all done modal',
      skipVisualChecks,
    );

    await isaRegularPaymentDoneModal.backToDashboardBtn.click();
    await expect(isaRegularPaymentDoneModal.modal).not.toBeVisible();
  });

  afterAllHook(test);
});
