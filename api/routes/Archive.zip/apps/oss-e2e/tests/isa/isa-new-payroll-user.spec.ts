import { expect } from '@playwright/test';

import { test } from '../../models/test-base';

test.describe.parallel('ISA new payroll user', () => {
  test.beforeEach(async ({ isaActivityPage }) => {
    await isaActivityPage.authenticationPage.navigate('User1_ISA');
  });

  test('New payroll customer', async ({ isaActivityPage }) => {
    await isaActivityPage.waitForPageToLoad();
    await isaActivityPage.manageIsaButton.click();

    await expect(isaActivityPage.manageIsaDropdownItems).toContainText([
      'Top up your ISA',
      'Pause payments',
      'Change',
      'Start an ISA transfer',
      'View investment options',
    ]);
  });
});
