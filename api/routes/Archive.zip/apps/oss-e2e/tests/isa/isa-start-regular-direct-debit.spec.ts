import { expect } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('ISA Start Direct Debit Regular Payments', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ isaActivityPage }) => {
    await isaActivityPage.authenticationPage.navigate('ISA_DIRECT_no_regular');
    await isaActivityPage.waitForPageToLoad();
    await isaActivityPage.manageIsaButton.click();
    await isaActivityPage.startRegularPaymentsMenuBtn.click();
  });

  test.fixme(
    'Start direct debit',
    async ({
      isaActivityPage,
      isaSetupRegularContributionPage,
      paymentsPage,
      skipVisualChecks,
    }) => {
      await isaSetupRegularContributionPage.waitForPageToLoad();

      await isaSetupRegularContributionPage.pageCheck(
        visualFunctions,
        'ISA - Start regular contributions',
        skipVisualChecks,
      );

      // Check the breadcrumb link back to the main activity page
      await isaSetupRegularContributionPage.isaBreadcrumb.click();
      await isaActivityPage.waitForPageToLoad();

      // Check can navigate from the payments tile
      await isaActivityPage.startRegularPaymentsBtn.click();
      await isaSetupRegularContributionPage.waitForPageToLoad();

      await isaSetupRegularContributionPage.clickButton(
        isaSetupRegularContributionPage.backBtn,
      );

      await isaActivityPage.waitForPageToLoad();

      // Check can navigate from the payments page
      await isaActivityPage.paymentsTile.click();
      await paymentsPage.waitForPageToLoad();
      await paymentsPage.startRegularPaymentsBtn.click();
      await isaSetupRegularContributionPage.waitForPageToLoad();

      // Continue the journey
      await isaSetupRegularContributionPage.clickButton(
        isaSetupRegularContributionPage.continueBtn,
      );

      await isaSetupRegularContributionPage.monthlyDirectDebitHeader.waitFor();

      await isaSetupRegularContributionPage.pageCheck(
        visualFunctions,
        'ISA - Start regular contributions - step 2',
        skipVisualChecks,
      );

      // Check the back button
      await isaSetupRegularContributionPage.backBtn.click();
      await isaSetupRegularContributionPage.waitForPageToLoad();

      // Continue the journey
      await isaSetupRegularContributionPage.clickButton(
        isaSetupRegularContributionPage.continueBtn,
      );

      await isaSetupRegularContributionPage.monthlyDirectDebitHeader.waitFor();

      // Check the validation errors
      await isaSetupRegularContributionPage.amountRequiredBtn.click();
      await isaSetupRegularContributionPage.amountRequiredError.waitFor();
      await isaSetupRegularContributionPage.amountInput.fill('19');
      await isaSetupRegularContributionPage.amountMinError.waitFor();
      await isaSetupRegularContributionPage.amountInput.fill('159.3');
      await isaSetupRegularContributionPage.amountWholeNumberError.waitFor();
      await isaSetupRegularContributionPage.amountInput.fill('4001');
      await isaSetupRegularContributionPage.amountMaxError.waitFor();
      await isaSetupRegularContributionPage.amountInput.fill('120');

      await isaSetupRegularContributionPage.pageCheck(
        visualFunctions,
        'ISA - Start regular contributions - amount entered',
        skipVisualChecks,
      );

      // Continue the journey to add direct debit details
      await isaSetupRegularContributionPage.addBtn.click();
      await isaSetupRegularContributionPage.directDebitDetailsHeader.waitFor();

      // Check the back button works
      await isaSetupRegularContributionPage.clickButton(
        isaSetupRegularContributionPage.backBtn,
      );

      await isaSetupRegularContributionPage.monthlyDirectDebitHeader.waitFor();

      // Continue the journey
      await isaSetupRegularContributionPage.addBtn.click();
      await isaSetupRegularContributionPage.directDebitDetailsHeader.waitFor();

      await isaSetupRegularContributionPage.pageCheck(
        visualFunctions,
        'ISA - Start regular contributions - direct debit details',
        skipVisualChecks,
      );

      // Check the validation errors
      await isaSetupRegularContributionPage.clickButton(
        isaSetupRegularContributionPage.continueBtn,
      );

      await isaSetupRegularContributionPage.sortCodeError.waitFor();
      await isaSetupRegularContributionPage.accountNumberError.waitFor();
      await isaSetupRegularContributionPage.dateError.waitFor();
      await isaSetupRegularContributionPage.sortCode1Input.fill('20');
      await isaSetupRegularContributionPage.sortCode2Input.fill('00');
      await isaSetupRegularContributionPage.sortCode3Input.fill('0');
      await isaSetupRegularContributionPage.sortCodeError.waitFor();
      await isaSetupRegularContributionPage.sortCode3Input.fill('ab');
      await isaSetupRegularContributionPage.sortCodeError.waitFor();
      await isaSetupRegularContributionPage.accountNumberInput.fill('121212');
      await isaSetupRegularContributionPage.accountNumberError.waitFor();
      await isaSetupRegularContributionPage.sortCode3Input.fill('00');
      await isaSetupRegularContributionPage.accountNumberInput.fill('12121212');
      await isaSetupRegularContributionPage.dateSelect.selectOption('1');

      // Continue the journey to review direct debit details step
      await expect(isaSetupRegularContributionPage.sortCodeError).not.toBeVisible();
      await expect(isaSetupRegularContributionPage.accountNumberError).not.toBeVisible();
      await expect(isaSetupRegularContributionPage.dateError).not.toBeVisible();
      await isaSetupRegularContributionPage.confirmCheckbox.click();

      await isaSetupRegularContributionPage.clickButton(
        isaSetupRegularContributionPage.continueBtn,
      );

      await isaSetupRegularContributionPage.reviewdirectDebitDetailsHeader.waitFor();

      await isaSetupRegularContributionPage.pageCheck(
        visualFunctions,
        'ISA - Start regular contributions - review direct debit details',
        skipVisualChecks,
      );

      await isaSetupRegularContributionPage.confirmMonthlyPmtBtn.click();
      await isaSetupRegularContributionPage.allDoneMessage.waitFor();
      await isaSetupRegularContributionPage.backToDashboarBtn.click();
      await paymentsPage.waitForPageToLoad();
    },
  );

  test('Start Direct Debit failure', async ({
    isaSetupRegularContributionPage,
    isaActivityPage,
  }) => {
    await isaSetupRegularContributionPage.waitForPageToLoad();

    await isaSetupRegularContributionPage.clickButton(
      isaSetupRegularContributionPage.continueBtn,
    );

    await isaSetupRegularContributionPage.monthlyDirectDebitHeader.waitFor();
    await isaSetupRegularContributionPage.amountInput.fill('1002');
    await isaSetupRegularContributionPage.addBtnFailScenario.click();
    await isaSetupRegularContributionPage.directDebitDetailsHeader.waitFor();
    await isaSetupRegularContributionPage.sortCode1Input.fill('20');
    await isaSetupRegularContributionPage.sortCode2Input.fill('00');
    await isaSetupRegularContributionPage.sortCode3Input.fill('00');
    await isaSetupRegularContributionPage.accountNumberInput.fill('12121212');
    await isaSetupRegularContributionPage.dateSelect.selectOption('1');

    // Continue the journey to review direct debit details step
    await expect(isaSetupRegularContributionPage.sortCodeError).not.toBeVisible();
    await expect(isaSetupRegularContributionPage.accountNumberError).not.toBeVisible();
    await expect(isaSetupRegularContributionPage.dateError).not.toBeVisible();
    await isaSetupRegularContributionPage.confirmCheckbox.click();

    await isaSetupRegularContributionPage.clickButton(
      isaSetupRegularContributionPage.continueBtn,
    );

    await isaSetupRegularContributionPage.confirmMonthlyPmtBtn.click();
    await isaSetupRegularContributionPage.errorMessage.waitFor();
    await isaSetupRegularContributionPage.backToDashboarBtn.click();
    await isaActivityPage.waitForPageToLoad();
  });

  afterAllHook(test);
});
