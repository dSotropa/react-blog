import { expect } from '@playwright/test';
import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('ISA edit & pause regular payroll payments', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ isaActivityPage }) => {
    await isaActivityPage.authenticationPage.navigate('User2_ISA');
  });

  test('Pause Regular payroll payment payments tile', async ({
    isaActivityPage,
    skipVisualChecks,
  }) => {
    // Click the pause payments button on the payments tile to open the confirmation modal
    await isaActivityPage.pausePaymentsBtn.click();
    await isaActivityPage.pausePaymentsModal.waitFor();

    await isaActivityPage.pageCheck(
      visualFunctions,
      'ISA activity page - pause payments confirm modal',
      skipVisualChecks,
    );

    // Click the confirm button and wait for the all done page
    await isaActivityPage.pausePaymentsModalConfirmlBtn.click();
    await isaActivityPage.gotItBtn.waitFor();

    await isaActivityPage.pageCheck(
      visualFunctions,
      'ISA activity page - pause payments all done modal',
      skipVisualChecks,
    );

    await isaActivityPage.gotItBtn.click();
    await expect(isaActivityPage.gotItBtn).not.toBeVisible();
  });

  test('Edit regular payroll payment payments tab - validation and success (percent)', async ({
    isaActivityPage,
    paymentsPage,
    isaRegularPaymentConfirmModal,
    isaRegularPaymentDoneModal,
    skipVisualChecks,
  }) => {
    // CLick on the payments tile anw wait for the payments tab to load
    await isaActivityPage.paymentsTile.click();
    await paymentsPage.waitForPageToLoad();

    await paymentsPage.pageCheck(
      visualFunctions,
      'ISA activity page - user with regular payroll payments',
      skipVisualChecks,
    );

    // Click the Change link and wait for the editor to be visible
    await paymentsPage.changePaymentsBtn.click();
    await paymentsPage.regularPayrollPaymentsEditor.input.waitFor();

    await paymentsPage.pageCheck(
      visualFunctions,
      'ISA activity page - payroll payments editor',
      skipVisualChecks,
    );

    // Min percent validtion error
    await paymentsPage.regularPayrollPaymentsEditor.percentOption.click();
    await paymentsPage.regularPayrollPaymentsEditor.input.fill('');
    await paymentsPage.regularPayrollPaymentsEditor.minPercentError.waitFor();

    // Max percent validtion error
    await paymentsPage.regularPayrollPaymentsEditor.input.fill('110');
    await paymentsPage.regularPayrollPaymentsEditor.maxPercentError.waitFor();
    // Min amount validation error
    await paymentsPage.regularPayrollPaymentsEditor.amountOption.click();
    await paymentsPage.regularPayrollPaymentsEditor.input.fill('');
    await paymentsPage.regularPayrollPaymentsEditor.minAmountError.waitFor();

    // Max amount validation error
    await paymentsPage.regularPayrollPaymentsEditor.input.fill('20100');
    await paymentsPage.regularPayrollPaymentsEditor.maxAmountError.waitFor();

    // Enter a valid percentage and continue with the journey
    await paymentsPage.regularPayrollPaymentsEditor.percentOption.click();
    await paymentsPage.regularPayrollPaymentsEditor.input.fill('50');
    await paymentsPage.regularPayrollPaymentsEditor.reviewBtn.click();
    await isaRegularPaymentConfirmModal.modal.waitFor();

    await isaRegularPaymentConfirmModal.pageCheck(
      visualFunctions,
      'ISA activity page - payroll payments confirm modal',
      skipVisualChecks,
    );

    // Click confirm and finish journey
    await isaRegularPaymentConfirmModal.confirmBtn.click();
    await isaRegularPaymentDoneModal.modal.waitFor();

    await isaRegularPaymentConfirmModal.pageCheck(
      visualFunctions,
      'ISA activity page - payroll payments done modal',
      skipVisualChecks,
    );

    await isaRegularPaymentDoneModal.gotItBtn.click();
    await expect(isaRegularPaymentDoneModal.modal).not.toBeVisible();
  });

  test('Edit regular payroll payment payments tile - failure (amount)', async ({
    isaActivityPage,
    isaRegularPaymentConfirmModal,
    isaRegularPaymentDoneModal,
  }) => {
    isaActivityPage.changePaymentsBtn.click();

    // Enter a valid percentage and continue with the journey
    await isaActivityPage.regularPayrollPaymentsEditor.amountOption.click();
    await isaActivityPage.regularPayrollPaymentsEditor.input.fill('666');
    await isaActivityPage.regularPayrollPaymentsEditor.reviewBtn.click();
    await isaRegularPaymentConfirmModal.modal.waitFor();
    await isaRegularPaymentConfirmModal.confirmBtn.click();
    await isaRegularPaymentDoneModal.errorLabel.waitFor();
  });

  afterAllHook(test);
});
