import { expect } from '@playwright/test';
import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('ISA Withdrawal', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test('ISA withdrawal - partial', async ({
    isaActivityPage,
    investmentsPage,
    isaWithdrawalPage,
    skipVisualChecks,
  }) => {
    await isaActivityPage.authenticationPage.navigate('User3_ISA');
    await isaActivityPage.waitForPageToLoad();
    await isaActivityPage.investmentsTile.tile.click();
    await investmentsPage.withdrawBtn.click();
    await isaWithdrawalPage.waitForPageToLoad();

    await isaWithdrawalPage.pageCheck(
      visualFunctions,
      'ISA withdrawal',
      skipVisualChecks,
    );

    // Check validation errors
    await isaWithdrawalPage.clickButton(isaWithdrawalPage.nextBtn);
    await isaWithdrawalPage.amountMinError.waitFor();
    await isaWithdrawalPage.amountInput.fill('0');
    await isaWithdrawalPage.amountMinError.waitFor();
    await isaWithdrawalPage.amountInput.fill('1135');
    await isaWithdrawalPage.amountMaxError.waitFor();
    await isaWithdrawalPage.amountInput.fill('100.5');
    await isaWithdrawalPage.amountWholeNumberError.waitFor();

    // Continue the journey
    await isaWithdrawalPage.amountInput.fill('99');
    await expect(isaWithdrawalPage.amountWholeNumberError).not.toBeVisible();
    await isaWithdrawalPage.clickButton(isaWithdrawalPage.nextBtn);
    await isaWithdrawalPage.reviewPageHeading.waitFor();

    await isaWithdrawalPage.pageCheck(
      visualFunctions,
      'ISA withdrawal - review page',
      skipVisualChecks,
    );

    // Check the back button
    await isaWithdrawalPage.backBtn.click();
    await isaWithdrawalPage.waitForPageToLoad();

    // Continue
    await isaWithdrawalPage.clickButton(isaWithdrawalPage.nextBtn);
    await isaWithdrawalPage.withdraw99Btn.click();
    await isaWithdrawalPage.allDoneMessage.waitFor();

    await isaWithdrawalPage.pageCheck(
      visualFunctions,
      'ISA withdrawal - all done page',
      skipVisualChecks,
    );

    await isaWithdrawalPage.backToDashboardBtn.click();
    await investmentsPage.waitForPageToLoad();
  });

  test('ISA withdrawal - full', async ({
    isaActivityPage,
    isaWithdrawalPage,
    skipVisualChecks,
  }) => {
    await isaActivityPage.authenticationPage.navigate('User3_ISA');
    await isaActivityPage.waitForPageToLoad();
    await isaActivityPage.withdrawFromIsaBtn.click();
    await isaWithdrawalPage.waitForPageToLoad();

    await isaWithdrawalPage.fullAmountCheckbox.click();
    await isaWithdrawalPage.importantInformationAlert.waitFor();

    await isaWithdrawalPage.pageCheck(
      visualFunctions,
      'ISA withdrawal - with full amount selected',
      skipVisualChecks,
    );

    await isaWithdrawalPage.clickButton(isaWithdrawalPage.nextBtn);
    await isaWithdrawalPage.reviewPageHeading.waitFor();

    await isaWithdrawalPage.pageCheck(
      visualFunctions,
      'ISA withdrawal - review page with full amount selected',
      skipVisualChecks,
    );

    await isaWithdrawalPage.withdrawFullBtn.click();
    await isaWithdrawalPage.allDoneMessage.waitFor();
    await isaWithdrawalPage.backToDashboardBtn.click();
    await isaActivityPage.waitForPageToLoad();
  });

  test('ISA withdrawal - failure', async ({
    isaActivityPage,
    isaWithdrawalPage,
    skipVisualChecks,
  }) => {
    await isaActivityPage.authenticationPage.navigate('User3_ISA');
    await isaActivityPage.waitForPageToLoad();
    await isaActivityPage.withdrawFromIsaBtn.click();
    await isaWithdrawalPage.waitForPageToLoad();
    await isaWithdrawalPage.amountInput.fill('666');
    await isaWithdrawalPage.clickButton(isaWithdrawalPage.nextBtn);
    await isaWithdrawalPage.reviewPageHeading.waitFor();
    await isaWithdrawalPage.withdraw666Btn.click();
    await isaWithdrawalPage.errorMessage.waitFor();
    await isaWithdrawalPage.backToDashboardBtn.click();
    await isaActivityPage.waitForPageToLoad();
  });

  test('ISA withdrawal - no amount to sell available', async ({
    isaActivityPage,
    investmentsPage,
  }) => {
    await isaActivityPage.authenticationPage.navigate('User1_ISA');
    await isaActivityPage.waitForPageToLoad();
    await expect(isaActivityPage.withdrawFromIsaBtn).not.toBeVisible();
    await isaActivityPage.investmentsTile.tile.click();
    await investmentsPage.waitForPageToLoad();
    await expect(investmentsPage.withdrawBtn).not.toBeVisible();
  });

  afterAllHook(test);
});
