import { expect } from '@playwright/test';
import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('ISA activity smoke and accessibility checks', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ isaActivityPage }) => {
    await isaActivityPage.authenticationPage.navigate('User2_ISA');
  });

  test('Manage ISA button has the correct options', async ({ isaActivityPage }) => {
    await isaActivityPage.manageIsaButton.click();

    await expect(isaActivityPage.manageIsaDropdownItems).toContainText([
      'Top up your ISA',
      'Pause payments',
      'Change regular contribution',
      'Start an ISA transfer',
    ]);
  });

  test('Accessibility and visual checks', async ({
    isaActivityPage,
    paymentsPage,
    investmentsPage,
    documentsPage,
    pulsePage,
    feesAndChargesPage,
    skipVisualChecks,
  }) => {
    await isaActivityPage.waitForPageToLoad();

    await isaActivityPage.pageCheck(
      visualFunctions,
      'ISA activity page - active user',
      skipVisualChecks,
    );

    await isaActivityPage.paymentsTile.click();
    await paymentsPage.waitForPageToLoad();

    await paymentsPage.pageCheck(visualFunctions, 'ISA payments page', skipVisualChecks);

    await paymentsPage.backToSummaryBtn.click();
    await isaActivityPage.waitForPageToLoad();

    await isaActivityPage.investmentsTile.tile.click();
    await investmentsPage.waitForPageToLoad();

    await investmentsPage.pageCheck(
      visualFunctions,
      'ISA investment page',
      skipVisualChecks,
    );

    await investmentsPage.backToSummaryBtn.click();
    await isaActivityPage.waitForPageToLoad();

    await isaActivityPage.documentsTile.click();
    await documentsPage.waitForPageToLoad();

    await documentsPage.pageCheck(
      visualFunctions,
      'ISA documents page',
      skipVisualChecks,
    );

    await documentsPage.backToSummaryBtn.click();
    await isaActivityPage.waitForPageToLoad();

    await isaActivityPage.thePulseTile.click();
    await pulsePage.waitForPageToLoad();
    await pulsePage.backToSummaryBtn.click();
    await isaActivityPage.waitForPageToLoad();

    await isaActivityPage.feesAndChargesTile.click();
    await feesAndChargesPage.waitForPageToLoad();

    await feesAndChargesPage.pageCheck(
      visualFunctions,
      'ISA fees and charges - Multi Asset Core 45 Fund (I)',
      skipVisualChecks,
    );

    await feesAndChargesPage.backToSummaryBtn.click();
    await isaActivityPage.waitForPageToLoad();
  });

  afterAllHook(test);
});
