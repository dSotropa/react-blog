import { test } from '../../models/test-base';

test.describe.parallel('ISA mimic Shaun\'s account', () => {
  test.beforeEach(async ({ isaActivityPage }) => {
    await isaActivityPage.authenticationPage.navigate('Shauns_ISA');
  });

  test('Check investment and document messages', async ({
    isaActivityPage,
    investmentsPage,
    documentsPage,
  }) => {
    await isaActivityPage.waitForPageToLoad();
    await isaActivityPage.investmentAvailableSoonMsg.waitFor();
    await isaActivityPage.documentsAvailableSoonMsg.waitFor();

    await isaActivityPage.investmentsTile.tile.click();
    await investmentsPage.waitForPageToLoad();
    await investmentsPage.investmentAvailableSoonMsg.waitFor();
    await investmentsPage.backToSummaryBtn.click();
    await isaActivityPage.waitForPageToLoad();

    await isaActivityPage.documentsTile.click();
    await documentsPage.waitForPageToLoad();
    await documentsPage.documentsAvailableSoonMsg.waitFor();
  });
});
