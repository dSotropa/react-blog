import { expect } from '@playwright/test';
import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('ISA Transfer-In', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ isaActivityPage }) => {
    await isaActivityPage.authenticationPage.navigate('User3_ISA');
    await isaActivityPage.waitForPageToLoad();
  });

  test('Successful journey', async ({
    isaActivityPage,
    isaTransferPage,
    skipVisualChecks,
  }) => {
    await isaActivityPage.startIsaTransferBtn.click();
    await isaActivityPage.isaTransferOverlay.waitFor();

    await isaActivityPage.pageCheck(
      visualFunctions,
      'ISA activity - ISA transfer overlay',
      skipVisualChecks,
    );

    await isaActivityPage.isaTransferContinueBtn.click();
    await isaTransferPage.waitForPageToLoad();

    await isaTransferPage.pageCheck(
      visualFunctions,
      'ISA transfer - Impotrant information',
      skipVisualChecks,
    );

    await isaTransferPage.clickButton(isaTransferPage.backBtn);
    await isaActivityPage.waitForPageToLoad();
  });

  test('Start a transfer journey - post the form to me', async ({
    isaActivityPage,
    isaTransferPage,
    skipVisualChecks,
  }) => {
    await isaActivityPage.startIsaTransferBtn.click();
    await isaActivityPage.isaTransferOverlay.waitFor();
    await isaActivityPage.isaTransferContinueBtn.click();
    await isaTransferPage.waitForPageToLoad();
    await isaTransferPage.clickButton(isaTransferPage.startTransferBtn);
    await isaTransferPage.isaDetailsHeading.waitFor();

    await isaTransferPage.pageCheck(
      visualFunctions,
      'ISA transfer - ISA details page',
      skipVisualChecks,
    );

    // Check validation errors
    await isaTransferPage.continueBtn.click();
    await isaTransferPage.accountProviderError.waitFor();
    await isaTransferPage.accountNumberError.waitFor();

    // Enter valid details and continue
    await isaTransferPage.acountProviderInput.fill('Aegon');
    await isaTransferPage.accountNumberInput.fill('123');
    await isaTransferPage.continueBtn.click();
    await isaTransferPage.printPage.waitFor();

    await isaTransferPage.pageCheck(
      visualFunctions,
      'ISA Transfer - Print, sign and post page',
      skipVisualChecks,
    );

    // Click send by post
    await isaTransferPage.sendByPostBtn.click();
    await isaTransferPage.confirmModal.waitFor();

    await isaTransferPage.pageCheck(
      visualFunctions,
      'ISA Transfer - Confirm modal',
      skipVisualChecks,
    );

    await isaTransferPage.cancelBtn.click();
    await expect(isaTransferPage.cancelBtn).not.toBeVisible();
    await isaTransferPage.sendByPostBtn.click();
    await isaTransferPage.sendInPostBtn.waitFor();
    await isaTransferPage.sendInPostBtn.click();
    await isaTransferPage.transferBeingPerparedPage.waitFor();

    await isaTransferPage.pageCheck(
      visualFunctions,
      'ISA Transfer - Transfer being prepared page',
      skipVisualChecks,
    );

    await isaTransferPage.backToDashboardBtn.click();
    await isaActivityPage.waitForPageToLoad();
  });

  afterAllHook(test);
});
