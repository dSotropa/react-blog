import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

let visualFunctions: VisualFunctions;

test.beforeAll(() => {
  visualFunctions = VisualFunctions.getInstance();
});

test.describe.parallel('ISA Advertising tile', () => {
  test('Tax year end advert', async ({ isaActivityPage, isaTopUpPage }) => {
    await isaActivityPage.authenticationPage.navigate('ISA_tax_year_end');
    await isaActivityPage.waitForPageToLoad();
    await isaActivityPage.advertisingTile.heading.waitFor();
    await isaActivityPage.advertisingTile.topUpBtn.click();
    await isaTopUpPage.waitForPageToLoad();
  });

  afterAllHook(test);
});
