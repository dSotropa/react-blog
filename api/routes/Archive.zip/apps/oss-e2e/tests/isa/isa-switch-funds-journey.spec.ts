import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('ISA Switch Funds Journey', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ isaActivityPage }) => {
    await isaActivityPage.authenticationPage.navigate('ISA_User_can_switch_funds');
    await isaActivityPage.waitForPageToLoad();
  });

  test.fixme(
    'Successful Journey',
    async ({
      isaActivityPage,
      fundSwitchPage,
      skipVisualChecks,
      changeInvestmentsPage,
    }) => {
      // Start the journey
      await isaActivityPage.viewInvestmentOptionsBtn.click();

      await changeInvestmentsPage.waitForPageToLoad();
      await changeInvestmentsPage.overview.simpleFunds.viewOptionsBtn.click();
      await fundSwitchPage.waitForPageToLoad();

      await fundSwitchPage.pageCheck(
        visualFunctions,
        'ISA Fund switch - start',
        skipVisualChecks,
        2000,
      );

      // check the Understanding Investment Risk modal
      await fundSwitchPage.basicsOfRiskBtn.click();
      await fundSwitchPage.undestandingRiskModal.heading.waitFor();

      await fundSwitchPage.pageCheck(
        visualFunctions,
        'ISA Fund switch - Understanding Investment Risk',
        skipVisualChecks,
      );

      await fundSwitchPage.undestandingRiskModal.closeBtn.click();

      // select the higher risk fund
      await fundSwitchPage.entryStep.higherRiskBtn.click();
      await fundSwitchPage.entryStep.higherRiskHeading.waitFor();

      await fundSwitchPage.pageCheck(
        visualFunctions,
        'ISA Fund switch - Higher risk option selected',
        skipVisualChecks,
        2000,
      );

      // Select the performance tab
      await fundSwitchPage.entryStep.tabs.performance.btn.click();
      await fundSwitchPage.entryStep.tabs.performance.heading.waitFor();

      await fundSwitchPage.pageCheck(
        visualFunctions,
        'ISA Fund switch - Higher risk option performance tab',
        skipVisualChecks,
      );

      // Continue the journey
      await fundSwitchPage.clickButton(fundSwitchPage.entryStep.continueBtn);
      await fundSwitchPage.reviewStep.heading.waitFor();

      await fundSwitchPage.pageCheck(
        visualFunctions,
        'ISA Fund switch - Review and confirm page',
        skipVisualChecks,
      );

      // check the back button
      await fundSwitchPage.reviewStep.backBtn.click();
      await fundSwitchPage.waitForPageToLoad();

      // Complete the journey
      await fundSwitchPage.entryStep.continueBtn.click();
      await fundSwitchPage.reviewStep.confirmBtn.click();
      await fundSwitchPage.allDoneStep.successMessage.waitFor();
      await fundSwitchPage.allDoneStep.backToDashboardBtn.click();
      await isaActivityPage.waitForPageToLoad();
    },
  );

  afterAllHook(test);
});
