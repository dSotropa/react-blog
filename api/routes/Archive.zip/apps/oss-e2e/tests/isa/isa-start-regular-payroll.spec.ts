import { expect } from '@playwright/test';
import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('ISA Payroll Start Regular Payments', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ isaActivityPage }) => {
    await isaActivityPage.authenticationPage.navigate('User3_ISA');
    await isaActivityPage.waitForPageToLoad();
  });

  test('Start Regular', async ({
    isaActivityPage,
    isaStartRegularPaymentPage,
    paymentsPage,
    skipVisualChecks,
  }) => {
    // Check the link in the tile
    await isaActivityPage.startRegularPaymentsBtn.click();
    await isaStartRegularPaymentPage.waitForPageToLoad();

    // Check the back button
    await isaStartRegularPaymentPage.clickButton(isaStartRegularPaymentPage.backBtn);
    await isaActivityPage.waitForPageToLoad();

    // Check the link from the payments tile
    await isaActivityPage.paymentsTile.click();
    await paymentsPage.waitForPageToLoad();
    await paymentsPage.startRegularPaymentsBtn.click();
    await isaStartRegularPaymentPage.waitForPageToLoad();

    // Check validation errors
    await isaStartRegularPaymentPage.clickButton(isaStartRegularPaymentPage.reviewBtn);
    await isaStartRegularPaymentPage.minAmountError.waitFor();
    await isaStartRegularPaymentPage.percentBtn.click();
    await isaStartRegularPaymentPage.minPercentError.waitFor();

    // Continue and review
    await isaStartRegularPaymentPage.amountInput.fill('50');
    await expect(isaStartRegularPaymentPage.minPercentError).not.toBeVisible();
    await isaStartRegularPaymentPage.clickButton(isaStartRegularPaymentPage.reviewBtn);
    await isaStartRegularPaymentPage.submitBtn.waitFor();

    // Submit
    await isaStartRegularPaymentPage.submitBtn.click();
    await isaStartRegularPaymentPage.gotItBtn.waitFor();
    await isaStartRegularPaymentPage.gotItBtn.click();
    await paymentsPage.waitForPageToLoad();
  });

  afterAllHook(test);
});
