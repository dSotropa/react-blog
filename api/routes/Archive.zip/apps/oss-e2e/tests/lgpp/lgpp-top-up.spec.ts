import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('LGPP Top-Up Journey', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ lgppActivityPage }) => {
    await lgppActivityPage.authenticationPage.navigate('User2_LGPP');
    await lgppActivityPage.waitForPageToLoad();
  });

  test('LGPP debit card top up CTAs', async ({
    lgppActivityPage,
    lgppPensionTopUpPage,
    skipVisualChecks,
  }) => {
    await lgppActivityPage.paymentsTile.topUpPensionBtn.click();
    await lgppPensionTopUpPage.waitForPageToLoad();

    await lgppPensionTopUpPage.pageCheck(
      visualFunctions,
      'LGPP - Top up your pension - entry',
      skipVisualChecks,
    );

    // Check the back button
    await lgppPensionTopUpPage.clickButton(lgppPensionTopUpPage.backBtn);
    await lgppActivityPage.waitForPageToLoad();

    // Continue journey - validation errors
    await lgppActivityPage.paymentsTile.topUpPensionBtn.click();
    await lgppPensionTopUpPage.waitForPageToLoad();
    await lgppPensionTopUpPage.clickButton(lgppPensionTopUpPage.entryStep.addBtn);
    await lgppPensionTopUpPage.entryStep.amountRequiredError.waitFor();
    await lgppPensionTopUpPage.entryStep.amountInput.fill('0');
    await lgppPensionTopUpPage.entryStep.amountMinError.waitFor();
    await lgppPensionTopUpPage.entryStep.amountInput.fill('100000.5');
    await lgppPensionTopUpPage.entryStep.wholeNumberError.waitFor();
    await lgppPensionTopUpPage.entryStep.amountInput.fill('1000000');
    await lgppPensionTopUpPage.entryStep.amountMaxError.waitFor();
  });

  test('LGPP debit card top-up success', async ({
    lgppActivityPage,
    lgppPensionTopUpPage,
    barclaysPaymentPage,
    skipVisualChecks,
  }) => {
    await lgppActivityPage.paymentsTile.topUpPensionBtn.click();
    await lgppPensionTopUpPage.waitForPageToLoad();
    await lgppPensionTopUpPage.entryStep.amountInput.fill('1');
    await lgppPensionTopUpPage.entryStep.personalDebitCardOption.click();
    await lgppPensionTopUpPage.clickButton(lgppPensionTopUpPage.entryStep.addBtn);
    await barclaysPaymentPage.waitForPageToLoad();
    await barclaysPaymentPage.investSecurlyBtn.click();
    await lgppPensionTopUpPage.allDoneStep.backToDashboardBtn.waitFor();

    await lgppPensionTopUpPage.pageCheck(
      visualFunctions,
      'ISA Top up page - all done',
      skipVisualChecks,
    );

    // Open the feedback survey
    await lgppPensionTopUpPage.allDoneStep.feedbackBtn.click();
    await lgppPensionTopUpPage.allDoneStep.feedbackSurveyCloseBtn.click();

    // Back to activity page
    await lgppPensionTopUpPage.allDoneStep.backToDashboardBtn.click();
    await lgppActivityPage.waitForPageToLoad();
  });

  test('LGPP debit card top-up order failure & payment error', async ({
    lgppActivityPage,
    lgppPensionTopUpPage,
    barclaysPaymentPage,
    skipVisualChecks,
  }) => {
    await lgppActivityPage.paymentsTile.topUpPensionBtn.click();
    await lgppPensionTopUpPage.waitForPageToLoad();
    await lgppPensionTopUpPage.entryStep.amountInput.fill('666');
    await lgppPensionTopUpPage.entryStep.personalDebitCardOption.click();
    await lgppPensionTopUpPage.clickButton(lgppPensionTopUpPage.entryStep.addBtn);
    await lgppPensionTopUpPage.allDoneStep.errorMessage.waitFor();

    await lgppPensionTopUpPage.pageCheck(
      visualFunctions,
      'LGPP Top up page - error',
      skipVisualChecks,
    );

    await lgppPensionTopUpPage.clickButton(lgppPensionTopUpPage.allDoneStep.gotItBtn);
    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.paymentsTile.topUpPensionBtn.click();
    await lgppPensionTopUpPage.waitForPageToLoad();
    await lgppPensionTopUpPage.entryStep.amountInput.fill('1');
    await lgppPensionTopUpPage.entryStep.personalDebitCardOption.click();
    await lgppPensionTopUpPage.clickButton(lgppPensionTopUpPage.entryStep.addBtn);
    await barclaysPaymentPage.waitForPageToLoad();
    await barclaysPaymentPage.errorWhenProcessingOption.click();
    await barclaysPaymentPage.investSecurlyBtn.click();
    await lgppPensionTopUpPage.allDoneStep.errorMessage.waitFor();
  });

  test('LGPP debit business card top-up success', async ({
    lgppActivityPage,
    lgppPensionTopUpPage,
    barclaysPaymentPage,
    skipVisualChecks,
  }) => {
    await lgppActivityPage.paymentsTile.topUpPensionBtn.click();
    await lgppPensionTopUpPage.waitForPageToLoad();
    await lgppPensionTopUpPage.entryStep.amountInput.fill('1');
    await lgppPensionTopUpPage.entryStep.businessDebitCardOption.click();
    await lgppPensionTopUpPage.entryStep.businessDebitCardAlert.waitFor();

    await lgppPensionTopUpPage.pageCheck(
      visualFunctions,
      'LGPP Top up page - business debit card',
      skipVisualChecks,
    );

    // Company details
    await lgppPensionTopUpPage.clickButton(lgppPensionTopUpPage.entryStep.addBtn);
    await lgppPensionTopUpPage.companyDetailsStep.heading.waitFor();

    await lgppPensionTopUpPage.pageCheck(
      visualFunctions,
      'LGPP Top up page - company details',
      skipVisualChecks,
    );

    // Client validation errors
    await lgppPensionTopUpPage.companyDetailsStep.checkDetailsBtn.click();
    await lgppPensionTopUpPage.companyDetailsStep.crnRequiredError.waitFor();
    await lgppPensionTopUpPage.companyDetailsStep.crnInput.fill('1234567');
    await lgppPensionTopUpPage.companyDetailsStep.checkDetailsBtn.click();
    await lgppPensionTopUpPage.companyDetailsStep.crnMinLenghError.waitFor();

    // Server errors
    await lgppPensionTopUpPage.companyDetailsStep.crnInput.fill('ER000000');
    await lgppPensionTopUpPage.companyDetailsStep.checkDetailsBtn.click();
    await lgppPensionTopUpPage.companyDetailsStep.crnGenericError.waitFor();

    await lgppPensionTopUpPage.companyDetailsStep.crnInput.fill('CV000001');
    await lgppPensionTopUpPage.companyDetailsStep.checkDetailsBtn.click();
    await lgppPensionTopUpPage.companyDetailsStep.crnNotRecognisedError.waitFor();

    // Success
    await lgppPensionTopUpPage.companyDetailsStep.crnInput.fill('12345678');
    await lgppPensionTopUpPage.companyDetailsStep.checkDetailsBtn.click();
    await lgppPensionTopUpPage.companyDetailsStep.companyDetailsAlert.waitFor();

    await lgppPensionTopUpPage.pageCheck(
      visualFunctions,
      'LGPP Top up page - company details - after check',
      skipVisualChecks,
    );

    // Continue
    await lgppPensionTopUpPage.companyDetailsStep.continueBtn.click();
    await barclaysPaymentPage.waitForPageToLoad();
  });

  afterAllHook(test);
});
