import { expect } from '@playwright/test';
import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('LGPP Amend Direct Debit Journey', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test('LGPP amend direct debit contribution', async ({
    lgppActivityPage,
    paymentsPage,
    lgppAmendDirectDebitPage,
    skipVisualChecks,
  }) => {
    await lgppActivityPage.authenticationPage.navigate('User33_LGPP_Test');
    await lgppActivityPage.waitForPageToLoad();

    await lgppActivityPage.pageCheck(
      visualFunctions,
      'LGPP - Activity page User33_LGPP_Test',
      skipVisualChecks,
    );

    await lgppActivityPage.paymentsTile.tile.click();
    await paymentsPage.waitForPageToLoad();
    await paymentsPage.amendDirectDebitsBtn.click();
    await lgppAmendDirectDebitPage.waitForPageToLoad();

    await lgppAmendDirectDebitPage.pageCheck(
      visualFunctions,
      'LGPP - Amend direct debit - direct debit payment',
      skipVisualChecks,
    );

    // Check the  back button
    await lgppAmendDirectDebitPage.clickButton(lgppAmendDirectDebitPage.backBtn);
    await paymentsPage.waitForPageToLoad();

    // Check validation errors
    await paymentsPage.amendDirectDebitsBtn.click();
    await lgppAmendDirectDebitPage.waitForPageToLoad();
    await lgppAmendDirectDebitPage.paymentStep.amountInput.fill('');
    await lgppAmendDirectDebitPage.paymentStep.amountRequiredError.waitFor();
    await lgppAmendDirectDebitPage.paymentStep.amountInput.fill('159.3');
    await lgppAmendDirectDebitPage.paymentStep.amountWholeNumberError.waitFor();
    await lgppAmendDirectDebitPage.paymentStep.amountInput.fill('750');

    await expect(
      lgppAmendDirectDebitPage.paymentStep.amountWithTopupParagraph,
    ).toContainText('£937.50');
  });

  test('LGPP amend direct debit payment day successfully', async ({
    lgppActivityPage,
    lgppAmendDirectDebitPage,
    skipVisualChecks,
  }) => {
    // Enter amount
    await lgppActivityPage.authenticationPage.navigate('User33_LGPP_Test');
    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.paymentsTile.amendDirectDebitBtn.click();
    await lgppAmendDirectDebitPage.waitForPageToLoad();
    await lgppAmendDirectDebitPage.paymentStep.amountInput.fill('120');

    await expect(lgppAmendDirectDebitPage.paymentStep.addBtn).toContainText(
      'Add £120 every month',
    );

    await lgppAmendDirectDebitPage.clickButton(
      lgppAmendDirectDebitPage.paymentStep.addBtn,
    );

    // Select monthly payment date
    await lgppAmendDirectDebitPage.directDebitDetailsStep.heading.waitFor();

    await lgppAmendDirectDebitPage.pageCheck(
      visualFunctions,
      'LGPP - Amend direct debit - direct debit details',
      skipVisualChecks,
    );

    await lgppAmendDirectDebitPage.directDebitDetailsStep.monthlyPaymentDateSelect.selectOption(
      '16',
    );

    await lgppAmendDirectDebitPage.continueBtn.click();

    // Review
    await lgppAmendDirectDebitPage.reviewStep.heading.waitFor();

    await lgppAmendDirectDebitPage.pageCheck(
      visualFunctions,
      'LGPP - Amend direct debit - review',
      skipVisualChecks,
    );

    await lgppAmendDirectDebitPage.reviewStep.confirmBtn.click();

    // All done
    await lgppAmendDirectDebitPage.allDoneStep.successMessage.waitFor();

    await lgppAmendDirectDebitPage.pageCheck(
      visualFunctions,
      'LGPP - Amend direct debit - all done page',
      skipVisualChecks,
    );

    await lgppAmendDirectDebitPage.allDoneStep.backToDashboardtn.click();
    await lgppActivityPage.waitForPageToLoad();
  });

  test('LGPP amend direct debit bank details failure', async ({
    lgppActivityPage,
    lgppAmendDirectDebitPage,
    skipVisualChecks,
  }) => {
    await lgppActivityPage.authenticationPage.navigate('User33_LGPP_Test');
    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.paymentsTile.amendDirectDebitBtn.click();
    await lgppAmendDirectDebitPage.waitForPageToLoad();
    await lgppAmendDirectDebitPage.paymentStep.amountInput.fill('1002');

    await lgppAmendDirectDebitPage.clickButton(
      lgppAmendDirectDebitPage.paymentStep.addBtn,
    );

    await lgppAmendDirectDebitPage.directDebitDetailsStep.monthlyPaymentDateSelect.selectOption(
      '22',
    );

    await lgppAmendDirectDebitPage.continueBtn.click();
    await lgppAmendDirectDebitPage.reviewStep.heading.waitFor();
    await lgppAmendDirectDebitPage.reviewStep.confirmBtn.click();
    await lgppAmendDirectDebitPage.allDoneStep.errorMessage.waitFor();

    await lgppAmendDirectDebitPage.pageCheck(
      visualFunctions,
      'LGPP - Amend direct debit - all error page',
      skipVisualChecks,
    );

    await lgppAmendDirectDebitPage.allDoneStep.backToDashboardtn.click();
    await lgppActivityPage.waitForPageToLoad();
  });

  test('Amend direct debit not available when an existing dd is due', async ({
    lgppActivityPage,
  }) => {
    await lgppActivityPage.authenticationPage.navigate(
      'LGPP_User_waiting_for_wake_up_pack',
    );

    await lgppActivityPage.waitForPageToLoad();
    await expect(lgppActivityPage.paymentsTile.amendDirectDebitBtn).not.toBeVisible();
  });

  test(' Manage Pension Menu', async ({ lgppActivityPage }) => {
    await lgppActivityPage.authenticationPage.navigate('User33_LGPP_Test');
    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.managePensions.dropdownBtn.click();

    await expect(lgppActivityPage.managePensions.dropdownitems).toContainText([
      'Top up your Pension',
      'Stop payments',
      'Change regular contribution',
      'Transfer in',
      'Change fund',
    ]);
  });

  afterAllHook(test);
});
