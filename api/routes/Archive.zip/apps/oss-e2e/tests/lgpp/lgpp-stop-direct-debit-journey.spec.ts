import { expect } from '@playwright/test';
import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('LGPP Stop Direct Debit Journey', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test('LGPP Stop Direct Debit Journey', async ({
    lgppActivityPage,
    paymentsPage,
    stopDirectDebitConfirmModal,
    stopDirectDebitDoneModal,
    skipVisualChecks,
  }) => {
    await lgppActivityPage.authenticationPage.navigate('User33_LGPP_Test');
    await lgppActivityPage.waitForPageToLoad();

    // From the payments tile
    await lgppActivityPage.paymentsTile.stopPaymentsBtn.click();
    await stopDirectDebitConfirmModal.modal.waitFor();

    await stopDirectDebitConfirmModal.pageCheck(
      visualFunctions,
      'LGPP - Stop payments - confirm modal',
      skipVisualChecks,
    );

    await stopDirectDebitConfirmModal.backBtn.click();
    await stopDirectDebitConfirmModal.modal.waitFor();

    // From the payments page
    await lgppActivityPage.paymentsTile.tile.click();
    await paymentsPage.waitForPageToLoad();

    await paymentsPage.pageCheck(
      visualFunctions,
      'LGPP - Stop payments - payments page',
      skipVisualChecks,
    );

    await paymentsPage.stopPaymentsBtn.click();
    await stopDirectDebitConfirmModal.modal.waitFor();
    await stopDirectDebitConfirmModal.backBtn.click();
    await expect(stopDirectDebitConfirmModal.modal).not.toBeVisible();
    await paymentsPage.stopPaymentsBtn.click();
    await stopDirectDebitConfirmModal.modal.waitFor();
    await stopDirectDebitConfirmModal.confirmBtn.click();
    await stopDirectDebitDoneModal.modal.waitFor();

    await paymentsPage.pageCheck(
      visualFunctions,
      'LGPP - Stop payments - done modal',
      skipVisualChecks,
    );

    await stopDirectDebitDoneModal.gotItBtn.click();
    await expect(stopDirectDebitDoneModal.modal).not.toBeVisible();
  });

  afterAllHook(test);
});
