import { expect } from '@playwright/test';
import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('LGPP Pension transfer in Journey', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  // Causes the test run to hang in CI and is cancelled after 40 mins
  test.fixme(
    'Successful Journey',
    async ({ lgppActivityPage, lgppTransferInPensionPage, skipVisualChecks }) => {
      await lgppActivityPage.authenticationPage.navigate('User2_LGPP');
      await lgppActivityPage.waitForPageToLoad();
      await lgppActivityPage.managePensions.dropdownBtn.click();
      await lgppActivityPage.managePensions.transferInBtn.click();
      await lgppTransferInPensionPage.waitForPageToLoad();

      await lgppTransferInPensionPage.pageCheck(
        visualFunctions,
        'LGPP - Transfer in a pension - Important information',
        skipVisualChecks,
      );

      // Check breadcrumb and back buttons
      await lgppTransferInPensionPage.personalPensionBreadcrumb.click();
      await lgppActivityPage.waitForPageToLoad();
      await lgppActivityPage.managePensions.dropdownBtn.click();
      await lgppActivityPage.managePensions.transferInBtn.click();
      await lgppTransferInPensionPage.waitForPageToLoad();
      await lgppTransferInPensionPage.backBtn.click();
      await lgppActivityPage.waitForPageToLoad();

      // Continue
      await lgppActivityPage.managePensions.dropdownBtn.click();
      await lgppActivityPage.managePensions.transferInBtn.click();
      await lgppTransferInPensionPage.waitForPageToLoad();

      // Your pension details
      await lgppTransferInPensionPage.continueBtn.click();
      await lgppTransferInPensionPage.yourDetails.heading.waitFor();

      await lgppTransferInPensionPage.pageCheck(
        visualFunctions,
        'LGPP - Transfer in a pension - Your pension details',
        skipVisualChecks,
      );

      await lgppTransferInPensionPage.yourDetails.accordianToggleBtn.click();

      await expect(
        lgppTransferInPensionPage.yourDetails.accordianContent,
      ).not.toBeVisible();

      await lgppTransferInPensionPage.clickButton(lgppTransferInPensionPage.backBtn);
      await lgppTransferInPensionPage.waitForPageToLoad();
      await lgppTransferInPensionPage.clickButton(lgppTransferInPensionPage.continueBtn);
      await lgppTransferInPensionPage.yourDetails.heading.waitFor();

      // Validation errors
      await lgppTransferInPensionPage.page.pause();
      await lgppTransferInPensionPage.clickButton(lgppTransferInPensionPage.continueBtn);
      await lgppTransferInPensionPage.yourDetails.valueRequiredError.waitFor();
      await lgppTransferInPensionPage.yourDetails.providerRequiredError.waitFor();
      await lgppTransferInPensionPage.yourDetails.policyNumberReqiredError.waitFor();

      await lgppTransferInPensionPage.yourDetails.valueInput.fill('0.5');
      await lgppTransferInPensionPage.page.keyboard.press('Tab');
      await lgppTransferInPensionPage.yourDetails.valueMinError.waitFor();

      // Continue and review
      await lgppTransferInPensionPage.yourDetails.valueInput.fill('100000');
      await lgppTransferInPensionPage.yourDetails.providerInput.fill('Aegon');
      await lgppTransferInPensionPage.yourDetails.policyNumberInput.fill('123');
      await lgppTransferInPensionPage.clickButton(lgppTransferInPensionPage.continueBtn);
      await lgppTransferInPensionPage.review.heading.waitFor();

      await lgppTransferInPensionPage.pageCheck(
        visualFunctions,
        'LGPP - Transfer in a pension - Review your pension details',
        skipVisualChecks,
      );

      await lgppTransferInPensionPage.clickButton(
        lgppTransferInPensionPage.review.editBtn,
      );

      await lgppTransferInPensionPage.yourDetails.heading.waitFor();
      await lgppTransferInPensionPage.clickButton(lgppTransferInPensionPage.continueBtn);

      // All done
      await lgppTransferInPensionPage.clickButton(
        lgppTransferInPensionPage.review.confirmTransferBtn,
      );

      await lgppTransferInPensionPage.allDone.successMessage.waitFor();
    },
  );

  afterAllHook(test);
});
