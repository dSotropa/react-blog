import { expect } from '@playwright/test';
import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('LGPP activity', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ lgppActivityPage }) => {
    await lgppActivityPage.authenticationPage.navigate('User2_LGPP');
  });

  test('LGPP OSS', async ({
    lgppActivityPage,
    investmentsPage,
    paymentsPage,
    documentsPage,
    lgppPensionDetailsPage,
    fundDetailsPage,
    skipVisualChecks,
  }) => {
    await lgppActivityPage.waitForPageToLoad();

    await lgppActivityPage.pageCheck(
      visualFunctions,
      'LGPP - Activity page User2_LGPP',
      skipVisualChecks,
    );

    // Investments page
    await lgppActivityPage.investmentsTile.tile.click();
    await investmentsPage.waitForPageToLoad();
    await investmentsPage.backToSummaryBtn.click();
    await lgppActivityPage.waitForPageToLoad();

    // Payments page
    await lgppActivityPage.paymentsTile.tile.click();
    await paymentsPage.waitForPageToLoad();
    await paymentsPage.backToSummaryBtn.click();
    await lgppActivityPage.waitForPageToLoad();

    // Documents page
    await lgppActivityPage.documentsTile.click();
    await documentsPage.waitForPageToLoad();
    await documentsPage.backToSummaryBtn.click();
    await lgppActivityPage.waitForPageToLoad();

    // Pension details
    await lgppActivityPage.pensionDetailsTile.click();
    await lgppPensionDetailsPage.waitForPageToLoad();
    await lgppPensionDetailsPage.backToSummaryBtn.click();
    await lgppActivityPage.waitForPageToLoad();

    // Fund details page
    await lgppActivityPage.investmentsTile.multiIndex3FundLink.click();
    await fundDetailsPage.waitForPageToLoad();
    await fundDetailsPage.backToSummaryBtn.click();
    await lgppActivityPage.waitForPageToLoad();
  });

  test('Manage pension menu', async ({ lgppActivityPage }) => {
    await lgppActivityPage.managePensions.dropdownBtn.click();

    await expect(lgppActivityPage.managePensions.dropdownitems).toContainText([
      'Top up your Pension',
      'Set up regular contribution',
      'Change regular contribution',
      'Transfer in',
      'Change fund',
    ]);

    await lgppActivityPage.page.keyboard.press('Escape');
    await expect(lgppActivityPage.managePensions.dropdownitems).not.toBeVisible();
  });

  afterAllHook(test);
});
