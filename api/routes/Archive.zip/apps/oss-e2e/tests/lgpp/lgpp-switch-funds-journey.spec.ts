import { expect } from '@playwright/test';
import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('LGPP Switch Funds Journey', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  // Causes the test run to hang in CI and is cancelled after 40 mins
  test.fixme(
    'Outstanding balance - cannot start journey',
    async ({ lgppActivityPage }) => {
      await lgppActivityPage.authenticationPage.navigate(
        'LGPP_User_with_outstanding_balance',
      );

      await lgppActivityPage.waitForPageToLoad();

      await expect(
        lgppActivityPage.investmentsTile.changeInvestmentsBtn,
      ).not.toBeVisible();
    },
  );

  test('Successful Journey', async ({
    lgppActivityPage,
    changeInvestmentsPage,
    fundSwitchPage,
    skipVisualChecks,
  }) => {
    await lgppActivityPage.authenticationPage.navigate('LGPP_User_can_switch_funds');
    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.investmentsTile.changeInvestmentsBtn.click();
    await changeInvestmentsPage.waitForPageToLoad();
    await changeInvestmentsPage.overview.simpleFunds.viewOptionsBtn.click();
    await fundSwitchPage.waitForPageToLoad();

    // select the medium risk fund
    await fundSwitchPage.entryStep.higherRiskBtn.click();
    await fundSwitchPage.entryStep.higherRiskHeading.waitFor();

    await fundSwitchPage.pageCheck(
      visualFunctions,
      'LGPP Fund switch - Higher risk option selected',
      skipVisualChecks,
      2000,
    );

    // Select the perfomance tab
    await fundSwitchPage.entryStep.tabs.performance.btn.click();
    await fundSwitchPage.entryStep.tabs.performance.heading.waitFor();

    await fundSwitchPage.pageCheck(
      visualFunctions,
      'LGPP Fund switch - Higher risk option performance tab',
      skipVisualChecks,
    );

    // Continue the journey
    await fundSwitchPage.entryStep.continueBtn.click();
    await fundSwitchPage.reviewStep.heading.waitFor();

    await fundSwitchPage.pageCheck(
      visualFunctions,
      'LPGG Fund switch - Review and confirm page - Higher risk',
      skipVisualChecks,
    );

    // check the back button
    await fundSwitchPage.reviewStep.backBtn.click();
    await fundSwitchPage.entryStep.heading.waitFor();

    // Complete the journey
    await fundSwitchPage.entryStep.continueBtn.click();
    await fundSwitchPage.reviewStep.confirmBtn.click();
    await fundSwitchPage.allDoneStep.successMessage.waitFor();

    await fundSwitchPage.pageCheck(
      visualFunctions,
      'LGPP Fund switch - All done page - success',
      skipVisualChecks,
    );

    await fundSwitchPage.allDoneStep.backToDashboardBtn.click();
    await lgppActivityPage.waitForPageToLoad();
  });

  test('Failure Journey - switch fund completed with error', async ({
    lgppActivityPage,
    changeInvestmentsPage,
    fundSwitchPage,
    skipVisualChecks,
  }) => {
    await lgppActivityPage.authenticationPage.navigate('LGPP_User_can_switch_funds');
    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.investmentsTile.changeInvestmentsBtn.click();
    await changeInvestmentsPage.overview.simpleFunds.viewOptionsBtn.click();

    // select the medium risk fund
    await fundSwitchPage.entryStep.mediumRiskBtn.click();
    await fundSwitchPage.entryStep.mediumRiskHeading.waitFor();

    await fundSwitchPage.pageCheck(
      visualFunctions,
      'LGPP Fund switch - Medium risk option selected',
      skipVisualChecks,
      2000,
    );

    // Select the perfomance tab
    await fundSwitchPage.entryStep.tabs.performance.btn.click();
    await fundSwitchPage.entryStep.tabs.performance.heading.waitFor();

    await fundSwitchPage.pageCheck(
      visualFunctions,
      'LGPP Fund switch - Medium risk option performance tab',
      skipVisualChecks,
    );

    // Continue the journey
    await fundSwitchPage.entryStep.continueBtn.click();
    await fundSwitchPage.reviewStep.heading.waitFor();

    await fundSwitchPage.pageCheck(
      visualFunctions,
      'LPGG Fund switch - Review and confirm page - Medium risk',
      skipVisualChecks,
    );

    // Complete the journey
    await fundSwitchPage.reviewStep.confirmBtn.click();
    await fundSwitchPage.allDoneStep.errorMessage.waitFor();

    await fundSwitchPage.pageCheck(
      visualFunctions,
      'LGPP Fund switch - All done page - error',
      skipVisualChecks,
    );

    await fundSwitchPage.allDoneStep.backToDashboardBtn.click();
    await lgppActivityPage.waitForPageToLoad();
  });

  test('Failure Journey - can not continue without selecting a new risk level', async ({
    lgppActivityPage,
    changeInvestmentsPage,
    fundSwitchPage,
  }) => {
    await lgppActivityPage.authenticationPage.navigate('LGPP_User_can_switch_funds');
    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.investmentsTile.changeInvestmentsBtn.click();
    await changeInvestmentsPage.overview.simpleFunds.viewOptionsBtn.click();
    await fundSwitchPage.entryStep.continueBtn.click();
    await fundSwitchPage.entryStep.selectFundAlert.waitFor();
  });

  afterAllHook(test);
});
