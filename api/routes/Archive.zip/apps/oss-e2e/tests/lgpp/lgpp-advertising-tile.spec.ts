import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('LGPP Advertising tile', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test('Simplify your pension', async ({
    lgppActivityPage,
    lgppTransferInPensionPage,
    skipVisualChecks,
  }) => {
    await lgppActivityPage.authenticationPage.navigate('User2_LGPP');
    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.advertisingTile.tileBtn(2).click();
    await lgppActivityPage.advertisingTile.simplifyYourPension.heading.waitFor();

    await lgppActivityPage.advertisingTile.pageCheck(
      visualFunctions,
      'LGPP - Advertising tile - simplify your pension',
      skipVisualChecks,
    );

    await lgppActivityPage.advertisingTile.simplifyYourPension.howATransferWorksBtn.click();
    await lgppActivityPage.advertisingTile.simplifyYourPension.infoPage.waitFor();

    await lgppActivityPage.advertisingTile.pageCheck(
      visualFunctions,
      'LGPP - Simplify your pension saving',
      skipVisualChecks,
    );

    await lgppActivityPage.advertisingTile.simplifyYourPension.startTransferBtn.click();
    await lgppTransferInPensionPage.waitForPageToLoad();
  });

  test('Find your lost pension', async ({ lgppActivityPage, skipVisualChecks }) => {
    await lgppActivityPage.authenticationPage.navigate('User2_LGPP');
    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.advertisingTile.tileBtn(3).click();
    await lgppActivityPage.advertisingTile.findLostPensions.heading.waitFor();

    await lgppActivityPage.advertisingTile.pageCheck(
      visualFunctions,
      'LGPP - Advertising tile - Find your lost and old pensions',
      skipVisualChecks,
    );

    await lgppActivityPage.advertisingTile.findLostPensions.howTracingWorksBtn.click();
    await lgppActivityPage.advertisingTile.findLostPensions.infoPage.waitFor();

    await lgppActivityPage.advertisingTile.pageCheck(
      visualFunctions,
      'LGPP - Find your lost and old pensions',
      skipVisualChecks,
    );
  });

  test('Tax year end advert', async ({
    lgppActivityPage,
    lgppPensionTopUpPage,
    skipVisualChecks,
  }) => {
    await lgppActivityPage.authenticationPage.navigate('LGPP_tax_year_end');
    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.advertisingTile.tileBtn(2).click();
    await lgppActivityPage.advertisingTile.taxYearEnd.heading.waitFor();

    await lgppActivityPage.advertisingTile.pageCheck(
      visualFunctions,
      'LGPP - Advertising tile - Tax year end',
      skipVisualChecks,
    );

    await lgppActivityPage.advertisingTile.taxYearEnd.topUpBtn.click();
    await lgppPensionTopUpPage.waitForPageToLoad();
  });

  afterAllHook(test);
});
