import { expect } from '@playwright/test';
import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('LGPP Setup Direct Debit Journey', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ lgppActivityPage }) => {
    await lgppActivityPage.authenticationPage.navigate('User2_LGPP');
    await lgppActivityPage.waitForPageToLoad();
  });

  test('LGPP setup direct debit advance notice', async ({
    lgppActivityPage,
    lgppSetupDirectDebitPage,
    paymentsPage,
    skipVisualChecks,
  }) => {
    await lgppActivityPage.paymentsTile.startRegularContributionBtn.click();
    await lgppSetupDirectDebitPage.waitForPageToLoad();

    await lgppSetupDirectDebitPage.pageCheck(
      visualFunctions,
      'LGPP - Start up a regular contribution - overview',
      skipVisualChecks,
    );

    await lgppSetupDirectDebitPage.personalPensionBreadcrumb.click();
    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.paymentsTile.startRegularContributionBtn.click();
    await lgppSetupDirectDebitPage.waitForPageToLoad();
    await lgppSetupDirectDebitPage.backBtn.click();
    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.paymentsTile.tile.click();
    await paymentsPage.waitForPageToLoad();
    await paymentsPage.startRegularPaymentsBtn.click();
    await lgppSetupDirectDebitPage.waitForPageToLoad();
  });

  test('LGPP setup direct debit contribution validations', async ({
    lgppActivityPage,
    lgppSetupDirectDebitPage,
  }) => {
    await lgppActivityPage.paymentsTile.startRegularContributionBtn.click();
    await lgppSetupDirectDebitPage.waitForPageToLoad();
    await lgppSetupDirectDebitPage.continueBtn.click();
    await lgppSetupDirectDebitPage.paymentStep.heading.waitFor();

    // Payment page
    await lgppSetupDirectDebitPage.paymentStep.addBtn.click();
    await lgppSetupDirectDebitPage.paymentStep.amountRequiredError.waitFor();
    await lgppSetupDirectDebitPage.paymentStep.amountInput.fill('0');
    await lgppSetupDirectDebitPage.paymentStep.amountMinError.waitFor();
    await lgppSetupDirectDebitPage.paymentStep.amountInput.fill('159.3');
    await lgppSetupDirectDebitPage.paymentStep.amountWholeNumberError.waitFor();
    await lgppSetupDirectDebitPage.paymentStep.amountInput.fill('750');

    await expect(
      lgppSetupDirectDebitPage.paymentStep.amountWholeNumberError,
    ).not.toBeVisible();

    await lgppSetupDirectDebitPage.backBtn.click();
    await lgppSetupDirectDebitPage.overview.heading.waitFor();
  });

  test('LGPP setup direct debit bank details successfully', async ({
    lgppActivityPage,
    lgppSetupDirectDebitPage,
    skipVisualChecks,
  }) => {
    await lgppActivityPage.paymentsTile.startRegularContributionBtn.click();
    await lgppSetupDirectDebitPage.waitForPageToLoad();
    await lgppSetupDirectDebitPage.continueBtn.click();

    // Payments step
    await lgppSetupDirectDebitPage.paymentStep.heading.waitFor();

    await lgppSetupDirectDebitPage.pageCheck(
      visualFunctions,
      'LGPP - Setup up a regular contribution - direct debit payment',
      skipVisualChecks,
    );

    await lgppSetupDirectDebitPage.paymentStep.amountInput.fill('120');
    await lgppSetupDirectDebitPage.paymentStep.addBtn.click();

    // Direct debit details step
    await lgppSetupDirectDebitPage.directDebitDetailsStep.heading.waitFor();

    await lgppSetupDirectDebitPage.pageCheck(
      visualFunctions,
      'LGPP - Start up a regular contribution - direct debit details',
      skipVisualChecks,
    );

    // Check validation errors
    await lgppSetupDirectDebitPage.continueBtn.click();
    await lgppSetupDirectDebitPage.directDebitDetailsStep.sortCodeRequiredError.waitFor();
    await lgppSetupDirectDebitPage.directDebitDetailsStep.accountNumberRequiredError.waitFor();
    await lgppSetupDirectDebitPage.directDebitDetailsStep.monthlPaymentDateRequiredError.waitFor();
    await lgppSetupDirectDebitPage.directDebitDetailsStep.confirmRequiredError.waitFor();
    await lgppSetupDirectDebitPage.directDebitDetailsStep.sortCodeInput1.fill('20');
    await lgppSetupDirectDebitPage.directDebitDetailsStep.sortCodeInput2.fill('00');
    await lgppSetupDirectDebitPage.directDebitDetailsStep.sortCodeInput3.fill('0');
    await lgppSetupDirectDebitPage.directDebitDetailsStep.sortCodeRequiredError.waitFor();
    await lgppSetupDirectDebitPage.directDebitDetailsStep.sortCodeInput3.fill('ab');
    await lgppSetupDirectDebitPage.directDebitDetailsStep.sortCodeRequiredError.waitFor();

    await lgppSetupDirectDebitPage.directDebitDetailsStep.accountNumberInput.fill(
      '121212',
    );

    await lgppSetupDirectDebitPage.directDebitDetailsStep.accountNumberRequiredError.waitFor();

    // Continue
    await lgppSetupDirectDebitPage.directDebitDetailsStep.sortCodeInput3.fill('00');

    await lgppSetupDirectDebitPage.directDebitDetailsStep.accountNumberInput.fill(
      '12121212',
    );

    await lgppSetupDirectDebitPage.directDebitDetailsStep.monthlyPaymentDateSelect.selectOption(
      '6',
    );

    await lgppSetupDirectDebitPage.directDebitDetailsStep.confirmCheckbox.click();
    await lgppSetupDirectDebitPage.directDebitDetailsStep.bankNameMessage.waitFor();

    await lgppSetupDirectDebitPage.continueBtn.click();

    // Review page
    await lgppSetupDirectDebitPage.reviewStep.heading.waitFor();

    await lgppSetupDirectDebitPage.pageCheck(
      visualFunctions,
      'LGPP - Start up a regular contribution - review',
      skipVisualChecks,
    );

    await lgppSetupDirectDebitPage.reviewStep.confirmBtn.click();

    // All done page
    await lgppSetupDirectDebitPage.allDoneStep.successMessage.waitFor();
    await lgppSetupDirectDebitPage.allDoneStep.backToDashboardtn.click();
    await lgppActivityPage.waitForPageToLoad();
  });

  test('LGPP setup direct debit bank details failure', async ({
    lgppActivityPage,
    lgppSetupDirectDebitPage,
  }) => {
    await lgppActivityPage.paymentsTile.startRegularContributionBtn.click();
    await lgppSetupDirectDebitPage.waitForPageToLoad();
    await lgppSetupDirectDebitPage.continueBtn.click();
    await lgppSetupDirectDebitPage.paymentStep.heading.waitFor();
    await lgppSetupDirectDebitPage.paymentStep.amountInput.fill('1002');
    await lgppSetupDirectDebitPage.paymentStep.addBtn.click();
    await lgppSetupDirectDebitPage.directDebitDetailsStep.sortCodeInput1.fill('20');
    await lgppSetupDirectDebitPage.directDebitDetailsStep.sortCodeInput2.fill('00');
    await lgppSetupDirectDebitPage.directDebitDetailsStep.sortCodeInput3.fill('00');

    await lgppSetupDirectDebitPage.directDebitDetailsStep.accountNumberInput.fill(
      '12121212',
    );

    await lgppSetupDirectDebitPage.directDebitDetailsStep.monthlyPaymentDateSelect.selectOption(
      '26',
    );

    await lgppSetupDirectDebitPage.directDebitDetailsStep.confirmCheckbox.click();
    await lgppSetupDirectDebitPage.continueBtn.click();
    await lgppSetupDirectDebitPage.reviewStep.heading.waitFor();
    await lgppSetupDirectDebitPage.reviewStep.confirmBtn.click();
    await lgppSetupDirectDebitPage.allDoneStep.errorMessage.waitFor();
    await lgppSetupDirectDebitPage.allDoneStep.backToDashboardtn.click();
    await lgppActivityPage.waitForPageToLoad();
  });

  afterAllHook(test);
});
