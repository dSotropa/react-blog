import { expect } from '@playwright/test';
import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('LGPP Move to Drawdown Journey', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test('Retirement Options Overlay', async ({ lgppActivityPage, skipVisualChecks }) => {
    await lgppActivityPage.authenticationPage.navigate('User2_LGPP');
    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.retirementOptionsTile.click();
    await lgppActivityPage.waitForOverlayToLoad();
    await lgppActivityPage.retirementOptionsOverlay.closeBtn.click();
    await expect(lgppActivityPage.retirementOptionsOverlay.heading).not.toBeVisible();

    await lgppActivityPage.retirementOptionsTile.click();
    await lgppActivityPage.retirementOptionsOverlay.leaveItWhereItIsBtn.click();
    await lgppActivityPage.retirementOptionsOverlay.pensionDrawdown.heading.click();
    await lgppActivityPage.retirementOptionsOverlay.pensionAnnuityBtn.click();
    await lgppActivityPage.retirementOptionsOverlay.fixedTermBtn.click();
    await lgppActivityPage.retirementOptionsOverlay.cashOutBtn.click();
    await lgppActivityPage.retirementOptionsOverlay.cashInBtn.click();

    await lgppActivityPage.pageCheck(
      visualFunctions,
      'LGPP - Retirement options overlay - Expanded',
      skipVisualChecks,
    );
  });

  // Causes the test run to hang in CI and is cancelled after 40 mins
  test.fixme(
    'Successful Journey',
    async ({ lgppActivityPage, lgppMoveToDrawdownPage, skipVisualChecks }) => {
      // What you need to know step
      await lgppActivityPage.authenticationPage.navigate('User2_LGPP');
      await lgppActivityPage.waitForPageToLoad();
      await lgppActivityPage.retirementOptionsTile.click();
      await lgppActivityPage.retirementOptionsOverlay.heading.waitFor();
      await lgppActivityPage.retirementOptionsOverlay.pensionDrawdown.heading.click();
      await lgppActivityPage.retirementOptionsOverlay.pensionDrawdown.applyBtn.click();
      await lgppMoveToDrawdownPage.waitForPageToLoad();

      await lgppMoveToDrawdownPage.pageCheck(
        visualFunctions,
        'LGPP - Apply for drawdown - What you need to know',
        skipVisualChecks,
      );

      await lgppMoveToDrawdownPage.whatYouNeedToKnowStep.keyFeaturesLink.waitFor();

      await lgppMoveToDrawdownPage.whatYouNeedToKnowStep.termsAndConditionsLink.waitFor();

      // Check breadcrumb and cancel buttons
      await lgppMoveToDrawdownPage.personalPensionBreadcrumb.click();
      await lgppActivityPage.waitForPageToLoad();
      await lgppActivityPage.retirementOptionsTile.click();
      await lgppActivityPage.retirementOptionsOverlay.heading.waitFor();
      await lgppActivityPage.retirementOptionsOverlay.pensionDrawdown.heading.click();
      await lgppActivityPage.retirementOptionsOverlay.pensionDrawdown.applyBtn.click();
      await lgppMoveToDrawdownPage.waitForPageToLoad();
      await lgppMoveToDrawdownPage.cancelBtn.click();
      await lgppActivityPage.waitForPageToLoad();

      // Continue to Pension Wise appointment
      await lgppActivityPage.retirementOptionsTile.click();
      await lgppActivityPage.retirementOptionsOverlay.heading.waitFor();
      await lgppActivityPage.retirementOptionsOverlay.pensionDrawdown.heading.click();
      await lgppActivityPage.retirementOptionsOverlay.pensionDrawdown.applyBtn.click();
      await lgppMoveToDrawdownPage.waitForPageToLoad();
      await lgppMoveToDrawdownPage.continueBtn.click();
      await lgppMoveToDrawdownPage.pensionWiseStep.heading.waitFor();
      await lgppMoveToDrawdownPage.accessibilityCheck();

      await lgppMoveToDrawdownPage.pensionWiseStep.appointmentSelect.selectOption(
        'noAdviceGuidanceWanted',
      );

      await lgppMoveToDrawdownPage.pensionWiseStep.infoMessage.waitFor();

      // Important considerations
      await lgppMoveToDrawdownPage.continueBtn.click();
      await lgppMoveToDrawdownPage.importantConsiderationsStep.heading.waitFor();

      await lgppMoveToDrawdownPage.continueBtn.click();

      await expect(
        lgppMoveToDrawdownPage.importantConsiderationsStep.validationError,
      ).toHaveCount(5);

      await lgppMoveToDrawdownPage.importantConsiderationsStep.option(0, 'No').click();
      await lgppMoveToDrawdownPage.importantConsiderationsStep.option(1, 'No').click();
      await lgppMoveToDrawdownPage.importantConsiderationsStep.option(2, 'Yes').click();
      await lgppMoveToDrawdownPage.importantConsiderationsStep.option(3, 'No').click();
      await lgppMoveToDrawdownPage.importantConsiderationsStep.option(4, 'Yes').click();

      await lgppMoveToDrawdownPage.pageCheck(
        visualFunctions,
        'LGPP - Apply for drawdown - Important considerations',
        skipVisualChecks,
      );

      // Your tax free cash
      await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn2);
      await lgppMoveToDrawdownPage.taxFreeCashStep.heading.waitFor();

      await lgppMoveToDrawdownPage.pageCheck(
        visualFunctions,
        'LGPP - Apply for drawdown - Your tax free cash',
        skipVisualChecks,
      );

      await lgppMoveToDrawdownPage.continueBtn.click();
      await lgppMoveToDrawdownPage.taxFreeCashStep.validationError.waitFor();
      await lgppMoveToDrawdownPage.taxFreeCashStep.checkbox.click();

      // Your inestment pathhways
      await lgppMoveToDrawdownPage.continueBtn.click();
      await lgppMoveToDrawdownPage.investmentPathwaysStep.heading.waitFor();
      await lgppMoveToDrawdownPage.continueBtn.click();
      await lgppMoveToDrawdownPage.investmentPathwaysStep.validationError.waitFor();
      await lgppMoveToDrawdownPage.investmentPathwaysStep.option1.click();
      await lgppMoveToDrawdownPage.investmentPathwaysStep.option2.click();
      await lgppMoveToDrawdownPage.investmentPathwaysStep.option3.click();
      await lgppMoveToDrawdownPage.investmentPathwaysStep.option4.click();
      await lgppMoveToDrawdownPage.investmentPathwaysStep.paragraph4.waitFor();

      await lgppMoveToDrawdownPage.pageCheck(
        visualFunctions,
        'LGPP - Apply for drawdown - Your investment pathway - read',
        skipVisualChecks,
      );

      await lgppMoveToDrawdownPage.investmentPathwaysStep.select4.click();
      await lgppMoveToDrawdownPage.continueBtn.click();

      // Your income options
      await lgppMoveToDrawdownPage.incomeOptionsStep.heading.waitFor();
      await lgppMoveToDrawdownPage.backBtn.click();
      await lgppMoveToDrawdownPage.investmentPathwaysStep.heading.waitFor();
      await lgppMoveToDrawdownPage.continueBtn.click();
      await lgppMoveToDrawdownPage.incomeOptionsStep.heading.waitFor();
      await lgppMoveToDrawdownPage.incomeOptionsStep.amountInput.fill('120');
      await lgppMoveToDrawdownPage.incomeOptionsStep.daySelect.selectOption('6');
      await lgppMoveToDrawdownPage.incomeOptionsStep.option1No.click();
      await lgppMoveToDrawdownPage.incomeOptionsStep.option2No.click();
      await lgppMoveToDrawdownPage.incomeOptionsStep.warningMessage.waitFor();

      await lgppMoveToDrawdownPage.pageCheck(
        visualFunctions,
        'LGPP - Apply for drawdown - Your income options  ',
        skipVisualChecks,
      );

      // Pensions millionare
      await lgppMoveToDrawdownPage.continueBtn.click();
      await lgppMoveToDrawdownPage.pensionsMillionaireStep.heading.waitFor();
      await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn2);

      await lgppMoveToDrawdownPage.pensionsMillionaireStep.validationError.waitFor();

      await lgppMoveToDrawdownPage.pensionsMillionaireStep.option(0, 'Yes').click();
      await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn2);

      await lgppMoveToDrawdownPage.pensionsMillionaireStep.validationError.waitFor();

      await lgppMoveToDrawdownPage.pensionsMillionaireStep.option(1, 'Yes').click();
      await lgppMoveToDrawdownPage.pensionsMillionaireStep.message.waitFor();

      await lgppMoveToDrawdownPage.pageCheck(
        visualFunctions,
        'LGPP - Apply for drawdown - Are you a oensions millionare - Yes Selected',
        skipVisualChecks,
      );

      // Important considerations
      await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn2);
      await lgppMoveToDrawdownPage.importantConsiderations2Step.heading.waitFor();
      await lgppMoveToDrawdownPage.importantConsiderations2Step.option(0, 'No').click();
      await lgppMoveToDrawdownPage.importantConsiderations2Step.option(1, 'No').click();
      await lgppMoveToDrawdownPage.importantConsiderations2Step.option(2, 'Yes').click();
      await lgppMoveToDrawdownPage.importantConsiderations2Step.option(3, 'No').click();
      await lgppMoveToDrawdownPage.importantConsiderations2Step.option(4, 'Yes').click();
      await lgppMoveToDrawdownPage.importantConsiderations2Step.option(5, 'No').click();
      await lgppMoveToDrawdownPage.importantConsiderations2Step.option(6, 'No').click();
      await lgppMoveToDrawdownPage.importantConsiderations2Step.option(7, 'Yes').click();
      await lgppMoveToDrawdownPage.importantConsiderations2Step.option(8, 'No').click();
      await lgppMoveToDrawdownPage.importantConsiderations2Step.option(9, 'No').click();
      await lgppMoveToDrawdownPage.importantConsiderations2Step.option(10, 'No').click();

      await lgppMoveToDrawdownPage.pageCheck(
        visualFunctions,
        'LGPP - Apply for drawdown - Important considerations - options selected',
        skipVisualChecks,
      );

      // Summary
      await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn2);
      await lgppMoveToDrawdownPage.summaryStep.heading.waitFor();

      await lgppMoveToDrawdownPage.pageCheck(
        visualFunctions,
        'LGPP - Apply for drawdown - Summary',
        skipVisualChecks,
      );

      await lgppMoveToDrawdownPage.continueBtn.click();
      await lgppMoveToDrawdownPage.summaryStep.validationError.waitFor();
      await lgppMoveToDrawdownPage.summaryStep.checkbox.click();
      await lgppMoveToDrawdownPage.continueBtn.click();

      // Before you apply
      await lgppMoveToDrawdownPage.beforeAppplyStep.heading.waitFor();

      await lgppMoveToDrawdownPage.pageCheck(
        visualFunctions,
        'LGPP - Apply for drawdown - Before you apply',
        skipVisualChecks,
      );

      await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn2);
      await lgppMoveToDrawdownPage.beforeAppplyStep.sortCodeRequiredError.waitFor();
      await lgppMoveToDrawdownPage.beforeAppplyStep.accountNumberRequiredError.waitFor();
      await lgppMoveToDrawdownPage.beforeAppplyStep.sortCodeInput1.fill('20');
      await lgppMoveToDrawdownPage.beforeAppplyStep.sortCodeInput2.fill('00');
      await lgppMoveToDrawdownPage.beforeAppplyStep.sortCodeInput3.fill('0');
      await lgppMoveToDrawdownPage.beforeAppplyStep.sortCodeRequiredError.waitFor();
      await lgppMoveToDrawdownPage.beforeAppplyStep.sortCodeInput3.fill('ab');
      await lgppMoveToDrawdownPage.beforeAppplyStep.sortCodeRequiredError.waitFor();
      await lgppMoveToDrawdownPage.beforeAppplyStep.sortCodeInput3.fill('00');
      await lgppMoveToDrawdownPage.beforeAppplyStep.accountNumberInput.fill('121212');
      await lgppMoveToDrawdownPage.beforeAppplyStep.accountNumberRequiredError.waitFor();
      await lgppMoveToDrawdownPage.beforeAppplyStep.accountNumberInput.fill('12121212');
      await lgppMoveToDrawdownPage.beforeAppplyStep.bankNameMessage.waitFor();

      // Request received
      await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn2);
      await lgppMoveToDrawdownPage.requestReceivedStep.heading.waitFor();
      await lgppMoveToDrawdownPage.requestReceivedStep.phoneLink.waitFor();

      await lgppMoveToDrawdownPage.pageCheck(
        visualFunctions,
        'LGPP - Apply for drawdown - Request Received',
        skipVisualChecks,
      );
    },
  );

  test('Customer whom is not at pension benefits age so no tile displayed and no notification', async ({
    lgppActivityPage,
  }) => {
    await lgppActivityPage.authenticationPage.navigate('User33_LGPP_Test');
    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.pensionDetailsTile.waitFor();
    await lgppActivityPage.documentsTile.waitFor();
    await expect(lgppActivityPage.retirementOptionsNotification).not.toBeVisible();
    await expect(lgppActivityPage.retirementOptionsTile).not.toBeVisible();
  });

  test('Retirement options notification not displayed ', async ({ lgppActivityPage }) => {
    await lgppActivityPage.authenticationPage.navigate(
      'LGPP_User_retirement_options_notification_dismissed',
    );

    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.pensionDetailsTile.waitFor();
    await lgppActivityPage.documentsTile.waitFor();
    await expect(lgppActivityPage.retirementOptionsNotification).not.toBeVisible();
    await lgppActivityPage.retirementOptionsTile.waitFor();
  });

  test('Customer whom requires a wake up pack', async ({
    lgppActivityPage,
    skipVisualChecks,
  }) => {
    await lgppActivityPage.authenticationPage.navigate('LGPP_User_requires_wake_up_pack');

    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.retirementOptionsTile.click();
    await lgppActivityPage.retirementOptionsOverlay.messagePopup.requestPackText.waitFor();

    await lgppActivityPage.pageCheck(
      visualFunctions,
      'LGPP - Retirement options overlay - request pack message',
      skipVisualChecks,
    );

    await lgppActivityPage.retirementOptionsOverlay.messagePopup.dismissBtn.click();

    await expect(
      lgppActivityPage.retirementOptionsOverlay.messagePopup.requestPackText,
    ).not.toBeVisible();

    await lgppActivityPage.retirementOptionsOverlay.pensionDrawdown.heading.click();

    await lgppActivityPage.retirementOptionsOverlay.pensionDrawdown.packRequiredText.waitFor();

    await lgppActivityPage.pageCheck(
      visualFunctions,
      'LGPP - Retirement options overlay - pension drawdown - request pack message',
      skipVisualChecks,
    );
  });

  test('Customer requests a wake up pack', async ({
    lgppActivityPage,
    skipVisualChecks,
  }) => {
    await lgppActivityPage.authenticationPage.navigate('LGPP_User_requires_wake_up_pack');

    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.retirementOptionsTile.click();
    await lgppActivityPage.retirementOptionsOverlay.messagePopup.requestPackBtn.click();
    await lgppActivityPage.retirementOptionsOverlay.messagePopup.packRequestedText.waitFor();

    await lgppActivityPage.pageCheck(
      visualFunctions,
      'LGPP - Retirement options overlay - pack requested message',
      skipVisualChecks,
    );

    await lgppActivityPage.retirementOptionsOverlay.messagePopup.dismissBtn.click();
    await lgppActivityPage.retirementOptionsOverlay.closeBtn.click();
    await lgppActivityPage.retirementOptionsTile.click();
    await lgppActivityPage.retirementOptionsOverlay.messagePopup.packAlreadyRequestedText.waitFor();
  });

  test(' Customer has requested a wake up pack', async ({ lgppActivityPage }) => {
    await lgppActivityPage.authenticationPage.navigate(
      'LGPP_User_waiting_for_wake_up_pack',
    );

    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.retirementOptionsTile.click();
    await lgppActivityPage.retirementOptionsOverlay.messagePopup.packAlreadyRequestedText.waitFor();
    await lgppActivityPage.retirementOptionsOverlay.messagePopup.dismissBtn.click();
    await lgppActivityPage.retirementOptionsOverlay.pensionDrawdown.heading.click();
    await lgppActivityPage.retirementOptionsOverlay.pensionDrawdown.packWaitingText.waitFor();
  });

  test('Customer with an outstanding balance', async ({ lgppActivityPage }) => {
    await lgppActivityPage.authenticationPage.navigate(
      'LGPP_User_with_outstanding_balance',
    );

    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.retirementOptionsTile.click();
    await lgppActivityPage.retirementOptionsOverlay.messagePopup.unableToStartDrawdownText.waitFor();
    await lgppActivityPage.retirementOptionsOverlay.pensionDrawdown.heading.click();
    await lgppActivityPage.retirementOptionsOverlay.pensionDrawdown.unableToStartDrawdownText.waitFor();
  });

  test('Successful Journey when pension is less than one million', async ({
    lgppActivityPage,
    lgppMoveToDrawdownPage,
  }) => {
    await lgppActivityPage.authenticationPage.navigate('User2_LGPP');
    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.retirementOptionsTile.click();
    await lgppActivityPage.retirementOptionsOverlay.pensionDrawdown.heading.click();
    await lgppActivityPage.retirementOptionsOverlay.pensionDrawdown.applyBtn.click();
    await lgppMoveToDrawdownPage.waitForPageToLoad();
    await lgppMoveToDrawdownPage.continueBtn.click();
    await lgppMoveToDrawdownPage.continueBtn.click();

    await lgppMoveToDrawdownPage.pensionWiseStep.appointmentSelect.selectOption(
      'noAdviceGuidanceWanted',
    );

    await lgppMoveToDrawdownPage.continueBtn.click();
    await lgppMoveToDrawdownPage.importantConsiderationsStep.option(0, 'No').click();
    await lgppMoveToDrawdownPage.importantConsiderationsStep.option(1, 'No').click();
    await lgppMoveToDrawdownPage.importantConsiderationsStep.option(2, 'No').click();
    await lgppMoveToDrawdownPage.importantConsiderationsStep.option(3, 'No').click();
    await lgppMoveToDrawdownPage.importantConsiderationsStep.option(4, 'No').click();

    await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn2);
    await lgppMoveToDrawdownPage.taxFreeCashStep.checkbox.click();

    await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn2);
    await lgppMoveToDrawdownPage.investmentPathwaysStep.option1.click();
    await lgppMoveToDrawdownPage.investmentPathwaysStep.option2.click();
    await lgppMoveToDrawdownPage.investmentPathwaysStep.option3.click();
    await lgppMoveToDrawdownPage.investmentPathwaysStep.option4.click();
    await lgppMoveToDrawdownPage.investmentPathwaysStep.select4.click();

    await lgppMoveToDrawdownPage.continueBtn.click();
    await lgppMoveToDrawdownPage.incomeOptionsStep.amountInput.fill('120');
    await lgppMoveToDrawdownPage.incomeOptionsStep.daySelect.selectOption('6');
    await lgppMoveToDrawdownPage.incomeOptionsStep.option1No.click();
    await lgppMoveToDrawdownPage.incomeOptionsStep.option2No.click();

    // Pensions millionaire - select no
    await lgppMoveToDrawdownPage.continueBtn.click();
    await lgppMoveToDrawdownPage.pensionsMillionaireStep.option(0, 'No').click();

    await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn2);
    await lgppMoveToDrawdownPage.importantConsiderations2Step.option(5, 'Yes').click();
    await lgppMoveToDrawdownPage.importantConsiderations2Step.option(6, 'Yes').click();
    await lgppMoveToDrawdownPage.importantConsiderations2Step.option(7, 'Yes').click();
    await lgppMoveToDrawdownPage.importantConsiderations2Step.option(8, 'Yes').click();
    await lgppMoveToDrawdownPage.importantConsiderations2Step.option(9, 'Yes').click();
    await lgppMoveToDrawdownPage.importantConsiderations2Step.option(10, 'Yes').click();

    await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn2);
    await lgppMoveToDrawdownPage.summaryStep.checkbox.click();

    await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn);
    await lgppMoveToDrawdownPage.beforeAppplyStep.sortCodeInput1.fill('20');
    await lgppMoveToDrawdownPage.beforeAppplyStep.sortCodeInput2.fill('00');
    await lgppMoveToDrawdownPage.beforeAppplyStep.sortCodeInput3.fill('00');
    await lgppMoveToDrawdownPage.beforeAppplyStep.accountNumberInput.fill('12121212');
    await lgppMoveToDrawdownPage.beforeAppplyStep.bankNameMessage.waitFor();

    await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn2);
    await lgppMoveToDrawdownPage.allDoneStep.successText.waitFor();
  });

  test('Failed order submission', async ({
    lgppActivityPage,
    lgppMoveToDrawdownPage,
  }) => {
    test.setTimeout(240000);
    await lgppActivityPage.authenticationPage.navigate('User2_LGPP');
    await lgppActivityPage.waitForPageToLoad();
    await lgppActivityPage.retirementOptionsTile.click();
    await lgppActivityPage.retirementOptionsOverlay.pensionDrawdown.heading.click();
    await lgppActivityPage.retirementOptionsOverlay.pensionDrawdown.applyBtn.click();
    await lgppMoveToDrawdownPage.waitForPageToLoad();
    await lgppMoveToDrawdownPage.continueBtn.click();
    await lgppMoveToDrawdownPage.continueBtn.click();

    await lgppMoveToDrawdownPage.pensionWiseStep.appointmentSelect.selectOption(
      'noAdviceGuidanceWanted',
    );

    await lgppMoveToDrawdownPage.continueBtn.click();
    await lgppMoveToDrawdownPage.importantConsiderationsStep.option(0, 'No').click();
    await lgppMoveToDrawdownPage.importantConsiderationsStep.option(1, 'No').click();
    await lgppMoveToDrawdownPage.importantConsiderationsStep.option(2, 'No').click();
    await lgppMoveToDrawdownPage.importantConsiderationsStep.option(3, 'No').click();
    await lgppMoveToDrawdownPage.importantConsiderationsStep.option(4, 'No').click();
    await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn2);
    await lgppMoveToDrawdownPage.taxFreeCashStep.checkbox.click();

    await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn2);
    await lgppMoveToDrawdownPage.investmentPathwaysStep.option1.click();
    await lgppMoveToDrawdownPage.investmentPathwaysStep.option2.click();
    await lgppMoveToDrawdownPage.investmentPathwaysStep.option3.click();
    await lgppMoveToDrawdownPage.investmentPathwaysStep.option4.click();
    await lgppMoveToDrawdownPage.investmentPathwaysStep.select4.click();

    await lgppMoveToDrawdownPage.continueBtn.click();
    await lgppMoveToDrawdownPage.incomeOptionsStep.amountInput.fill('666');
    await lgppMoveToDrawdownPage.incomeOptionsStep.daySelect.selectOption('6');
    await lgppMoveToDrawdownPage.incomeOptionsStep.option1No.click();
    await lgppMoveToDrawdownPage.incomeOptionsStep.option2No.click();

    // Pensions millionaire - select no
    await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn);

    await lgppMoveToDrawdownPage.clickButton(
      lgppMoveToDrawdownPage.pensionsMillionaireStep.option(0, 'No'),
    );

    await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn2);

    await lgppMoveToDrawdownPage.importantConsiderations2Step.option(5, 'Yes').waitFor();

    await lgppMoveToDrawdownPage.importantConsiderations2Step.option(5, 'Yes').click();
    await lgppMoveToDrawdownPage.importantConsiderations2Step.option(6, 'Yes').click();
    await lgppMoveToDrawdownPage.importantConsiderations2Step.option(7, 'Yes').click();
    await lgppMoveToDrawdownPage.importantConsiderations2Step.option(8, 'Yes').click();
    await lgppMoveToDrawdownPage.importantConsiderations2Step.option(9, 'Yes').click();
    await lgppMoveToDrawdownPage.importantConsiderations2Step.option(10, 'Yes').click();

    await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn2);
    await lgppMoveToDrawdownPage.summaryStep.checkbox.click();

    await lgppMoveToDrawdownPage.continueBtn.click();
    await lgppMoveToDrawdownPage.beforeAppplyStep.sortCodeInput1.fill('20');
    await lgppMoveToDrawdownPage.beforeAppplyStep.sortCodeInput2.fill('00');
    await lgppMoveToDrawdownPage.beforeAppplyStep.sortCodeInput3.fill('00');
    await lgppMoveToDrawdownPage.beforeAppplyStep.accountNumberInput.fill('12121212');
    await lgppMoveToDrawdownPage.beforeAppplyStep.bankNameMessage.waitFor();
    await lgppMoveToDrawdownPage.clickButton(lgppMoveToDrawdownPage.continueBtn2);
    await lgppMoveToDrawdownPage.allDoneStep.errorText.waitFor();
  });

  afterAllHook(test);
});
