import { test } from '../models/test-base';

test.describe.parallel('Pulse Feature Vote', () => {
  test('Submits a feature vote', async ({ isaActivityPage, pulsePage }) => {
    await isaActivityPage.authenticationPage.navigate('User1_ISA');
    await isaActivityPage.waitForPageToLoad();
    await isaActivityPage.thePulseTile.click();

    await pulsePage.waitForPageToLoad();
    await pulsePage.banChristmasOption.click();
    await pulsePage.submitBtn.click();
    await pulsePage.thankYouMessage.waitFor();
    await pulsePage.backToSummaryBtn.click();
    await isaActivityPage.waitForPageToLoad();
  });
});
