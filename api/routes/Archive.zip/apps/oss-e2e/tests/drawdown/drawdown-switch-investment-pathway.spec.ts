import { expect } from '@playwright/test';
import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('Drawdown switch investment pathway', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test('Manage Retirement Menu', async ({ drawdownActivityPage }) => {
    await drawdownActivityPage.authenticationPage.navigate('Drawdown_pathway_switch');

    // open manage retirement dropdown
    await drawdownActivityPage.manageRetirementDropDown.click();

    // assert manage retirment dropdown items
    await expect(drawdownActivityPage.retirementDropdownItems).toContainText([
      'Start regular income',
      'Make a withdrawal',
      'Change investment pathway',
    ]);
  });

  test('Outstanding balance - cannot start journey check', async ({
    drawdownActivityPage,
  }) => {
    await drawdownActivityPage.authenticationPage.navigate('Drawdown_regular_income');
    await expect(drawdownActivityPage.changeInvestmentPathway).not.toBeVisible();
  });

  test('Investment tile', async ({
    drawdownActivityPage,
    fundDetailsPage,
    drawdownPathwaySwitchPage,
    skipVisualChecks,
  }) => {
    await drawdownActivityPage.authenticationPage.navigate('Drawdown_pathway_switch');

    // Click on the 'I plan to use my money to setup a guaranteed income (annuity) within the next 5 years'
    await drawdownActivityPage.investmentPathwayLink.click();
    await drawdownActivityPage.investmentPathwayDetailModal.waitFor();

    await drawdownActivityPage.pageCheck(
      visualFunctions,
      'Drawdown - Investment pathway detail modal',
      skipVisualChecks,
    );

    await drawdownActivityPage.investmentPathwayDetailCloseBtn.click();

    // Click on the 'Sterling Corporate Bond Index Fund' link to view the find details page
    await drawdownActivityPage.sterlingCorpBondIndexFundLink.click();
    await fundDetailsPage.waitForPageToLoad();

    await fundDetailsPage.pageCheck(
      visualFunctions,
      'Drawdown - Fund details page',
      skipVisualChecks,
    );

    await fundDetailsPage.backToSummaryBtn.click();
    await drawdownActivityPage.waitForPageToLoad();

    // Click on the 'Change Investment pathway link' to view the pathway switch page
    await drawdownActivityPage.changeInvestmentPathway.click();
    await drawdownPathwaySwitchPage.waitForPageToLoad();

    await drawdownPathwaySwitchPage.pageCheck(
      visualFunctions,
      'Drawdown - Pathway switch page',
      skipVisualChecks,
    );

    await drawdownPathwaySwitchPage.clickButton(drawdownPathwaySwitchPage.cancelBtn);
    await drawdownActivityPage.waitForPageToLoad();
  });

  // Causes the test run to hang in CI and is cancelled after 40 mins
  test.fixme(
    'Successful journeys',
    async ({
      drawdownActivityPage,
      investmentsPage,
      drawdownPathwaySwitchPage,
      skipVisualChecks,
    }) => {
      await drawdownActivityPage.authenticationPage.navigate('Drawdown_pathway_switch');
      await drawdownActivityPage.waitForPageToLoad();

      const pageName = 'Drawdown Switch Investment Pathway';
      const pageName1 = `${pageName} - Investment tile start journey - success`;
      const pageName2 = `${pageName} - Investment Pathway Accordion`;
      const pageName3 = `${pageName} - I have no plans to touch my money in the next 5 years`;
      const pageName4 = `${pageName} - I plan to start taking my money as a long-term income within the next 5 years`;
      const pageName5 = `${pageName} - I plan to take out all my money within the next 5 years`;
      const pageName6 = `${pageName} - Change your investment pathway`;
      const pageName7 = `${pageName} - Switch From/Switch to`;
      const pageName8 = `${pageName} - All Done`;

      await drawdownActivityPage.page.pause();
      await drawdownActivityPage.investmentPathwayLink.click();
      await drawdownPathwaySwitchPage.waitForPageToLoad();
      await investmentsPage.investmentPathwayDetail.waitFor();

      await investmentsPage.investmentPathwayCloseBtn.click();
      await investmentsPage.investmentPathwayFundLink.click();
      await investmentsPage.page.waitForURL('**/fund/**');
      await investmentsPage.refreshPage();
      await investmentsPage.fundTileHeader.waitFor();

      await expect(investmentsPage.fundTileHeader).toContainText(
        'Sterling Corporate Bond Index Fund',
      );

      await investmentsPage.backToSummaryBtn.click();
      await investmentsPage.changeInvestmentPathway.click();
      await drawdownPathwaySwitchPage.waitForPageToLoad();
      await investmentsPage.pageCheck(visualFunctions, pageName1, skipVisualChecks);

      await drawdownPathwaySwitchPage.accordion.click();
      await drawdownPathwaySwitchPage.accordionOpen.waitFor();

      await drawdownPathwaySwitchPage.pageCheck(
        visualFunctions,
        pageName2,
        skipVisualChecks,
      );

      await drawdownPathwaySwitchPage.clickButton(
        drawdownPathwaySwitchPage.noPlanNext5Years,
      );

      await drawdownPathwaySwitchPage.pageCheck(
        visualFunctions,
        pageName3,
        skipVisualChecks,
      );

      await drawdownPathwaySwitchPage.continueBtn.click();
      await drawdownPathwaySwitchPage.unreadErrorAlert.waitFor();

      await drawdownPathwaySwitchPage.startIncomeNext5Years.click();

      await drawdownPathwaySwitchPage.pageCheck(
        visualFunctions,
        pageName4,
        skipVisualChecks,
      );

      await drawdownPathwaySwitchPage.takeMoneyNext5Years.click();

      await drawdownPathwaySwitchPage.pageCheck(
        visualFunctions,
        pageName5,
        skipVisualChecks,
      );

      await drawdownPathwaySwitchPage.continueBtn.click();

      await drawdownPathwaySwitchPage.assertTextExists(
        'Please select a pathway to change pathways',
      );

      await drawdownPathwaySwitchPage.takeOutMoneySelectBtn.click();
      await drawdownPathwaySwitchPage.continueBtn.click();
      await drawdownPathwaySwitchPage.assertTextExists('Change your investment pathway');

      await drawdownPathwaySwitchPage.pageCheck(
        visualFunctions,
        pageName6,
        skipVisualChecks,
      );

      await drawdownPathwaySwitchPage.investmentsPathwayBackBtn.click();

      await drawdownPathwaySwitchPage.pageCheck(
        visualFunctions,
        pageName7,
        skipVisualChecks,
      );

      await drawdownPathwaySwitchPage.continueBtn.click();
      await drawdownPathwaySwitchPage.confirmChangeOfPathWay.click();
      await drawdownPathwaySwitchPage.assertTextExists('All done');

      await drawdownPathwaySwitchPage.pageCheck(
        visualFunctions,
        pageName8,
        skipVisualChecks,
      );

      await drawdownPathwaySwitchPage.backToMyDashboard.click();
      await drawdownPathwaySwitchPage.assertTextExists('Retirement account');
    },
  );

  afterAllHook(test);
});
