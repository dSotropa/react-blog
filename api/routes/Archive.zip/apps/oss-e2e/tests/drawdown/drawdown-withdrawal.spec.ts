import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('Drawdown withdrawal', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ drawdownActivityPage }) => {
    await drawdownActivityPage.authenticationPage.navigate('Drawdown');
  });

  // Times out in CI after 180000 ms
  test.fixme(
    'withdrawal journey',
    async ({ drawdownActivityPage, drawdownMakeWithdrawalPage, skipVisualChecks }) => {
      // Start the make a withdrawal journey
      await drawdownActivityPage.makeWithdrawalBtn.click();
      await drawdownMakeWithdrawalPage.waitForPageToLoad();

      await drawdownMakeWithdrawalPage.pageCheck(
        visualFunctions,
        'Drawdown - make a withdrawal start',
        skipVisualChecks,
      );

      // Click make a withdrawal and continue
      await drawdownMakeWithdrawalPage.continueBtn.waitFor();
      await drawdownMakeWithdrawalPage.continueBtn.click({ delay: 500 });
      await drawdownMakeWithdrawalPage.withdrawalAmountInput.waitFor();

      await drawdownMakeWithdrawalPage.pageCheck(
        visualFunctions,
        'Drawdown - make a withdrawal choose an amount',
        skipVisualChecks,
      );

      // Continue without entering an amount
      await drawdownMakeWithdrawalPage.continueBtn.click();
      await drawdownMakeWithdrawalPage.withdrawalAmountMinError.waitFor();

      // Continue with insufficient funds amount
      await drawdownMakeWithdrawalPage.withdrawalAmountInput.fill('2000');
      await drawdownMakeWithdrawalPage.continueBtn.click();
      await drawdownMakeWithdrawalPage.insufficientFundsError.waitFor();

      // Continue with valid amount
      await drawdownMakeWithdrawalPage.withdrawalAmountInput.fill('200');
      await drawdownMakeWithdrawalPage.continueBtn.click();

      await drawdownMakeWithdrawalPage
        .getRiskWarningOption('FinancialAdviceReceived', 'Yes')
        .waitFor();

      await drawdownMakeWithdrawalPage.selectAllOptions('No');

      await drawdownMakeWithdrawalPage.pageCheck(
        visualFunctions,
        'Drawdown - make a withdrawal options "No" selected',
        skipVisualChecks,
      );

      // Answer yes to all the options and continue
      await drawdownMakeWithdrawalPage.selectAllOptions('Yes');

      await drawdownMakeWithdrawalPage.pageCheck(
        visualFunctions,
        'Drawdown - make a withdrawal options "Yes" selected',
        skipVisualChecks,
      );

      await drawdownMakeWithdrawalPage.continueBtn.click();
      await drawdownMakeWithdrawalPage.confirmWithdrawalBtn.waitFor();

      // Confirm and end journey
      await drawdownMakeWithdrawalPage.confirmWithdrawalBtn.click();
      await drawdownMakeWithdrawalPage.gotItBtn.waitFor();

      await drawdownMakeWithdrawalPage.pageCheck(
        visualFunctions,
        'Drawdown - make a withdrawal all done',
        skipVisualChecks,
      );

      await drawdownMakeWithdrawalPage.gotItBtn.click();
      await drawdownActivityPage.waitForPageToLoad();
    },
  );

  afterAllHook(test);
});
