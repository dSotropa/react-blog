import { expect } from '@playwright/test';
import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('Drawdown stop regular income journey', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ drawdownActivityPage }) => {
    await drawdownActivityPage.authenticationPage.navigate('Drawdown_regular_income');
    await drawdownActivityPage.waitForPageToLoad();
  });

  test('Stop regular income', async ({ drawdownActivityPage, skipVisualChecks }) => {
    await drawdownActivityPage.getWidget('Withdrawals').click();

    await drawdownActivityPage.pageCheck(
      visualFunctions,
      'Drawdown - Withdrawals',
      skipVisualChecks,
    );

    await drawdownActivityPage.stopRegularIncomeBtn.click();
    await drawdownActivityPage.stopRegularIncomeModal.waitFor();

    await drawdownActivityPage.pageCheck(
      visualFunctions,
      'Drawdown - Stop regular income modal',
      skipVisualChecks,
    );

    await drawdownActivityPage.confirmBtn.click();
    await drawdownActivityPage.stopRegularIncomeResultModal.waitFor();
    await drawdownActivityPage.gotItBtn.waitFor();

    await drawdownActivityPage.pageCheck(
      visualFunctions,
      'Drawdown - Stop regular income - all done',
      skipVisualChecks,
    );
  });

  test('Manage retirement menu', async ({ drawdownActivityPage }) => {
    // open manage retirement dropdown
    await drawdownActivityPage.manageRetirementDropDown.click();

    // assert manage retirment dropdown items
    await expect(drawdownActivityPage.retirementDropdownItems).toContainText([
      'Stop regular income',
      'Make a withdrawal',
    ]);
  });

  afterAllHook(test);
});
