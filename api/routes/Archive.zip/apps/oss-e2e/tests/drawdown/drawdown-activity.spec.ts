import { expect } from '@playwright/test';
import { VisualFunctions, afterAllHook } from '@utility-e2e';

import { test } from '../../models/test-base';

test.describe.parallel('Drawdown activity', () => {
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ drawdownActivityPage }) => {
    await drawdownActivityPage.authenticationPage.navigate('Drawdown');
    await drawdownActivityPage.waitForPageToLoad();
  });

  test('Drawdown activity page', async ({ drawdownActivityPage, skipVisualChecks }) => {
    await drawdownActivityPage.pageCheck(
      visualFunctions,
      'Drawdown activity page',
      skipVisualChecks,
    );
  });

  test('Manage retirement menu has the correct options', async ({
    drawdownActivityPage,
  }) => {
    // open manage retirement dropdown
    await drawdownActivityPage.manageRetirementDropDown.click();

    // assert manage retirment dropdown items
    await expect(drawdownActivityPage.retirementDropdownItems).toContainText([
      'Start regular income',
      'Make a withdrawal',
    ]);
  });

  afterAllHook(test);
});
