import { Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

import { HomePage } from './homepage';

export class BasePage extends PageFunctions {
  readonly homePage: HomePage;

  constructor(page: Page) {
    super(page);
    this.homePage = new HomePage(page);
  }
}
