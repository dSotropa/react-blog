import { Locator, Page } from '@playwright/test';
import { MOCK_ENV, PageFunctions } from '@utility-e2e';

export class HomePage extends PageFunctions {
  readonly pageHeader: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
  }

  async navigate(): Promise<void> {
    await this.page.goto(MOCK_ENV);
  }
}
