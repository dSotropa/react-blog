import { PageFunctions } from '@utility-e2e';
import { expect, Locator, Page } from '@playwright/test';

export class ConsumerLoginPage extends PageFunctions {
  readonly page: Page;
  readonly loginPage: Locator;
  readonly loginInputField: Locator;
  readonly loginBtn: Locator;
  readonly passwordInputField: Locator;
  readonly continueBtn: Locator;
  readonly successPage: Locator;
  readonly logOutBtn: Locator;
  readonly loginError: Locator;
  readonly change: Locator;
  readonly forgotPassword: Locator;
  readonly forgotPasswordPage: Locator;

  readonly route = '';

  constructor(page: Page) {
    super(page);
    this.page = page;

    this.loginPage = this.page.locator('h1:has-text("Log in")');
    this.continueBtn = this.page.locator('button:has-text("Continue")');
    this.logOutBtn = this.page.locator('button:has-text("Log out")');
    this.loginBtn = this.page.locator('#loginButton');
    this.loginInputField = this.page.locator('data-testid=username');
    this.passwordInputField = this.page.locator('data-testid=password');
    this.successPage = this.page.locator('text=You\'re logged in successfully');
    this.loginError = this.page.locator('data-testid=password-error-message');
    this.change = this.page.locator('button:has-text("Change")');
    this.forgotPassword = this.page.locator('a:has-text("Forgot your password?")');
    this.forgotPasswordPage = this.page.locator('h1:has-text("Forgot your password?")');
  }

  async isLoginPageDisplayed() {
    await expect(this.loginPage).toBeVisible();

    if (await this.loginPage.isVisible()) {
      return true;
    }

    return false;
  }

  async isLoginErrorDisplayed() {
    await expect(this.loginError).toBeVisible();

    if (await this.loginError.isVisible()) {
      return true;
    }

    return false;
  }

  async isRedirectAfterSuccess() {
    await expect(this.page).toHaveTitle(/^Legal and General [-|–] */); // May need to be more specific
    expect(this.page.url()).toBe('https://www.legalandgeneral.com/'); // Default page on successful login - different when querystring passed
  }

  async isSuccessPageDisplayed() {
    await expect(this.successPage).toBeVisible();

    if (await this.successPage.isVisible()) {
      return true;
    }

    return false;
  }

  async isForgotPasswordPageDisplayed() {
    await expect(this.forgotPasswordPage).toBeVisible();

    if (await this.forgotPasswordPage.isVisible()) {
      return true;
    }

    return false;
  }

  async enterUserDetails(username: string, password: string) {
    await this.loginInputField.fill(username);
    await this.continueBtn.click();
    await this.passwordInputField.fill(password);
    await this.loginBtn.click();
  }

  async enterUsername(username: string) {
    await this.loginInputField.fill(username);
    await this.continueBtn.click();
  }

  async wrongPassword() {
    await this.loginInputField.fill('emma.serra');
    await this.continueBtn.click();
    await this.passwordInputField.fill('Testing00001');
    await this.loginBtn.click();
  }
}
