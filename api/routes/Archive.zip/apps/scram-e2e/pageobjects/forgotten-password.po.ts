import { PageFunctions } from '@utility-e2e';
import { expect, Locator, Page } from '@playwright/test';

export class ForgottenPassword extends PageFunctions {
  readonly page: Page;
  readonly loginPage: Locator;
  readonly loginInputField: Locator;
  readonly continueBtn: Locator;
  readonly forgotPassLink: Locator;
  readonly forgotPassPage: Locator;
  readonly day: Locator;
  readonly month: Locator;
  readonly year: Locator;
  readonly chooseVeriOptionPage: Locator;
  readonly selectEmail: Locator;
  readonly selectSMS: Locator;
  readonly verificationCodePage: Locator;
  readonly verificationCodeField: Locator;
  readonly createPassword: Locator;
  readonly confirmPassword: Locator;
  readonly resetPasswordSuccessfully: Locator;
  readonly loginBtn: Locator;

  readonly route = '';

  constructor(page: Page) {
    super(page);
    this.page = page;

    this.loginPage = page.locator('h1:has-text("Log in")');
    this.forgotPassPage = page.locator('h1:has-text("Forgot your password?")');
    this.continueBtn = page.locator('button:has-text("Continue")');
    this.loginInputField = this.page.locator('data-testid=username');
    this.forgotPassLink = page.locator('data-testid=forgot-password-link');
    this.day = page.locator('[placeholder="DD"]');
    this.month = page.locator('[placeholder="MM"]');
    this.year = page.locator('[placeholder="YYYY"]');
    this.chooseVeriOptionPage = page.locator('h1:has-text("Choose verification option")');
    this.selectEmail = page.locator('label:has-text("Email")');
    this.selectSMS = page.locator('label:has-text("SMS")');

    this.verificationCodePage = page.locator(
      'h1:has-text("Enter your verification code")',
    );

    this.resetPasswordSuccessfully = page.locator(
      'h1:has-text("You\'ve succesfully reset your password")',
    );

    this.verificationCodeField = page.locator('data-testid=verification-code');
    this.createPassword = page.locator('data-testid=newPassword');
    this.confirmPassword = page.locator('data-testid=confirmPassword');
    this.loginBtn = page.locator('button:has-text(" Log in to My Account")');
  }

  async isLoginPageDisplayed() {
    await expect(this.loginPage).toBeVisible();

    if (await this.loginPage.isVisible()) {
      return true;
    }

    return false;
  }

  async isForgottenPasswordPageDisplayed() {
    await expect(this.forgotPassPage).toBeVisible();

    if (await this.forgotPassPage.isVisible()) {
      return true;
    }

    return false;
  }

  async enterUserId(loginInputField: string) {
    await this.loginInputField.fill(loginInputField);
  }

  async resetPasswordDetails() {
    await this.loginInputField.fill('bende.nku');
    await this.day.fill('01');
    await this.month.fill('01');
    await this.year.fill('2000');
    await this.continueBtn.click();
    await expect(this.chooseVeriOptionPage).toHaveText('Choose verification option');
  }

  async selectEmailOption() {
    await this.selectEmail.click();
    await this.continueBtn.click();
    await expect(this.verificationCodePage).toBeVisible();
  }

  async selectSMSOption() {
    await this.selectSMS.click();
    await this.continueBtn.click();
    await expect(this.verificationCodePage).toBeVisible();
  }

  async enterVerificationCodeAndResetPassword() {
    await this.verificationCodeField.fill('123456');
    await this.continueBtn.click();
    await this.createPassword.fill('Consumertesting12');
    await this.confirmPassword.fill('Consumertesting12');
    await this.continueBtn.click();
    await expect(this.resetPasswordSuccessfully).toBeVisible();
    await this.loginBtn.click();
  }
}
