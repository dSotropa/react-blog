import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class ForgotEmailaddress extends PageFunctions {
  readonly page: Page;
  readonly forgotYourEmailaddress: Locator;
  readonly forgotEmailaddressPage: Locator;
  readonly lastNameField: Locator;
  readonly lastNameFieldError: Locator;
  readonly day: Locator;
  readonly dayError: Locator;
  readonly month: Locator;
  readonly monthError: Locator;
  readonly year: Locator;
  readonly yearError: Locator;
  readonly dobError: Locator;
  readonly postcodeField: Locator;
  readonly postcodeError: Locator;
  readonly displayRegisteredBtn: Locator;
  readonly backToLoginBtn: Locator;
  readonly verificationOptions: Locator;
  readonly inValidLastname: Locator;
  readonly futureDobError: Locator;
  readonly ageRangeError: Locator;

  readonly route = '';

  constructor(page: Page) {
    super(page);
    this.page = page;

    this.forgotYourEmailaddress = page.locator('data-testid=forgotten-user/userdetails');

    this.forgotEmailaddressPage = page.locator(
      'h1:has-text(" Forgot your email address or User ID? ")',
    );

    this.verificationOptions = page.locator(
      'h1:has-text(" Choose verification option ")',
    );

    this.lastNameField = page.locator('data-testid=lastname');
    this.lastNameFieldError = page.locator('data-testid=lastname-error');
    this.day = page.locator('[placeholder="DD"]');
    this.month = page.locator('[placeholder="MM"]');
    this.year = page.locator('[placeholder="YYYY"]');
    this.dobError = page.locator('data-testid=dob-error');
    this.postcodeField = page.locator('data-testid=postcode');
    this.postcodeError = page.locator('data-testid=postcode-error');

    this.displayRegisteredBtn = page.locator(
      'button:has-text(" Display my registered details ")',
    );

    this.backToLoginBtn = page.locator('data-testid=back-to-login-btn');
    this.inValidLastname = page.locator('data-testid=invalid-lastname-error');
    this.futureDobError = page.locator('data-testid=futureDate-error');
    this.ageRangeError = page.locator('data-testid=ageRange-error');
    this.yearError = page.locator('data-testid=invalid-dob-error');
  }

  async clickForgetEmailAddress() {
    await this.forgotYourEmailaddress.click();
    await this.isElementVisible(this.forgotEmailaddressPage);
  }

  async userClicksBackToLogin() {
    await this.forgotYourEmailaddress.click();
    await this.backToLoginBtn.click();
  }

  async lastNameFieldEmpty() {
    await this.forgotYourEmailaddress.click();
    await this.isElementVisible(this.forgotEmailaddressPage);
    await this.lastNameField.fill('');
    await this.day.fill('01');
    await this.month.fill('01');
    await this.year.fill('2000');
    await this.postcodeField.fill('DA15RP');
    await this.displayRegisteredBtn.click();
    await this.isElementVisible(this.lastNameFieldError);
  }

  async lastNameInvalidChar() {
    await this.forgotYourEmailaddress.click();
    await this.isElementVisible(this.forgotEmailaddressPage);
    await this.lastNameField.fill('Bende@');
    await this.day.fill('01');
    await this.month.fill('01');
    await this.year.fill('2000');
    await this.postcodeField.fill('DA15RP');
    await this.displayRegisteredBtn.click();
    await this.isElementVisible(this.inValidLastname);
  }

  async dobEmpty() {
    await this.forgotYourEmailaddress.click();
    await this.isElementVisible(this.forgotEmailaddressPage);
    await this.lastNameField.fill('Bende');
    await this.day.fill('');
    await this.month.fill('');
    await this.year.fill('');
    await this.postcodeField.fill('DA15RP');
    await this.displayRegisteredBtn.click();
    await this.isElementVisible(this.dobError);
  }

  async dobWithoutYear() {
    await this.forgotYourEmailaddress.click();
    await this.isElementVisible(this.forgotEmailaddressPage);
    await this.lastNameField.fill('Bende');
    await this.day.fill('01');
    await this.month.fill('01');
    await this.year.fill('');
    await this.postcodeField.fill('DA15RP');
    await this.displayRegisteredBtn.click();
    await this.isElementVisible(this.yearError);
  }

  async dobWithoutMonth() {
    await this.forgotYourEmailaddress.click();
    await this.isElementVisible(this.forgotEmailaddressPage);
    await this.lastNameField.fill('Bende');
    await this.day.fill('01');
    await this.month.fill('');
    await this.year.fill('2000');
    await this.postcodeField.fill('DA15RP');
    await this.displayRegisteredBtn.click();
    await this.isElementVisible(this.monthError);
  }

  async dobWithoutDay() {
    await this.forgotYourEmailaddress.click();
    await this.isElementVisible(this.forgotEmailaddressPage);
    await this.lastNameField.fill('Bende');
    await this.day.fill('');
    await this.month.fill('01');
    await this.year.fill('2000');
    await this.postcodeField.fill('DA15RP');
    await this.displayRegisteredBtn.click();
    await this.isElementVisible(this.dayError);
  }

  async userHasFutureDate() {
    await this.forgotYourEmailaddress.click();
    await this.isElementVisible(this.forgotEmailaddressPage);
    await this.lastNameField.fill('Bende');
    await this.day.fill('10');
    await this.month.fill('10');
    await this.year.fill('2025');
    await this.postcodeField.fill('DA15RP');
    await this.displayRegisteredBtn.click();
    await this.isElementVisible(this.futureDobError);
  }

  async outSideAgeRange() {
    await this.forgotYourEmailaddress.click();
    await this.isElementVisible(this.forgotEmailaddressPage);
    await this.lastNameField.fill('Bende');
    await this.day.fill('10');
    await this.month.fill('10');
    await this.year.fill('1900');
    await this.postcodeField.fill('DA15RP');
    await this.displayRegisteredBtn.click();
    await this.isElementVisible(this.ageRangeError);
  }

  async postcodeFieldEmpty() {
    await this.forgotYourEmailaddress.click();
    await this.isElementVisible(this.forgotEmailaddressPage);
    await this.lastNameField.fill('Bende');
    await this.day.fill('01');
    await this.month.fill('01');
    await this.year.fill('2000');
    await this.postcodeField.fill('');
    await this.displayRegisteredBtn.click();
    await this.isElementVisible(this.postcodeError);
  }

  async userDetails() {
    await this.forgotYourEmailaddress.click();
    await this.isElementVisible(this.forgotEmailaddressPage);
    await this.lastNameField.fill('Bende');
    await this.day.fill('01');
    await this.month.fill('01');
    await this.year.fill('2000');
    await this.postcodeField.fill('DA15RP');
    await this.displayRegisteredBtn.click();
    await this.isElementVisible(this.verificationOptions);
  }

  async userEnterInvalidPostcode() {
    await this.forgotYourEmailaddress.click();
    await this.isElementVisible(this.forgotEmailaddressPage);
    await this.lastNameField.fill('Bende');
    await this.day.fill('01');
    await this.month.fill('01');
    await this.year.fill('2000');
    await this.postcodeField.fill('DA1');
    await this.displayRegisteredBtn.click();
    await this.isElementVisible(this.postcodeError);
  }
}
