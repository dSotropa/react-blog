import { expect, Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class VerificationCodePage extends PageFunctions {
  readonly sendCodeLink: Locator;
  readonly loginInputField: Locator;
  readonly day: Locator;
  readonly dateOfBirthError: Locator;
  readonly usernameError: Locator;
  readonly month: Locator;
  readonly year: Locator;
  readonly continueBtn: Locator;
  readonly verificationCodePage: Locator;
  readonly usernameChars: Locator;
  readonly invalidDateOfBirthChars: Locator;
  readonly futureDOBError: Locator;
  readonly blankMonthFieldError: Locator;
  readonly verificationOptionPage: Locator;
  readonly backToLogin: Locator;
  readonly verificationOptionError: Locator;
  readonly email: Locator;
  readonly sms: Locator;
  readonly enterVerficationCodePage: Locator;
  readonly changeUsername: Locator;
  readonly changeDOB: Locator;
  readonly verificationCodeField: Locator;
  readonly verificationCodeError: Locator;
  readonly invalidVerifyCodeError: Locator;
  readonly accountSuspendedPage: Locator;

  readonly route = '';

  constructor(page: Page) {
    super(page);
    this.page = page;

    this.sendCodeLink = page.locator('button:has-text("Send me a code to log in")');
    this.continueBtn = page.locator('button:has-text("Continue")');
    this.loginInputField = this.page.locator('data-testid=username');
    this.day = page.locator('[placeholder="DD"]');
    this.month = page.locator('[placeholder="MM"]');
    this.year = page.locator('[placeholder="YYYY"]');

    this.verificationCodePage = page.locator(
      'h1:has-text("Send me a verification code to log in")',
    );

    this.verificationOptionPage = page.locator(
      'h1:has-text(" Choose verification option ")',
    );

    this.usernameError = page.locator('data-testid=username-error-message');
    this.dateOfBirthError = page.locator('data-testid=dob-error-message');
    this.usernameChars = page.locator('data-testid=usernameMax-error-message');
    this.invalidDateOfBirthChars = page.locator('data-testid=invalidDate-error-message');
    this.futureDOBError = page.locator('data-testid=futureDate-error-message');
    this.blankMonthFieldError = page.locator('data-testid=requiredField-error-message');
    this.backToLogin = page.locator('a:has-text("Back to Log In")');
    this.verificationOptionError = page.locator('data-testid=verification-error');
    this.email = page.locator('data-testid=email');
    this.sms = page.locator('data-testid=sms');
    this.changeUsername = page.locator('data-testid=change-username');
    this.changeDOB = page.locator('data-testid=change-dob');

    this.enterVerficationCodePage = page.locator(
      'h1:has-text(" Enter your verification code ")',
    );

    this.verificationCodeField = page.locator('data-testid=verification-code');
    this.verificationCodeError = page.locator('data-testid=verification-code-error');

    this.invalidVerifyCodeError = page.locator(
      'data-testid=invalid-verificationcode-error',
    );

    this.accountSuspendedPage = page.locator(
      'h1:has-text(" Your account is temporarily suspended ")',
    );
  }

  async isVerificationCodePageDisplayed() {
    await this.isElementVisible(this.verificationCodePage);
  }

  async isAccountSuspendedPageDisplayed() {
    await this.isElementVisible(this.accountSuspendedPage);
  }

  async isChooseVerificationOptionPageDisplayed() {
    await this.isElementVisible(this.verificationOptionPage);
  }

  async isVerificationCodeErrorDisplayed() {
    await this.isElementVisible(this.verificationCodeError);
  }

  async isInvalidVerificationCodeErrorDisplayed(count: string) {
    const locator = this.page.locator(
      `data-testid=pwd-attempt-remaining:text-is("${count}")`,
    );

    await this.isElementVisible(locator);
  }

  async blankEmail() {
    await this.loginInputField.fill('');
    await this.day.fill('01');
    await this.month.fill('01');
    await this.year.fill('2000');
    await this.continueBtn.click();
    await expect(this.usernameError).toBeVisible();
  }

  async EmailCharsLength() {
    await this.loginInputField.fill('bende');
    await this.day.fill('01');
    await this.month.fill('01');
    await this.year.fill('2000');
    await this.continueBtn.click();
    await expect(this.usernameChars).toBeVisible();
  }

  async blankEmailAndDateOfBirth() {
    await this.loginInputField.fill('');
    await this.day.fill('');
    await this.month.fill('');
    await this.year.fill('');
    await this.continueBtn.click();
    await expect(this.usernameError).toBeVisible();
    await expect(this.dateOfBirthError).toBeVisible();
  }

  async invalidDateOfBirth() {
    await this.loginInputField.fill('bende.nku');
    await this.day.fill('dd');
    await this.month.fill('mm');
    await this.year.fill('yyyy');
    await expect(this.invalidDateOfBirthChars).toBeVisible();
  }

  async futureDOBAndBlankField() {
    await this.loginInputField.fill('bende.nku');
    await this.day.fill('01');
    await this.month.fill('01');
    await this.year.fill('2025');
    await expect(this.futureDOBError).toBeVisible();
    await this.day.fill('01');
    await this.month.fill('');
    await this.year.fill('2000');
    await expect(this.blankMonthFieldError).toBeVisible();
  }

  async emailAndDOB() {
    await this.loginInputField.fill('bende.nku');
    await this.day.fill('01');
    await this.month.fill('01');
    await this.year.fill('2000');
    await this.continueBtn.click();
    await expect(this.verificationOptionPage).toBeVisible();
  }

  async choosVerificationOptionError() {
    await this.loginInputField.fill('bende.nku');
    await this.day.fill('01');
    await this.month.fill('01');
    await this.year.fill('2000');
    await this.continueBtn.click();
    await expect(this.verificationOptionPage).toBeVisible();
    await this.continueBtn.click();
    await expect(this.verificationOptionError).toBeVisible();
  }

  async clickChangeUsername() {
    await this.loginInputField.fill('bende.nku');
    await this.day.fill('01');
    await this.month.fill('01');
    await this.year.fill('2000');
    await this.continueBtn.click();
    await expect(this.verificationOptionPage).toBeVisible();
    await this.changeUsername.click();
    await expect(this.verificationCodePage).toBeVisible();
  }

  async emailOption() {
    await this.loginInputField.fill('bende.nku');
    await this.day.fill('01');
    await this.month.fill('01');
    await this.year.fill('2000');
    await this.continueBtn.click();
    await expect(this.verificationOptionPage).toBeVisible();
    await this.email.click();
    await this.continueBtn.click();
    await expect(this.enterVerficationCodePage).toBeVisible();
  }

  async smsOption() {
    await this.loginInputField.fill('bende.nku');
    await this.day.fill('01');
    await this.month.fill('01');
    await this.year.fill('2000');
    await this.continueBtn.click();
    await expect(this.verificationOptionPage).toBeVisible();
    await this.sms.click();
    await this.continueBtn.click();
    await expect(this.enterVerficationCodePage).toBeVisible();
  }

  async enterVerificationCode(code: string) {
    await this.verificationCodeField.fill(code);
    await this.continueBtn.click();
  }
}
