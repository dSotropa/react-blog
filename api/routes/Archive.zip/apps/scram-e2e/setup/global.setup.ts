import { chromium, FullConfig } from '@playwright/test';

import { BasePage } from '../models/basepage';

async function globalSetup(config: FullConfig) {
  const browser = await chromium.launch();
  const context = await browser.newContext();
  const page = await context.newPage();
  const basePage = new BasePage(page);
  const TEST = '';

  await basePage.homePage.navigate();
  await browser.close();
}

export default globalSetup;
