import { test as base } from '@playwright/test';

export interface TestOptions {
  saveSession: boolean;
}

export const test = base.extend<TestOptions>({
  saveSession: [ true, { option: true } ],
});
