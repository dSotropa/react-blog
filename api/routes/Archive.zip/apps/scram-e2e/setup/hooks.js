/* eslint-disable no-console */
import { chromium, test } from '@playwright/test';

test.beforeAll(async () => {
  console.log('Launch Browser');
  global.browser = await chromium.launch({ headless: false });
});

test.afterAll(async () => {
  console.log('Close Browser');
  await global.close();
});

test.beforeEach(async () => {
  console.log('Create new context and page');
  global.context = await global.browser.newContext();
  global.page = await global.context.newPage();
});

test.afterEach(async () => {
  console.log('Close context and page');
  await global.PageTransitionEvent.close();
  await global.context.close();
});
