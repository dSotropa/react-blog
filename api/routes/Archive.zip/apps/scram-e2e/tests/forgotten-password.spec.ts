import test from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../models/basepage';
import { ConsumerLoginPage } from '../pageobjects/consumer-login.po';
import { ForgottenPassword } from '../pageobjects/forgotten-password.po';

test.describe('forgotten password', () => {
  let authFunctions: ForgottenPassword;
  let basePage: BasePage;
  let forgottenPassword: ForgottenPassword;
  let consumerLoginPage: ConsumerLoginPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ page }) => {
    basePage = new BasePage(page);
    authFunctions = new ForgottenPassword(page);
    forgottenPassword = new ForgottenPassword(page);
    consumerLoginPage = new ConsumerLoginPage(page);

    await basePage.homePage.navigate();
    await page.waitForURL(`**/${forgottenPassword.route}`);
    await forgottenPassword.assertElementVisible(forgottenPassword.loginPage);
  });

  test('Compare the Login page to it\'s baseline @VisualCheck', async ({ page }) => {
    await forgottenPassword.isLoginPageDisplayed();

    await visualFunctions.eyesCheck('Consumer login page', page);
  });

  test('User enters reset password details and selects email option @CoreTest', async () => {
    await consumerLoginPage.wrongPassword();
    await consumerLoginPage.forgotPassword.click();
    await forgottenPassword.resetPasswordDetails();
    await forgottenPassword.selectEmailOption();
  });

  test('User enters reset password details and selects SMS option @CoreTest', async () => {
    await consumerLoginPage.wrongPassword();
    await consumerLoginPage.forgotPassword.click();
    await forgottenPassword.resetPasswordDetails();
    await forgottenPassword.selectSMSOption();
  });

  test('User enters verification code and reset password @CoreTest', async () => {
    await consumerLoginPage.wrongPassword();
    await consumerLoginPage.forgotPassword.click();
    await forgottenPassword.resetPasswordDetails();
    await forgottenPassword.selectEmailOption();
    await forgottenPassword.enterVerificationCodeAndResetPassword();
  });

  afterAllHook(test);
});
