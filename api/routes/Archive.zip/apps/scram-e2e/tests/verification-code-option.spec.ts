import test from '@playwright/test';
import { VisualFunctions } from '@utility-e2e';

import { BasePage } from '../models/basepage';
import { ConsumerLoginPage } from '../pageobjects/consumer-login.po';
import { ForgottenPassword } from '../pageobjects/forgotten-password.po';
import { VerificationCodePage } from '../pageobjects/verification-code.po';

test.describe('choose verification code option', () => {
  let authFunctions: ForgottenPassword;
  let basePage: BasePage;
  let forgottenPassword: ForgottenPassword;
  let consumerLoginPage: ConsumerLoginPage;
  let visualFunctions: VisualFunctions;
  let verificationCodePage: VerificationCodePage;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ page }) => {
    basePage = new BasePage(page);
    authFunctions = new ForgottenPassword(page);
    forgottenPassword = new ForgottenPassword(page);
    consumerLoginPage = new ConsumerLoginPage(page);
    verificationCodePage = new VerificationCodePage(page);

    await basePage.homePage.navigate();
    await page.waitForURL(`**/${forgottenPassword.route}`);
    await forgottenPassword.assertElementVisible(forgottenPassword.loginPage);
  });

  test('Compare the Login page to it\'s baseline @VisualCheck', async ({ page }) => {
    await forgottenPassword.isLoginPageDisplayed();

    await visualFunctions.eyesCheck('Choose verification code option page', page);
  });

  test('User navigates to Choose verification option page @CoreTest', async () => {
    await consumerLoginPage.enterUsername('bende.nku');
    await verificationCodePage.sendCodeLink.click();
    await verificationCodePage.emailAndDOB();
  });

  test('An error is displayed when a verification option is not selected @CoreTest', async () => {
    await consumerLoginPage.enterUsername('bende.nku');
    await verificationCodePage.sendCodeLink.click();
    await verificationCodePage.choosVerificationOptionError();
  });

  test('Clicking the Change button navigates back to Send me a verification code to log in @CoreTest', async () => {
    await consumerLoginPage.enterUsername('bende.nku');
    await verificationCodePage.sendCodeLink.click();
    await verificationCodePage.clickChangeUsername();
  });

  test('User navigates to Enter your verification code when email option is selected @CoreTest', async () => {
    await consumerLoginPage.enterUsername('bende.nku');
    await verificationCodePage.sendCodeLink.click();
    await verificationCodePage.emailOption();
  });

  test('User navigates to Enter your verification code when sms option is selected @CoreTest', async () => {
    await consumerLoginPage.enterUsername('bende.nku');
    await verificationCodePage.sendCodeLink.click();
    await verificationCodePage.smsOption();
  });

  test('User enters a verification code on the verification code page and redirects to Legal and General @CoreTest', async () => {
    await consumerLoginPage.enterUsername('bende.nku');
    await verificationCodePage.sendCodeLink.click();
    await verificationCodePage.smsOption();
    await verificationCodePage.enterVerificationCode('123456');
    await consumerLoginPage.isRedirectAfterSuccess();
  });
});
