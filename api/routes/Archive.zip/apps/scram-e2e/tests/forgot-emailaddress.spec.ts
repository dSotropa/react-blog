import test from '@playwright/test';
import { VisualFunctions } from '@utility-e2e';

import { BasePage } from '../models/basepage';
import { ConsumerLoginPage } from '../pageobjects/consumer-login.po';
import { ForgottenPassword } from '../pageobjects/forgotten-password.po';
import { ForgotEmailaddress } from '../pageobjects/forgot-emailaddress.po';

test.describe('forgot your email address', () => {
  let authFunctions: ForgottenPassword;
  let basePage: BasePage;
  let forgottenPassword: ForgottenPassword;
  let consumerLoginPage: ConsumerLoginPage;
  let visualFunctions: VisualFunctions;
  let forgotEmailaddress: ForgotEmailaddress;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ page }) => {
    basePage = new BasePage(page);
    authFunctions = new ForgottenPassword(page);
    forgottenPassword = new ForgottenPassword(page);
    consumerLoginPage = new ConsumerLoginPage(page);
    forgotEmailaddress = new ForgotEmailaddress(page);

    await basePage.homePage.navigate();
    await page.waitForURL(`**/${forgottenPassword.route}`);
    await forgottenPassword.assertElementVisible(forgottenPassword.loginPage);
  });

  test('Compare the Login page to it\'s baseline @VisualCheck', async ({ page }) => {
    await forgottenPassword.isLoginPageDisplayed();

    await visualFunctions.eyesCheck('Consumer login page', page);
  });

  test('User navigates to Forgot your email address page when clicks forgot your email address link @CoreTest', async () => {
    await forgotEmailaddress.clickForgetEmailAddress();
  });

  test('An error is displayed when last name is empty @CoreTest', async () => {
    await forgotEmailaddress.lastNameFieldEmpty();
  });

  test('An error is displayed when last name has invalid character @CoreTest', async () => {
    await forgotEmailaddress.lastNameInvalidChar();
  });

  test('An error is displayed when date of birth is empty @CoreTest', async () => {
    await forgotEmailaddress.dobEmpty();
  });

  test('An error is displayed when date of birth is missing a year @CoreTest', async () => {
    await forgotEmailaddress.dobWithoutYear();
  });

  test('An error is displayed when date of birth is missing a month @CoreTest', async () => {
    await forgotEmailaddress.dobWithoutMonth();
  });

  test('An error is displayed when date of birth is missing a day @CoreTest', async () => {
    await forgotEmailaddress.dobWithoutDay();
  });

  test('An error is displayed when postcode is empty @CoreTest', async () => {
    await forgotEmailaddress.postcodeFieldEmpty();
  });

  test('An error is displayed when postcode is invalid @CoreTest', async () => {
    await forgotEmailaddress.userEnterInvalidPostcode();
  });

  test('User returns to Login when clicks the back to login button @CoreTest', async () => {
    await forgotEmailaddress.userClicksBackToLogin();
  });

  test('An error is displayed when user enter a future date of birth @CoreTest', async () => {
    await forgotEmailaddress.userHasFutureDate();
  });

  test('An error is displayed when user age range is above 120 @CoreTest', async () => {
    await forgotEmailaddress.outSideAgeRange();
  });

  test('User navigates to Choose verification option page @CoreTest', async () => {
    await forgotEmailaddress.userDetails();
  });
});
