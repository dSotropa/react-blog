import test from '@playwright/test';
import { VisualFunctions } from '@utility-e2e';

import { BasePage } from '../models/basepage';
import { ConsumerLoginPage } from '../pageobjects/consumer-login.po';
import { ForgottenPassword } from '../pageobjects/forgotten-password.po';
import { VerificationCodePage } from '../pageobjects/verification-code.po';

test.describe('verification code', () => {
  let authFunctions: ForgottenPassword;
  let basePage: BasePage;
  let forgottenPassword: ForgottenPassword;
  let consumerLoginPage: ConsumerLoginPage;
  let visualFunctions: VisualFunctions;
  let verificationCodePage: VerificationCodePage;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ page }) => {
    basePage = new BasePage(page);
    authFunctions = new ForgottenPassword(page);
    forgottenPassword = new ForgottenPassword(page);
    consumerLoginPage = new ConsumerLoginPage(page);
    verificationCodePage = new VerificationCodePage(page);

    await basePage.homePage.navigate();
    await page.waitForURL(`**/${forgottenPassword.route}`);
    await forgottenPassword.assertElementVisible(forgottenPassword.loginPage);
  });

  test('Compare the Login page to it\'s baseline @VisualCheck', async ({ page }) => {
    await forgottenPassword.isLoginPageDisplayed();

    await visualFunctions.eyesCheck('Verification code page', page);
  });

  test('User navigates to Send me a verification code to log in @CoreTest', async () => {
    await consumerLoginPage.enterUsername('bende.nku');
    await verificationCodePage.sendCodeLink.click();
    await verificationCodePage.isVerificationCodePageDisplayed();
  });

  test('Back to login button navigates back to login page from Send me a verification code to log in page @CoreTest', async () => {
    await consumerLoginPage.enterUsername('bende.nku');
    await verificationCodePage.sendCodeLink.click();
    await verificationCodePage.isVerificationCodePageDisplayed();
    await verificationCodePage.backToLogin.click();
  });

  test('An error is displayed with blank email on Send me a verification code page @CoreTest', async () => {
    await consumerLoginPage.enterUsername('bende.nku');
    await verificationCodePage.sendCodeLink.click();
    await verificationCodePage.blankEmail();
  });

  test('Errors are displayed when email and date of birth field are blank on Send me a verification code page @CoreTest', async () => {
    await consumerLoginPage.enterUsername('bende.nku');
    await verificationCodePage.sendCodeLink.click();
    await verificationCodePage.blankEmailAndDateOfBirth();
  });

  test('An error is displayed when email characters are not valid on Send me a verification code page @CoreTest', async () => {
    await consumerLoginPage.enterUsername('bende.nku');
    await verificationCodePage.sendCodeLink.click();
    await verificationCodePage.EmailCharsLength();
  });

  test('An error is displayed when date of birth has non numeric or special characters @CoreTest', async () => {
    await consumerLoginPage.enterUsername('bende.nku');
    await verificationCodePage.sendCodeLink.click();
    await verificationCodePage.invalidDateOfBirth();
  });

  test('An error is displayed when date of birth is in future and month is left blank @CoreTest', async () => {
    await consumerLoginPage.enterUsername('bende.nku');
    await verificationCodePage.sendCodeLink.click();
    await verificationCodePage.futureDOBAndBlankField();
  });

  test('User enter email and date of birth on Send me a verification code page  @CoreTest', async () => {
    await consumerLoginPage.enterUsername('bende.nku');
    await verificationCodePage.sendCodeLink.click();
    await verificationCodePage.emailAndDOB();
  });
});
