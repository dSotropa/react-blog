import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../models/basepage';
import { ConsumerLoginPage } from '../pageobjects/consumer-login.po';

test.describe('Consumer login', () => {
  let basePage: BasePage;
  let consumerLoginPage: ConsumerLoginPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ page }) => {
    basePage = new BasePage(page);
    consumerLoginPage = new ConsumerLoginPage(page);

    await basePage.homePage.navigate();
    await page.waitForURL(`**/${consumerLoginPage.route}`);
    await consumerLoginPage.assertElementVisible(consumerLoginPage.loginPage);
  });

  test('Compare the Login page to it\'s baseline @VisualCheck', async ({ page }) => {
    await consumerLoginPage.isLoginPageDisplayed();

    await visualFunctions.eyesCheck('Consumer login page', page);
  });

  test('User enters correct username and login successfully @CoreTest', async () => {
    await consumerLoginPage.enterUserDetails('emma.serra', 'Cl0udyday258');
    await consumerLoginPage.isRedirectAfterSuccess();
    // await consumerLoginPage.logOutBtn.click();
    // await consumerLoginPage.isLoginPageDisplayed();
  });

  test('User enters correct email and login successfully @CoreTest', async () => {
    await consumerLoginPage.enterUserDetails('emma.serra@landg.com', 'Cl0udyday258');
    await consumerLoginPage.isRedirectAfterSuccess();
    // await consumerLoginPage.logOutBtn.click();
    // await consumerLoginPage.isLoginPageDisplayed();
  });

  test('An error is displayed when an invalid password is entered @CoreTest', async () => {
    await consumerLoginPage.wrongPassword();
    await consumerLoginPage.isLoginErrorDisplayed();
  });

  test('The user is returned to the login page when clicking on change link page @CoreTest', async () => {
    await consumerLoginPage.wrongPassword();
    await consumerLoginPage.isLoginErrorDisplayed();
    await consumerLoginPage.change.click();
    await consumerLoginPage.isLoginPageDisplayed();
  });

  test('The user navigates to the forgotten password page @CoreTest', async () => {
    await consumerLoginPage.wrongPassword();
    await consumerLoginPage.isLoginErrorDisplayed();
    await consumerLoginPage.forgotPassword.click();
    await consumerLoginPage.isForgotPasswordPageDisplayed();
  });

  afterAllHook(test);
});
