import { MOCK_ENV } from '@utility-e2e';

import { test } from '../setup/extendConfig';
import { ConsumerLoginPage } from '../pageobjects/consumer-login.po';
import { BasePage } from '../models/basepage';

test.describe('Navigate to the Consumer app', () => {
  let consumerLoginPage: ConsumerLoginPage;
  let basePage: BasePage;

  test.beforeEach(async ({ page }) => {
    basePage = new BasePage(page);
    consumerLoginPage = new ConsumerLoginPage(page);
    await basePage.homePage.navigate();
  });

  test('User is routed to the consumer login page @CoreTest', async ({ page }) => {
    await page.waitForURL(`${MOCK_ENV}${consumerLoginPage.route}`);
  });
});
