import { test } from '@playwright/test';
import { VisualFunctions } from '@utility-e2e';

import { BasePage } from '../models/basepage';
import { ConsumerLoginPage } from '../pageobjects/consumer-login.po';
import { ForgottenPassword } from '../pageobjects/forgotten-password.po';
import { VerificationCodePage } from '../pageobjects/verification-code.po';

test.describe('Enter your verification code', () => {
  let authFunctions: ForgottenPassword;
  let basePage: BasePage;
  let forgottenPassword: ForgottenPassword;
  let consumerLoginPage: ConsumerLoginPage;
  let visualFunctions: VisualFunctions;
  let verificationCodePage: VerificationCodePage;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ page }) => {
    basePage = new BasePage(page);
    authFunctions = new ForgottenPassword(page);
    forgottenPassword = new ForgottenPassword(page);
    consumerLoginPage = new ConsumerLoginPage(page);
    verificationCodePage = new VerificationCodePage(page);

    await basePage.homePage.navigate();
    await page.waitForURL(`**/${forgottenPassword.route}`);
    await forgottenPassword.assertElementVisible(forgottenPassword.loginPage);
  });

  test('Compare the Login page to it\'s baseline @VisualCheck', async ({ page }) => {
    await forgottenPassword.isLoginPageDisplayed();

    await visualFunctions.eyesCheck('Choose verification code option page', page);
  });

  test('An error is displayed when verification code field is empty when SMS option is selected @CoreTest', async () => {
    await consumerLoginPage.enterUsername('bende.nku');
    await verificationCodePage.sendCodeLink.click();
    await verificationCodePage.smsOption();
    await verificationCodePage.enterVerificationCode('');
    await verificationCodePage.isVerificationCodeErrorDisplayed();
  });

  test('An error is displayed when verification code field is empty when email option is selected @CoreTest', async () => {
    await consumerLoginPage.enterUsername('bende.nku');
    await verificationCodePage.sendCodeLink.click();
    await verificationCodePage.emailOption();
    await verificationCodePage.enterVerificationCode('');
    await verificationCodePage.isVerificationCodeErrorDisplayed();
  });

  test('An error is displayed when user enters verification code incorrectly 5 times then account suspended @CoreTest', async () => {
    await consumerLoginPage.enterUsername('bende.nku');
    await verificationCodePage.sendCodeLink.click();
    await verificationCodePage.smsOption();
    await verificationCodePage.enterVerificationCode('654321');
    await verificationCodePage.isInvalidVerificationCodeErrorDisplayed('4');
    await verificationCodePage.enterVerificationCode('654322');
    await verificationCodePage.isInvalidVerificationCodeErrorDisplayed('3');
    await verificationCodePage.enterVerificationCode('654323');
    await verificationCodePage.isInvalidVerificationCodeErrorDisplayed('2');
    await verificationCodePage.enterVerificationCode('654324');
    await verificationCodePage.isInvalidVerificationCodeErrorDisplayed('1');
    await verificationCodePage.enterVerificationCode('654325');
    await verificationCodePage.isInvalidVerificationCodeErrorDisplayed('0');
    await verificationCodePage.enterVerificationCode('654326');
    await verificationCodePage.isAccountSuspendedPageDisplayed();
  });
});
