import { PlaywrightTestConfig } from '@playwright/test';
import { getConfig } from '@utility-e2e';

const config: PlaywrightTestConfig = getConfig({
  appNameRef: 'scram',
  timeout: 300000,
  port: 4200,
  projects: [
    {
      name: 'CoreAndVisual',
      grep: [ /@CoreTest/, /@VisualCheck/ ],
      use: { channel: 'chrome' },
    },
    {
      name: 'CoreOnly',
      grep: [ /@CoreTest/ ],
      use: { channel: 'chrome' },
    },
  ],
});

export default config;
