import {
  actAsProxy,
  getPort,
  getServers,
  setupListener,
  startApollo,
} from '@libs/shared/utility-mock-server';

import { setupExpressMocks } from './express';
import mocks from './apollo/mocks';
import resolvers from './apollo/resolvers';

(async () => {
  let gqlPath;
  const appRefName = 'oss';
  const servers = getServers(appRefName);
  const port: number = getPort();

  if (!actAsProxy) {
    setupExpressMocks({
      server: servers.http,
      port,
      appRefName,
    });

    gqlPath = await startApollo({
      server: servers.http,
      mocks,
      resolvers,
      context: async ({ req }) =>
        new Promise(res => {
          res({ headers: req.headers });
        }),
    });
  }

  setupListener({
    appRefName,
    servers,
    port,
    gqlPath,
  });
})();
