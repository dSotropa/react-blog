export interface CardData {
  paymentStatus?: string;
}

export interface PayPage {
  cardData: CardData;
}

export const payPage: PayPage = {
  cardData: {},
};
