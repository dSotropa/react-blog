import * as express from 'express';

import {
  setupConfigMocks,
  setupEpiServerMocks,
  setupExpressMocksConfig,
  setupForgeRockAuthMocks,
  setupForgeRockCors,
  setupLandingPage,
} from '@libs/shared/utility-mock-server';

import { setupKeycloakMocks } from './keycloak';
import { setupThirdPartyUrlMocks } from './third-party';

export function setupExpressMocks({
  server,
  port,
  appRefName,
}: setupExpressMocksConfig): void {
  server.use(express.urlencoded({ extended: true }));
  server.use(express.json());

  setupForgeRockCors(server);
  setupForgeRockAuthMocks(server);
  setupEpiServerMocks(server);
  setupKeycloakMocks(server);
  setupThirdPartyUrlMocks(server);
  setupConfigMocks({ server, appRefName });

  setupLandingPage({
    server,
    port,
    gql: true,
    restApi: false,
    name: 'Online Self Service',
    keycloak: true,
    forgeRockAuth: true,
    forgeRockData: false,
    episerver: true,
  });
}
