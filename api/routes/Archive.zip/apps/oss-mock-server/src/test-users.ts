export const testUsers: {
  [key: string]: {
    username: string;
    accountHash?: string;
  };
} = {
  Drawdown: {
    username: 'Drawdown',
    accountHash: 'C9131ADD3342EC88EEAA1D5E534CFC2D4F16B7ED3632924F32654216E1107590', // accountSubType:"PERSONAL_PENSION_ACCUMULATION"
  },
  User1_ISA: {
    username: 'User1ISA',
    accountHash: '681324C7AAA894B806B10383B6D18B6B6F0D585BE21FD1DF7300EA6796B1AFA7', // accountSubType:"ISA_WORKPLACE"
  },
  User2_LGPP: {
    username: 'User2 LGPP',
    accountHash: '123F2BB8073D046F1BA22EC5C17BAA4E71C8D3A7AF5F91A502C7A55E7C8420C7', // accountSubType:"PERSONAL_PENSION_ACCUMULATION"
  },
  ISA_tax_year_end: {
    username: 'ISA tax year end',
    accountHash: 'TAXYEARENDISATAXYEARENDISATAXYEARENDISATAXYEARENDISATAXYEARENDISA', // accountSubType:"ISA_WORKPLACE"
  },
  LGPP_tax_year_end: {
    username: 'LGPP tax year end',
    accountHash: 'TAXYEARENDPENSIONTAXYEARENDPENSIONTAXYEARENDPENSIONTAXYEARENDPENSION', // accountSubType:"PERSONAL_PENSION_ACCUMULATION"
  },
  User2_ISA: {
    username: 'User2 ISA',
    accountHash: 'A1D19063873B09E675F63591B24547BAFF59C6C202B0CFA10FC3A869133F3C1D', // accountSubType:"ISA_WORKPLACE"
  },
  User3_ISA: {
    username: 'User3 ISA',
    accountHash: 'B3FD26E9D0FA269F0AA25479007B8D0B3547C6A5524106C1497931251A465E71', // accountSubType:"ISA_WORKPLACE"
  },
  ISA_LEAVER_with_a_regular: {
    username: 'ISA LEAVER - with a regular',
    accountHash: 'FD937809F900E9311D235771CEDE7C66E8B2A8951F548D4D709B1D165C013AB4', // accountSubType:"ISA_WORKPLACE"
  },
  ISA_DIRECT_no_regular: {
    username: 'ISA DIRECT - no regular',
    accountHash: 'LoremipsumdolorsitametconsecteturadipiscingelitIntegerquisfacilisis', // accountSubType:"ISA_D2C"
  },
  Shauns_ISA: {
    username: 'Shaun\'s ISA',
    accountHash: 'imissthecomfortinbeingsadimissthecomfortinbeingsad', // accountSubType:"ISA_WORKPLACE"
  },
  User33_LGPP_Test: {
    username: 'User33 LGPP Test',
    accountHash: '4F6C5DF027486B64AF7ADDE5491ED86DA31CF3F0F7AF098603606A5A6E032308', // accountSubType:"PERSONAL_PENSION_ACCUMULATION"
  },
  LGPP_User_requires_wake_up_pack: {
    username: 'LGPP User requires wake up pack',
    accountHash: 'GFDK8800MARKWOZHERE20210202WOZZA0088HG8GIJF9R8UWRQ5POQR5353H6445', // accountSubType:"PERSONAL_PENSION_ACCUMULATION"
  },
  LGPP_User_with_outstanding_balance: {
    username: 'LGPP User with outstanding balance',
    accountHash: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789QW', // accountSubType:"PERSONAL_PENSION_ACCUMULATION"
  },
  LGPP_User_waiting_for_wake_up_pack: {
    username: 'LGPP User waiting for wake-up pack',
    accountHash: 'DEATHFROMABOVE1979STILLWAITINGFORAWAKEUPPACKDEATHFROMABOVE1979ZZ', // accountSubType:"PERSONAL_PENSION_ACCUMULATION"
  },
  LGPP_User_retirement_options_notification_dismissed: {
    username: 'LGPP User retirement options notification dismissed',
    accountHash: 'V3FQMYDVBJV4EZRSPCHVEXYKKGDMZ0XAV4WXJJDRL780CSVK1A4838VKC1CGRX2W', // accountSubType:"PERSONAL_PENSION_ACCUMULATION"
  },
  LGPP_User_can_switch_funds: {
    username: 'LGPP User can switch funds',
    accountHash: '31DGFN5MH2G15PIYRN7CIHDOR8TJR6QJYKFK2I4HMJ573NGPW2YIIP08IQAQT1FY', // accountSubType:"PERSONAL_PENSION_ACCUMULATION"
  },
  Drawdown_regular_income: {
    username: 'Drawdown regular income',
    accountHash: 'c9d6348956272b72cb175c7992b4e9024d2fbdbfdfc8569c23adf792ee52a20f', // accountSubType:"PERSONAL_PENSION_ACCUMULATION"
  },
  Drawdown_pathway_switch: {
    username: 'Drawdown pathway switch',
    accountHash: '7f59fe06465f10c3ee21ffa225755466513a1840e463c78eec15fa8335869381', // accountSubType:"PERSONAL_PENSION_ACCUMULATION"
  },
  ISA_User_can_switch_funds: {
    username: 'ISA User can switch funds',
    accountHash: '31DGFN5MH2G15PIYRN7CIHDOR8TJR6QJYKFK2I4HMJ573NGPW2YIIP0ISASWITCH', // accountSubType:"ISA_D2C"
  },
};
