const fs = require('fs');
const { buildClientSchema, getIntrospectionQuery, printSchema } = require('graphql');
const fetch = require('node-fetch');
const https = require('https');

/*
  Created based upon ideas from https://www.apollographql.com/blog/backend/schema-design/three-ways-to-represent-your-graphql-schema/
  This was after I couldn't get the built-in Apollo tools to work (certificate errors)
*/

function getArg(argName, defaultValue = null) {
  const i = process.argv.indexOf(argName);

  return i >= 0
    ? process.argv[i + 1]
    : defaultValue;
}

async function saveSchema() {
  const output = getArg('--output', '../oss-mock-server/src/assets/lg.graphql');
  const endPoint = getArg('--endpoint');
  const appId = getArg('--appid');

  if (endPoint && appId) {
    // this is needed to workaround the 'unable to find local certificate' error
    const agent = new https.Agent({
      rejectUnauthorized: false,
    });

    const response = await fetch(endPoint, {
      agent,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'app-id': appId,
      },
      body: JSON.stringify({ query: getIntrospectionQuery() }),
    });
    const graphqlSchemaObj = buildClientSchema((await response.json()).data);
    const sdlString = printSchema(graphqlSchemaObj);

    fs.writeFileSync(output, sdlString);
    console.info(`${output} saved!`);
    process.exit();
  } else {
    console.error('--endpoint or --appid arg(s) missing');
    process.exit(1);
  }
}

module.exports.init = saveSchema();
