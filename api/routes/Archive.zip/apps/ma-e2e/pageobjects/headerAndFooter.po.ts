import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class HeaderAndFooterPage extends PageFunctions {
  readonly page: Page;
  readonly accessibilityLink: Locator;
  readonly legalInformationLink: Locator;
  readonly cookiePolicyLink: Locator;
  readonly privacyPolicyLink: Locator;
  readonly securityInformationLink: Locator;
  readonly navFooterLGLogo: Locator;
  readonly navMenuRewards: Locator;
  readonly navMenuNotificationBellIcon: Locator;
  readonly notificationMenuItems: Locator;
  readonly navMenuAccountDetails: Locator;
  readonly navMenuNotificationsMenu: Locator;
  readonly navMenuLogout: Locator;
  readonly navLandGLogo: Locator;

  readonly accessibilityHref =
    'https://www.legalandgeneral.com/log-in/shared-pages/footer-links/accessibility.html';
  readonly legalInformationHref =
    'https://www.legalandgeneral.com/log-in/shared-pages/footer-links/legal.html';
  readonly cookiePolicyHref =
    'https://www.legalandgeneral.com/privacy-policy/cookies.html';
  readonly privacyPolicyHref = 'https://www.legalandgeneral.com/privacy-policy';

  readonly securityInformationHref =
    'https://www.legalandgeneral.com/log-in/shared-pages/footer-links/security.html';

  readonly notificationDocumentLink =
    'https://preprod.mya.platform.landg.com/product/documents?productId=';

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.accessibilityLink = page.locator('[id="accessibility-link"]');
    this.legalInformationLink = page.locator('[id="legal-regulatory-link"]');
    this.cookiePolicyLink = page.locator('[id="ot-sdk-btn"]');
    this.privacyPolicyLink = page.locator('[id="privacy-policy-linl"]');
    this.securityInformationLink = page.locator('[id="security-link"]');
    this.navFooterLGLogo = page.locator('.lg-footer-logo__img');
    this.navMenuNotificationBellIcon = page.locator('data-testid=nav-notification-menu');
    this.navMenuNotificationsMenu = page.locator('data-testid=nav-notification-menu');
    this.notificationMenuItems = page.locator('.menu-item');
    this.navMenuAccountDetails = page.locator('data-testid=account-details-nav-link');
    this.navMenuRewards = page.locator('data-testid=rewards-nav-link');
    this.navMenuLogout = page.locator('data-testid=logout-nav-link');
    this.navLandGLogo = page.locator('data-testid=nav-header-logo');
  }
}
