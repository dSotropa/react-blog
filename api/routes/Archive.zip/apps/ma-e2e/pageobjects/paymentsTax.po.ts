import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class PaymentsTaxPage extends PageFunctions {
  readonly page: Page;
  readonly cbankAccountValue: Locator;
  readonly sortCodeValue: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.cbankAccountValue = page.locator('data-testid=bank-account-number-value');
    this.sortCodeValue = page.locator('data-testid=sort-code-value');
  }
}
