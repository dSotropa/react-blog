import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class ConfirmDetailsEmailPage extends PageFunctions {
  readonly page: Page;

  readonly emailInput: Locator;
  readonly confirmEmailSubmitButton: Locator;
  readonly emailError: Locator;

  readonly confirmDetailsRoute = '#/welcome/confirm-details';

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.emailInput = page.locator('data-testid=email-details-personal-input');

    this.confirmEmailSubmitButton = page.locator(
      'data-testid=confirm-details-email-submit',
    );

    this.emailError = page.locator('data-testid=email-validation-personal-invalid');
  }
}
