import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class MailboxPage extends PageFunctions {
  readonly page: Page;
  readonly composeMessageBtn: Locator;
  readonly chooseProductDropDown: Locator;
  readonly chooseSubjectDropDown: Locator;
  readonly knowledgeBaseCards: Locator;
  readonly sendMessageBtn: Locator;
  readonly textMessageArea: Locator;
  readonly composeSuccessMessage: Locator;
  readonly firstConversation: Locator;
  readonly firstMessage: Locator;
  readonly replyBtn: Locator;
  readonly knowledgeBaseCardSelector: Locator;
  readonly kbCardInsuranceLink =
    'https://www.legalandgeneral.com/insurance/existing-customers';
  readonly textMessage = 'This is a test message used for automation';

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.composeMessageBtn = page.locator('[data-testid="compose-message"]');
    this.chooseProductDropDown = page.locator('[id="select-product"]');
    this.chooseSubjectDropDown = page.locator('[id="select-subject"]');
    this.knowledgeBaseCards = page.locator('.kb-list-item');
    this.sendMessageBtn = page.locator('id=send-button');
    this.textMessageArea = page.locator('id=message-text');
    this.composeSuccessMessage = page.locator('.compose-message-success');
    this.firstConversation = page.locator('.coversation').first();
    this.firstMessage = page.locator('.message-body').first();
    this.replyBtn = page.locator('id=message-reply-btn');
    this.knowledgeBaseCardSelector = page.locator('.kb-list-item');
  }

  async enterTextMessage(): Promise<void> {
    await this.textMessageArea.type(this.textMessage);
  }

  async getKbCardsCount(): Promise<number> {
    return await this.knowledgeBaseCards.count();
  }

  getKnowledgeBaseCardButton(displayName: string) {
    return this.page.locator(`//h2[text()="${displayName}"]/../button`);
  }
}
