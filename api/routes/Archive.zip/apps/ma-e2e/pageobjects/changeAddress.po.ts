import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class ChangeAddressPage extends PageFunctions {
  readonly page: Page;
  readonly countrySelectDropdown: Locator;
  readonly houseNumberInput: Locator;
  readonly postcodeInput: Locator;
  readonly addressSearchButton: Locator;
  readonly addressSelectDropdown: Locator;
  readonly addressSelectDropdownError: Locator;
  readonly saveChangesButton: Locator;
  readonly confirmButton: Locator;
  readonly postcodeDataPointValue: Locator;
  readonly cancelButton: Locator;
  readonly loginButton: Locator;
  readonly cookieBannerAccept: Locator;
  readonly manualAddressLine1Input: Locator;
  readonly manualAddressLine2Input: Locator;
  readonly manualAddressLine3Input: Locator;
  readonly manualAddressLine4Input: Locator;
  readonly manualAddressPostcodeInput: Locator;
  readonly internationalAddressWarning: Locator;
  readonly sendSecureMessageButton: Locator;
  readonly changeAddressManuallyLink: Locator;
  readonly changeAddressRoute = '#/account-details/contact-details/change-address';
  readonly changeAddressManualRoute =
    '#/account-details/contact-details/change-address-manually';
  readonly confirmAddressRoute =
    '#/account-details/contact-details/change-address/confirm-address';
  readonly contactDetailsRoute = '#/account-details/contact-details';
  readonly confirmAddressManualRoute =
    'account-details/contact-details/change-address-manually/confirm-address';

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.countrySelectDropdown = page.locator('[data-testid="country-select-dropdown"]');
    this.houseNumberInput = page.locator('[data-testid="house-number-input"]');
    this.postcodeInput = page.locator('[data-testid="postcode-input"]');
    this.addressSearchButton = page.locator('[data-testid="address-search-button"]');
    this.addressSelectDropdown = page.locator('[data-testid="address-select-dropdown"]');

    this.addressSelectDropdownError = page.locator(
      '[data-testid="select-dropdown-error"]',
    );

    this.saveChangesButton = page.locator('[data-testid="change-address-save-button"]');
    this.confirmButton = page.locator('[data-testid="confirm-address-confirm-button"]');
    this.cancelButton = page.locator('[data-testid="change-address-cancel-button"]');
    this.loginButton = page.locator('id=kc-login');
    this.cookieBannerAccept = page.locator('text=✓ Accept All Cookies');

    this.manualAddressLine1Input = page.locator(
      '[data-testid="manual-address-line1-input"]',
    );

    this.manualAddressLine2Input = page.locator(
      '[data-testid="manual-address-line2-input"]',
    );

    this.manualAddressLine3Input = page.locator(
      '[data-testid="manual-address-line3-input"]',
    );

    this.manualAddressLine4Input = page.locator(
      '[data-testid="manual-address-line4-input"]',
    );

    this.manualAddressPostcodeInput = page.locator(
      '[data-testid="manual-address-postcode-input"]',
    );

    this.internationalAddressWarning = page.locator(
      'data-testid=international-address-warning',
    );

    this.sendSecureMessageButton = page.locator(
      'data-testid=change-address-send-secure-message-button',
    );

    this.changeAddressManuallyLink = page.locator(
      'data-testid=manual-address-entry-link',
    );
  }

  async changeForHouseNumber(houseNumber: string, postcode: string): Promise<void> {
    await this.houseNumberInput.type(houseNumber);
    await this.postcodeInput.type(postcode);
    await this.addressSearchButton.click();
  }

  async navigate(baseUrl = '/', waitForPageToLoad = true): Promise<void> {
    await this.page.goto(baseUrl);

    if (waitForPageToLoad) {
      await this.waitForPageToLoad();
    }
  }

  async acceptCookieBanner(): Promise<void> {
    if (await this.isElementVisible(this.cookieBannerAccept)) {
      await this.cookieBannerAccept.click();
    }
  }

  async setAddress(
    line1: string,
    line2: string,
    line3: string,
    line4: string,
    postcode: string,
  ): Promise<void> {
    await this.manualAddressLine1Input.type(line1);
    await this.manualAddressLine2Input.type(line2);
    await this.manualAddressLine3Input.type(line3);
    await this.manualAddressLine4Input.type(line4);
    await this.manualAddressPostcodeInput.type(postcode);
  }
}
