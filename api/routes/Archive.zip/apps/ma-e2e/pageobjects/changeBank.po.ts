import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class ChangeBank extends PageFunctions {
  public page: Page;
  readonly accountNumber: Locator;
  readonly sortCodeWrapper: Locator;
  readonly sortCodeNumber: Locator;
  readonly confirmBtn: Locator;
  readonly submitMyDetailsBtn: Locator;
  readonly viewMyPolicyBtn: Locator;
  readonly changeBankDetailsLink: Locator;
  readonly submitYourDocumentsOnlineBtn: Locator;
  readonly boldChatContent: Locator;
  readonly boldChatContentTitle: Locator;
  readonly changeBankDetailsPageSupportArticles: Locator;

  readonly changeBankProductNo =
    '#/form/change-bank-account/550cdcdd88f0a7be72b1b6265b26000d1cdf01135948b290250d90164e591854';
  readonly bankAccountNumber = '12345678';

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.accountNumber = page.locator('data-testid=account-number');
    this.sortCodeWrapper = page.locator('[data-testid="sort-code-number"]');
    this.sortCodeNumber = page.locator('data-testid=sort-code-number');
    this.confirmBtn = page.locator('data-testid=confirm');
    this.submitMyDetailsBtn = page.locator('data-testid=submit-my-details');
    this.viewMyPolicyBtn = page.locator('data-testid=view-my-policy');
    this.changeBankDetailsLink = page.locator('text=Update bank details');

    this.submitYourDocumentsOnlineBtn = page.locator(
      'data-testid=submit-your-document-online',
    );

    this.boldChatContent = page.locator('.core-search__content');
    this.boldChatContentTitle = page.locator('.answer-header__title-text-node').first();

    this.changeBankDetailsPageSupportArticles = page.locator(
      'data-testid=support-article-button',
    );
  }

  async enterSortCode(sortCode: string) {
    await this.sortCodeNumber.fill(sortCode);
  }

  async enterBankAccountNr(bankAccount: string) {
    await this.accountNumber.fill(bankAccount);
  }
}
