import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class PreferencesPage extends PageFunctions {
  readonly page: Page;
  readonly communicationPreferencesSection: Locator;
  readonly marketingPreferencesSection: Locator;

  readonly route = '#/account-details/preferences';

  constructor(page: Page) {
    super(page);
    this.page = page;

    this.communicationPreferencesSection = page.locator(
      'data-testid=communication-preferences',
    );

    this.marketingPreferencesSection = page.locator('data-testid=marketing-preferences');
  }

  getMarketingPreferenceButton(name: string, type: string) {
    return this.page.locator(`data-testid=marketing-preference-${name}-${type}-button`);
  }

  getMarketingPreferenceSuccessAlert(name: string) {
    return this.page.locator(`data-testid=marketing-preference-${name}-success-alert`);
  }

  getCommunicationPreferenceButton(name: string, type: string) {
    return this.page.locator(
      `data-testid=communication-preference-${name}-${type}-button`,
    );
  }

  getCommuncationPreferenceSuccessAlert(name: string, type: string) {
    return this.page.locator(
      `data-testid=communication-preference-${name}-success-${type}-alert`,
    );
  }
}
