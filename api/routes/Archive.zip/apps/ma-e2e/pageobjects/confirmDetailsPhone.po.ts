import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class ConfirmDetailsPhonePage extends PageFunctions {
  readonly page: Page;

  readonly confirmPhoneNumbersSubmitButton: Locator;
  readonly mobilePhoneInput: Locator;
  readonly homePhoneInput: Locator;
  readonly confirmDetailsPhoneRoute = '#/welcome/confirm-details/phone';

  constructor(page: Page) {
    super(page);
    this.page = page;

    this.confirmPhoneNumbersSubmitButton = page.locator(
      'data-testid=confirm-phone-details-submit-button',
    );

    this.mobilePhoneInput = page.locator('data-testid=phone-details-mobile-input');
    this.homePhoneInput = page.locator('data-testid=phone-details-home-input');
  }
}
