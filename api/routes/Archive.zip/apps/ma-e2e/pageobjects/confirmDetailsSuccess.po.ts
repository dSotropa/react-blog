import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class ConfirmDetailsSuccessPage extends PageFunctions {
  readonly page: Page;

  readonly continueToMyAccountBtn: Locator;
  readonly confirmDetailsSuccessRoute = '#/welcome/confirm-details/success';

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.continueToMyAccountBtn = page.locator('data-testid=continue');
  }
}
