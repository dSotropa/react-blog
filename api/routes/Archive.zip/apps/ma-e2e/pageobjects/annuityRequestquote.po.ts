import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class RequestQuotePage extends PageFunctions {
  readonly page: Page;
  readonly byEmailRadioButton: Locator;
  readonly byPostRadioButton: Locator;
  readonly secureEmailMessage: Locator;
  readonly continueButton: Locator;
  readonly retirementAgeInput: Locator;
  readonly retirementDateInput: Locator;
  readonly submitButton: Locator;
  readonly productPageRetirementQuoteBtn: Locator;
  readonly productPageTransferQuoteBtn: Locator;
  readonly byAgeLink: Locator;
  readonly byDateLink: Locator;
  readonly requestATransferQuoteLink: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.byEmailRadioButton = page.locator('[for="radio-email"]');
    this.byPostRadioButton = page.locator('[for="radio-post"]');
    this.secureEmailMessage = page.locator('data-testid=secure-email-message');
    this.continueButton = page.locator('data-testid=request-quote-btn-continue');
    this.retirementAgeInput = page.locator('data-testid=retirement-age-input');
    this.retirementDateInput = page.locator('data-testid=retirement-date-input');
    this.submitButton = page.locator('data-testid=btn-submit');

    this.productPageRetirementQuoteBtn = page.locator(
      'data-testid=request-a-retirement-quote-btn',
    );

    this.productPageTransferQuoteBtn = page.locator(
      'data-testid=request-a-transfer-quote-btn',
    );

    this.byAgeLink = page.locator('text=By age');
    this.byDateLink = page.locator('text=By date');
    this.requestATransferQuoteLink = page.locator('text=request a transfer quote');
  }
}
