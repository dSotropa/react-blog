import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class PersonalDetailsPage extends PageFunctions {
  readonly page: Page;
  readonly leavePageDialogBtn: Locator;
  readonly maritalStatusDropdown: Locator;
  readonly maritalStatusUpdateSuccess: Locator;

  readonly maritalStatusDefaultValueText = 'Select marital status';

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.leavePageDialogBtn = page.locator('data-testid=leave-page-confirm');
    this.maritalStatusDropdown = page.locator('data-testid=marital-status-select');

    this.maritalStatusUpdateSuccess = page.locator(
      'data-testid=marital-status-success-alert',
    );
  }
}
