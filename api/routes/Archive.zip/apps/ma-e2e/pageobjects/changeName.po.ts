import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class ChangeNamePage extends PageFunctions {
  readonly page: Page;
  readonly cancelButton: Locator;
  readonly titleInput: Locator;

  readonly changeNameRoute = '#/account-details/personal-details/change-name';

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.cancelButton = page.locator('data-testid=change-name-cancel');
    this.titleInput = page.locator('[data-testid="change-name-title-input"] option');
  }
}
