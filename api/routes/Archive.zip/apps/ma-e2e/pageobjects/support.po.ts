import { Locator, Page } from '@playwright/test';
import { AssertionFunctions } from '@utility-e2e';

export class Support extends AssertionFunctions {
  public page: Page;
  readonly helpButton: Locator;
  readonly triageWidgetOpen: Locator;
  readonly triageItems: Locator;
  readonly closeButtonTriage: Locator;
  readonly boldWidget: Locator;
  readonly closeButtonBold: Locator;
  readonly closeButtonNanorep: Locator;
  readonly nanorepWidget: Locator;
  readonly changeHelp: Locator;
  readonly faqTitleNanorep: Locator;
  readonly faqTitleBold: Locator;

  readonly insuranceHelpLink =
    'https://www.legalandgeneral.com/insurance/existing-customers';

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.helpButton = page.locator('[id="support-button"]');
    this.triageWidgetOpen = page.locator('.triage-container');
    this.triageItems = page.locator('.triage-item');
    this.closeButtonTriage = page.locator('.triage-button-close');
    this.boldWidget = page.locator('.widget-floating__wrapper');
    this.closeButtonBold = page.locator('.close-icon');
    this.closeButtonNanorep = page.locator('.widget-side__close');
    this.nanorepWidget = page.locator('.widget-side__wrapper');
    this.changeHelp = page.locator('.change-section');
    this.faqTitleNanorep = page.locator('.widget-side__caption');
    this.faqTitleBold = page.locator('.widget-floating__title');
  }

  getKnowledgeBaseCardTriage(displayName: string) {
    return this.page.locator(`//strong[text()="${displayName}"]`);
  }
}
