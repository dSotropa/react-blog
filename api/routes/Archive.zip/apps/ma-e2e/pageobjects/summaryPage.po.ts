import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class SummaryPage extends PageFunctions {
  readonly page: Page;
  readonly navMenuRewards: Locator;
  readonly editDetailsButton: Locator;
  readonly navMenuMailbox: Locator;
  readonly updateBankDetails: Locator;
  readonly back: Locator;
  readonly productName: Locator;
  readonly policyNumber: Locator;
  readonly policyStartDate: Locator;
  readonly productLink: Locator;
  readonly productLinkDisabled: Locator;
  readonly productMessageLinks: Locator;
  readonly summaryPageHeader: Locator;
  readonly productId: Locator;
  readonly productData: Locator;
  readonly productValuation: Locator;
  readonly productQuickActionLinks: Locator;
  readonly productDataPointText: Locator;
  readonly productDataPointValueCurrency: Locator;
  readonly productDataPointValueDate: Locator;
  readonly productDataPointValueText: Locator;
  readonly myaHeadingCard: Locator;
  readonly navMenuHome: Locator;
  readonly productMessage: Locator;
  readonly navMenuSupport: Locator;
  readonly productLinks: Locator;
  readonly requestAquotationLink: Locator;
  readonly supportWidget: Locator;
  readonly closeSupport: Locator;
  readonly helpButton: Locator;
  readonly coverValue: Locator;
  readonly alldataPoints: Locator;
  readonly productInfoLabels: Locator;
  readonly productInfoValues: Locator;
  readonly changeCollectionDayLink: Locator;
  readonly changeDirectDebitLink: Locator;
  readonly productFormContent: Locator;
  readonly isaOverviewHeader: Locator;
  readonly pensionSummaryPage: Locator;
  readonly transactionsPage: Locator;
  readonly productValuationUnavailable: Locator;
  readonly informationNoteRibbon: Locator;
  readonly retirementPage: Locator;
  readonly productNames: Locator;
  readonly paymentsCardLink: Locator;
  readonly documentsCardLink: Locator;
  readonly productContainer: Locator;
  readonly pageContent: Locator;
  readonly yearsDataPoint: Locator;

  readonly SIPPHeaderText = 'Your total savings are £';
  readonly soldToFidelityMsg =
    'From 6 April 2022, some of the services we offer our customers will be limited.';

  readonly notificationDocumentLink =
    'https://preprod.mya.platform.landg.com/product/documents?productId=';
  readonly expectedProductMsgText =
    'We\'re sorry, but we\'re updating your account, which means your valuation isn\'t available right now.';
  readonly logoutSuccessText = 'You\'ve successfully logged out';

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.navMenuRewards = page.locator('[data-testid="rewards-nav-link"]');
    this.editDetailsButton = page.locator('[id="update-link-profile-summary"]');
    this.navMenuMailbox = page.locator('[data-testid="mailbox-nav-link"]');
    this.updateBankDetails = page.locator('text=Update bank details');
    this.back = page.locator('.lg-breadcrumb-item__container');
    this.productName = page.locator('[data-testid="product__name"]').first();
    this.policyNumber = page.locator('[data-testid="product__id"]').first();

    this.policyStartDate = page.locator('[data-testid="value-date"]').first();

    this.productLink = page
      .locator('.product-card__head .link, .product-card__head .primary-link__link')
      .first();

    this.productLinkDisabled = page
      .locator('.product-card__head .primary-link__link--disabled')
      .first();

    this.productMessageLinks = page.locator('.product-message a');

    this.summaryPageHeader = page.locator('.lg-hero-card-title__heading');
    this.productId = page.locator('[data-testid="product__id"]');
    this.productData = page.locator('[data-testid="principal-data-point__information"]');
    this.productValuation = page.locator('[data-testid="principal-data-point__value"]');
    this.productQuickActionLinks = page.locator('.lg-quick-action');

    this.productDataPointText = page.locator('[data-testid="data-point__text"]');

    this.productDataPointValueCurrency = page.locator(
      '.data-point__value .value--currency, .product-data-point-value .value--currency',
    );

    this.productDataPointValueDate = page.locator('.value--full-date').first();

    this.productDataPointValueText = page.locator(
      'ma-product-data-point:nth-child(3) ma-product-data-point-value',
    );

    this.myaHeadingCard = page.locator('.lg-hero-card-title__heading');
    this.navMenuHome = page.locator('[data-testid="home-nav-link"]');
    this.productMessage = page.locator('[data-testid="product-message"] p');
    this.navMenuSupport = page.locator('data-testid=support-nav-link');

    this.productLinks = page.locator(
      '.product-card__head .link, .product-card__head .primary-link__link',
    );

    this.requestAquotationLink = page.locator('text=Request a quotation');
    this.supportWidget = page.locator('[aria-label="support centre"]');
    this.closeSupport = page.locator('.triage-header button');
    this.helpButton = page.locator('id=support-button');
    this.coverValue = page.locator('[data-testid="principal-data-point__value"]').first();
    this.alldataPoints = page.locator('.data-point');
    this.productInfoLabels = page.locator('[data-testid="data-point__text"]');
    this.productInfoValues = page.locator('.data-point .value');

    this.changeCollectionDayLink = page.locator(
      '.lg-quick-action >> text=Change collection day',
    );

    this.changeDirectDebitLink = page.locator(
      '.lg-quick-action >> text=Change Direct Debit',
    );

    this.productFormContent = page.locator('.product-form-content');
    this.isaOverviewHeader = page.locator('text=ISA overview');
    this.pensionSummaryPage = page.locator('#tab-label-pension-summary');
    this.transactionsPage = page.locator('#tab-label-transactions');

    this.productValuationUnavailable = page.locator('.temporarily-unavailable');

    this.informationNoteRibbon = page.locator('.product-message');
    this.retirementPage = page.locator('#tab-label-retirement');
    this.productNames = page.locator('[data-testid="product__name"]');
    this.paymentsCardLink = page.locator('data-testid=Payments-card-link');
    this.documentsCardLink = page.locator('data-testid=Documents-card-link');
    this.productContainer = page.locator('[id="main-content"]');
    this.pageContent = page.locator('.page-content');
    this.yearsDataPoint = page.locator('ma-product-data-point-value');
  }

  filterLabels(labelText: string) {
    return this.productDataPointText.locator(`text=${labelText}`);
  }

  async navigateBackToMAPSP(page: Page) {
    await this.navMenuHome.click();
    await page.waitForURL('**/products');
  }
}
