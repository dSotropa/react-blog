import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class ConfirmContactDetailsPage extends PageFunctions {
  readonly page: Page;
  readonly emailInput: Locator;
  readonly route = '#/welcome/confirm-contact-details';

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.emailInput = page.locator('data-testid=confirm-contact-details-email');
  }
}
