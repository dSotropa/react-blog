import { FrameLocator, Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class ProductDetailsPage extends PageFunctions {
  readonly page: Page;
  readonly productDetailsPageContainer: Locator;
  readonly overviewTab: Locator;
  readonly overviewLabel: Locator;
  readonly documentsTab: Locator;
  readonly documentsTable: Locator;
  readonly documentsLabel: Locator;
  readonly documentsContainer: Locator;
  readonly paymentsTabLabel: Locator;
  readonly annuitiesProductDetailsContainer: Locator;
  readonly oldAnnuitiesProductDetailsContainer: Locator;
  readonly annuityDocumentsTab: Locator;
  readonly deathBenefitsTab: Locator;
  readonly fundsTab: Locator;
  readonly transactionsTab: Locator;
  readonly assetsTab: Locator;
  readonly requestsTab: Locator;
  readonly requestDocumentsButton: Locator;
  readonly supportArticles: Locator;
  readonly requestRetirementQuoteBtn: Locator;
  readonly requestTransferQuoteBtn: Locator;
  readonly collectionDayDropdown: Locator;
  readonly confirmButton: Locator;
  readonly confirmationText: Locator;
  readonly homeBreadcrumb: Locator;
  readonly bankAccountNumberInput: Locator;
  readonly sortCodeInput: Locator;
  readonly accountHolderNameInput: Locator;
  readonly overviewContainer: Locator;
  readonly changeContributionLink: Locator;
  readonly manageMyPensionLink: Locator;
  readonly viewTransactionsLink: Locator;
  readonly retirementOptionsLink: Locator;
  readonly paymentsTab: Locator;
  readonly productDescriptionMessage: Locator;
  readonly productInfoMessage: Locator;
  readonly productInfoMessageLink: Locator;
  readonly annuitySchemeName: Locator;
  readonly deathBenefitsLabel: Locator;
  readonly youtubeFrame: FrameLocator;
  readonly youtubeFrameLocator: FrameLocator;
  readonly landGFooterLogo: Locator;
  readonly taxTab: Locator;
  readonly firstAnnuitiesDocument: Locator;
  readonly firstLgiDocument: Locator;
  readonly myApplicationTab: Locator;
  readonly documentDeliveryPreference: Locator;
  readonly communicationPreferenceOnline: Locator;
  readonly paymentHistoryLoadMore: Locator;

  readonly confirmationTransferabilityText =
    'You have the ability to cash-in or transfer your policy.';
  readonly denyTransferabilityText =
    'You don\'t have the ability to cash-in or transfer your policy.';
  readonly noDocumentsMessageText =
    'If you would like to request any documents not shown here please contact us.';
  readonly confirmationTransferabilityTextFTRP =
    'You have the ability to cash-in or transfer your plan.';
  readonly denyTransferabilityTextFTRP =
    'You don\'t have the ability to cash-in, transfer or make withdrawals from your plan';
  readonly schemeName = 'Whessoe PLC';
  readonly ctaButtonLinks = [
    'https://www.legalandgeneral.com/retirement/care/?WebCrosspromoMyAccount003',
    'https://www.legalandgeneral.com/retirement/pension-consolidation/?WebCrosspromoMyAccount002',
    'https://www.legalandgeneral.com/retirement/options-for-using-your-pension-pot/?WebCrosspromoMyAccount001',
  ];

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.productDetailsPageContainer = page.locator('.product-container').first();
    this.overviewTab = page.locator('data-testid=tab-Overview');
    this.overviewLabel = page.locator('[id="tab-overview-label"]');
    this.documentsTab = page.locator('data-testid=tab-Documents');
    this.documentsTable = page.locator('.documents-table');
    this.documentsLabel = page.locator('[id="tab-documents-label"]');
    this.documentsContainer = page.locator('.documents');
    this.paymentsTabLabel = page.locator('id=tab-payment-label');
    this.annuitiesProductDetailsContainer = page.locator('ma-product-details-container');
    this.oldAnnuitiesProductDetailsContainer = page.locator('.product-summary-container');
    this.annuityDocumentsTab = page.locator('data-testid=tab-Documents');
    this.deathBenefitsTab = page.locator('data-testid=tab-DeathBenefits');
    this.fundsTab = page.locator('id=tab-funds-label');
    this.transactionsTab = page.locator('id=tab-transactions-label');
    this.assetsTab = page.locator('id=tab-assets-label');
    this.requestsTab = page.locator('id=tab-requests-label');
    this.requestDocumentsButton = page.locator('data-testid=request-documents');
    this.supportArticles = page.locator('data-testid=support-article-button');
    this.paymentsTab = page.locator('data-testid=tab-Payment');
    this.deathBenefitsLabel = page.locator('id=tab-death-label');

    this.requestRetirementQuoteBtn = page.locator(
      'data-testid=request-a-retirement-quote-btn',
    );

    this.requestTransferQuoteBtn = page.locator(
      'data-testid=request-a-transfer-quote-btn',
    );

    this.productInfoMessage = page.locator('data-testid=product-message');
    this.productInfoMessageLink = page.locator('data-testid=product-message-link');

    this.collectionDayDropdown = page.locator('id=collection-day');
    this.confirmButton = page.locator('id=confirm');
    this.confirmationText = page.locator('.confirmation-text');
    this.homeBreadcrumb = page.locator('.breadcrumb-item-link');
    this.bankAccountNumberInput = page.locator('id=bankAccountNumber');
    this.sortCodeInput = page.locator('id=sortCode');
    this.accountHolderNameInput = page.locator('id=accountHolderName');
    this.overviewContainer = page.locator('.product-overview-container');

    this.changeContributionLink = page.locator(
      '.lg-quick-action >> text=Change Contribution',
    );

    this.manageMyPensionLink = page.locator('.lg-quick-action >> text=Manage my pension');

    this.viewTransactionsLink = page.locator(
      '.lg-quick-action >> text=View Transactions',
    );

    this.retirementOptionsLink = page.locator(
      '.lg-quick-action >> text=Retirement Options',
    );

    this.productDescriptionMessage = page.locator(
      'data-testid=product-description-message',
    );

    this.annuitySchemeName = page.locator('data-testid=scheme-name-and-title');
    this.youtubeFrame = page.frameLocator('.ytp-cued-thumbnail-overlay-image');
    this.youtubeFrameLocator = page.frameLocator('iframe').first();
    this.landGFooterLogo = page.locator('.lg-footer-logo');
    this.taxTab = page.locator('id=tab-tax-label');
    this.firstAnnuitiesDocument = page.locator('.document-list__li').first();
    this.firstLgiDocument = page.locator('.document-list__li').first();
    this.myApplicationTab = page.locator('data-testid=tab-Overview');
    this.documentDeliveryPreference = page.locator('data-testid=document-preference');

    this.communicationPreferenceOnline = page.locator(
      'data-testid=communication-preference--online-button',
    );

    this.paymentHistoryLoadMore = page.locator('.ma-payment-history__load-more-button');
  }

  async isTabActive(tabToCheck: Locator): Promise<boolean> {
    try {
      const tabClass = await tabToCheck.getAttribute('class');

      return tabClass.includes('lg-tab-nav-bar-link--selected');
    } catch (error) {
      return false;
    }
  }

  async clickPaymentsTab(): Promise<void> {
    if (await this.isElementVisible(this.paymentsTab)) {
      await this.paymentsTab.click();
    } else {
      await this.paymentsTabLabel.click();
    }
  }

  async clickDocumentsTab(): Promise<void> {
    if (await this.isElementVisible(this.documentsTab)) {
      await this.documentsTab.click();
    } else {
      await this.documentsLabel.click();
    }
  }

  async clickDeathBenefits(): Promise<void> {
    if (await this.isElementVisible(this.deathBenefitsTab)) {
      await this.deathBenefitsTab.click();
    } else {
      await this.deathBenefitsLabel.click();
    }
  }

  youtubePlayerLocator() {
    return this.youtubeFrameLocator.locator('id=player');
  }

  youtubeMainPlayBtnLocator() {
    return this.youtubeFrameLocator.locator('.ytp-large-play-button.ytp-button');
  }

  youtubePlayBtnLocator() {
    return this.youtubeFrameLocator.locator('[data-title-no-tooltip="Play"]');
  }

  youtubePauseBtnLocator() {
    return this.youtubeFrameLocator.locator('[title="Pause (k)"]');
  }

  mainYoutubeFrame() {
    return this.youtubeFrameLocator.locator(
      '[id="movie_player"] div.ytp-cued-thumbnail-overlay-image',
    );
  }
}
