import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class ContactDetailsPage extends PageFunctions {
  readonly page: Page;
  readonly contactDetails: Locator;
  readonly phoneDetailsMobileInput: Locator;
  readonly phoneDetailsMobileSuccess: Locator;
  readonly phoneDetailsHomeInput: Locator;
  readonly phoneDetailsSaveButton: Locator;
  readonly phoneDetailsHomeSuccess: Locator;
  readonly phoneDetailsWorkInput: Locator;
  readonly phoneDetailsWorkSuccess: Locator;
  readonly emailDetailsPersonalInput: Locator;
  readonly emailDetailsSaveButton: Locator;
  readonly emailDetailsPersonalSuccess: Locator;
  readonly personalEmail: Locator;
  readonly emailDetailsWorkReadOnlyAlert: Locator;
  readonly emailDetailsWorkInput: Locator;
  readonly emailDetailsWorkSuccess: Locator;
  readonly changeAddressReadOnlyAlert: Locator;
  readonly changeAddressButton: Locator;
  readonly leavePageDialogBtn: Locator;
  readonly postcodeDataPointValue: Locator;

  readonly contactDetailsRoute = '#/account-details/contact-details';
  readonly summaryPageRoute = '#/products';

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.contactDetails = page.locator('[id="contact-details"]');

    this.phoneDetailsMobileInput = page.locator(
      '[data-testid="phone-details-mobile-input"]',
    );

    this.phoneDetailsSaveButton = page.locator(
      '[data-testid="phone-details-save-button"]',
    );

    this.phoneDetailsMobileSuccess = page.locator(
      '[data-testid="phone-details-mobile-success"]',
    );

    this.phoneDetailsHomeInput = page.locator('[data-testid="phone-details-home-input"]');

    this.phoneDetailsHomeSuccess = page.locator(
      '[data-testid="phone-details-home-success"]',
    );

    this.phoneDetailsWorkInput = page.locator('[data-testid="phone-details-work-input"]');

    this.phoneDetailsWorkSuccess = page.locator(
      '[data-testid="phone-details-work-success"]',
    );

    this.emailDetailsPersonalInput = page.locator(
      '[data-testid="email-details-personal-input"]',
    );

    this.emailDetailsSaveButton = page.locator('data-testid=email-details-save-button');

    this.phoneDetailsMobileSuccess = page.locator(
      '[data-testid="email-details-save-button"]',
    );

    this.emailDetailsPersonalSuccess = page.locator(
      '[data-testid="email-details-personal-success"]',
    );

    this.personalEmail = page.locator('[id="personal-email"]');

    this.emailDetailsWorkReadOnlyAlert = page.locator(
      '[data-testid="email-details-work-read-only"]',
    );

    this.emailDetailsWorkInput = page.locator('[data-testid="email-details-work-input"]');

    this.changeAddressReadOnlyAlert = page.locator(
      '[data-testid="change-address-read-only-alert"]',
    );

    this.changeAddressButton = page.locator('[data-testid="change-address-button"]');
    this.leavePageDialogBtn = page.locator('[data-testid="leave-page-confirm"]');

    this.postcodeDataPointValue = page.locator(
      '[data-testid="postcode-data-point-value"]',
    );

    this.emailDetailsWorkSuccess = page.locator('data-testid=email-details-work-success');
  }

  async navigateToChangeAddressRoute(): Promise<void> {
    await this.page.goto(this.contactDetailsRoute);
  }

  async navigateToSummaryPage(): Promise<void> {
    await this.page.goto(this.summaryPageRoute);
  }
}
