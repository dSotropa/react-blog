import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class AccountDetailsOverviewPage extends PageFunctions {
  readonly page: Page;
  readonly overviewDetails: Locator;

  readonly accountDetailsOverviewRoute = '#/account-details/overview';

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.overviewDetails = page.locator('.account-details-overview');
  }
}
