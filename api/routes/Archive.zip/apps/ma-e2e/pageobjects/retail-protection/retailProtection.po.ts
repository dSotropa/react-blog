import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class RetailProtectionPage extends PageFunctions {
  readonly page: Page;
  readonly paymentDetailsLink: Locator;
  readonly documentsPageLink: Locator;
  readonly navMenuRewards: Locator;
  readonly documentsLink: Locator;
  readonly changeCollectionDayLink: Locator;
  readonly formCancel: Locator;
  readonly collectionDayDropdown: Locator;
  readonly confirmFormChangeButton: Locator;
  readonly changeDirectDebitLink: Locator;
  readonly overviewLink: Locator;
  readonly homeBreadcrumb: Locator;
  readonly bankAccountNumberInput: Locator;
  readonly sortCodeInput: Locator;
  readonly accountHolderNameInput: Locator;
  readonly navHomeLink: Locator;
  readonly backToMyAccount: Locator;
  readonly manageMyCoverButton: Locator;
  readonly manageMyCoverMenu: Locator;
  readonly mYCMenuChangeDirectDebit: Locator;
  readonly mYCMenuChangeCollectionDay: Locator;
  readonly mYCMenuCancelPolicy: Locator;
  readonly mYCMenuStartAClaim: Locator;
  readonly retentionContinueBtn: Locator;
  readonly backButton: Locator;
  readonly advisedYesBtn: Locator;
  readonly advisedNoBtn: Locator;
  readonly cancelPolicyAdvisedBtn: Locator;
  readonly cancelPolicyContinueBtn: Locator;
  readonly cancelPolicyNotAdvisedBtn: Locator;
  readonly policyDetailsLink: Locator;
  readonly moreInformationBtn: Locator;
  readonly claimsExitBtn: Locator;
  readonly trustedIndividualsYesBtn: Locator;
  readonly trustedIndividualsNoBtn: Locator;
  readonly addPersonBtn: Locator;
  readonly removePersonBtn: Locator;
  readonly nrOfTrustedIndividuals: Locator;
  readonly nrOfConsultants: Locator;
  readonly claimJourneyContinueBtn: Locator;
  readonly claimsModal: Locator;
  readonly claimsModalOpen: Locator;
  readonly claimsModalClose: Locator;
  readonly otherPoliciesYesBtn: Locator;
  readonly otherPiliciesNoBtn: Locator;
  readonly addOtherPolicyBtn: Locator;
  readonly nrOfOtherPolicies: Locator;
  readonly removeOtherPolicyBtn: Locator;
  readonly editDetailsBtn: Locator;
  readonly submitMyClaimBtn: Locator;
  readonly claimsTypeDropdown: Locator;
  readonly claimsTypeBoldArticles: Locator;
  readonly statutoryRightsLink: Locator;

  readonly checkYourContactDetailsUrl =
    '#/form/claims/trusted-individuals/755dd754d09163dd2221f4f8f20fe005cf37af1b2c0334fbd37ec4eca7d667e3';
  readonly customerDeclarationUrl =
    '#/form/claims/declaration/755dd754d09163dd2221f4f8f20fe005cf37af1b2c0334fbd37ec4eca7d667e3';
  readonly doctorsDetailsUrl =
    '#/form/claims/doctors-details/755dd754d09163dd2221f4f8f20fe005cf37af1b2c0334fbd37ec4eca7d667e3';
  readonly otherPoliciesUrl =
    '#/form/claims/other-policies/755dd754d09163dd2221f4f8f20fe005cf37af1b2c0334fbd37ec4eca7d667e3';
  readonly childrenCriticalIllnessUrl =
    '#/form/claims/children-cic/755dd754d09163dd2221f4f8f20fe005cf37af1b2c0334fbd37ec4eca7d667e3';
  readonly jointMedicalRecordsUrl =
    '#/form/claims/joint-medical-records/755dd754d09163dd2221f4f8f20fe005cf37af1b2c0334fbd37ec4eca7d667e3';
  readonly claimTypeUrl =
    '#/form/claims/claim-type/755dd754d09163dd2221f4f8f20fe005cf37af1b2c0334fbd37ec4eca7d667e3';

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.paymentDetailsLink = page.locator('data-testid=Payments-card-link');
    this.documentsPageLink = page.locator('data-testid=Documents-card-link');
    this.navMenuRewards = page.locator('data-testid=rewards-nav-link');
    this.documentsLink = page.locator('id=document-card-link-0');
    this.changeCollectionDayLink = page.locator('id=quick-action-0');
    this.formCancel = page.locator('id=cancel');
    this.collectionDayDropdown = page.locator('[formcontrolname="day"]');
    this.confirmFormChangeButton = page.locator('id=confirm');
    this.changeDirectDebitLink = page.locator('id=quick-action-1');
    this.overviewLink = page.locator('data-testid=overview-link').first();
    this.homeBreadcrumb = page.locator('.breadcrumb-item-link');
    this.bankAccountNumberInput = page.locator('data-testid=bankAccountNumber');
    this.sortCodeInput = page.locator('data-testid=sortCode');
    this.accountHolderNameInput = page.locator('data-testid=accountHolderName');
    this.navHomeLink = page.locator('data-testid=home-nav-link');
    this.backToMyAccount = page.locator('data-testid=account-back-button');
    this.manageMyCoverButton = page.locator('[data-testid="manage-my-cover"]');
    this.manageMyCoverMenu = page.locator('[data-testid="manage-my-cover-menu"]');

    this.mYCMenuChangeDirectDebit = this.manageMyCoverMenu.locator(
      'a:has-text("Change Direct Debit")',
    );

    this.mYCMenuChangeCollectionDay = this.manageMyCoverMenu.locator(
      'a:has-text("Change collection day")',
    );

    this.mYCMenuCancelPolicy = this.manageMyCoverMenu.locator(
      'a:has-text("Cancel my policy")',
    );

    this.mYCMenuStartAClaim = this.manageMyCoverMenu.locator(
      'a:has-text("Start a claim")',
    );

    this.retentionContinueBtn = page.locator('[data-testid="retention-btn-continue"]');
    this.backButton = page.locator('.lg-breadcrumb-item__content a');
    this.advisedYesBtn = page.locator('.form-group label').nth(0);
    this.advisedNoBtn = page.locator('.form-group label').nth(1);
    this.cancelPolicyAdvisedBtn = page.locator('[id="retention-btn-cancel"]');
    this.cancelPolicyContinueBtn = page.locator('[id="retention-btn-continue"]');
    this.cancelPolicyNotAdvisedBtn = page.locator('[data-testid="retention-btn-submit"]');
    this.policyDetailsLink = page.locator('data-testid=Policy-details-card-link');
    this.moreInformationBtn = page.locator('.lg-quick-action__icon').first();

    this.claimsExitBtn =
      page.locator('data-testid=claim-btn-exit') || page.locator('data-testid=exit-btn');

    this.trustedIndividualsYesBtn = page.locator(
      '[data-testid="trusted-individuals-radio"] >> text=Yes',
    );

    this.trustedIndividualsNoBtn = page.locator(
      '[data-testid="trusted-individuals-radio"] >> text=No',
    );

    this.addPersonBtn = page.locator('[data-testid="add-button"]');
    this.removePersonBtn = page.locator('[data-testid="remove-button"]');

    this.nrOfTrustedIndividuals = page.locator(
      '[data-testid="trusted-individual-headings"]',
    );

    this.nrOfConsultants = page.locator('[data-testid="additional-doctors-headings"]');

    this.claimJourneyContinueBtn = page.locator('[data-testid="continue-btn"]');
    this.claimsModal = page.locator('[id="lg-modal-header-claims-modal"]');
    this.claimsModalOpen = page.locator('[id="claims-modal-open"]');
    this.claimsModalClose = page.locator('[data-testid="claims-modal-close"]');
    this.otherPoliciesYesBtn = page.locator('[data-testid="other-policies"] >> text=Yes');
    this.otherPiliciesNoBtn = page.locator('[data-testid="other-policies"] >> text=No');
    this.addOtherPolicyBtn = page.locator('[data-testid="add-button"]');
    this.nrOfOtherPolicies = page.locator('[data-testid="policy-details-headings"]');
    this.removeOtherPolicyBtn = page.locator('[data-testid="remove-button"]');
    this.editDetailsBtn = page.locator('[data-testid="edit-link"]');
    this.submitMyClaimBtn = page.locator('[data-testid="claim-btn-submit"]');
    this.claimsTypeDropdown = page.locator('.lg-details-panel-heading__toggle');
    this.claimsTypeBoldArticles = page.locator('[data-testid="support-article-button"]');

    this.statutoryRightsLink = page.locator(
      '[href="https://www.legalandgeneral.com/insurance/your-statutory-rights/"]',
    );
  }

  getCancelReason(reason: string) {
    return this.page.locator(`.form-group >> text=${reason}`);
  }

  getFurtherInfo(furtherInfo: string) {
    return this.page.locator(`.form-group >> text=${furtherInfo}`);
  }

  async startCancelMyPolicyJourney() {
    await this.manageMyCoverButton.click();
    await this.mYCMenuCancelPolicy.click();
  }

  async startClaimsJourney() {
    await this.manageMyCoverButton.click();
    await this.mYCMenuStartAClaim.click();
  }
}
