import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class ReviewAddressPage extends PageFunctions {
  readonly page: Page;
  readonly currentAddress: Locator;
  readonly confirmAddressBtn: Locator;
  readonly changeAddressBtn: Locator;

  route = '#/welcome/review-address';
  summaryPageRoute = 'products';
  changeAddressSearchPage = 'account-details/contact-details/change-address';

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.currentAddress = page.locator('[data-testid="review-address-current-address"]');
    this.confirmAddressBtn = page.locator('[data-testid="review-address-confirm"]');
    this.changeAddressBtn = page.locator('[data-testid="review-address-change"]');
  }
}
