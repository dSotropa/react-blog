export const veryShortWait = 3_000;
export const shortWait = 10_000;
export const mediumWait = 30_000;
export const longWait = 45_000;
export const veryLongWait = 60_000;
