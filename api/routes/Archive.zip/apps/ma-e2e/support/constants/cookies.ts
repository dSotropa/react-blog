export const maCookie = {
  name: 'maEntry',
  value: 'e2eTest-710f0e04-d482-d9cd-5b7e-e2d961bbdd01',
  domain: '.landg.com',
  path: '/',
};
export const sealCookie = {
  name: 'sealEntry',
  value: 'e2eTest-f5b68f0a-25f4-9300-7821-49e7801f1db1',
  domain: '.landg.com',
  path: '/',
};
export const apiCookie = {
  name: 'apiEntry',
  value: 'e2eTest-f5b68f0a-25f4-9300-7821-49e7801f1db1',
  domain: '.landg.com',
  path: '/',
};
