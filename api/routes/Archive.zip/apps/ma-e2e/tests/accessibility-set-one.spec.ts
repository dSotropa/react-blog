import test from '@playwright/test';
import { AccessibilityFunctions } from '@utility-e2e';

import { BasePage } from '../models/basepage';
import { LoginPage } from '../models/loginpage';
import { MailboxPage } from '../pageobjects/mailbox.po';
import { SummaryPage } from '../pageobjects/summaryPage.po';
import { Support } from '../pageobjects/support.po';

test.describe.parallel('Accessibility tests', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let summaryPage: SummaryPage;
  let support: Support;
  let mailboxPage: MailboxPage;

  test.beforeEach(({ page, context }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    summaryPage = new SummaryPage(page);
    support = new Support(page);
    mailboxPage = new MailboxPage(page);
  });

  test('Check My Account portfolio summary page has no accessibility issues @Accessibility @NotYetMocked', async ({
    page,
    browserName,
  }) => {
    test.skip(browserName !== 'chromium', 'Skipping as only need to run on Chrome');
    await loginPage.login('3elsglr6m4', 'Pass1pass');
    await new AccessibilityFunctions(page).injectAxe();
  });

  test('Check My Account portfolio summary page for annuities has no accessibility issues @Accessibility @NotYetMocked', async ({
    page,
    browserName,
  }) => {
    test.skip(browserName !== 'chromium', 'Skipping as only need to run on Chrome');
    await loginPage.login('BBTQYZWY0', 'Test1test');
    await new AccessibilityFunctions(page).injectAxe();
  });

  test('Check Rewards page has no accessibility issues @Accessibility @NotYetMocked', async ({
    page,
    browserName,
  }) => {
    test.skip(browserName !== 'chromium', 'Skipping as only need to run on Chrome');
    await loginPage.login('72r3uk5c2k', 'Test2test');
    await summaryPage.navMenuRewards.click();
    await new AccessibilityFunctions(page).injectAxe();
  });

  test('Check Update my details page has no accessibility issues @Accessibility @NotYetMocked', async ({
    page,
    browserName,
  }) => {
    test.skip(browserName !== 'chromium', 'Skipping as only need to run on Chrome');
    await loginPage.login('72r3uk5c2k', 'Test2test');
    await summaryPage.editDetailsButton.click();
    await new AccessibilityFunctions(page).injectAxe();
  });

  test('Check support widget has no accessibility issues @Accessibility @NotYetMocked', async ({
    page,
    browserName,
  }) => {
    test.skip(browserName !== 'chromium', 'Skipping as only need to run on Chrome');
    await loginPage.login('2366456031', 'Test2test');
    await support.assertElementVisible(support.helpButton);
    await support.helpButton.click();
    await new AccessibilityFunctions(page).injectAxe();
  });

  test('Check mailbox has no accessibility issues @Accessibility @NotYetMocked', async ({
    page,
    browserName,
  }) => {
    test.skip(browserName !== 'chromium', 'Skipping as only need to run on Chrome');
    await loginPage.login('2366456031', 'Test2test');
    await summaryPage.navMenuMailbox.click();
    await page.waitForSelector('[data-testid="compose-message"]');
    await new AccessibilityFunctions(page).injectAxe();
  });

  test('Check mailbox - send message has no accessibility issues @Accessibility @NotYetMocked', async ({
    page,
    browserName,
  }) => {
    test.skip(browserName !== 'chromium', 'Skipping as only need to run on Chrome');
    await loginPage.login('2366456031', 'Test2test');
    await summaryPage.navMenuMailbox.click();
    await mailboxPage.composeMessageBtn.click();

    await mailboxPage.selectFromDropdown(
      mailboxPage.chooseProductDropDown,
      'Anything else',
    );

    await mailboxPage.selectFromDropdown(
      mailboxPage.chooseSubjectDropDown,
      'Anything else',
    );

    await new AccessibilityFunctions(page).injectAxe();
  });

  test('Check bank change page has no accessibility issues @Accessibility @NotYetMocked', async ({
    page,
    browserName,
  }) => {
    test.skip(browserName !== 'chromium', 'Skipping as only need to run on Chrome');
    await loginPage.login('BBGPRYBY0', 'Test1test');
    await summaryPage.updateBankDetails.click();
    await new AccessibilityFunctions(page).injectAxe();
    await summaryPage.back.click();
  });
});
