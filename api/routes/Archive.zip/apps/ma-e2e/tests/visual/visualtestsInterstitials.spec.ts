import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ConfirmContactDetailsPage } from '../../pageobjects/confirmContactDetails.po';
import { ConfirmDetailsEmailPage } from '../../pageobjects/confirmDetailsEmail.po';
import { ReviewAddressPage } from '../../pageobjects/reviewAddress.po';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe.parallel('Visual regression tests for Interstitial pages', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let summaryPage: SummaryPage;
  let reviewAddressPage: ReviewAddressPage;
  let confirmContactDetailsPage: ConfirmContactDetailsPage;
  let confirmDetailsEmailPage: ConfirmDetailsEmailPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    summaryPage = new SummaryPage(page);
    reviewAddressPage = new ReviewAddressPage(page);
    confirmContactDetailsPage = new ConfirmContactDetailsPage(page);
    confirmDetailsEmailPage = new ConfirmDetailsEmailPage(page);
  });

  test('Compare the My Account Review Address Interstitial to its baseline @VisualCheck', async ({
    page,
  }) => {
    const pageName = 'Review Address';

    await loginPage.login('bvmuemcqn4', 'Pass1pass', true, reviewAddressPage.route);

    await reviewAddressPage.assertElementVisible(reviewAddressPage.currentAddress);
    await visualFunctions.eyesCheck(pageName, page);
  });

  test('Compare the My Account Confirm Contact Details Interstitial to its baseline @VisualCheck', async ({
    page,
  }) => {
    const pageName = 'Confirm Contact Details';

    await loginPage.login(
      'BBQ7BQMY0',
      'Test1test',
      true,
      confirmContactDetailsPage.route,
    );

    await confirmContactDetailsPage.assertElementVisible(
      confirmContactDetailsPage.emailInput,
    );

    await visualFunctions.eyesCheck(pageName, page);
  });

  test('Compare the My Account Confirm Details (LGI CYD) Interstitial to its baseline @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('BBWK4GHY0', 'Test2test');
    const pageName = 'Confirm Your Details';

    if ((await page.locator('data-testid=lgi-action-title').count()) === 0) {
      await loginPage.login('BBWK4GHY0', 'Test2test');
    }

    await visualFunctions.eyesCheck(pageName, page);
  });

  test('Compare the My Account Data Cleanse Interstitial to its baseline @VisualCheck', async ({
    page,
  }) => {
    const pageName = 'Confirm Details';

    await loginPage.login(
      'myat10one',
      'Test1test',
      true,
      confirmDetailsEmailPage.confirmDetailsRoute,
    );

    await visualFunctions.eyesCheck(pageName, page);
  });

  afterAllHook(test);
});
