import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ProductDetailsPage } from '../../pageobjects/productDetails.po';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe.parallel('Visual regression tests for Annuities death benefits', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let summaryPage: SummaryPage;
  let productDetailsPage: ProductDetailsPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    summaryPage = new SummaryPage(page);
    productDetailsPage = new ProductDetailsPage(page);
  });

  test('Compare the death benefits details for death benefits user to its baseline @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('BBSS5S4Y0', 'Test1test');
    const pageName = 'death benefits page';

    await summaryPage.productLink.click();
    await productDetailsPage.deathBenefitsTab.click();
    await visualFunctions.eyesCheck(pageName, page);
  });

  afterAllHook(test);
});
