import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ProductDetailsPage } from '../../pageobjects/productDetails.po';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe.parallel('Visual regression tests for LGI', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let summaryPage: SummaryPage;
  let productDetailsPage: ProductDetailsPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    summaryPage = new SummaryPage(page);
    productDetailsPage = new ProductDetailsPage(page);
  });

  async function assertProductAndNavigateToProductPage() {
    // assert product name, policy number and policy start date are visible
    await summaryPage.assertElementVisible(summaryPage.productName);
    await summaryPage.assertElementVisible(summaryPage.policyNumber);

    // click on product link and land on product details page
    await summaryPage.productLink.click();

    await productDetailsPage.assertElementVisible(
      productDetailsPage.productDetailsPageContainer,
    );
  }

  test('Verify product cards on MyAccount PSP- CIC @VisualCheck', async ({ page }) => {
    await loginPage.login('dhvd879t9e', 'Test2test');
    const pageName1 = 'My Account PSP - My Account Home Page';
    const pageName2 = 'My Account PSP - Product Details Page CIC new template';
    const pageName3 = 'My Account PSP - Documents Page';

    await summaryPage.assertElementVisible(summaryPage.productName);
    await visualFunctions.eyesCheck(pageName1, page);

    await summaryPage.productLink.click();
    await summaryPage.assertUrlContains('product-details');
    await visualFunctions.eyesCheck(pageName2, page);

    // click on documents tab and check if a message is displayed when no documents
    await summaryPage.documentsCardLink.click();
    await summaryPage.assertUrlContains('Documents');
    await visualFunctions.eyesCheck(pageName3, page);
  });

  afterAllHook(test);
});
