import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe.parallel('Visual regression tests - Decumulation', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let summaryPage: SummaryPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    summaryPage = new SummaryPage(page);
  });

  test('Compare the My Account New Product Summary page to its baseline - WP partial drawdown – valuation class WP03 @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('d69c2gn24e', 'Test2test');
    const pageName = 'My Account New Product Summary page - WP partial drawdown';

    await summaryPage.assertElementVisible(summaryPage.productName);
    await visualFunctions.eyesCheck(pageName, page);
  });

  afterAllHook(test);
});
