import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { RequestQuotePage } from '../../pageobjects/annuityRequestquote.po';
import { ProductDetailsPage } from '../../pageobjects/productDetails.po';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe
  .parallel('Visual regression tests for Annuity Deferred (DA) PRT Request a Quote', () => {
    let basePage: BasePage;
    let loginPage: LoginPage;
    let summaryPage: SummaryPage;
    let productDetailsPage: ProductDetailsPage;
    let requestQuotePage: RequestQuotePage;
    let visualFunctions: VisualFunctions;

    test.beforeAll(() => {
      visualFunctions = VisualFunctions.getInstance();
    });

    test.beforeEach(async ({ page }) => {
      basePage = new BasePage(page);
      loginPage = basePage.loginPage;
      summaryPage = new SummaryPage(page);
      productDetailsPage = new ProductDetailsPage(page);
      requestQuotePage = new RequestQuotePage(page);
      await loginPage.login('MS00001061', '1Test2test');
    });

    test('Compare Annuity Deferred Retirement Quote (by age) @VisualCheck', async ({
      page,
    }) => {
      const pageName1 = 'MA Annuity Request Retirement Quote Start page';
      const pageName2 = 'MA Annuity Request Retirement Quote Selection page';
      const pageName3 = 'MA Annuity Request Retirement Quote By Age Form page';
      const pageName4 = 'MA Annuity Request Retirement Quote Success page';
      const pageName5 = 'MA Annuity Request Retirement Quote Fail page';

      await summaryPage.requestAquotationLink.click();
      await requestQuotePage.byEmailRadioButton.click();
      await visualFunctions.eyesCheck(pageName1, page);

      await requestQuotePage.continueButton.click();
      await visualFunctions.eyesCheck(pageName2, page);

      await requestQuotePage.byAgeLink.click();
      await visualFunctions.eyesCheck(pageName3, page);

      // enter an age and click request quote
      await requestQuotePage.retirementAgeInput.type('62');
      await requestQuotePage.submitButton.click();
      await visualFunctions.eyesCheck(pageName4, page);

      // navigate to the request quote error page
      await requestQuotePage.navigateTo(
        '#/form/request-quote/retirement/selection/by-age/fail/abc',
      );

      await visualFunctions.eyesCheck(pageName5, page);
    });

    test('Compare Annuity Deferred Retirement Quote (by date) @VisualCheck', async ({
      page,
    }) => {
      const pageName = 'MA Annuity Request Retirement Quote By Date Form page';

      await summaryPage.requestAquotationLink.click();
      await requestQuotePage.byPostRadioButton.click();
      await requestQuotePage.continueButton.click();
      await requestQuotePage.byDateLink.click();
      await visualFunctions.eyesCheck(pageName, page);
    });

    test('Compare Annuity Deferred Transfer Quote @VisualCheck', async ({ page }) => {
      const pageName1 = 'MA Annuity Request Transfer Quote start page';
      const pageName2 = 'MA Annuity Request Transfer Quote success page';

      await summaryPage.productLink.click();
      await productDetailsPage.requestTransferQuoteBtn.click();
      await visualFunctions.eyesCheck(pageName1, page);

      await requestQuotePage.byEmailRadioButton.click();
      await requestQuotePage.submitButton.click();
      await visualFunctions.eyesCheck(pageName2, page);
    });

    afterAllHook(test);
  });
