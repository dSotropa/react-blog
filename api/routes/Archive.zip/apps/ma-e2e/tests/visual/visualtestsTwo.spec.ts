import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe.parallel('Visual regression tests set two', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let summaryPage: SummaryPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    summaryPage = new SummaryPage(page);
    await loginPage.login('CTMPORTAL_11', 'Test2test');
  });

  test('Compare the My Account New Product nav menu pages @VisualCheck', async ({
    page,
  }) => {
    const pageName1 = 'My Account Rewards page - no rewards';
    const pageName2 = 'My Account Support page';

    await summaryPage.navMenuRewards.click();
    await visualFunctions.eyesCheck(pageName1, page);

    await summaryPage.navMenuSupport.click();
    await visualFunctions.eyesCheck(pageName2, page);
  });

  test('Compare the My Account Product Details page to its baseline - Template 16 : Decreasing Life Insurance @VisualCheck', async ({
    page,
  }) => {
    const pageName =
      'My Account Product Details page - Template 16 : Decreasing Life Insurance';

    await summaryPage.productLink.click();
    await visualFunctions.eyesCheck(pageName, page);
  });

  afterAllHook(test);
});
