import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';

test.describe.parallel('Visual regression tests for PSP Action card', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
  });

  test('Compare the Psp action for Continue your application to baselines @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('AN14727772', 'Test2test');
    const pageName1 =
      'My Account Psp page with Psp action card - continue your application';

    await visualFunctions.eyesCheck(pageName1, page);
  });

  test('Compare the Psp action for Contfirm your application to baselines @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('n35hk8k8bb', 'Test2test');
    const pageName1 =
      'My Account Psp page with Psp action card - confirm your application';

    await visualFunctions.eyesCheck(pageName1, page);
  });

  test('Compare the Psp action for View your offer to baselines @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('AN14733519', 'Test2test');
    const pageName1 = 'My Account Psp page with Psp action card - view your offer';

    await visualFunctions.eyesCheck(pageName1, page);
  });

  test('Compare the Psp action for Complete your application to baselines @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('AN14733368', 'Test2test');
    const pageName1 =
      'My Account Psp page with Psp action card - complete your application';

    await visualFunctions.eyesCheck(pageName1, page);
  });

  afterAllHook(test);
});
