import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe.parallel('Visual regression tests set one', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let summaryPage: SummaryPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    summaryPage = new SummaryPage(page);
  });

  test('Compare the My Account New Product Summary page to its baseline - Template 16 : Decreasing Life Insurance @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('CTMPORTAL_11', 'Test2test');
    const pageName1 =
      'My Account New Product Summary page - Template 16 : Decreasing Life Insurance';

    await summaryPage.assertElementVisible(summaryPage.productName);
    await visualFunctions.eyesCheck(pageName1, page);
  });

  test('Compare the My Account New Product Summary page to its baseline - no products @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('myat2two', 'Test1test');
    const pageName1 = 'My Account New Product Summary page - no products';

    await visualFunctions.eyesCheck(pageName1, page);
  });

  test('Compare the Account Details page to its baseline @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('72r3uk5c2k', 'Test2test');
    const pageName1 = 'Account Details page';

    await summaryPage.editDetailsButton.click();
    await visualFunctions.eyesCheck(pageName1, page);
  });

  test('Compare the My Account New Product Summary page to its baseline - unread documents notifications @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('2366456031', 'Test2test');
    const pageName1 = 'My Account Product Summary page - MYA';

    await summaryPage.assertElementVisible(summaryPage.productName);
    await visualFunctions.eyesCheck(pageName1, page);
  });

  afterAllHook(test);
});
