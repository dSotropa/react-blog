import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe.parallel('Visual regression tests for Rewards', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let summaryPage: SummaryPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    summaryPage = new SummaryPage(page);
  });

  test('Compare the My Account Rewards (Confirm e-gift) page @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('6u8vnggghb', 'Test2test');
    const pageName1 = 'My Account Rewards page - Confirm e-gift';

    await summaryPage.navMenuRewards.click();
    await visualFunctions.eyesCheck(pageName1, page);
  });

  test('Compare the My Account Rewards (Wait to qualify) page @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('fgefeehvcq', 'Test2test');
    const pageName1 = 'My Account Rewards page - Wait to qualify';

    await summaryPage.navMenuRewards.click();
    await visualFunctions.eyesCheck(pageName1, page);
  });

  test('Compare the My Account Rewards (Claim reward) page @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('3c36akmdh9', 'Test2test');
    const pageName1 = 'My Account Rewards page - Claim reward';

    await summaryPage.navMenuRewards.click();
    await visualFunctions.eyesCheck(pageName1, page);
  });

  test('Compare the My Account Rewards (Expired) page @VisualCheck', async ({ page }) => {
    await loginPage.login('dq65tqnv3j', 'Test2test');
    const pageName1 = 'Account Rewards page - Expired';

    await summaryPage.navMenuRewards.click();
    await visualFunctions.eyesCheck(pageName1, page);
  });

  afterAllHook(test);
});
