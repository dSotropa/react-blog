import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { MailboxPage } from '../../pageobjects/mailbox.po';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe.parallel('Visual regression tests for Mailbox', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let summaryPage: SummaryPage;
  let mailboxPage: MailboxPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    summaryPage = new SummaryPage(page);
    mailboxPage = new MailboxPage(page);
  });

  test('Compare the My Account Mailbox pages @VisualCheck', async ({ page }) => {
    await loginPage.login('BBVJ2ZMY0', 'London1a');
    const pageName1 = 'My Account Mailbox page';
    const pageName2 = 'My Account Mailbox page - send a message';

    await summaryPage.navMenuMailbox.click();
    await visualFunctions.eyesCheck(pageName1, page);

    await mailboxPage.composeMessageBtn.click();
    await visualFunctions.eyesCheck(pageName2, page);
  });

  test('Compare the My Account Mailbox pages - Life Cover product @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('dhvd879t9e', 'Test2test');
    const pageName1 = 'My Account Mailbox page - Life Cover product';
    const pageName2 = 'My Account Mailbox page - User ID or passwords subject';

    await summaryPage.navMenuMailbox.click();
    await visualFunctions.eyesCheck(pageName1, page);

    await mailboxPage.composeMessageBtn.click();
    await mailboxPage.selectFromDropdown(mailboxPage.chooseProductDropDown, 'Life Cover');

    await mailboxPage.selectFromDropdown(
      mailboxPage.chooseSubjectDropDown,
      'User ID or passwords',
    );

    await visualFunctions.eyesCheck(pageName2, page);
  });

  test('Compare the My Account Mailbox pages - Annuities product @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('f4qebq8p5t', 'Test2test');
    const pageName1 = 'My Account Mailbox page - Annuities';
    const pageName2 = 'My Account Mailbox page - Annuities product';

    await summaryPage.navMenuMailbox.click();
    await visualFunctions.eyesCheck(pageName1, page);

    await mailboxPage.composeMessageBtn.click();
    await mailboxPage.selectFromDropdown(mailboxPage.chooseProductDropDown, 'Annuities');

    await mailboxPage.selectFromDropdown(
      mailboxPage.chooseSubjectDropDown,
      'Changing names or contact details',
    );

    await visualFunctions.eyesCheck(pageName2, page);
  });

  test('Compare the My Account Mailbox pages - ISA product @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('RB848110C', 'A1@calumb3st');
    const pageName1 = 'My Account Mailbox page - ISA';
    const pageName2 = 'My Account Mailbox page - Legal & General ISA product';

    await summaryPage.navMenuMailbox.click();
    await visualFunctions.eyesCheck(pageName1, page);

    await mailboxPage.composeMessageBtn.click();

    await mailboxPage.selectFromDropdown(
      mailboxPage.chooseProductDropDown,
      'Legal & General ISA',
    );

    await mailboxPage.selectFromDropdown(
      mailboxPage.chooseSubjectDropDown,
      'Contributing to my ISA',
    );

    await visualFunctions.eyesCheck(pageName2, page);
  });

  test('Compare the My Account Mailbox pages - Investments product/TAWeb @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('invest01', 'Test2test');
    const pageName1 = 'My Account Mailbox page Investments';
    const pageName2 =
      'My Account Mailbox page - Changing names or contact details subject';

    await summaryPage.navMenuMailbox.click();
    await visualFunctions.eyesCheck(pageName1, page);

    await mailboxPage.composeMessageBtn.click();

    await mailboxPage.selectFromDropdown(
      mailboxPage.chooseProductDropDown,
      'Investments',
    );

    await mailboxPage.selectFromDropdown(
      mailboxPage.chooseSubjectDropDown,
      'Changing names or contact details',
    );

    await visualFunctions.eyesCheck(pageName2, page);
  });

  test('Compare the My Account Mailbox pages - Personal Pension product @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('omotest20', 'Test1234@');
    const pageName1 = 'My Account Mailbox page - PPP';
    const pageName2 = 'My Account Mailbox page - Personal Pension subject';

    await summaryPage.navMenuMailbox.click();
    await visualFunctions.eyesCheck(pageName1, page);

    await mailboxPage.composeMessageBtn.click();

    await mailboxPage.selectFromDropdown(
      mailboxPage.chooseProductDropDown,
      'Legal & General Personal Pension',
    );

    await mailboxPage.selectFromDropdown(
      mailboxPage.chooseSubjectDropDown,
      'Financial Advice',
    );

    await visualFunctions.eyesCheck(pageName2, page);
  });

  afterAllHook(test);
});
