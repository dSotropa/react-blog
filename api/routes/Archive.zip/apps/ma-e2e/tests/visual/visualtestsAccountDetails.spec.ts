import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { AccountDetailsOverviewPage } from '../../pageobjects/accountDetailsOverviewPage.po';
import { ChangeAddressPage } from '../../pageobjects/changeAddress.po';
import { ContactDetailsPage } from '../../pageobjects/contactDetails.po';
import { PreferencesPage } from '../../pageobjects/preferences.po';

test.describe.parallel('Account details in My Account visual tests', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let changeAddressPage: ChangeAddressPage;
  let contactDetailsPage: ContactDetailsPage;
  let preferencesPage: PreferencesPage;
  let accountDetailsOverviewPage: AccountDetailsOverviewPage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    changeAddressPage = new ChangeAddressPage(page);
    contactDetailsPage = new ContactDetailsPage(page);
    preferencesPage = new PreferencesPage(page);
    accountDetailsOverviewPage = new AccountDetailsOverviewPage(page);
  });

  test('Compare the Account Details pages to its baselines @VisualCheck', async ({
    page,
  }) => {
    const pageName1 = 'Contact Details Page';
    const pageName2 = 'Change Address Page';

    await loginPage.login(
      'greendani1000',
      'Pass1pass',
      true,
      changeAddressPage.contactDetailsRoute,
    );

    await visualFunctions.eyesCheck(pageName1, page);
    await changeAddressPage.navigateTo(changeAddressPage.changeAddressRoute);
    await visualFunctions.eyesCheck(pageName2, page);
  });

  test('Compare the Account Details page to its baseline - Manual Address Entry pages @VisualCheck', async ({
    page,
  }) => {
    const pageName1 = 'Manual Address Entry';
    const pageName2 = 'Manual Address Entry validation error';

    await loginPage.login(
      '72r3uk5c2k',
      'Test2test',
      true,
      changeAddressPage.changeAddressManualRoute,
    );

    await visualFunctions.eyesCheck(pageName1, page);
    await changeAddressPage.saveChangesButton.click();
    await visualFunctions.eyesCheck(pageName2, page);
  });

  test('Compare the account details pages to baselines @VisualCheck', async ({
    page,
  }) => {
    const pageName1 = 'Confirm Address Entry';
    const pageName2 = 'Personal Details';
    const pageName3 = 'Change Name Page';
    const pageName4 = 'Login and security Page';
    const pageName5 = 'Preferences Page';

    await loginPage.login(
      '72r3uk5c2k',
      'Test2test',
      true,
      changeAddressPage.changeAddressManualRoute,
    );

    await changeAddressPage.setAddress(
      'address line 1',
      'address line 2',
      'address line 3',
      'Brighton',
      'BN19JY',
    );

    await changeAddressPage.saveChangesButton.click();

    await changeAddressPage.assertUrlContains(
      changeAddressPage.confirmAddressManualRoute,
    );

    await visualFunctions.eyesCheck(pageName1, page);

    await page.goto('#/account-details/personal-details');
    await contactDetailsPage.leavePageDialogBtn.click();
    await visualFunctions.eyesCheck(pageName2, page);

    await page.goto('#/account-details/personal-details/change-name');
    await visualFunctions.eyesCheck(pageName3, page);

    await page.goto('#/account-details/login-and-security');
    await visualFunctions.eyesCheck(pageName4, page);

    await page.goto('#/account-details/preferences');
    await visualFunctions.eyesCheck(pageName5, page);
  });

  test('Compare the account details preferences page for an MYA user to baseline @VisualCheck', async ({
    page,
  }) => {
    const pageName = 'Preferences Page - MYA user';

    await loginPage.login('2366456031', 'Test2test', true, preferencesPage.route);

    await preferencesPage.assertElementVisible(
      preferencesPage.communicationPreferencesSection,
    );

    await preferencesPage.assertElementVisible(
      preferencesPage.marketingPreferencesSection,
    );

    await visualFunctions.eyesCheck(pageName, page);
  });

  test('Compare the account details preferences page for an Annuities user to baseline @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('DCJtestdata2', 'Test2test');
    const pageName = 'Preferences Page - Annuities user';

    await preferencesPage.assertTextExists('PR00577510');

    await preferencesPage.navigateTo(preferencesPage.route);

    await preferencesPage.assertElementVisible(
      preferencesPage.communicationPreferencesSection,
    );

    await preferencesPage.assertElementVisible(
      preferencesPage.marketingPreferencesSection,
    );

    await visualFunctions.eyesCheck(pageName, page);
  });

  test('Compare the account details preferences page for Annuities and MYA user to baseline @VisualCheck', async ({
    page,
  }) => {
    const pageName = 'Preferences Page - Annuities and MYA user';

    await loginPage.login('DAVIDDCJ', 'Test@1234', true, preferencesPage.route);

    await preferencesPage.assertElementVisible(
      preferencesPage.communicationPreferencesSection,
    );

    await preferencesPage.assertElementVisible(
      preferencesPage.marketingPreferencesSection,
    );

    await visualFunctions.eyesCheck(pageName, page);
  });

  afterAllHook(test);
});
