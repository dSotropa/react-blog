import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ChangeBank } from '../../pageobjects/changeBank.po';
import { ProductDetailsPage } from '../../pageobjects/productDetails.po';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe.parallel('Visual regression tests for Annuities change bank', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let summaryPage: SummaryPage;
  let productDetailsPage: ProductDetailsPage;
  let visualFunctions: VisualFunctions;
  let changeBankPage: ChangeBank;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    summaryPage = new SummaryPage(page);
    productDetailsPage = new ProductDetailsPage(page);
    changeBankPage = new ChangeBank(page);
  });

  test('Compare the change bank details pages to baselines @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('BBTQZJFY0', 'Test1test');
    const pageName = 'change bank details page';

    await summaryPage.updateBankDetails.click();
    await visualFunctions.eyesCheck(pageName, page);
  });

  test('Compare the change bank details request evidence page to its baseline @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('BBTQZJFY0', 'Test1test');
    const pageName1 = 'change bank details request evidence';
    const pageName2 = 'change bank details error';

    await summaryPage.updateBankDetails.click();
    await changeBankPage.accountNumber.fill('00641859');
    await changeBankPage.sortCodeNumber.fill('110717');
    await changeBankPage.confirmBtn.click();
    await changeBankPage.assertUrlContains('/confirm');
    await changeBankPage.submitMyDetailsBtn.click();
    await visualFunctions.eyesCheck(pageName1, page);

    await changeBankPage.navigateTo('#/form/change-bank-account/P00446633/error');
    await visualFunctions.eyesCheck(pageName2, page);
  });

  test('Compare the change bank details payment and tax page for suspended user to its baseline @VisualCheck', async ({
    page,
  }) => {
    await loginPage.login('BBSP8TGY0', 'Test3test');
    const pageName = 'change bank payment page';

    await summaryPage.productLink.click();
    await productDetailsPage.clickPaymentsTab();
    await visualFunctions.eyesCheck(pageName, page);
  });

  afterAllHook(test);
});
