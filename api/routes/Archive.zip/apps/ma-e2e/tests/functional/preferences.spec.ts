import test from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { PreferencesPage } from '../../pageobjects/preferences.po';

test.describe.parallel('Preferences tests', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let preferencesPage: PreferencesPage;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    preferencesPage = new PreferencesPage(page);
  });

  test('Ensure user is able to update their marketing preferences @Smoke', async () => {
    await loginPage.login('72r3uk5c2k', 'Test2test', true, preferencesPage.route);

    await preferencesPage.assertElementVisible(
      preferencesPage.communicationPreferencesSection,
    );

    await preferencesPage.assertElementVisible(
      preferencesPage.marketingPreferencesSection,
    );

    // set email marketing preference value and validate the save confirmation message
    await preferencesPage.getMarketingPreferenceButton('email', 'no').click();
    await preferencesPage.getMarketingPreferenceButton('email', 'yes').click();

    await preferencesPage.assertElementVisible(
      preferencesPage.getMarketingPreferenceSuccessAlert('email'),
    );

    // set email marketing preference value and validate the save confirmation message
    await preferencesPage.getMarketingPreferenceButton('email', 'no').click();

    await preferencesPage.assertElementVisible(
      preferencesPage.getMarketingPreferenceSuccessAlert('email'),
    );
  });

  test('Ensure user is able to update their Workplace communication preferences @Smoke', async () => {
    await loginPage.login('2366456031', 'Test2test', true, preferencesPage.route);

    await preferencesPage.assertElementVisible(
      preferencesPage.communicationPreferencesSection,
    );

    await preferencesPage.assertElementVisible(
      preferencesPage.marketingPreferencesSection,
    );

    // set communication preference value and validate the save confirmation message
    await preferencesPage.getCommunicationPreferenceButton('workplace', 'online').click();
    await preferencesPage.getCommunicationPreferenceButton('workplace', 'paper').click();

    await preferencesPage.assertElementVisible(
      preferencesPage.getCommuncationPreferenceSuccessAlert('workplace', 'paper'),
    );

    // set communication preference value and validate the save confirmation message
    await preferencesPage.getCommunicationPreferenceButton('workplace', 'online').click();

    await preferencesPage.assertElementVisible(
      preferencesPage.getCommuncationPreferenceSuccessAlert('workplace', 'online'),
    );
  });

  test('Ensure user is able to update their Annuity communication preferences @Smoke', async () => {
    await loginPage.login('f4qebq8p5t', 'Test2test', true, preferencesPage.route);

    await preferencesPage.assertElementVisible(
      preferencesPage.communicationPreferencesSection,
    );

    await preferencesPage.assertElementVisible(
      preferencesPage.marketingPreferencesSection,
    );

    // set communication preference value and validate the save confirmation message
    await preferencesPage
      .getCommunicationPreferenceButton('PR00479208', 'online')
      .click();

    await preferencesPage.getCommunicationPreferenceButton('PR00479208', 'paper').click();

    await preferencesPage.assertElementVisible(
      preferencesPage.getCommuncationPreferenceSuccessAlert('PR00479208', 'paper'),
    );

    // set communication preference value and validate the save confirmation message
    await preferencesPage
      .getCommunicationPreferenceButton('PR00479208', 'online')
      .click();

    await preferencesPage.assertElementVisible(
      preferencesPage.getCommuncationPreferenceSuccessAlert('PR00479208', 'online'),
    );
  });
});
