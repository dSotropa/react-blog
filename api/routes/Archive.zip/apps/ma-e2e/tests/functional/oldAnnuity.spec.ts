import test from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ProductDetailsPage } from '../../pageobjects/productDetails.po';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe.parallel('Verify Old Annuities product card on MyAccount PSP', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let productDetailsPage: ProductDetailsPage;
  let summaryPage: SummaryPage;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    productDetailsPage = new ProductDetailsPage(page);
    summaryPage = new SummaryPage(page);
  });

  test('Verify Annuities PRT product card on MyAccount PSP @Smoke', async () => {
    await loginPage.login('myat10one', 'Test1test');
    await summaryPage.assertElementVisible(summaryPage.productName);
    await summaryPage.assertElementVisible(summaryPage.policyNumber);
    await summaryPage.assertElementVisible(summaryPage.policyStartDate);
    await summaryPage.productLink.click();

    await productDetailsPage.assertElementVisible(
      productDetailsPage.oldAnnuitiesProductDetailsContainer,
    );
  });
});
