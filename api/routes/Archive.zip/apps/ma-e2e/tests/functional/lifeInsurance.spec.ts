import test, { expect } from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { LogoutPage } from '../../models/logoutpage';
import { ProductDetailsPage } from '../../pageobjects/productDetails.po';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe.parallel('Life insurance tests', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let summaryPage: SummaryPage;
  let productDetailsPage: ProductDetailsPage;
  let logoutPage: LogoutPage;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    summaryPage = new SummaryPage(page);
    productDetailsPage = new ProductDetailsPage(page);
    logoutPage = new LogoutPage(page);
  });

  // marked as skiped due to product is not loading. there is an issue
  test.skip('Verify product cards on MyAccount PSP and the Quick Actions - Over 50\'s @NotYetMocked', async ({
    page,
  }) => {
    await loginPage.login('myat15one', 'Test1test');

    await summaryPage.assertElementVisible(summaryPage.productName);
    await summaryPage.assertElementVisible(summaryPage.policyNumber);

    // assert current cover in pound
    await summaryPage.assertElementVisible(summaryPage.coverValue);
    await expect(summaryPage.coverValue).toContainText('£');

    // assert montly contribution in pound
    await summaryPage.assertElementVisible(summaryPage.alldataPoints.first());
    await expect(summaryPage.productInfoLabels.nth(0)).toHaveText('Monthly');
    await expect(summaryPage.productInfoValues.nth(0)).toContainText('£');

    // assert payment label in correct format
    await summaryPage.assertElementVisible(summaryPage.alldataPoints.first());
    await expect(summaryPage.productInfoLabels.nth(1)).toHaveText('Next payment due');

    await summaryPage.assertElementVisible(summaryPage.alldataPoints.first());
    await expect(summaryPage.productInfoLabels.nth(2)).toHaveText('Start date');

    // assert the two quick links on the product card
    expect(await summaryPage.productQuickActionLinks.count()).toEqual(2);

    // navigate to Change collection day page
    await summaryPage.changeCollectionDayLink.click();
    await summaryPage.assertElementVisible(summaryPage.productFormContent);
    await summaryPage.assertUrlContains('/change-collection-day');

    // change the collection day and confirm
    await productDetailsPage.selectFromDropdown(
      productDetailsPage.collectionDayDropdown,
      '5',
    );

    await productDetailsPage.confirmButton.click();
    await productDetailsPage.assertElementVisible(productDetailsPage.confirmationText);

    await productDetailsPage.homeBreadcrumb.click();

    // navigate to Change direct debit page
    await summaryPage.changeDirectDebitLink.click();
    await summaryPage.assertElementVisible(summaryPage.productFormContent);
    await summaryPage.assertUrlContains('/change-direct-debit');

    // change the direct debit details and confirm
    await productDetailsPage.assertElementVisible(
      productDetailsPage.bankAccountNumberInput,
    );

    await productDetailsPage.bankAccountNumberInput.type('12345678');
    await productDetailsPage.sortCodeInput.type('123456');
    await productDetailsPage.accountHolderNameInput.type('Random Name todo');
    await productDetailsPage.confirmButton.click();
    await productDetailsPage.assertElementVisible(productDetailsPage.confirmationText);

    // navigate back to MA PSP
    await summaryPage.navigateBackToMAPSP(page);
    await expect(page).toHaveTitle('My Account Home');

    await summaryPage.productLink.click();
    expect(page).toHaveTitle('My Product Details');

    await productDetailsPage.assertElementVisible(productDetailsPage.overviewContainer);

    await expect(productDetailsPage.overviewContainer).toContainText(
      'Over 50s Life Insurance Plan',
    );
  });

  test('Verify user is able to log out and have an option to log back in again @NotYetMocked', async () => {
    await loginPage.login('myat15one', 'Test1test');

    await summaryPage.assertElementVisible(summaryPage.productName);

    // logout actions
    await logoutPage.ensureLoggedOut();

    await logoutPage.loginAgain.click();
    await loginPage.assertElementVisible(loginPage.userNameInput);
  });

  test('Verify user is taken to L&G homepage via the homepage link @NotYetMocked', async ({
    page,
  }) => {
    await loginPage.login('myat15one', 'Test1test');

    await summaryPage.assertElementVisible(summaryPage.productName);

    // logout actions
    await logoutPage.ensureLoggedOut();

    await logoutPage.goToHomePage.click();
    expect(page.url()).toEqual('https://www.legalandgeneral.com/');
  });
});
