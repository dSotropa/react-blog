import test from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ConfirmContactDetailsPage } from '../../pageobjects/confirmContactDetails.po';

test.describe.parallel('Confirm contact details interstitial', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let confirmContactDetailsPage: ConfirmContactDetailsPage;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    confirmContactDetailsPage = new ConfirmContactDetailsPage(page);
  });

  test('Verify interstitial is displayed to a user without an email address @Smoke', async () => {
    await loginPage.login('BBQ7BQMY0', 'Test1test');
    await confirmContactDetailsPage.assertTextExists('Complete your contact details');

    // assert confirm details page
    await confirmContactDetailsPage.assertUrlContains(confirmContactDetailsPage.route);

    await confirmContactDetailsPage.assertElementVisible(
      confirmContactDetailsPage.emailInput,
    );
  });
});
