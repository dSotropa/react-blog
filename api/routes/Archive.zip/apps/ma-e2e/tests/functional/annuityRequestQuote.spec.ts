import test, { expect } from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { SummaryPage } from '../../pageobjects/summaryPage.po';
import { RequestQuotePage } from '../../pageobjects/annuityRequestquote.po';

test.describe.parallel('Request a quote test - Annuities', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let summaryPage: SummaryPage;
  let requestQuotePage: RequestQuotePage;

  test.beforeEach(async ({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    summaryPage = new SummaryPage(page);
    requestQuotePage = new RequestQuotePage(page);
    await loginPage.login('MS00001061', '1Test2test');
  });

  test('Verify that I can successfully submit a Retirement Quote via "email" and by "age" @Smoke', async () => {
    await summaryPage.requestAquotationLink.click();
    await summaryPage.assertTextExists('Request a quote');
    await summaryPage.assertUrlContains('/form/request-quote/retirement/');

    await requestQuotePage.byEmailRadioButton.click();

    await expect(requestQuotePage.secureEmailMessage).toContainText(
      'We will send this via the L&G secure email service.',
    );

    await requestQuotePage.continueButton.click();
    await requestQuotePage.assertUrlContains('/form/request-quote/retirement/selection');

    await requestQuotePage.byAgeLink.click();
    requestQuotePage.assertUrlContains('/form/request-quote/retirement/selection/by-age');

    await requestQuotePage.retirementAgeInput.type('62');
    await requestQuotePage.submitButton.click();
    await requestQuotePage.assertTextExists('Thanks for your request');

    await requestQuotePage.assertUrlContains(
      '/form/request-quote/retirement/selection/by-age/success',
    );
  });

  test('Verify that I can successfully submit a Retirement Quote via "post" and by "date" @Smoke', async () => {
    await summaryPage.productLink.click();
    await requestQuotePage.productPageRetirementQuoteBtn.click();
    await requestQuotePage.assertTextExists('Request a quote');
    await requestQuotePage.assertUrlContains('/form/request-quote/retirement');

    await requestQuotePage.byPostRadioButton.click();
    await requestQuotePage.continueButton.click();
    await requestQuotePage.assertUrlContains('/form/request-quote/retirement/selection');

    await requestQuotePage.byDateLink.click();

    await requestQuotePage.assertUrlContains(
      '/form/request-quote/retirement/selection/by-date',
    );

    await requestQuotePage.retirementDateInput.type('10/10/2045');
    await requestQuotePage.submitButton.click();

    await requestQuotePage.waitForPageToLoad();
    await requestQuotePage.assertTextExists('Thanks for your request');

    await requestQuotePage.assertUrlContains(
      '/form/request-quote/retirement/selection/by-date/success',
    );
  });

  test('Verify that I can successfully submit a Transfer Quote @Smoke', async () => {
    await summaryPage.requestAquotationLink.click();
    await requestQuotePage.requestATransferQuoteLink.click();
    await requestQuotePage.assertUrlContains('/form/request-quote/transfer');

    await requestQuotePage.byEmailRadioButton.click();

    await expect(requestQuotePage.secureEmailMessage).toContainText(
      'We will send this via the L&G secure email service.',
    );

    await requestQuotePage.submitButton.click();
    await requestQuotePage.assertTextExists('Thanks for your request');
    await requestQuotePage.assertUrlContains('/form/request-quote/transfer/success');
  });
});
