import test from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ConfirmDetailsPhonePage } from '../../pageobjects/confirmDetailsPhone.po';
import { ConfirmDetailsSuccessPage } from '../../pageobjects/confirmDetailsSuccess.po';
import { ContactDetailsPage } from '../../pageobjects/contactDetails.po';

test.describe.parallel('Confirm details phone page tests', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let confirmDetailsPhonePage: ConfirmDetailsPhonePage;
  let contactDetailsPage: ContactDetailsPage;
  let confirmDetailsSuccessPage: ConfirmDetailsSuccessPage;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    confirmDetailsPhonePage = new ConfirmDetailsPhonePage(page);
    contactDetailsPage = new ContactDetailsPage(page);
    confirmDetailsSuccessPage = new ConfirmDetailsSuccessPage(page);
  });

  test('Confirm details phone page tests @Smoke', async () => {
    await loginPage.login(
      'dhvd879t9e',
      'Test2test',
      true,
      confirmDetailsPhonePage.confirmDetailsPhoneRoute,
    );

    await contactDetailsPage.assertElementVisible(
      contactDetailsPage.phoneDetailsHomeInput,
    );

    // enter a home phone number
    await confirmDetailsPhonePage.homePhoneInput.fill('01273456789');
    await confirmDetailsPhonePage.confirmPhoneNumbersSubmitButton.click();

    await confirmDetailsSuccessPage.assertElementVisible(
      confirmDetailsSuccessPage.continueToMyAccountBtn,
    );

    await confirmDetailsSuccessPage.assertUrlContains(
      confirmDetailsSuccessPage.confirmDetailsSuccessRoute,
    );
  });
});
