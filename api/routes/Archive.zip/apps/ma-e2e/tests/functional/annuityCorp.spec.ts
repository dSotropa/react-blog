import test, { expect } from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ProductDetailsPage } from '../../pageobjects/productDetails.po';
import { ChangeBank } from '../../pageobjects/changeBank.po';
import { PaymentsTaxPage } from '../../pageobjects/paymentsTax.po';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe.parallel('Summary Page test - Annuities CORP', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let productDetailsPage: ProductDetailsPage;
  let changeBankPage: ChangeBank;
  let paymentsTaxPage: PaymentsTaxPage;
  let summaryPage: SummaryPage;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    productDetailsPage = new ProductDetailsPage(page);
    changeBankPage = new ChangeBank(page);
    paymentsTaxPage = new PaymentsTaxPage(page);
    summaryPage = new SummaryPage(page);
  });

  test('Verify there is an active overview tab @NotYetMocked', async () => {
    await loginPage.login('BBTQY5WY0', 'Test1test');

    await summaryPage.productLink.click();
    await productDetailsPage.isTabActive(productDetailsPage.overviewTab);
    await productDetailsPage.assertUrlContains('/Overview');

    // bold support articles are present and click on the tax code bold support article link
    expect(await productDetailsPage.supportArticles.count()).toBeGreaterThanOrEqual(1);
    await productDetailsPage.supportArticles.first().click();

    // assert that bold chat opens up with the correct
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContent);
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContentTitle);

    await expect(changeBankPage.boldChatContentTitle).toContainText(
      'Can I change my tax code?',
    );
  });

  test('Verify switching to payments and tax tab @NotYetMocked', async () => {
    await loginPage.login('BBTQY5WY0', 'Test1test');

    await summaryPage.productLink.click();
    await productDetailsPage.isTabActive(productDetailsPage.overviewTab);
    await productDetailsPage.assertUrlContains('/Overview');
    await productDetailsPage.clickPaymentsTab();
    await productDetailsPage.isTabActive(productDetailsPage.paymentsTab);
    await productDetailsPage.assertUrlContains('/Payment');

    // bold support articles are present and click on the tax code bold support article link
    expect(await productDetailsPage.supportArticles.count()).toBeGreaterThanOrEqual(1);
    await productDetailsPage.supportArticles.first().click();

    // assert that bold chat opens up with the correct
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContent);
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContentTitle);

    await expect(changeBankPage.boldChatContentTitle).toContainText(
      'Can I change my tax code?',
    );
  });

  test('Verify switching to documents tab for annuities CORP @NotYetMocked', async () => {
    await loginPage.login('BBTQY5WY0', 'Test1test');

    await summaryPage.productLink.click();

    await productDetailsPage.assertElementVisible(
      productDetailsPage.annuitiesProductDetailsContainer,
    );

    await productDetailsPage.clickDocumentsTab();
    await productDetailsPage.isTabActive(productDetailsPage.documentsTab);
    await productDetailsPage.assertUrlContains('/Documents');

    // bold support articles are present and click on the tax code bold support article link
    expect(await productDetailsPage.supportArticles.count()).toBeGreaterThanOrEqual(1);
    await productDetailsPage.supportArticles.first().click();

    // assert that bold chat opens up with the correct
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContent);
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContentTitle);

    await expect(changeBankPage.boldChatContentTitle).toContainText(
      'Can I change my tax code?',
    );
  });

  test('Verify Annuities CORP product has correct Transferability copy displayed @Smoke', async () => {
    await loginPage.login('BBS689MY0', 'Test1test');

    await summaryPage.assertElementVisible(summaryPage.productName);
    await summaryPage.productLink.click();

    await productDetailsPage.assertElementVisible(
      productDetailsPage.annuitiesProductDetailsContainer,
    );

    // assert confirmation transferability text
    await productDetailsPage.assertElementVisible(
      productDetailsPage.productDescriptionMessage,
    );

    await expect(productDetailsPage.productDescriptionMessage).toContainText(
      productDetailsPage.confirmationTransferabilityText,
    );
  });

  test('Verify Annuities CORP product has correct Transferability copy deny displayed @Smoke', async () => {
    await loginPage.login('BBLZJXJY0', 'Test1test');

    await summaryPage.assertElementVisible(summaryPage.productName);
    await summaryPage.productLink.click();

    await productDetailsPage.assertElementVisible(
      productDetailsPage.annuitiesProductDetailsContainer,
    );

    // assert confirmation transferability text
    await productDetailsPage.assertElementVisible(
      productDetailsPage.productDescriptionMessage,
    );

    await expect(productDetailsPage.productDescriptionMessage).toContainText(
      productDetailsPage.denyTransferabilityText,
    );
  });
});
