import test, { expect } from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe.parallel('Online Self Service Page tests', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let summaryPage: SummaryPage;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    summaryPage = new SummaryPage(page);
  });

  test('Verify Legal and General ISA product card on My Account @NotYetMocked', async () => {
    await loginPage.login('HS296110B', 'Test@1234');

    await summaryPage.assertElementVisible(summaryPage.navMenuHome);
    await summaryPage.assertTextExists('Your total savings are £');

    // assert ISA product, pension account, investment account
    await summaryPage.assertElementVisible(summaryPage.productName);
    await summaryPage.assertElementVisible(summaryPage.productId);
    await expect(summaryPage.productValuation).toContainText('£');

    await expect(summaryPage.summaryPageHeader).toContainText(
      await summaryPage.productValuation.textContent(),
    );

    // navigate and assert OSS page
    await summaryPage.productName.click();
    await summaryPage.assertElementVisible(summaryPage.isaOverviewHeader);
    await summaryPage.assertUrlContains('/activity');
  });
});
