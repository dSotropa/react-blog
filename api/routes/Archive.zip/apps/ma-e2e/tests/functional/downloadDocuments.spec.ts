import fs from 'fs-extra';
import test from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ProductDetailsPage } from '../../pageobjects/productDetails.po';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe.parallel('Downloading documents', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let productDetailsPage: ProductDetailsPage;
  let summaryPage: SummaryPage;

  test.beforeEach(async ({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    productDetailsPage = new ProductDetailsPage(page);
    summaryPage = new SummaryPage(page);
    await loginPage.acceptCookieBanner();
  });

  test('Ensure user is able to download CORP annuities document @Smoke', async ({
    page,
  }) => {
    await loginPage.login('BBS5JH5Y0', 'Test1test');
    await summaryPage.assertElementVisible(summaryPage.productName);
    await summaryPage.productLink.click();

    await productDetailsPage.isTabActive(productDetailsPage.overviewTab);

    await productDetailsPage.clickDocumentsTab();
    await productDetailsPage.isTabActive(productDetailsPage.documentsTab);
    await page.waitForURL('**/Documents');

    const [ download ] = await Promise.all([
      // Start waiting for the download
      page.waitForEvent('download'),
      // Perform the action that initiates download
      await productDetailsPage.firstAnnuitiesDocument.click(),
    ]);

    // Wait for the download process to complete
    await download.saveAs('my_corp_doc.pdf');
    await fs.remove('my_corp_doc.pdf');
  });

  test('Ensure user is able to download FTRP annuities document @Smoke', async ({
    page,
  }) => {
    await loginPage.login('BBL3WNWY0', 'Test1test');
    await summaryPage.assertElementVisible(summaryPage.productName);
    await summaryPage.productLink.click();

    await productDetailsPage.isTabActive(productDetailsPage.overviewTab);

    await productDetailsPage.clickDocumentsTab();
    await productDetailsPage.isTabActive(productDetailsPage.documentsTab);
    await page.waitForURL('**/Documents');

    const [ download ] = await Promise.all([
      // Start waiting for the download
      page.waitForEvent('download'),
      // Perform the action that initiates download
      await productDetailsPage.firstAnnuitiesDocument.click(),
    ]);

    // Wait for the download process to complete
    await download.saveAs('my_file.pdf');
    await fs.remove('my_file.pdf');
  });

  test('Ensure user is able to download New Business annuities document @Smoke', async ({
    page,
  }) => {
    await loginPage.login('DCJtestdata3', 'Test2test');
    await summaryPage.assertElementVisible(summaryPage.productName);
    await summaryPage.productLink.click();

    await productDetailsPage.isTabActive(productDetailsPage.overviewTab);

    await productDetailsPage.clickDocumentsTab();
    await productDetailsPage.isTabActive(productDetailsPage.documentsTab);
    await page.waitForURL('**/Documents');

    const [ download ] = await Promise.all([
      // Start waiting for the download
      page.waitForEvent('download'),
      // Perform the action that initiates download
      await productDetailsPage.firstAnnuitiesDocument.click(),
    ]);

    // Wait for the download process to complete
    await download.saveAs('my_new_business_annuity.pdf');
    await fs.remove('my_new_business_annuity.pdf');
  });

  test('Ensure user is able to download PRT annuities document @Smoke', async ({
    page,
  }) => {
    await loginPage.login('BBTQYZWY0', 'Test1test');
    await summaryPage.assertElementVisible(summaryPage.productName);
    await summaryPage.productLink.click();

    await productDetailsPage.isTabActive(productDetailsPage.overviewTab);

    await productDetailsPage.clickDocumentsTab();
    await productDetailsPage.isTabActive(productDetailsPage.documentsTab);
    await page.waitForURL('**/Documents');

    const [ download ] = await Promise.all([
      // Start waiting for the download
      page.waitForEvent('download'),
      // Perform the action that initiates download
      await productDetailsPage.firstAnnuitiesDocument.click(),
    ]);

    // Wait for the download process to complete
    await download.saveAs('my_prt_doc.pdf');
    await fs.remove('my_prt_doc.pdf');
  });

  test('Ensure user is able to download SLA annuities document @Smoke', async ({
    page,
  }) => {
    await loginPage.login('BBSP8TGY0', 'Test3test');
    await summaryPage.assertElementVisible(summaryPage.productName);
    await summaryPage.productLink.click();

    await productDetailsPage.isTabActive(productDetailsPage.overviewTab);

    await productDetailsPage.clickDocumentsTab();
    await productDetailsPage.isTabActive(productDetailsPage.documentsTab);
    await page.waitForURL('**/Documents');

    const [ download ] = await Promise.all([
      // Start waiting for the download
      page.waitForEvent('download'),
      // Perform the action that initiates download
      await productDetailsPage.firstAnnuitiesDocument.click(),
    ]);

    // Wait for the download process to complete
    await download.saveAs('my_sla_doc.pdf');
    await fs.remove('my_sla_doc.pdf');
  });
});
