import test, { expect } from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ChangeNamePage } from '../../pageobjects/changeName.po';
import { ConfirmContactDetailsPage } from '../../pageobjects/confirmContactDetails.po';

test.describe.parallel('Change name tests', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let confirmContactDetailsPage: ConfirmContactDetailsPage;
  let changeNamePage: ChangeNamePage;

  test.beforeEach(async ({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    confirmContactDetailsPage = new ConfirmContactDetailsPage(page);
    changeNamePage = new ChangeNamePage(page);

    await loginPage.login(
      '72r3uk5c2k',
      'Test2test',
      true,
      changeNamePage.changeNameRoute,
    );
  });

  test('Ensure user is able to cancel @Smoke', async () => {
    await changeNamePage.cancelButton.click();
    await changeNamePage.assertUrlContains('/account-details/personal-details');
  });

  test('Ensure the common titles are first in the title drop down list @Smoke', async () => {
    await expect(changeNamePage.titleInput).toContainText(
      [ 'Mr', 'Mrs', 'Ms', 'Miss', 'Mx', 'Doctor' ],
      {
        timeout: 10000,
      },
    );
  });
});
