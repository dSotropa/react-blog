import test from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ConfirmDetailsSuccessPage } from '../../pageobjects/confirmDetailsSuccess.po';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe.parallel('Confirm details success page tests', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let confirmDetailsSuccessPage: ConfirmDetailsSuccessPage;
  let summaryPage: SummaryPage;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    confirmDetailsSuccessPage = new ConfirmDetailsSuccessPage(page);
    summaryPage = new SummaryPage(page);
  });

  test('Continue to My Account @Smoke', async () => {
    await loginPage.login(
      'dhvd879t9e',
      'Test2test',
      true,
      confirmDetailsSuccessPage.confirmDetailsSuccessRoute,
    );

    await confirmDetailsSuccessPage.assertElementVisible(
      confirmDetailsSuccessPage.continueToMyAccountBtn,
    );

    await confirmDetailsSuccessPage.continueToMyAccountBtn.click();
    await summaryPage.assertElementVisible(summaryPage.navMenuHome);
  });
});
