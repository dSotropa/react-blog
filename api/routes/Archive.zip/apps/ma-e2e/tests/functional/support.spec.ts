import test, { expect } from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { Support } from '../../pageobjects/support.po';

test.describe.parallel('Support tests', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let support: Support;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    support = new Support(page);
  });

  async function openTriageWidget() {
    await support.helpButton.click();
    await support.assertElementVisible(support.triageWidgetOpen);
    expect(await support.triageWidgetOpen.getAttribute('class')).toContain('open');
  }

  test('Verify Support widget for LGI @NotYetMocked', async () => {
    await loginPage.login('myat15two', 'Test1test');

    // assertions for help button
    await support.assertElementVisible(support.helpButton);
    await openTriageWidget();
    expect(await support.triageItems.count()).toBe(2);
    await support.assertTextExists('Life Cover Help');
    await support.assertTextExists('General Help');
    await support.getKnowledgeBaseCardTriage('Life Cover Help').click();
    await support.assertElementVisible(support.boldWidget);
    await support.changeHelp.click();
    await support.assertElementVisible(support.triageWidgetOpen);

    await support.getKnowledgeBaseCardTriage('General Help').click();
    await support.assertElementVisible(support.nanorepWidget);
    await support.changeHelp.click();
    await support.assertElementVisible(support.triageWidgetOpen);

    await support.closeButtonTriage.click();
    await support.assertElementVisible(support.helpButton);
  });

  test('Verify Support widget for LGR - annuities @NotYetMocked', async () => {
    await loginPage.login('myat10two', 'Test1test');

    // assertions for help button
    await support.assertElementVisible(support.helpButton);
    await openTriageWidget();
    expect(await support.triageItems.count()).toBe(2);
    await support.assertTextExists('Annuity');
    await support.assertTextExists('General Help');
    await support.getKnowledgeBaseCardTriage('Annuity').click();
    await support.assertElementVisible(support.nanorepWidget);
    await support.assertElementVisible(support.faqTitleNanorep);
    await expect(support.faqTitleNanorep).toHaveText('Help & Support');
    await support.changeHelp.click();
    await support.assertElementVisible(support.triageWidgetOpen);

    await support.getKnowledgeBaseCardTriage('General Help').click();
    await support.assertElementVisible(support.nanorepWidget);
    await support.closeButtonNanorep.click();
    await support.assertElementVisible(support.helpButton);
  });

  test('Verify Support widget for PI ISA and personal pension @NotYetMocked', async () => {
    await loginPage.login('uatven94@test.com', 'Chr1stma5@2020');

    // assertions for help button
    await support.assertElementVisible(support.helpButton);
    await openTriageWidget();
    expect(await support.triageItems.count()).toBe(3);
    await support.assertTextExists('Personal Pensions Help');
    await support.assertTextExists('Legal & General IS');
    await support.assertTextExists('General Help');

    await support.getKnowledgeBaseCardTriage('Personal Pensions Help').click();
    await support.assertElementVisible(support.boldWidget);
    await support.changeHelp.click();
    await support.assertElementVisible(support.triageWidgetOpen);

    await support.getKnowledgeBaseCardTriage('General Help').click();
    await support.assertElementVisible(support.nanorepWidget);
    await support.changeHelp.click();
    await support.assertElementVisible(support.triageWidgetOpen);

    await support.getKnowledgeBaseCardTriage('Legal & General ISA').click();
    await support.assertElementVisible(support.boldWidget);

    await support.closeButtonBold.click();
    await support.assertElementVisible(support.helpButton);
  });

  test('Verify Support widget for MYA @NotYetMocked', async () => {
    await loginPage.login('2366456031', 'Test2test');

    // assertions for help button
    await support.assertElementVisible(support.helpButton);
    await openTriageWidget();
    await support.assertTextExists('General Help');
    await support.getKnowledgeBaseCardTriage('General Help').click();
    await support.assertElementVisible(support.nanorepWidget);
    await support.closeButtonNanorep.click();
    await support.assertElementVisible(support.helpButton);
  });

  test('Verify Support widget for Invesments product/TAWeb @NotYetMocked', async () => {
    await loginPage.login('invest01', 'Test2test');

    // assertions for help button
    await support.assertElementVisible(support.helpButton);
    await openTriageWidget();
    expect(await support.triageItems.count()).toBe(2);
    await support.assertTextExists('Investments Help');
    await support.assertTextExists('General Help');
    await support.getKnowledgeBaseCardTriage('Investments Help').click();
    await support.assertElementVisible(support.boldWidget);
    await support.assertElementVisible(support.faqTitleBold);
    await expect(support.faqTitleBold).toContainText('Investments support');
    await support.changeHelp.click();
    await support.assertElementVisible(support.triageWidgetOpen);

    await support.getKnowledgeBaseCardTriage('General Help').click();
    await support.assertElementVisible(support.nanorepWidget);
    await support.closeButtonNanorep.click();
    await support.assertElementVisible(support.helpButton);
  });
});
