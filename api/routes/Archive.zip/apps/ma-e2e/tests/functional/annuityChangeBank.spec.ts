import test, { expect } from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ProductDetailsPage } from '../../pageobjects/productDetails.po';
import { ChangeBank } from '../../pageobjects/changeBank.po';
import { PaymentsTaxPage } from '../../pageobjects/paymentsTax.po';

test.describe.parallel('Change bank Page test - Annuities', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let productDetailsPage: ProductDetailsPage;
  let changeBankPage: ChangeBank;
  let paymentsTaxPage: PaymentsTaxPage;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    productDetailsPage = new ProductDetailsPage(page);
    changeBankPage = new ChangeBank(page);
    paymentsTaxPage = new PaymentsTaxPage(page);
  });

  test('Verify bold chat opens with correct article on request evidence page @NotYetMocked', async () => {
    await loginPage.login('BBL3WM2Y0', 'Test1test');

    // navigate to a specific change bank account page
    await changeBankPage.changeBankDetailsLink.first().click();

    // fill in the change bank account form
    await changeBankPage.assertElementVisible(changeBankPage.accountNumber);
    await changeBankPage.enterBankAccountNr('99999999');
    await changeBankPage.enterSortCode('999999');
    await changeBankPage.confirmBtn.click();

    // assert user is on confirm details page
    await changeBankPage.assertUrlContains('/confirm');

    // submit and assert request-evidence page
    await changeBankPage.submitMyDetailsBtn.click();

    await changeBankPage.assertElementVisible(
      changeBankPage.submitYourDocumentsOnlineBtn,
    );

    await changeBankPage.assertUrlContains('/request-evidence');

    await changeBankPage.submitYourDocumentsOnlineBtn.click();
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContent);
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContentTitle);

    await expect(changeBankPage.boldChatContentTitle).toContainText(
      'I need to send evidence of my new bank account details',
    );
  });

  test('Verify that a customers bank details are updated on the payments and tax tab after a successful change @Smoke', async () => {
    await loginPage.login(
      'BBRVVYPY0',
      'Test1test',
      true,
      changeBankPage.changeBankProductNo,
    );

    // fill in the change bank account form
    await changeBankPage.assertElementVisible(changeBankPage.accountNumber);
    await changeBankPage.enterBankAccountNr(changeBankPage.bankAccountNumber);
    await changeBankPage.enterSortCode('112233');
    await changeBankPage.confirmBtn.click();

    // assert user is on confirm details page
    await changeBankPage.assertUrlContains('/confirm');
    await changeBankPage.assertTextExists('Submit my details');

    // submit and assert success page
    await changeBankPage.submitMyDetailsBtn.click();
    await changeBankPage.assertUrlContains('/success');

    // click on view my policy button
    await changeBankPage.viewMyPolicyBtn.click();

    await productDetailsPage.assertElementVisible(
      productDetailsPage.annuitiesProductDetailsContainer,
    );

    await productDetailsPage.clickPaymentsTab();

    // assert changed bank account number and sort code
    await expect(paymentsTaxPage.cbankAccountValue).toContainText('5678');
    await expect(paymentsTaxPage.sortCodeValue).toContainText('11-22-**');
  });

  test('Verify bold chat opens with correct contact article on change bank details page @NotYetMocked', async () => {
    await loginPage.login('BBRVVYPY0', 'Test1test');

    await changeBankPage.changeBankDetailsLink.click();
    await changeBankPage.assertTextExists('How do I contact you?');
    expect(await productDetailsPage.supportArticles.count()).toBeGreaterThanOrEqual(1);
    await changeBankPage.changeBankDetailsPageSupportArticles.nth(0).click();
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContent);
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContentTitle);

    await expect(changeBankPage.boldChatContentTitle).toContainText(
      'How do I contact you?',
    );
  });

  test('Verify bold chat opens with correct payments article on change bank details page @NotYetMocked', async () => {
    await loginPage.login('BBRVVYPY0', 'Test1test');

    await changeBankPage.changeBankDetailsLink.click();

    await changeBankPage.assertTextExists(
      'What bank accounts can I receive payments to?',
    );

    expect(await productDetailsPage.supportArticles.count()).toBeGreaterThanOrEqual(1);
    await changeBankPage.changeBankDetailsPageSupportArticles.nth(1).click();
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContent);
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContentTitle);

    await expect(changeBankPage.boldChatContentTitle).toContainText(
      'What bank accounts can I receive payments to?',
    );
  });
});
