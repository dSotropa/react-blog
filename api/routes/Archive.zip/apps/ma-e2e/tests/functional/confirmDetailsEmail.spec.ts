import test from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ConfirmDetailsEmailPage } from '../../pageobjects/confirmDetailsEmail.po';
import { ConfirmDetailsPhonePage } from '../../pageobjects/confirmDetailsPhone.po';

test.describe.parallel('Confirm details email page tests', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let confirmDetailsPhonePage: ConfirmDetailsPhonePage;
  let confirmDetailsEmailPage: ConfirmDetailsEmailPage;

  test.beforeEach(async ({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    confirmDetailsPhonePage = new ConfirmDetailsPhonePage(page);
    confirmDetailsEmailPage = new ConfirmDetailsEmailPage(page);

    await loginPage.login(
      'dhvd879t9e',
      'Test2test',
      true,
      confirmDetailsEmailPage.confirmDetailsRoute,
    );
  });

  test('Validation: Invalid email address @Smoke', async () => {
    await confirmDetailsEmailPage.assertElementVisible(
      confirmDetailsEmailPage.emailInput,
    );

    // enter invalid email address
    await confirmDetailsEmailPage.emailInput.fill('testing_invalid_email_address.com');
    await confirmDetailsEmailPage.confirmEmailSubmitButton.click();

    await confirmDetailsEmailPage.assertElementVisible(
      confirmDetailsEmailPage.emailError,
    );
  });

  test('Validation: Email address starting with number @Smoke', async () => {
    await confirmDetailsEmailPage.assertElementVisible(
      confirmDetailsEmailPage.emailInput,
    );

    // enter email address starting with number
    await confirmDetailsEmailPage.emailInput.fill(
      '13testing_l&g_invalid_email_address@landg.com',
    );

    await confirmDetailsEmailPage.confirmEmailSubmitButton.click();

    await confirmDetailsEmailPage.assertElementVisible(
      confirmDetailsEmailPage.emailError,
    );
  });

  test('Save new email address @Smoke', async () => {
    await confirmDetailsEmailPage.assertElementVisible(
      confirmDetailsEmailPage.emailInput,
    );

    // enter a valid email address
    await confirmDetailsEmailPage.emailInput.fill('valid_email_address@landg.com');
    await confirmDetailsEmailPage.confirmEmailSubmitButton.click();

    await confirmDetailsPhonePage.assertElementVisible(
      confirmDetailsPhonePage.mobilePhoneInput,
    );

    await confirmDetailsPhonePage.assertUrlContains(
      confirmDetailsPhonePage.confirmDetailsPhoneRoute,
    );
  });
});
