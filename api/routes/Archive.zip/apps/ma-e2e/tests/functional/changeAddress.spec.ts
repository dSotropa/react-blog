import { expect, test } from '@playwright/test';
import { IS_MOCKED } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ChangeAddressPage } from '../../pageobjects/changeAddress.po';
import { ContactDetailsPage } from '../../pageobjects/contactDetails.po';

test.describe.parallel('Change address tests', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let changeAddressPage: ChangeAddressPage;
  let contactDetailsPage: ContactDetailsPage;

  test.beforeEach(async ({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    changeAddressPage = new ChangeAddressPage(page);
    contactDetailsPage = new ContactDetailsPage(page);

    await loginPage.login(
      '72r3uk5c2k',
      'Test2test',
      true,
      changeAddressPage.changeAddressRoute,
    );
  });

  test('Ensure user sees an error when submitting postcode twice @Smoke', async () => {
    await changeAddressPage.assertElementVisible(changeAddressPage.houseNumberInput);
    await changeAddressPage.changeForHouseNumber('1', 'BN1 3PB');
    await expect(changeAddressPage.postcodeInput).toHaveValue('BN1 3PB');
    await changeAddressPage.assertElementVisible(changeAddressPage.addressSelectDropdown);
    await changeAddressPage.addressSelectDropdown.click();

    if (IS_MOCKED) {
      await changeAddressPage.selectFromDropdown(
        changeAddressPage.addressSelectDropdown,
        '1 Working Street. Brighton, BN1 3PB',
        'label',
      );
    } else {
      await changeAddressPage.selectFromDropdown(
        changeAddressPage.addressSelectDropdown,
        'Flat 1, 54 Surrey Street, BRIGHTON BN1 3PB',
        'label',
      );
    }

    await changeAddressPage.addressSearchButton.click();

    await expect(changeAddressPage.addressSelectDropdownError).toContainText(
      'Please select an address',
    );
  });

  test('Ensure user is able to search for and save an address @Smoke', async ({
    page,
  }) => {
    await changeAddressPage.assertElementVisible(changeAddressPage.houseNumberInput);
    await changeAddressPage.changeForHouseNumber('1', 'BN1 3PB');
    await expect(changeAddressPage.postcodeInput).toHaveValue('BN1 3PB');
    await changeAddressPage.assertElementVisible(changeAddressPage.addressSelectDropdown);

    if (IS_MOCKED) {
      await changeAddressPage.selectFromDropdown(
        changeAddressPage.addressSelectDropdown,
        '1',
      );
    } else {
      await changeAddressPage.selectFromDropdown(
        changeAddressPage.addressSelectDropdown,
        'Flat 1, 54 Surrey Street, BRIGHTON BN1 3PB',
        'label',
      );
    }

    await changeAddressPage.saveChangesButton.click();
    await changeAddressPage.assertUrlContains(changeAddressPage.confirmAddressRoute);
    await changeAddressPage.confirmButton.click();
    await changeAddressPage.assertUrlContains(changeAddressPage.contactDetailsRoute);
    const text = (
      await page.textContent('[data-testid="postcode-data-point-value"]')
    ).trim();

    expect(text).toBe('BN1 3PB');
  });

  test('Ensure user is able to cancel @Smoke', async () => {
    await changeAddressPage.assertElementVisible(changeAddressPage.houseNumberInput);
    await changeAddressPage.cancelButton.click();
    await changeAddressPage.assertUrlContains(changeAddressPage.contactDetailsRoute);
  });

  test('Ensure user can see an international address warning and send a secure message @Smoke', async () => {
    await changeAddressPage.assertElementVisible(changeAddressPage.houseNumberInput);

    await changeAddressPage.selectFromDropdown(
      changeAddressPage.countrySelectDropdown,
      'Outside the United Kingdom',
      'label',
    );

    await expect(changeAddressPage.internationalAddressWarning).toContainText(
      'We can only accept UK addresses online',
    );

    await changeAddressPage.sendSecureMessageButton.click();
    await changeAddressPage.assertUrlContains('/mailbox');
  });

  test('Ensure user is able to update address manually @Smoke', async () => {
    await changeAddressPage.assertElementVisible(changeAddressPage.houseNumberInput);
    await changeAddressPage.changeAddressManuallyLink.click();
    await changeAddressPage.assertUrlContains(changeAddressPage.changeAddressManualRoute);

    await changeAddressPage.setAddress(
      'address line 1',
      'address line 2',
      'address line 3',
      'Brighton',
      'BN19JY',
    );

    await changeAddressPage.saveChangesButton.click();
    await changeAddressPage.assertUrlContains(changeAddressPage.changeAddressManualRoute);
    await changeAddressPage.confirmButton.click();
    await changeAddressPage.assertUrlContains(changeAddressPage.contactDetailsRoute);
    await expect(contactDetailsPage.postcodeDataPointValue).toHaveText('BN19JY');
  });
});
