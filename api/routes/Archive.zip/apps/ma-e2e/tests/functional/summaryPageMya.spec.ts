import test, { expect } from '@playwright/test';
import { IS_MOCKED } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ProductDetailsPage } from '../../pageobjects/productDetails.po';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe.parallel('Summary Page test set one - MYA', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let summaryPage: SummaryPage;
  let productDetailsPage: ProductDetailsPage;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    summaryPage = new SummaryPage(page);
    productDetailsPage = new ProductDetailsPage(page);
  });

  test('Verify MYA product card on MyAccount PSP - Pension plan with regular contributions only @Smoke', async ({
    page,
  }) => {
    await loginPage.login('2366456031', 'Test2test');

    // assertions for page header, product name, pension acount number, date
    await summaryPage.assertElementVisible(summaryPage.summaryPageHeader);
    await expect(summaryPage.summaryPageHeader).toContainText(summaryPage.SIPPHeaderText);
    await summaryPage.assertElementVisible(summaryPage.productName);
    await summaryPage.assertElementVisible(summaryPage.productId);
    await summaryPage.assertElementVisible(summaryPage.productData);

    // assertion for product valuation
    await summaryPage.assertElementVisible(summaryPage.productValuation);
    await expect(summaryPage.productValuation).toContainText('£');

    // assertion for Last contribution amount label and the value in pounds under it
    await summaryPage.assertElementVisible(
      summaryPage.filterLabels('Last contribution amount'),
    );

    await summaryPage.assertElementVisible(summaryPage.productDataPointValueCurrency);
    await expect(summaryPage.productDataPointValueCurrency).toContainText('£');

    // assertion fo Last contribution date and the date appears under the label in correct format
    await summaryPage.assertElementVisible(
      summaryPage.filterLabels('Last contribution date'),
    );

    await summaryPage.assertElementVisible(summaryPage.productDataPointValueDate);
    const dateElement = await summaryPage.productDataPointValueDate.textContent();

    // assertion for Retirement age displayed in the correct format
    await summaryPage.assertElementVisible(summaryPage.filterLabels('Retirement age'));
    await summaryPage.assertElementVisible(summaryPage.productDataPointValueText);
    await expect(summaryPage.productDataPointValueText).toContainText('years');

    expect(await summaryPage.productQuickActionLinks.count()).toBeGreaterThanOrEqual(1);

    if (page.url().includes('localhost:4200')) {
      return;
    } else {
      await summaryPage.productLink.click();
      await summaryPage.assertElementVisible(summaryPage.myaHeadingCard);
    }
  });

  test('Verify "Manage my pension" quick link MYA product card on MyAccount PSP for regular contributions user @NotYetMocked', async () => {
    await loginPage.login('2366456031', 'Test2test');

    await summaryPage.assertElementVisible(summaryPage.summaryPageHeader);
    await productDetailsPage.manageMyPensionLink.click();
    await summaryPage.assertElementVisible(summaryPage.pensionSummaryPage);
    await expect(summaryPage.pensionSummaryPage).toHaveAttribute('aria-selected', 'true');
  });

  test('Verify "View transactions" quick link MYA product card on MyAccount PSP for regular contributions user @NotYetMocked', async () => {
    await loginPage.login('2366456031', 'Test2test');

    await summaryPage.assertElementVisible(summaryPage.summaryPageHeader);
    await productDetailsPage.viewTransactionsLink.click();
    await summaryPage.assertElementVisible(summaryPage.transactionsPage);
    await expect(summaryPage.transactionsPage).toHaveAttribute('aria-selected', 'true');
  });

  test('Verify MYA product card on MyAccount PSP - Error correction @Smoke', async () => {
    await loginPage.login('2036035031', 'Test2test');

    // assert pension product name, pension account number, product valuation unavailable, information note ribbon,
    await summaryPage.assertElementVisible(summaryPage.productName);
    await summaryPage.assertElementVisible(summaryPage.productId);
    await summaryPage.assertElementVisible(summaryPage.productValuationUnavailable);
    await summaryPage.assertElementVisible(summaryPage.informationNoteRibbon);

    // assertion for Retirement age displayed in the correct format
    await summaryPage.assertElementVisible(summaryPage.filterLabels('Retirement age'));
    await summaryPage.assertElementVisible(summaryPage.yearsDataPoint);
    await expect(summaryPage.yearsDataPoint).toContainText('years');
  });

  test('Verify MYA product card on MyAccount PSP - Generic @Smoke', async () => {
    await loginPage.login('2107221031', 'Test3test');

    /* assert pension product name, pension account number, product valuation unavailable,
    information note ribbon, last contribution ammount*/
    await summaryPage.assertElementVisible(summaryPage.productName);
    await summaryPage.assertElementVisible(summaryPage.productId);
    await summaryPage.assertElementVisible(summaryPage.productValuationUnavailable);

    await expect(summaryPage.productValuationUnavailable).toHaveText(
      'Temporarily unavailable',
    );

    await summaryPage.assertElementVisible(summaryPage.informationNoteRibbon);

    // assertion for Last contribution amount label and the value in pounds under it
    await summaryPage.assertElementVisible(
      summaryPage.filterLabels('Last contribution amount'),
    );

    await summaryPage.assertElementVisible(summaryPage.productDataPointValueCurrency);
    await expect(summaryPage.productDataPointValueCurrency).toContainText('£');

    // assertion fo Last contribution date and the date appears under the label in correct format
    await summaryPage.assertElementVisible(
      summaryPage.filterLabels('Last contribution amount'),
    );

    await summaryPage.assertElementVisible(summaryPage.productDataPointValueCurrency);
    await expect(summaryPage.productDataPointValueCurrency).toContainText('£');

    // assertion for Retirement age displayed in the correct format
    await summaryPage.assertElementVisible(summaryPage.filterLabels('Retirement age'));
    await summaryPage.assertTextExists('70 years');

    expect(await summaryPage.productQuickActionLinks.count()).toBeGreaterThanOrEqual(1);

    if (IS_MOCKED) {
      return;
    } else {
      await summaryPage.productLink.click();
      await summaryPage.assertElementVisible(summaryPage.myaHeadingCard);
    }
  });

  test('Verify "Manage my pension" quick link MYA product card on MyAccount PSP for generic user @NotYetMocked', async () => {
    await loginPage.login('2107221031', 'Test3test');

    await summaryPage.assertElementVisible(summaryPage.summaryPageHeader);
    await productDetailsPage.manageMyPensionLink.click();
    await summaryPage.assertElementVisible(summaryPage.pensionSummaryPage);
    await expect(summaryPage.pensionSummaryPage).toHaveAttribute('aria-selected', 'true');
  });

  test('Verify "View Documents" quick link MYA product card on MyAccount PSP for regular contributions user @Smoke', async () => {
    await loginPage.login('2366456031', 'Test2test');

    await summaryPage.assertElementVisible(summaryPage.summaryPageHeader);
    await summaryPage.assertTextExists('View Documents');
    const viewDocumentsLink = await summaryPage.productQuickActionLinks
      .nth(2)
      .getAttribute('href');

    expect(viewDocumentsLink).toContain(summaryPage.notificationDocumentLink);
  });
});
