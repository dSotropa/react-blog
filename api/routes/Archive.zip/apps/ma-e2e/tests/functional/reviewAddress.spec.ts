import test from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ChangeAddressPage } from '../../pageobjects/changeAddress.po';
import { ReviewAddressPage } from '../../pageobjects/reviewAddress.po';

test.describe.parallel('Review address interstitial', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let reviewAddressPage: ReviewAddressPage;
  let changeAddressPage: ChangeAddressPage;

  test.beforeEach(async ({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    reviewAddressPage = new ReviewAddressPage(page);
    changeAddressPage = new ChangeAddressPage(page);
    await loginPage.login('bvmuemcqn4', 'Pass1pass');
  });

  // actually these tests are passing in playwright, but in protractor they are ignored
  // need to verify if they are correct accordingly to the ticket SSP-1322

  test('Verify interstitial is displayed to a gone away user @Smoke', async () => {
    await reviewAddressPage.assertUrlContains(reviewAddressPage.route);
    await reviewAddressPage.assertElementVisible(reviewAddressPage.currentAddress);
  });

  test('Ensure user can choose to confirm their address @Smoke', async () => {
    await reviewAddressPage.assertUrlContains(reviewAddressPage.route);
    await reviewAddressPage.assertElementVisible(reviewAddressPage.currentAddress);
    await reviewAddressPage.confirmAddressBtn.click();
    await reviewAddressPage.assertUrlContains(reviewAddressPage.summaryPageRoute);
  });

  test('Ensure user can choose to change their address @Smoke', async () => {
    await reviewAddressPage.assertUrlContains(reviewAddressPage.route);
    await reviewAddressPage.assertElementVisible(reviewAddressPage.currentAddress);
    await reviewAddressPage.changeAddressBtn.click();
    await reviewAddressPage.assertUrlContains(reviewAddressPage.changeAddressSearchPage);
  });
});
