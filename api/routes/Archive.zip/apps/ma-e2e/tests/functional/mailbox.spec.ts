import test, { expect } from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { MailboxPage } from '../../pageobjects/mailbox.po';
import { SummaryPage } from '../../pageobjects/summaryPage.po';
import { Support } from '../../pageobjects/support.po';

test.describe.parallel('Mailbox tests', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let summaryPage: SummaryPage;
  let mailboxPage: MailboxPage;
  let support: Support;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    mailboxPage = new MailboxPage(page);
    summaryPage = new SummaryPage(page);
    support = new Support(page);
  });

  test('Verify user is able to navigate to Mailbox page @Smoke', async () => {
    await loginPage.login('DCJtestdata1', 'Test2test');

    // navigate to Mailbox page
    await summaryPage.navMenuMailbox.click();
    await summaryPage.assertUrlContains('/mailbox');
  });

  test('Ensure user can send a message @NotYetMocked', async () => {
    await loginPage.login('7b7qtpmnqf', 'Test2test');

    // navigate to Mailbox page
    await summaryPage.navMenuMailbox.click();
    await summaryPage.assertUrlContains('/mailbox');

    await mailboxPage.composeMessageBtn.click();

    await mailboxPage.selectFromDropdown(
      mailboxPage.chooseProductDropDown,
      'Anything else',
    );

    await mailboxPage.selectFromDropdown(
      mailboxPage.chooseSubjectDropDown,
      'Anything else',
    );

    await mailboxPage.assertElementVisible(mailboxPage.textMessageArea);
    await mailboxPage.enterTextMessage();
    await mailboxPage.sendMessageBtn.click();
    await mailboxPage.assertElementVisible(mailboxPage.composeSuccessMessage);
  });

  test('Ensure user can reply to a message @NotYetMocked', async () => {
    await loginPage.login('7b7qtpmnqf', 'Test2test');

    // navigate to Mailbox page
    await summaryPage.navMenuMailbox.click();
    await summaryPage.assertUrlContains('/mailbox');

    await mailboxPage.firstConversation.click();
    await mailboxPage.firstMessage.click();
    await mailboxPage.replyBtn.click();

    await mailboxPage.assertElementVisible(mailboxPage.textMessageArea);
    await mailboxPage.enterTextMessage();
    await mailboxPage.sendMessageBtn.click();
    await mailboxPage.assertElementVisible(mailboxPage.composeSuccessMessage);
  });

  test('Verify Support widget for LGI @NotYetMocked', async () => {
    await loginPage.login('myatest50', 'Testing1all');

    // navigate to Mailbox page
    await summaryPage.navMenuMailbox.click();
    await summaryPage.assertUrlContains('/mailbox');

    expect(await mailboxPage.getKbCardsCount()).toEqual(2);
    await mailboxPage.assertTextExists('Life Cover Help');
    await mailboxPage.getKnowledgeBaseCardButton('Life Cover Help').click();
    await support.assertElementVisible(support.boldWidget);
    await support.closeButtonBold.click();
    await support.assertElementVisible(support.helpButton);

    await mailboxPage.assertTextExists('General Help');
    await mailboxPage.getKnowledgeBaseCardButton('General Help').click();
    await support.closeButtonNanorep.click();
    await support.assertElementVisible(support.helpButton);
  });

  test('Verify Support widget for LGR - annuities @NotYetMocked', async () => {
    await loginPage.login('myat10two', 'Test1test');

    // navigate to Mailbox page
    await summaryPage.navMenuMailbox.click();
    await summaryPage.assertUrlContains('/mailbox');

    expect(await mailboxPage.getKbCardsCount()).toEqual(2);
    await mailboxPage.assertTextExists('Annuity');
    await mailboxPage.getKnowledgeBaseCardButton('Annuity').click();
    await support.assertTextExists('Help & Support');
    await support.assertElementVisible(support.nanorepWidget);
    await support.closeButtonNanorep.click();
    await support.assertElementVisible(support.helpButton);

    await mailboxPage.assertTextExists('General Help');
    await mailboxPage.getKnowledgeBaseCardButton('General Help').click();
    await support.closeButtonNanorep.click();
    await support.assertElementVisible(support.helpButton);
  });

  test('Verify Support widget for PI ISA and personal pension @NotYetMocked', async () => {
    await loginPage.login('uatven94@test.com', 'Chr1stma5@2020');

    // navigate to Mailbox page
    await summaryPage.navMenuMailbox.click();
    await summaryPage.assertUrlContains('/mailbox');

    expect(await mailboxPage.getKbCardsCount()).toEqual(3);
    await mailboxPage.assertTextExists('Personal Pensions Help');
    await mailboxPage.getKnowledgeBaseCardButton('Personal Pensions Help').click();
    await support.assertElementVisible(support.boldWidget);
    await support.closeButtonBold.click();
    await support.assertElementVisible(support.helpButton);

    await mailboxPage.assertTextExists('Legal & General ISA');
    await mailboxPage.getKnowledgeBaseCardButton('Legal & General ISA').click();
    await support.assertElementVisible(support.boldWidget);
    await support.closeButtonBold.click();
    await support.assertElementVisible(support.helpButton);

    await mailboxPage.assertTextExists('General Help');
    await mailboxPage.getKnowledgeBaseCardButton('General Help').click();
    await support.assertElementVisible(support.nanorepWidget);
    await support.closeButtonNanorep.click();
    await support.assertElementVisible(support.helpButton);
  });

  test('Verify Support widget for MYA @NotYetMocked', async () => {
    await loginPage.login('2366456031', 'Test2test');

    // navigate to Mailbox page
    await summaryPage.navMenuMailbox.click();
    await summaryPage.assertUrlContains('/mailbox');

    await mailboxPage.assertTextExists('General Help');
    await mailboxPage.getKnowledgeBaseCardButton('General Help').click();
    await support.closeButtonNanorep.click();
    await support.assertElementVisible(support.helpButton);
  });

  test('Verify Support widget for Invesments product/TAWeb @NotYetMocked', async () => {
    await loginPage.login('invest01', 'Test2test');

    // navigate to Mailbox page
    await summaryPage.navMenuMailbox.click();
    await summaryPage.assertUrlContains('/mailbox');

    expect(await mailboxPage.getKbCardsCount()).toEqual(2);
    await mailboxPage.assertTextExists('Investments Help');
    await mailboxPage.getKnowledgeBaseCardButton('Investments Help').click();
    await support.assertTextExists('Investments support');
    await support.assertElementVisible(support.boldWidget);
    await support.closeButtonBold.click();
    await support.assertElementVisible(support.helpButton);

    await mailboxPage.assertTextExists('General Help');
    await mailboxPage.getKnowledgeBaseCardButton('General Help').click();
    await support.closeButtonNanorep.click();
    await support.assertElementVisible(support.helpButton);
  });
});
