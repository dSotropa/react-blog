import test, { expect } from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ProductDetailsPage } from '../../pageobjects/productDetails.po';
import { ChangeBank } from '../../pageobjects/changeBank.po';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe.parallel('Summary Page test - Lifetime Annuities', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let productDetailsPage: ProductDetailsPage;
  let changeBankPage: ChangeBank;
  let summaryPage: SummaryPage;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    productDetailsPage = new ProductDetailsPage(page);
    changeBankPage = new ChangeBank(page);
    summaryPage = new SummaryPage(page);
  });

  test('Verify there is an active overview tab @NotYetMocked', async () => {
    await loginPage.login('f4qebq8p5t', 'Test2test');
    await summaryPage.productName.click();
    await productDetailsPage.isTabActive(productDetailsPage.overviewTab);
    await productDetailsPage.assertUrlContains('/Overview');
    expect(await productDetailsPage.supportArticles.count()).toBeGreaterThanOrEqual(1);
    await productDetailsPage.supportArticles.first().click();

    // assert that bold chat opens up with the correct
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContent);
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContentTitle);

    await expect(changeBankPage.boldChatContentTitle).toContainText(
      'Can I change my tax code?',
    );
  });

  test('Verify switching to payments and tax tab @NotYetMocked', async () => {
    await loginPage.login('f4qebq8p5t', 'Test2test');
    await summaryPage.productName.click();
    await productDetailsPage.isTabActive(productDetailsPage.overviewTab);
    await productDetailsPage.clickPaymentsTab();
    await productDetailsPage.isTabActive(productDetailsPage.paymentsTab);
    await productDetailsPage.assertUrlContains('/Payment');

    expect(await productDetailsPage.supportArticles.count()).toBeGreaterThanOrEqual(1);
    await productDetailsPage.supportArticles.first().click();

    // assert that bold chat opens up with the correct
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContent);
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContentTitle);

    await expect(changeBankPage.boldChatContentTitle).toContainText(
      'Can I change my tax code?',
    );
  });

  test('Verify switching to documents tab for lifetime annuities @NotYetMocked', async () => {
    await loginPage.login('f4qebq8p5t', 'Test2test');
    await summaryPage.productName.click();
    await productDetailsPage.isTabActive(productDetailsPage.overviewTab);
    await productDetailsPage.clickDocumentsTab();
    await productDetailsPage.isTabActive(productDetailsPage.paymentsTab);
    await productDetailsPage.assertUrlContains('/Documents');

    expect(await productDetailsPage.supportArticles.count()).toBeGreaterThanOrEqual(1);
    await productDetailsPage.supportArticles.first().click();

    // assert that bold chat opens up with the correct
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContent);
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContentTitle);

    await expect(changeBankPage.boldChatContentTitle).toContainText(
      'Can I change my tax code?',
    );
  });
});
