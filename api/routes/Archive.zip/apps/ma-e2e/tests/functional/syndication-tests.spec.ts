import test, { expect } from '@playwright/test';

import { SummaryPage } from '../../pageobjects/summaryPage.po';
import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { LogoutPage } from '../../models/logoutpage';

test.describe.parallel('Syndicated Sites', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let summaryPage: SummaryPage;
  let logoutPage: LogoutPage;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    summaryPage = new SummaryPage(page);
    logoutPage = new LogoutPage(page);
  });

  test('Branding checks for Barclays site @NotYetMocked', async ({ page }) => {
    await loginPage.login(
      'SF_7407_Barclays',
      'Test02test',
      true,
      'https://barclays.preprod.myaccount.platform.landg.com',
    );

    await summaryPage.assertElementVisible(summaryPage.productName);
    await summaryPage.assertElementNotVisible(summaryPage.navMenuRewards);
    await summaryPage.assertElementVisible(summaryPage.productContainer);
    await summaryPage.assertUrlContains('barclays');
    await logoutPage.ensureLoggedOut();
    await summaryPage.assertElementVisible(summaryPage.pageContent);
    await expect(summaryPage.pageContent).toContainText(summaryPage.logoutSuccessText);

    await expect(logoutPage.goToHomePage).toHaveAttribute(
      'href',
      'https://www.barclays.co.uk',
    );
  });

  test('Branding checks for Nationwide site @NotYetMocked', async ({ page }) => {
    await loginPage.login(
      'elvgv2qfv4',
      'Test2test',
      true,
      'https://nationwide.preprod.myaccount.platform.landg.com',
    );

    await summaryPage.assertElementVisible(summaryPage.productName);
    await summaryPage.assertElementNotVisible(summaryPage.navMenuRewards);
    await summaryPage.assertElementVisible(summaryPage.productContainer);
    await summaryPage.assertUrlContains('nationwide');
    await logoutPage.ensureLoggedOut();
    await summaryPage.assertElementVisible(summaryPage.pageContent);
    await expect(summaryPage.pageContent).toContainText(summaryPage.logoutSuccessText);

    await expect(logoutPage.goToHomePage).toHaveAttribute(
      'href',
      'https://www.nationwide.co.uk',
    );
  });

  test('Branding checks for Sainsburys site with Sainsburys use @NotYetMocked', async ({
    page,
  }) => {
    await loginPage.login(
      'sainsburysd2c',
      'Test2test',
      true,
      'https://sainsburysbank.preprod.myaccount.platform.landg.com',
    );

    await summaryPage.assertElementVisible(summaryPage.productName);
    await summaryPage.assertElementNotVisible(summaryPage.navMenuRewards);
    await summaryPage.assertElementVisible(summaryPage.productContainer);
    await summaryPage.assertUrlContains('sainsburysbank');
    await logoutPage.ensureLoggedOut();
    await summaryPage.assertElementVisible(summaryPage.pageContent);
    await expect(summaryPage.pageContent).toContainText(summaryPage.logoutSuccessText);

    await expect(logoutPage.goToHomePage).toHaveAttribute(
      'href',
      'https://www.sainsburysbank.co.uk/',
    );
  });

  test('Branding checks for Sainsburys site with non Sainsburys user @NotYetMocked', async ({
    page,
  }) => {
    await loginPage.login(
      'elvgv2qfv4',
      'Test2test',
      true,
      'https://sainsburysbank.preprod.myaccount.platform.landg.com',
    );

    await summaryPage.assertElementNotVisible(summaryPage.productName);
    await summaryPage.assertElementNotVisible(summaryPage.navMenuRewards);
    await summaryPage.assertElementVisible(summaryPage.productContainer);
    await summaryPage.assertUrlContains('sainsburysbank');
    await logoutPage.ensureLoggedOut();
    await summaryPage.assertElementVisible(summaryPage.pageContent);
    await expect(summaryPage.pageContent).toContainText(summaryPage.logoutSuccessText);

    await expect(logoutPage.goToHomePage).toHaveAttribute(
      'href',
      'https://www.sainsburysbank.co.uk/',
    );
  });
});
