import test, { expect } from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ContactDetailsPage } from '../../pageobjects/contactDetails.po';
import { PersonalDetailsPage } from '../../pageobjects/personalDetails.po';

test.describe.parallel('Contact details tests', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let contactDetailsPage: ContactDetailsPage;
  let personalDetailsPage: PersonalDetailsPage;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    contactDetailsPage = new ContactDetailsPage(page);
    personalDetailsPage = new PersonalDetailsPage(page);
  });

  test('Ensure user is able to save mobile phone number @Smoke', async () => {
    await loginPage.login(
      '72r3uk5c2k',
      'Test2test',
      true,
      contactDetailsPage.contactDetailsRoute,
    );

    await contactDetailsPage.assertElementVisible(contactDetailsPage.contactDetails);

    await contactDetailsPage.setInputValue(
      contactDetailsPage.phoneDetailsMobileInput,
      '01273456789',
    );

    await contactDetailsPage.emailDetailsSaveButton.click();

    await contactDetailsPage.assertElementVisible(
      contactDetailsPage.phoneDetailsMobileSuccess,
    );
  });

  test('Ensure user is able to save home phone number @Smoke', async () => {
    await loginPage.login(
      '72r3uk5c2k',
      'Test2test',
      true,
      contactDetailsPage.contactDetailsRoute,
    );

    await contactDetailsPage.assertElementVisible(contactDetailsPage.contactDetails);

    await contactDetailsPage.setInputValue(
      contactDetailsPage.phoneDetailsHomeInput,
      '01273456789',
    );

    await contactDetailsPage.phoneDetailsSaveButton.click();

    await contactDetailsPage.assertElementVisible(
      contactDetailsPage.phoneDetailsHomeSuccess,
    );
  });

  test('Ensure user is able to save work phone number @Smoke', async () => {
    await loginPage.login(
      '72r3uk5c2k',
      'Test2test',
      true,
      contactDetailsPage.contactDetailsRoute,
    );

    await contactDetailsPage.assertElementVisible(contactDetailsPage.contactDetails);

    await contactDetailsPage.setInputValue(
      contactDetailsPage.phoneDetailsWorkInput,
      '01273456789',
    );

    await contactDetailsPage.phoneDetailsSaveButton.click();

    await contactDetailsPage.assertElementVisible(
      contactDetailsPage.phoneDetailsWorkSuccess,
    );
  });

  test('Ensure user is able to save personal email address @Smoke', async () => {
    await loginPage.login(
      '72r3uk5c2k',
      'Test2test',
      true,
      contactDetailsPage.contactDetailsRoute,
    );

    await contactDetailsPage.assertElementVisible(contactDetailsPage.contactDetails);

    await contactDetailsPage.setInputValue(
      contactDetailsPage.emailDetailsPersonalInput,
      'testing@test.com',
    );

    await contactDetailsPage.phoneDetailsMobileSuccess.click();

    await contactDetailsPage.assertElementVisible(
      contactDetailsPage.emailDetailsPersonalSuccess,
    );

    await contactDetailsPage.navigateToSummaryPage();
    await expect(contactDetailsPage.personalEmail).toHaveValue('testing@test.com');
  });

  test('Ensure user is able to save work email address @Smoke', async () => {
    await loginPage.login(
      'greendani1000',
      'Pass1pass',
      true,
      contactDetailsPage.contactDetailsRoute,
    );

    await contactDetailsPage.assertElementVisible(contactDetailsPage.contactDetails);

    await contactDetailsPage.setInputValue(
      contactDetailsPage.emailDetailsWorkInput,
      'testing@test.com',
    );

    await contactDetailsPage.phoneDetailsMobileSuccess.click();

    await contactDetailsPage.assertElementVisible(
      contactDetailsPage.emailDetailsWorkSuccess,
    );
  });

  test('Ensure user with single locked workplace product cannot edit address or work email @Smoke', async () => {
    await loginPage.login(
      'BBG3NQTY0',
      'Test2test',
      true,
      contactDetailsPage.contactDetailsRoute,
    );

    await contactDetailsPage.assertElementVisible(contactDetailsPage.contactDetails);

    await contactDetailsPage.assertElementVisible(
      contactDetailsPage.phoneDetailsMobileInput,
    );

    await contactDetailsPage.assertElementVisible(
      contactDetailsPage.phoneDetailsHomeInput,
    );

    await contactDetailsPage.assertElementVisible(
      contactDetailsPage.phoneDetailsWorkInput,
    );

    await contactDetailsPage.assertElementVisible(
      contactDetailsPage.emailDetailsPersonalInput,
    );

    await contactDetailsPage.assertElementVisible(
      contactDetailsPage.emailDetailsWorkReadOnlyAlert,
    );

    await contactDetailsPage.assertElementNotVisible(
      contactDetailsPage.emailDetailsWorkInput,
    );

    await contactDetailsPage.assertElementVisible(
      contactDetailsPage.changeAddressReadOnlyAlert,
    );

    await contactDetailsPage.assertElementNotVisible(
      contactDetailsPage.changeAddressButton,
    );
  });

  test('Ensure user with single open workplace product can edit contract details @Smoke', async () => {
    await loginPage.login(
      'test_test_kt',
      'Test2test',
      true,
      contactDetailsPage.contactDetailsRoute,
    );

    await contactDetailsPage.assertElementVisible(contactDetailsPage.contactDetails);

    await contactDetailsPage.assertElementVisible(
      contactDetailsPage.phoneDetailsMobileInput,
    );

    await contactDetailsPage.assertElementVisible(
      contactDetailsPage.phoneDetailsHomeInput,
    );

    await contactDetailsPage.assertElementVisible(
      contactDetailsPage.phoneDetailsWorkInput,
    );

    await contactDetailsPage.assertElementVisible(
      contactDetailsPage.emailDetailsPersonalInput,
    );

    await contactDetailsPage.assertElementNotVisible(
      contactDetailsPage.emailDetailsWorkReadOnlyAlert,
    );

    await contactDetailsPage.assertElementVisible(
      contactDetailsPage.emailDetailsWorkInput,
    );

    await contactDetailsPage.assertElementNotVisible(
      contactDetailsPage.changeAddressReadOnlyAlert,
    );

    await contactDetailsPage.assertElementVisible(contactDetailsPage.changeAddressButton);
  });

  test('Ensure user is able to save marital status @Smoke', async ({ page }) => {
    await loginPage.login(
      '72r3uk5c2k',
      'Test2test',
      true,
      '#/account-details/personal-details',
    );

    await personalDetailsPage.selectFromDropdown(
      personalDetailsPage.maritalStatusDropdown,
      'Married',
    );

    await personalDetailsPage.assertElementVisible(
      personalDetailsPage.maritalStatusUpdateSuccess,
    );
  });
});
