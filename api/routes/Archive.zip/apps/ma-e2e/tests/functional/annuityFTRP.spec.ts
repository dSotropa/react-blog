import test, { expect } from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { ProductDetailsPage } from '../../pageobjects/productDetails.po';
import { SummaryPage } from '../../pageobjects/summaryPage.po';
import { ChangeBank } from '../../pageobjects/changeBank.po';

test.describe.parallel('Summary Page test - Annuities FTRP', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let productDetailsPage: ProductDetailsPage;
  let summaryPage: SummaryPage;
  let changeBankPage: ChangeBank;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    productDetailsPage = new ProductDetailsPage(page);
    summaryPage = new SummaryPage(page);
    changeBankPage = new ChangeBank(page);
  });

  test('Verify there is an active overview tab @NotYetMocked', async () => {
    await loginPage.loginViaSeal('BBL3WNWY0', 'Test1test');
    await summaryPage.productName.click();
    await productDetailsPage.isTabActive(productDetailsPage.overviewTab);
    await productDetailsPage.assertUrlContains('/Overview');
    expect(await productDetailsPage.supportArticles.count()).toBeGreaterThanOrEqual(1);
    await productDetailsPage.supportArticles.first().click();

    // assert that bold chat opens up with the correct
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContent);
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContentTitle);

    await expect(changeBankPage.boldChatContentTitle).toContainText(
      'Can I change my tax code?',
    );
  });

  test('Verify switching to payments and tax tab @NotYetMocked', async () => {
    await loginPage.login('BBL3WNWY0', 'Test1test');
    await summaryPage.productName.click();
    await productDetailsPage.isTabActive(productDetailsPage.overviewTab);
    await productDetailsPage.clickPaymentsTab();
    await productDetailsPage.isTabActive(productDetailsPage.paymentsTab);
    await productDetailsPage.assertUrlContains('/Payment');

    expect(await productDetailsPage.supportArticles.count()).toBeGreaterThanOrEqual(1);
    await productDetailsPage.supportArticles.first().click();

    // assert that bold chat opens up with the correct
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContent);
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContentTitle);

    await expect(changeBankPage.boldChatContentTitle).toContainText(
      'Can I change my tax code?',
    );
  });

  test('Verify switching to documents tab for annuities FTRP @NotYetMocked', async () => {
    await loginPage.login('BBL3WNWY0', 'Test1test');
    await summaryPage.productName.click();
    await productDetailsPage.isTabActive(productDetailsPage.overviewTab);
    await productDetailsPage.clickDocumentsTab();
    await productDetailsPage.isTabActive(productDetailsPage.paymentsTab);
    await productDetailsPage.assertUrlContains('/Documents');

    expect(await productDetailsPage.supportArticles.count()).toBeGreaterThanOrEqual(1);
    await productDetailsPage.supportArticles.first().click();

    // assert that bold chat opens up with the correct
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContent);
    await changeBankPage.assertElementVisible(changeBankPage.boldChatContentTitle);

    await expect(changeBankPage.boldChatContentTitle).toContainText(
      'Can I change my tax code?',
    );
  });

  test('Verify Annuities FTRP product has confirmation Transferability copy displayed @Smoke', async () => {
    await loginPage.login('BBVTGF6Y0', 'Test1test');
    await summaryPage.productName.click();
    await productDetailsPage.isTabActive(productDetailsPage.overviewTab);

    // assert confirmation transferability text
    await productDetailsPage.assertElementVisible(
      productDetailsPage.productDescriptionMessage,
    );

    await expect(productDetailsPage.productDescriptionMessage).toContainText(
      productDetailsPage.confirmationTransferabilityTextFTRP,
    );
  });

  test('Verify Annuities FTRP product has deny Transferability copy displayed @Smoke', async () => {
    await loginPage.login('BBL3WNWY0', 'Test1test');
    await summaryPage.productName.click();
    await productDetailsPage.isTabActive(productDetailsPage.overviewTab);

    // assert confirmation transferability text
    await productDetailsPage.assertElementVisible(
      productDetailsPage.productDescriptionMessage,
    );

    await expect(productDetailsPage.productDescriptionMessage).toContainText(
      productDetailsPage.denyTransferabilityTextFTRP,
    );
  });
});
