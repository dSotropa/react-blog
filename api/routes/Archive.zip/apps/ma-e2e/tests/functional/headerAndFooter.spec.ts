import test, { expect } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { HeaderAndFooterPage } from '../../pageobjects/headerAndFooter.po';
import { SummaryPage } from '../../pageobjects/summaryPage.po';

test.describe.parallel('Header Footer tests', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let headerAndFooterPage: HeaderAndFooterPage;
  let pageFunctions: PageFunctions;
  let summaryPage: SummaryPage;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    headerAndFooterPage = new HeaderAndFooterPage(page);
    pageFunctions = new PageFunctions(page);
    summaryPage = new SummaryPage(page);
  });

  test('Header tab existence check and navigation @Smoke', async ({ page }) => {
    await loginPage.login('dhvd879t9e', 'Test2test');
    await headerAndFooterPage.assertElementVisible(summaryPage.navMenuHome);
    await headerAndFooterPage.assertElementVisible(headerAndFooterPage.navFooterLGLogo);

    await summaryPage.assertElementVisible(summaryPage.navMenuHome);
    await expect(summaryPage.navMenuHome).toHaveText('Home');

    await summaryPage.assertElementVisible(summaryPage.navMenuMailbox);
    await expect(summaryPage.navMenuMailbox).toHaveText('Mailbox');

    await summaryPage.assertElementVisible(summaryPage.navMenuRewards);
    await expect(summaryPage.navMenuRewards).toHaveText('Rewards');

    await summaryPage.assertElementVisible(summaryPage.navMenuSupport);
    await expect(summaryPage.navMenuSupport).toHaveText('Help & Support');

    // navigate to Mailbox Page
    await summaryPage.navMenuMailbox.click();
    await summaryPage.assertUrlContains('/mailbox');

    // navigate to Home Tab My account PSP
    await summaryPage.navigateBackToMAPSP(page);
    await expect(page).toHaveTitle('My Account Home');

    // navigate to Rewards
    await summaryPage.navMenuRewards.click();
    await summaryPage.assertUrlContains('/rewards');

    // navigate to Home Tab My account PSP
    await summaryPage.navigateBackToMAPSP(page);
    await expect(page).toHaveTitle('My Account Home');

    // click on Support tab to open triage widget
    await summaryPage.navMenuSupport.click();
    await summaryPage.assertElementVisible(summaryPage.supportWidget);

    // close triage widget
    await summaryPage.closeSupport.click();
    await summaryPage.assertElementVisible(summaryPage.helpButton);

    // click on notification bell
    await headerAndFooterPage.navMenuNotificationBellIcon.click();

    // click on account details
    await headerAndFooterPage.navMenuAccountDetails.click();
    await headerAndFooterPage.assertUrlContains('/account-details/overview');

    await headerAndFooterPage.navLandGLogo.click();
    await expect(page).toHaveTitle('My Account Home');

    await headerAndFooterPage.assertElementVisible(
      headerAndFooterPage.navMenuNotificationBellIcon,
    );

    await headerAndFooterPage.assertElementVisible(
      headerAndFooterPage.navMenuNotificationsMenu,
    );
  });

  test('Footer tabs existence check and navigation @Smoke', async () => {
    await loginPage.login('dhvd879t9e', 'Test2test');
    await headerAndFooterPage.assertElementVisible(summaryPage.navMenuHome);

    await expect(headerAndFooterPage.accessibilityLink).toHaveText('Accessibility');

    await expect(headerAndFooterPage.legalInformationLink).toHaveText(
      'Legal information',
    );

    await expect(headerAndFooterPage.cookiePolicyLink).toHaveText('Cookie policy');
    await expect(headerAndFooterPage.privacyPolicyLink).toHaveText('Privacy policy');

    await expect(headerAndFooterPage.securityInformationLink).toHaveText(
      'Security information',
    );

    await expect(headerAndFooterPage.accessibilityLink).toHaveAttribute(
      'href',
      headerAndFooterPage.accessibilityHref,
    );

    await expect(headerAndFooterPage.legalInformationLink).toHaveAttribute(
      'href',
      headerAndFooterPage.legalInformationHref,
    );

    // Cookie policy url is null when running agains mock server
    await expect(headerAndFooterPage.privacyPolicyLink).toHaveAttribute(
      'href',
      headerAndFooterPage.privacyPolicyHref,
    );

    await expect(headerAndFooterPage.securityInformationLink).toHaveAttribute(
      'href',
      headerAndFooterPage.securityInformationHref,
    );

    await headerAndFooterPage.assertElementVisible(headerAndFooterPage.navFooterLGLogo);
  });

  test('Ensure opened links from footer section are not broken @Smoke', async ({
    page,
    context,
  }) => {
    await loginPage.login('dhvd879t9e', 'Test2test');
    await headerAndFooterPage.assertElementVisible(summaryPage.navMenuHome);

    await expect(headerAndFooterPage.accessibilityLink).toHaveText('Accessibility');

    await expect(headerAndFooterPage.accessibilityLink).toHaveAttribute(
      'href',
      headerAndFooterPage.accessibilityHref,
    );

    await expect(headerAndFooterPage.legalInformationLink).toHaveText(
      'Legal information',
    );

    await expect(headerAndFooterPage.legalInformationLink).toHaveAttribute(
      'href',
      headerAndFooterPage.legalInformationHref,
    );

    await expect(headerAndFooterPage.privacyPolicyLink).toHaveText('Privacy policy');

    await expect(headerAndFooterPage.privacyPolicyLink).toHaveAttribute(
      'href',
      headerAndFooterPage.privacyPolicyHref,
    );

    await expect(headerAndFooterPage.securityInformationLink).toHaveText(
      'Security information',
    );

    await expect(headerAndFooterPage.securityInformationLink).toHaveAttribute(
      'href',
      headerAndFooterPage.securityInformationHref,
    );

    await expect(headerAndFooterPage.cookiePolicyLink).toHaveText('Cookie policy');
    await headerAndFooterPage.assertElementVisible(headerAndFooterPage.navFooterLGLogo);
  });
});
