import test from '@playwright/test';

import { BasePage } from '../../models/basepage';
import { LoginPage } from '../../models/loginpage';
import { SummaryPage } from '../../pageobjects/summaryPage.po';
import { ProductDetailsPage } from '../../pageobjects/productDetails.po';

test.describe.parallel('Youtube tests - LTA', () => {
  let basePage: BasePage;
  let loginPage: LoginPage;
  let summaryPage: SummaryPage;
  let productDetailsPage: ProductDetailsPage;

  test.beforeEach(({ page }) => {
    basePage = new BasePage(page);
    loginPage = basePage.loginPage;
    summaryPage = new SummaryPage(page);
    productDetailsPage = new ProductDetailsPage(page);
  });

  test.skip('Ensure user can see youtube link for Annuities - LTA product @Smoke', async () => {
    await loginPage.login('f4qebq8p5t', 'Test2test');

    await summaryPage.assertElementVisible(summaryPage.productId.first());
    await summaryPage.productLink.click();

    await productDetailsPage.assertElementVisible(
      productDetailsPage.annuitiesProductDetailsContainer,
    );

    await productDetailsPage.clickDocumentsTab();
    await productDetailsPage.isTabActive(productDetailsPage.documentsTab);

    await productDetailsPage.assertElementVisible(productDetailsPage.mainYoutubeFrame());

    await productDetailsPage.assertElementVisible(
      productDetailsPage.youtubePlayerLocator(),
    );
  });

  test('Ensure user can play and pause youtube videos for Annuities - LTA product @YoutubeFrame', async ({
    page,
  }) => {
    await loginPage.login('f4qebq8p5t', 'Test2test');

    await summaryPage.assertElementVisible(summaryPage.productId.first());
    await summaryPage.productLink.click();

    await productDetailsPage.assertElementVisible(
      productDetailsPage.annuitiesProductDetailsContainer,
    );

    await productDetailsPage.clickDocumentsTab();
    await productDetailsPage.isTabActive(productDetailsPage.documentsTab);
    await productDetailsPage.assertElementVisible(productDetailsPage.mainYoutubeFrame());

    // start youtube video
    await productDetailsPage.scrollToElement(productDetailsPage.landGFooterLogo);

    await productDetailsPage.assertElementVisible(
      productDetailsPage.youtubeMainPlayBtnLocator(),
    );

    await page.waitForTimeout(3000);

    await productDetailsPage.youtubeMainPlayBtnLocator().click();

    await productDetailsPage.assertElementVisible(
      productDetailsPage.youtubePauseBtnLocator(),
    );

    await productDetailsPage.youtubePauseBtnLocator().click();

    await productDetailsPage.assertElementVisible(
      productDetailsPage.youtubePlayBtnLocator(),
    );

    await productDetailsPage.youtubePlayBtnLocator().click();

    await productDetailsPage.assertElementVisible(
      productDetailsPage.youtubePauseBtnLocator(),
    );
  });
});
