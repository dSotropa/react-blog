import { getConfig } from '@utility-e2e';
import { PlaywrightTestConfig } from '@playwright/test';

const config: PlaywrightTestConfig = getConfig({
  appNameRef: 'ma',
  timeout: 300000,
  port: 4200,
  projects: [
    {
      name: 'SmokeOnly',
      grep: [ /@Smoke/ ],
      use: { channel: 'chrome' },
    },
    {
      name: 'NotYetMockedOnly',
      grep: [ /@NotYetMocked/ ],
      use: { channel: 'chrome' },
    },
    {
      name: 'SmokeAndVisual',
      grep: [ /@Smoke/, /@VisualCheck/ ],
      use: { channel: 'chrome' },
    },
  ],
});

export default config;
