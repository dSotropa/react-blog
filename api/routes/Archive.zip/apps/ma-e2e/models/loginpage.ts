import { Locator, Page } from '@playwright/test';
import { IS_CI, IS_MOCKED, PageFunctions, PATHNAME } from '@utility-e2e';

import { users } from '../support/constants/users';
import { mediumWait } from '../support/constants/wait-times';

export class LoginPage extends PageFunctions {
  readonly page: Page;
  readonly userNameInput: Locator;
  readonly passwordInput: Locator;
  readonly loginButton: Locator;
  readonly cookieBannerAccept: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.userNameInput = page.locator('id=username');
    this.passwordInput = page.locator('id=password');
    this.loginButton = page.locator('id=kc-login');
    this.cookieBannerAccept = page.locator('text=✓ Accept All Cookies');
  }

  async navigate(waitForPageToLoad = true): Promise<void> {
    await this.page.goto(PATHNAME);

    if (waitForPageToLoad) {
      await this.waitForPageToLoad();
    }
  }

  async acceptCookieBanner(): Promise<void> {
    if (process.env.MOCKED?.toLowerCase() === 'true') {
      return;
    } else if (await this.isElementVisible(this.cookieBannerAccept, mediumWait)) {
      await this.cookieBannerAccept.click();
    }
  }

  async login(
    userName: string,
    password: string,
    waitForPageToLoad = true,
    path = '/',
  ): Promise<void> {
    path = PATHNAME === path
      ? path
      : `${PATHNAME.replace(/\/$/, '')}${path}`;

    if (await this.loginViaMockingIfEnabled(userName, password, path)) {
      return;
    }

    await this.loginViaSeal(userName, password, waitForPageToLoad, path);
  }

  async loginViaMockingIfEnabled(
    userName: string,
    password: string,
    path: string,
  ): Promise<boolean> {
    if (IS_MOCKED) {
      await this.logInViaMocking(userName, password, path);

      return true;
    }

    return false;
  }

  async loginViaSeal(
    userName: string,
    password: string,
    waitForPageToLoad = true,
    path = '/',
  ): Promise<void> {
    await this.page.goto(path);
    await this.waitForPageToLoad();

    await this.userNameInput.fill(userName);
    await this.loginButton.click();
    await this.passwordInput.fill(password);
    await this.loginButton.click();
    await this.acceptCookieBanner();

    if (waitForPageToLoad) {
      await this.waitForPageToLoad();
    }
  }

  async logInViaMocking(username: string, password: string, path: string): Promise<void> {
    const user = users.find(
      (u: { username: string; password: string }) =>
        u.username === username && u.password === password,
    );

    if (user == null) {
      throw new Error(
        `Could not find a test user with username: ${username}, password: ${password}`,
      );
    }

    await this.page.goto(`${path}?mockPartyId=${user.partyID}`);
    await this.waitForPageToLoad();

    if (!IS_CI) {
      // The below line makes the tests less flaky when running locally.
      await this.page.waitForTimeout(5000);
    }

    console.log(`Navigated to: ${this.page.url()}`);

    console.log('Logged in via mocking api');
  }
}
