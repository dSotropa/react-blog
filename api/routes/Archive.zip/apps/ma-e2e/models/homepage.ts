import { Locator, Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class HomePage extends PageFunctions {
  readonly navMenuHome: Locator;
  readonly summaryPageHeader: Locator;
  readonly productName: Locator;
  readonly mainContent: Locator;
  readonly editDetails: Locator;
  readonly personalDetails: Locator;
  readonly errorMessage =
    'Sorry, we\'re unable to display your product information at the moment.';
  readonly accountDetailsErrorMessage =
    'Please contact your employer to update your personal details.';

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.navMenuHome = page.locator('id=home-nav-link');

    this.summaryPageHeader = page.locator(
      'xpath=//*[@class="lg-hero-card-title__heading"]',
    );

    this.productName = page.locator('xpath=//*[@class="product__name"]');
    this.mainContent = page.locator('id=main-content');
    this.editDetails = page.locator('text=Edit details');

    this.personalDetails = page.locator(
      'lg-side-nav-bar-item-heading:has-text("Personal details")',
    );
  }
}
