import { Page, Locator } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

export class LogoutPage extends PageFunctions {
  readonly page: Page;
  readonly navMenuToggle: Locator;
  readonly logoutButton: Locator;
  readonly logoutPageBody: Locator;
  readonly loginAgain: Locator;
  readonly goToHomePage: Locator;
  readonly logoutConfirmationText = 'You\'ve successfully logged out';

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.navMenuToggle = page.locator('.primary-nav-toggle');

    this.logoutButton = page.locator(
      '[data-testid="logout-nav-link"].lg-account-menu-item',
    );

    this.logoutPageBody = page.locator('xpath=//*[@class="page-content"]');
    this.loginAgain = page.locator('data-testid=login-again-button');
    this.goToHomePage = page.locator('data-testid=homepage-link');
  }

  async ensureLoggedOut(): Promise<void> {
    await this.logoutButton.click();
    await this.waitForPageToLoad();

    try {
      await this.assertTextExists(this.logoutConfirmationText);
    } catch (error) {
      console.error(`Failed to logout: ${error}`);

      return;
    }

    console.log('Successfully logged out');
  }
}
