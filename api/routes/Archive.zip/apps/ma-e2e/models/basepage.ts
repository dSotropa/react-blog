import { Page } from '@playwright/test';
import { PageFunctions } from '@utility-e2e';

import { HomePage } from './homepage';
import { LoginPage } from './loginpage';
import { LogoutPage } from './logoutpage';

export class BasePage extends PageFunctions {
  readonly loginPage: LoginPage;
  readonly homePage: HomePage;
  readonly logoutPage: LogoutPage;

  constructor(page: Page) {
    super(page);
    this.loginPage = new LoginPage(page);
    this.homePage = new HomePage(page);
    this.logoutPage = new LogoutPage(page);
  }
}
