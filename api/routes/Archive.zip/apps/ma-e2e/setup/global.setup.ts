import { chromium, FullConfig } from '@playwright/test';

import { BasePage } from '../models/basepage';
import { apiCookie, maCookie, sealCookie } from '../support/constants/cookies';

async function globalSetup(config: FullConfig) {
  const { baseURL, storageState } = config.projects[0].use;
  const browser = await chromium.launch();
  const context = await browser.newContext();

  await context.addCookies([ maCookie, sealCookie, apiCookie ]);
  const page = await context.newPage();
  const basePage = new BasePage(page);

  await basePage.loginPage.navigate(baseURL, false);
  await basePage.loginPage.acceptCookieBanner();
  await basePage.loginPage.login('dhvd879t9e', 'Test2test');
  await page.context().storageState({ path: storageState as string });
  await browser.close();
}

export default globalSetup;
