import * as express from 'express';

import {
  setupConfigMocks,
  setupExpressMocksConfig,
  setupForgeRockAuthMocks,
  setupForgeRockCors,
  setupLandingPage,
  setupEpiServerMocks,
} from '@libs/shared/utility-mock-server';

import { setupKeycloakMocks } from './keycloak';
import { setupRestAPIMocks } from './rest-api';

export function setupExpressMocks({
  server,
  port,
  appRefName,
}: setupExpressMocksConfig): void {
  server.use(express.urlencoded({ extended: true }));
  server.use(express.json());

  setupForgeRockCors(server);
  setupForgeRockAuthMocks(server, appRefName);
  setupEpiServerMocks(server);
  setupKeycloakMocks(server);
  setupRestAPIMocks(server);
  setupConfigMocks({ server, appRefName });

  setupLandingPage({
    server,
    port,
    gql: false,
    restApi: true,
    name: 'My Account',
    keycloak: true,
    forgeRockAuth: true,
    forgeRockData: false,
    episerver: true,
  });
}
