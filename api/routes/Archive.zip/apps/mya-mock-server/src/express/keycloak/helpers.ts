import * as moment from 'moment';

function decodeToken(str: string): Record<string, never> {
  str = str.split('.')[1];

  str = str.replace('/-/g', '+');
  str = str.replace('/_/g', '/');

  switch (str.length % 4) {
    case 0:
      break;
    case 2:
      str += '==';
      break;
    case 3:
      str += '=';
      break;
    default:
      throw new Error('Invalid token');
  }

  str = (str + '===').slice(0, str.length + (str.length % 4));
  str = str.replace(/-/g, '+').replace(/_/g, '/');
  str = decodeURIComponent(escape(atob(str)));

  return JSON.parse(str);
}

function encodeToken(token: object): string {
  return btoa(JSON.stringify(token));
}

function atob(a: string): string {
  return Buffer.from(a, 'base64').toString('binary');
}

function btoa(b: string): string {
  return Buffer.from(b).toString('base64');
}

export function replaceNonce(token: string, nonce: string): string {
  const parsed_token = decodeToken(token);
  const exp = Math.ceil(moment().add(1000, 'days').toDate().getTime() / 1000);

  return token.split('.')[0] + '.' + encodeToken({ ...parsed_token, nonce, exp });
}
