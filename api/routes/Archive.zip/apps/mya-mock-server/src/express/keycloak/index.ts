import * as fs from 'fs';

import * as express from 'express';
import * as expressSession from 'express-session';

import { FE_BASE_URL } from '@libs/shared/utility-mock-server';

import { accessToken, idToken, refreshToken } from './tokens';
import { replaceNonce } from './helpers';

export function setupKeycloakMocks(server: express.Application): void {
  server.use(expressSession({ secret: 'Shh, its a secret!' }));

  server.get('/auth/realms/My-Account/protocol/openid-connect/logout', (req, res) => {
    res.redirect(`${FE_BASE_URL}/logged-out`);
  });

  server.get('/auth/realms/My-Account/protocol/openid-connect/auth', function(req, res) {
    res.setHeader('content-type', 'text/html');

    (req.session as any).lastNonce = req.query.nonce;

    req.res.redirect(
      `${req.query.redirect_uri}#state=${req.query.state}&session_state=ef4906c8-0da9-4a88-b569-e039fbe5229d&code=eyJhbGciOiJkaXIiLCJlbmMiOiJBMTI4Q0JDLUhTMjU2In0..pbeddVp6nDrS0lOFpPplag.2NXQgF8yJJjs3WiAxDyRoqEqC-tr-xx3rpozteUkqJDy6cOvy88_7_w0EA2aNQrfe_Mm3VFkcXK7-Z0DPMK2Uj7D88Lu10Jzl6i0k2Ag5xxeUbAi-mC5CxpKwQ1B3Xcub4IqEoPFw7yYpZSTCvLZ976QGogLqbt9RF71KScu9x9mQEyEIGMLtXmdXHgGKkvPlB8tQ5Zliqj6zSvcqcF1yOpb_ozjbDfSDoPZ2LaP2ylJll57TR-V4Sv78AIbgMYl.ht8Ti619HzajaX31PuFBng`,
    );
  });

  server.get(
    '/auth/realms/My-Account/protocol/openid-connect/login-status-iframe.html',
    function(req, res) {
      res.setHeader('content-type', 'text/html');

      fs.createReadStream(__dirname + '/assets/keycloak/login-status-iframe.html').pipe(
        res,
      );
    },
  );

  server.get(
    '/auth/realms/My-Account/protocol/openid-connect/3p-cookies/step1.html',
    function(req, res) {
      res.setHeader('content-type', 'text/html');
      fs.createReadStream(__dirname + '/assets/keycloak/step1.html').pipe(res);
    },
  );

  server.post(
    '/auth/realms/My-Account/protocol/openid-connect/token',
    function(req, res) {
      res.json({
        access_token: replaceNonce(accessToken, (req.session as any).lastNonce),
        expires_in: 9000,
        refresh_expires_in: 9600,
        refresh_token: replaceNonce(refreshToken, (req.session as any).lastNonce),
        token_type: 'bearer',
        id_token: replaceNonce(idToken, (req.session as any).lastNonce),
        'not-before-policy': 1557736240,
        session_state: 'ef4906c8-0da9-4a88-b569-e039fbe5229d',
        scope: '',
      });
    },
  );
}
