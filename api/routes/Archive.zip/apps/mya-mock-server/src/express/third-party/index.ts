import * as express from 'express';

import {
  addressFinderAPIFindMock,
  addressFinderAPIRetrieveMock,
} from './helpers/address-finder';
import { bankDetailsVerificationAPIMock } from './helpers/bank-details';
import { suspendedFunds } from './helpers/suspended-funds';

/**
 * Sets up mocks for third party URLs that are mapped to
 * the mock server via the MYA app's proxy.config.json
 */
export function setupThirdPartyUrlMocks(server: express.Application) {
  server.get('/address-finder-api-mock/Find/*', function(req, res) {
    res.setHeader('content-type', 'application/json');
    const queryText = req.query.Text as string;
    const query = Object.keys(addressFinderAPIFindMock).includes(queryText)
      ? queryText
      : 'test';

    res.send(JSON.stringify(addressFinderAPIFindMock[query]));
  });

  server.get('/address-finder-api-mock/Retrieve/*', function(req, res) {
    res.setHeader('content-type', 'application/json');
    const queryId = req.query.Id as string;
    const query = Object.keys(addressFinderAPIRetrieveMock).includes(queryId)
      ? queryId
      : 'test';

    res.send(JSON.stringify(addressFinderAPIRetrieveMock[query]));
  });

  server.get('/suspended-funds', function(req, res) {
    res.setHeader('content-type', 'application/json');
    res.send(JSON.stringify(suspendedFunds));
  });

  server.get('/bank-details-api-mock/*', function(req, res) {
    res.setHeader('content-type', 'application/json');

    const querySortCodes = req.query.SortCodes as string;
    const queryAccountNumbers = req.query.AccountNumbers as string;

    const query = Object.keys(bankDetailsVerificationAPIMock).includes(querySortCodes)
      ? querySortCodes
      : Object.keys(bankDetailsVerificationAPIMock).includes(queryAccountNumbers)
        ? queryAccountNumbers
        : 'ok';

    res.send(JSON.stringify(bankDetailsVerificationAPIMock[query]));
  });
}
