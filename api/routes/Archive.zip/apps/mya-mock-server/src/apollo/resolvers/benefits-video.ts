import { GraphQLError } from 'graphql';

let counter = 0;

const videoStatementMock = {
  requestInProgress: {
    requestStatus: 'REQUEST_IN_PROGRESS',
    url: null,
    transcript: null,
  },
  successfulResponse: {
    requestStatus: 'SUCCESSFUL_RESPONSE',
    transcript:
      'Hi Leone! If you haven\'t already, it\'s important to think about your retirement, and whether you\'ll be able to support the lifestyle you want. As at the 9th of December 2021, you had £17,691 in your pension. So, what does this mean for you? If you keep saving the same amount each year until you\'re 66 in today\'s prices, your pot value would be £33,796. That could give you £596.46 each year if you buy an annuity, plus your state pension when you reach state pension age. You\'d also get a tax-free cash sum of £8,449. But would this be enough? When you stop working, you\'re likely to want the same things you enjoy now, whether that\'s shopping or meals out, your pension pot will need to last throughout your later years. Select <a href=\'https://test.com\' target=\'_blank\'>the retirement planner tool here<span class=\'inject-icon icon--post\' src=\'link-external\'></span></a>, to find out what saving a little more today, could mean for your future. Or select ‘<a href=\'https://test2.com\' target=\'_blank\'>make changes to my pension<span class=\'inject-icon icon--post\' src=\'link-external\'></span></a>\' to increase the amount you save into your pension each month. Thank you for saving with Legal and General.',
    url: 'https://player-dev.videosmart.com/watch/f0c3z-j5hgU',
  },
  errorResponse: {
    requestStatus: 'ERROR_RESPONSE',
    url: null,
    transcript: null,
  },
  timeout: {
    requestStatus: 'TIMEOUT',
    url: null,
    transcript: null,
  },
};

export function getBenefitsVideo(requestStatus) {
  // When running in CI return successful response immediately
  // so that the BDD tests are not affected by the ghost
  if (process.env.CI) {
    return videoStatementMock['successfulResponse'];
  }

  counter++;

  const requestsBeforeResponse = 2;

  if (counter === requestsBeforeResponse) {
    // &setRequestStatus=vsErrorResponse
    if (requestStatus === 'vsErrorResponse') {
      return videoStatementMock['errorResponse'];
    }

    // &setRequestStatus=vsTimeout
    if (requestStatus === 'vsTimeout') {
      return videoStatementMock['timeout'];
    }

    // &setRequestStatus=vsInProgress
    if (requestStatus === 'vsInProgress') {
      return videoStatementMock['requestInProgress'];
    }

    // &setRequestStatus=vsNetworkErrors
    if (requestStatus === 'vsNetworkErrors') {
      throw new GraphQLError(
        'Variable \'accountId\' has coerced Null value for NonNull type \'String!\'',
        {
          extensions: {
            code: '200',
            errorType: 'TESTERROR',
            classification: 'ValidationError',
          },
        },
      );
    }

    return videoStatementMock['successfulResponse'];
  }

  if (counter > requestsBeforeResponse) {
    // reset counter on page refresh
    counter = 1;
  }

  return videoStatementMock['requestInProgress'];
}
