import { GraphQLError } from 'graphql';

let counter = 0;

export function getAppUrls(accountId: string, requestStatus?: string) {
  // &setRequestStatus=appUrlsNull
  if (requestStatus === 'appUrlsNull') {
    return {
      changeContributions: null,
      microSite: null,
      myFutureNow: null,
      nominateBeneficiaries: null,
      retirementPlanner: null,
      transferIn: null,
    };
  }

  // &setRequestStatus=appUrlsDataFetchingError
  if (requestStatus === 'appUrlsDataFetchingError') {
    if (counter < 2) {
      counter++;
      throw new GraphQLError(
        'Exception while fetching data (/getApplicationUrls) : Error while retrieving application URLs for account',
        {
          extensions: {
            code: '200',
            classification: 'DataFetchingException',
          },
        },
      );
    } else {
      counter = 0;
    }
  }

  return {
    changeContributions: 'https://www.legalandgeneral.com/',
    microSite: 'https://www.legalandgeneral.com/workplace/l/legalandgeneral-employee',
    myFutureNow: 'https://www.myfuturenow.co.uk/legal_and_general_scheme',
    nominateBeneficiaries: null,
    retirementPlanner:
      accountId === 'KINGFISHER' // add in url productId=kingfisherTheme
        ? 'https://landgmya.ctc.uk.com/Kingfisher'
        : 'https://landgmya.ctc.uk.com',
    transferIn: 'test',
  };
}
