// &setRequestStatus=accountContributionsNull
const ACCOUNT_CONTRIBUTIONS_STATUS = 'accountContributionsNull';

const noAccountContributionsValues = {
  lastContributionDate: null,
  lastRegularContributionAmt: null,
  singleContributionAmt: null,
  transferInAmt: null,
  totalContriInYearAmt: null,
  totalContriToDateAmt: null,
  totalRegularContributionAmt: null,
  employeeContributionPercentage: null,
  employerContributionPercentage: null,
};

const getDefaultValues = (accountId: string) => ({
  lastRegularContributionAmt: accountId === '2746456031'
    ? 50.0
    : 0.0,
  singleContributionAmt: accountId === '2746456031'
    ? 0.0
    : 2250.0,
  transferInAmt: 123123,
  totalContriInYearAmt: 0.0,
  totalContriToDateAmt: 2250.0,
  totalRegularContributionAmt: 0.0,
  employeeContributionPercentage: accountId.includes('ACCENTURE')
    ? 4.0
    : null,
  employerContributionPercentage: accountId.includes('ACCENTURE')
    ? 10.0
    : null,
});

export const getAccountContributionsMock = (
  accountId: string,
  requestStatus: string,
) => ({
  accountId: accountId,
  lastContributionDate: null,
  ...(requestStatus !== ACCOUNT_CONTRIBUTIONS_STATUS
    ? getDefaultValues(accountId)
    : noAccountContributionsValues),
});
