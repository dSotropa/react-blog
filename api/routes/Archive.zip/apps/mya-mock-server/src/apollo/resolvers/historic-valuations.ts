import { historicValuations } from './valuations';

let counter = 0;

const mockHistoricValuationsResponse = {
  requestInProgress: {
    requestStatus: 'REQUEST_IN_PROGRESS',
    historicValuations: [],
  },
  successfulResponse: {
    requestStatus: 'SUCCESSFUL_RESPONSE',
    historicValuations: historicValuations,
  },
  errorResponse: {
    requestStatus: 'ERROR_RESPONSE',
    historicValuations: [],
  },
  timeout: {
    requestStatus: 'TIMEOUT',
    historicValuations: [],
  },
};

export function getHistoricValuations(requestStatus) {
  // When running in CI return successful response immediately
  // so that the BDD tests are not affected by the ghost
  if (process.env.CI) {
    return mockHistoricValuationsResponse['successfulResponse'];
  }

  counter++;

  const requestsBeforeResponse = 2;

  if (counter === requestsBeforeResponse) {
    // &setRequestStatus=hvErrorResponse
    if (requestStatus === 'hvErrorResponse') {
      return mockHistoricValuationsResponse['errorResponse'];
    }

    // &setRequestStatus=hvTimeout
    if (requestStatus === 'hvTimeout') {
      return mockHistoricValuationsResponse['timeout'];
    }

    // &setRequestStatus=hvInProgress
    if (requestStatus === 'hvInProgress') {
      return mockHistoricValuationsResponse['requestInProgress'];
    }

    return mockHistoricValuationsResponse['successfulResponse'];
  }

  if (counter > requestsBeforeResponse) {
    // reset counter on page refresh
    counter = 1;
  }

  return mockHistoricValuationsResponse['requestInProgress'];
}
