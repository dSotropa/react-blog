import { testUsers } from './test-users';
import { getGroupArrangementID } from './gf-number';

export function getAccountSummary(accountHash: string, userType: string): any {
  const user = Object.values(testUsers).find(u => u.accountHash === accountHash);

  return {
    ...user,
    groupArrangementID: getGroupArrangementID(accountHash),
  };
}
