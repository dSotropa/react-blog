import { format } from 'date-fns';

import { InsuredAccountValuation, UnitHolding } from '@libs/mya/shared/utility-data';

export const insuredAccountValuation: InsuredAccountValuation = {
  totalValuation: 2303.51,
  effectiveDate: format(new Date(), 'yyyy-MM-dd'),
  investmentBenefits: [
    {
      id: 'TRO9CT',
      sequenceNumber: '01',
      benefitType: 'REGULAR',
      lifestyleFundId: 'LNC3',
      lifestyleFundName: 'GE 70:30/Ovr 5 Y IL Gts 5 Y LS',
      isLifestyle: true,
      unitHoldings: [
        {
          fundId: 'NEO3',
          fundName: 'NEO3 Fund',
          numberOfUnits: 641.436,
          bidUnitPrice: 368.14,
          valuation: 2361.38,
          bidUnitPriceEffectiveDate: '2019-12-09T00:00:00.000+0000',
        },
        {
          fundId: 'NTW3',
          fundName: 'NTW3 Fund',
          numberOfUnits: 5655.516,
          bidUnitPrice: 187.29,
          valuation: 10592.22,
          bidUnitPriceEffectiveDate: '2019-12-09T00:00:00.000+0000',
        },
        {
          fundId: 'FOO',
          fundName: 'FOO Fund',
          numberOfUnits: 5000,
          bidUnitPrice: 100,
          valuation: 5000.0,
          bidUnitPriceEffectiveDate: '2019-12-08T00:00:00.000+0000',
        },
      ] as unknown as Array<UnitHolding>,
    },
    {
      id: 'TRO9CU',
      sequenceNumber: '01',
      benefitType: 'SINGLE',
      lifestyleFundId: null,
      lifestyleFundName: null,
      isLifestyle: false,
      unitHoldings: [
        {
          fundId: 'FOO',
          fundName: 'FOO Fund',
          numberOfUnits: 50,
          bidUnitPrice: 100,
          valuation: 50.0,
          bidUnitPriceEffectiveDate: '2019-12-08T00:00:00.000+0000',
        },
        {
          fundId: 'BAR',
          fundName: 'BAR Fund',
          numberOfUnits: 50,
          bidUnitPrice: 200,
          valuation: 100.0,
          bidUnitPriceEffectiveDate: '2019-12-08T00:00:00.000+0000',
        },
      ] as unknown as Array<UnitHolding>,
    },
    {
      id: 'TR09KW',
      sequenceNumber: '01',
      benefitType: 'TRANSFERVALUE',
      lifestyleFundId: 'LNC3',
      lifestyleFundName: 'GE 70:30/Ovr 5 Y IL Gts 5 Y LS',
      isLifestyle: true,
      unitHoldings: [
        {
          fundId: 'NEO3',
          fundName: 'NEO3 Fund',
          numberOfUnits: 641.436,
          bidUnitPrice: 368.14,
          valuation: 2361.38,
          bidUnitPriceEffectiveDate: '2019-12-09T00:00:00.000+0000',
        },
        {
          fundId: 'NTW3',
          fundName: 'NTW3 Fund',
          numberOfUnits: 5655.516,
          bidUnitPrice: 187.29,
          valuation: 10592.22,
          bidUnitPriceEffectiveDate: '2019-12-09T00:00:00.000+0000',
        },
        {
          fundId: 'FOO',
          fundName: 'FOO Fund',
          numberOfUnits: 1000,
          bidUnitPrice: 100,
          valuation: 1000.0,
          bidUnitPriceEffectiveDate: '2019-12-08T00:00:00.000+0000',
        },
      ] as unknown as Array<UnitHolding>,
    },
    {
      id: 'TR09KW',
      sequenceNumber: '02',
      benefitType: 'TRANSFERVALUE',
      lifestyleFundId: 'SDB5',
      lifestyleFundName: 'SDB LSP',
      isLifestyle: true,
      unitHoldings: [
        {
          fundId: 'NEO3',
          fundName: 'NEO3 Fund',
          numberOfUnits: 641.436,
          bidUnitPrice: 368.14,
          valuation: 2361.38,
          bidUnitPriceEffectiveDate: '2019-12-09T00:00:00.000+0000',
        },
        {
          fundId: 'NTW3',
          fundName: 'NTW3 Fund',
          numberOfUnits: 5655.516,
          bidUnitPrice: 187.29,
          valuation: 10592.22,
          bidUnitPriceEffectiveDate: '2019-12-09T00:00:00.000+0000',
        },
        {
          fundId: 'FOO',
          fundName: 'FOO Fund',
          numberOfUnits: 1000,
          bidUnitPrice: 100,
          valuation: 1000.0,
          bidUnitPriceEffectiveDate: '2019-12-08T00:00:00.000+0000',
        },
      ] as unknown as Array<UnitHolding>,
    },
  ],
};

export const wholePotInsuredAccountValuation: InsuredAccountValuation = {
  totalValuation: 2303.51,
  effectiveDate: format(new Date(), 'yyyy-MM-dd'),
  investmentBenefits: [
    {
      id: '0',
      sequenceNumber: '01',
      benefitType: 'REGULAR',
      isLifestyle: false,
      unitHoldings: [
        {
          fundId: 'NEO3',
          fundName: 'NEO3 Fund',
          numberOfUnits: 641.436,
          bidUnitPrice: 368.14,
          valuation: 2361.38,
          bidUnitPriceEffectiveDate: '2019-12-09T00:00:00.000+0000',
        },
        {
          fundId: 'NTW3',
          fundName: 'NTW3 Fund',
          numberOfUnits: 5655.516,
          bidUnitPrice: 187.29,
          valuation: 10592.22,
          bidUnitPriceEffectiveDate: '2019-12-09T00:00:00.000+0000',
        },
        {
          fundId: 'FOO',
          fundName: 'FOO Fund',
          numberOfUnits: 5000,
          bidUnitPrice: 100,
          valuation: 5000.0,
          bidUnitPriceEffectiveDate: '2019-12-08T00:00:00.000+0000',
        },
      ] as unknown as Array<UnitHolding>,
    },
    {
      id: '1',
      sequenceNumber: '01',
      benefitType: 'SINGLE',
      isLifestyle: false,
      unitHoldings: [
        {
          fundId: 'NEO3',
          fundName: 'NEO3 Fund',
          numberOfUnits: 100,
          bidUnitPrice: 368.14,
          valuation: 3681.4,
          bidUnitPriceEffectiveDate: '2019-12-09T00:00:00.000+0000',
        },
        {
          fundId: 'NTW3',
          fundName: 'NTW3 Fund',
          numberOfUnits: 100,
          bidUnitPrice: 187.29,
          valuation: 1872.9,
          bidUnitPriceEffectiveDate: '2019-12-09T00:00:00.000+0000',
        },
        {
          fundId: 'FOO',
          fundName: 'FOO Fund',
          numberOfUnits: 100,
          bidUnitPrice: 100,
          valuation: 1000.0,
          bidUnitPriceEffectiveDate: '2019-12-08T00:00:00.000+0000',
        },
      ] as unknown as Array<UnitHolding>,
    },
  ],
};

export const selfInvestedAccountValuation = {
  totalValuation: 38000,
  investedHoldingsGroups: [
    {
      investedHoldings: [
        {
          holdingName: 'Current (****6215)',
          valuation: 25000,
        },
        {
          holdingName: 'Current (****9840)',
          valuation: 12000,
        },
      ],
    },
    {
      investedHoldings: [
        {
          holdingName: 'FOO',
          valuation: 1000,
        },
      ],
    },
  ],
};

export const regularContributionsOnlyMYI: InsuredAccountValuation = {
  totalValuation: 2303.51,
  effectiveDate: format(new Date(), 'yyyy-MM-dd'),
  investmentBenefits: [
    {
      id: '0',
      sequenceNumber: '01',
      benefitType: 'REGULAR',
      isLifestyle: false,
      unitHoldings: [
        {
          fundId: 'NTW3',
          fundName: 'NTW3 Fund',
          numberOfUnits: 5655.516,
          bidUnitPrice: 187.29,
          valuation: 10592.22,
          bidUnitPriceEffectiveDate: '2019-12-09T00:00:00.000+0000',
        },
        {
          fundId: 'FOO',
          fundName: 'FOO Fund',
          numberOfUnits: 5000,
          bidUnitPrice: 100,
          valuation: 5000.0,
          bidUnitPriceEffectiveDate: '2019-12-08T00:00:00.000+0000',
        },
      ] as unknown as Array<UnitHolding>,
    },
  ],
};

export const regularContributionsInvestedInFundsMYI: InsuredAccountValuation = {
  totalValuation: 2303.51,
  effectiveDate: format(new Date(), 'yyyy-MM-dd'),
  investmentBenefits: [
    {
      id: '0',
      sequenceNumber: '01',
      benefitType: 'REGULAR',
      isLifestyle: false,
      unitHoldings: [
        {
          fundId: 'NTW3',
          fundName: 'NTW3 Fund',
          numberOfUnits: 5655.516,
          bidUnitPrice: 187.29,
          valuation: 10592.22,
          bidUnitPriceEffectiveDate: '2019-12-09T00:00:00.000+0000',
        },
        {
          fundId: 'FOO',
          fundName: 'FOO Fund',
          numberOfUnits: 5000,
          bidUnitPrice: 100,
          valuation: 5000.0,
          bidUnitPriceEffectiveDate: '2019-12-08T00:00:00.000+0000',
        },
      ] as unknown as Array<UnitHolding>,
    },
  ],
};
