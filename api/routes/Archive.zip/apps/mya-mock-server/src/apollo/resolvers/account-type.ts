import { accountTypes } from '@libs/mya/shared/utility-data';

// In accumulation, all product types have a variety of valuation classes.
// BOP account type is returned for both WorkSave Buy Out Plan and Trustee Buy Out Plan.
export const accountTypeAccumulation = {
  wpp: {
    accountType: accountTypes.WPP,
    productMarketingName: 'WPP E',
    valuationClass: 'BSE',
  },
  mt: {
    accountType: accountTypes.MT,
    productMarketingName: 'WPT Nil Commission 2011',
    valuationClass: 'C2U',
  },
  wpt: {
    accountType: accountTypes.WPT, // represents the own trusts
    productMarketingName: 'WPT RAS Post RDR 2013',
    valuationClass: 'C55',
  },
  spp: {
    accountType: accountTypes.SPP,
    productMarketingName: 'Stakeholder BB',
    valuationClass: 'A5M',
  },
  wbop: {
    accountType: accountTypes.BOP,
    productMarketingName: 'WorkSave Buy Out Plan',
    valuationClass: 'BT6',
  },
  tbop: {
    accountType: accountTypes.BOP,
    productMarketingName: 'Trustee Buy Out Plan',
    valuationClass: 'BT5',
  },
};

// In drawdown, each account type has one valuation class.
// WPT account type is returned for both Own Trust and Master Trust.
// BOP account type is returned specifically for Trustee Buy Out Plan.
export const accountTypeDrawdown = {
  wpp: {
    accountType: accountTypes.WPP,
    productMarketingName: 'Pension WorkSave Plan',
    valuationClass: 'WP01',
  },
  mt: {
    accountType: accountTypes.WPT,
    productMarketingName: 'WorkSave Pension Master Trust',
    valuationClass: 'WP02',
  },
  wpt: {
    accountType: accountTypes.WPT,
    productMarketingName: 'WorkSave Pension Trust',
    valuationClass: 'WP02',
  },
  wbop: {
    accountType: accountTypes.WBOP,
    productMarketingName: 'WorkSave Buy Out Plan',
    valuationClass: 'WP03',
  },
  tbop: {
    accountType: accountTypes.BOP,
    productMarketingName: 'Trustee Buy Out Plan',
    valuationClass: 'WP04',
  },
};
