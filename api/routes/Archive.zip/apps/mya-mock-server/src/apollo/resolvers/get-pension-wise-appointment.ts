import { GraphQLError } from 'graphql';
import * as moment from 'moment';

// See interface used in mya for canonically correct types

export interface PensionWiseAppointment {
  appointmentDate: string;
}

const getPensionWiseAppointmentResponses = {
  successfulResponse: {
    noData: null,
    withData: {
      appointmentDate: getFormattedDate(0, 0),
    },
    // the date is 29 days in the past
    withAppointmentWithinLast30Days: {
      appointmentDate: getFormattedDate(0, 29),
    },
    appointmentOlderThan30Days: {
      appointmentDate: getFormattedDate(0, 30),
    },
    appointmentInTheFuture: {
      appointmentDate: getFormattedDate(2, 0, true),
    },
  },
};

// returns a date like this "2022-05-22T10:27:06Z"
function getFormattedDate(
  numOfHours: number,
  numOfDays: number,
  inTheFuture = false,
): string {
  const date = inTheFuture
    ? moment().add(numOfDays, 'days').add(numOfHours, 'hours')
    : moment().subtract(numOfDays, 'days').add(numOfHours, 'hours');

  return date.utcOffset(0, false).format();
}

export function getPensionWiseAppointmentData(
  requestStatus?: string,
): null | PensionWiseAppointment {
  // &setRequestStatus=pensionWiseAppointmentWithData
  if (requestStatus === 'pensionWiseAppointmentWithData') {
    return getPensionWiseAppointmentResponses.successfulResponse.withData;
  }

  // &setRequestStatus=appointmentWithinLast30Days
  if (requestStatus === 'appointmentWithinLast30Days') {
    return getPensionWiseAppointmentResponses.successfulResponse
      .withAppointmentWithinLast30Days;
  }

  // &setRequestStatus=appointmentOlderThan30Days
  if (requestStatus === 'appointmentOlderThan30Days') {
    return getPensionWiseAppointmentResponses.successfulResponse
      .appointmentOlderThan30Days;
  }

  // &setRequestStatus=appointmentInTheFuture
  if (requestStatus === 'appointmentInTheFuture') {
    return getPensionWiseAppointmentResponses.successfulResponse.appointmentInTheFuture;
  }

  // &setRequestStatus=pensionWiseAppointmentNetworkError
  if (requestStatus === 'pensionWiseAppointmentNetworkError') {
    throw new GraphQLError(
      'Variable \'accountId\' has coerced Null value for NonNull type \'String!\'',
      {
        extensions: {
          code: '200',
          errorType: 'TESTERROR',
          classification: 'ValidationError',
        },
      },
    );
  }

  return getPensionWiseAppointmentResponses.successfulResponse.noData;
}
