import { DrawdownUnitHolding, DrawdownValuation } from '@libs/mya/shared/utility-data';

export const drawDownValuation: DrawdownValuation = {
  totalValuation: 1494.5,
  unitHoldings: [
    {
      fundId: 'NEO3',
      fundName: 'L&G PMC Fixed Interest Fund 3',
      numberOfUnits: 373.0,
      bidUnitPrice: 1.0,
      valuation: 373.58,
      bidUnitPriceEffectiveDate: '1900-01-01T12:00:00Z',
    },
    {
      fundId: 'NDZ3',
      fundName: 'L&G PMC Global Eqty Fixed Weights 50:50 Index 3',
      numberOfUnits: 272.0,
      bidUnitPrice: 4.12,
      valuation: 1120.92,
      bidUnitPriceEffectiveDate: '2022-11-07T07:30:00Z',
    },
  ] as Array<DrawdownUnitHolding>,
};
