import { GraphQLError } from 'graphql';

let requestCounterUntilSuccess = 0;

export function submitAccentureOrder(params: any, requestStatus: string) {
  // &setRequestStatus=accentureContributionsSubmitError
  if (requestStatus === 'accentureContributionsSubmitError') {
    if (requestCounterUntilSuccess < 1) {
      requestCounterUntilSuccess += 1;

      throw new GraphQLError('Internal server error', {
        extensions: {
          code: '200',
        },
      });
    } else {
      requestCounterUntilSuccess = 0;
    }
  }

  return {
    emailAddress: params.order.emailAddress,
  };
}
