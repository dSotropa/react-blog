import { AccountSummary } from '@libs/mya/shared/utility-data';

import { insuredAccountValuation } from './account-valuation';
import { drawDownValuation } from './drawdown-valuation';

export const accountSummaryAccumulation: AccountSummary = {
  accountId: '2277899031',
  accountHash: '6e0d8eb84a80c6bd57dda81d1cecec7f99d104c8bb19fad2fd1246d18cef3fc3',
  accountRiskDate: '2020-06-10T00:00:00Z',
  accountType: 'WORKSAVE_PENSION_PLAN',
  isHybrid: false,
  isSonata: false,
  productName: 'WPP E',
  productMarketingName: 'WorkSave Pension Plan',
  groupArrangementName: 'LEGAL & GENERAL EMPLOYEE PENSION PLAN',
  groupArrangementID: 'GF22508000',
  groupCategory: '001',
  /**
   *  It is required for showing custom branded content.
   *  For example the cms.service.ts(check the `addCustomContent` method) merges branded content if the memberStatus isn't null
   */
  memberStatus: 'CUR',
  retirementAgeYears: 66,
  retirementAgeMonths: 0,
  valuationClass: 'BSE',
  sonataValuation: null,
  totalValuation: 2303.51,
  valuationUnavailableStatus: 'OK',
  workInProgressEndDate: null,
  selfInvestedAccountValuation: null,
  insuredAccountValuation: insuredAccountValuation,
  hasComplexCharges: false,
  drawDownValuation: null,
  insuredAccountId: '2277899031',
  sonataAccumulationAccountId: null,
  sonataDecumulationAccountId: null,
};

export const accountSummaryPartial: AccountSummary = {
  accountId: '2259371131',
  accountHash: '4c4813cd16d8b5b73698f81e6c4166c88de74fb8f73e96271dbff9e5e1949f69',
  accountRiskDate: '2023-01-03T00:00:00Z',
  accountType: 'BUY_OUT_PLAN',
  isHybrid: false,
  isSonata: false,
  productName: 'TBOP Reduced Allocation (3)',
  productMarketingName: 'Trustee Buy Out Plan',
  groupArrangementName: 'SONATA MAJOR RELEASE S3',
  groupArrangementID: 'GF18248000',
  groupCategory: '002',
  memberStatus: null,
  retirementAgeYears: 65,
  retirementAgeMonths: 0,
  valuationClass: 'BS5',
  sonataValuation: 749999.7,
  totalValuation: 4718166.14,
  valuationUnavailableStatus: 'OK',
  workInProgressEndDate: null,
  selfInvestedAccountValuation: null,
  insuredAccountValuation: insuredAccountValuation,
  hasComplexCharges: false,
  drawDownValuation: drawDownValuation,
  insuredAccountId: '2259371131',
  sonataAccumulationAccountId: 'S400070304',
  sonataDecumulationAccountId: 'S400070368',
};

export const accountSummaryDrawdown: AccountSummary = {
  accountId: 'S400055657',
  accountHash: '78ec8f85501c4f732217f512de72a5b6a055cd8e97fcd26792a71bb1b8cf4d21',
  accountRiskDate: null, // This is always null for drawdown users, even when there is a linked FPF account
  accountType: 'WORKSAVE_PENSION_TRUST',
  isHybrid: false,
  isSonata: true,
  productName: null,
  productMarketingName: 'WorkSave Pension Trust',
  groupArrangementName: 'SONATA MAJOR RELEASE S2',
  groupArrangementID: 'GF77248000',
  groupCategory: '004',
  memberStatus: null,
  retirementAgeYears: null,
  retirementAgeMonths: null,
  valuationClass: 'WP02',
  sonataValuation: 1494.5,
  totalValuation: 1494.5,
  valuationUnavailableStatus: 'OK',
  workInProgressEndDate: null,
  selfInvestedAccountValuation: null,
  insuredAccountValuation: null,
  hasComplexCharges: null,
  drawDownValuation: drawDownValuation,
  // These account id properties could return null due to the data
  insuredAccountId: '2001579031',
  sonataAccumulationAccountId: 'S400055657',
  sonataDecumulationAccountId: 'S400055680',
};
