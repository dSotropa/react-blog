import { AccountSummary } from '@libs/mya/shared/utility-data';

import {
  accountSummaryAccumulation,
  accountSummaryDrawdown,
  accountSummaryPartial,
} from './account-summary-base';
import {
  regularContributionsInvestedInFundsMYI,
  regularContributionsOnlyMYI,
  selfInvestedAccountValuation,
  wholePotInsuredAccountValuation,
} from './account-valuation';
import { accountTypeAccumulation, accountTypeDrawdown } from './account-type';

export interface TestUser extends AccountSummary {
  mockError?: string;
  requestStatus?: string;
}

export const testUsers: {
  [key: string]: TestUser;
} = {
  // default user
  accumulationWpp: {
    ...accountSummaryAccumulation,
    ...accountTypeAccumulation.wpp,
    accountHash: 'accumulationWpp',
  },
  accumulationWpt: {
    ...accountSummaryAccumulation,
    ...accountTypeAccumulation.wpt,
    accountHash: 'accumulationWpt',
  },
  accumulationSpp: {
    ...accountSummaryAccumulation,
    ...accountTypeAccumulation.spp,
    accountHash: 'accumulationSpp',
  },
  accumulationWbop: {
    ...accountSummaryDrawdown,
    ...accountTypeAccumulation.wbop,
    accountHash: 'accumulationWbop',
  },
  accumulationTbop: {
    ...accountSummaryDrawdown,
    ...accountTypeAccumulation.tbop,
    accountHash: 'accumulationTbop',
  },
  partialDrawdown: {
    ...accountSummaryPartial,
    accountHash: 'partialDrawdown',
  },
  drawdownWpp: {
    ...accountSummaryDrawdown,
    ...accountTypeDrawdown.wpp,
    accountHash: 'drawdownWpp',
  },
  drawdownWpt: {
    ...accountSummaryDrawdown,
    ...accountTypeDrawdown.wpt,
    accountHash: 'drawdownWpt',
  },
  drawdownWbop: {
    ...accountSummaryDrawdown,
    ...accountTypeDrawdown.wbop,
    accountHash: 'drawdownWbop',
  },
  drawdownTbop: {
    ...accountSummaryDrawdown,
    ...accountTypeDrawdown.tbop,
    accountHash: 'drawdownTbop',
  },

  // The below users are also configured with specific data overrides in other resolvers and/or are used for e2e tests

  // configured in getTransactions
  singleContributionOnly: {
    ...accountSummaryAccumulation,
    accountHash: '756e1c16a10f07b426a090c155709105944c241786b81776e82d9f04cda79e6e',
    accountId: '2568556031',
    selfInvestedAccountValuation: { ...selfInvestedAccountValuation },
  },
  // configured in getAccountContributions
  hybridRegularContribution: {
    ...accountSummaryAccumulation,
    accountId: '2746456031',
    accountHash: '1c1da91811d2b1f5ae12ff36e50676ecdcf7fc121a59f41419280015e7f5f91a',
  },
  // configured in getAccountContributions
  regularContributionsLSP: {
    ...accountSummaryAccumulation,
    accountId: '2746456031',
    accountHash: '1c1da91811d2b1f5ae12ff36e50676ecdcf7fc121a59f41419280015e7f5f91a',
  },
  // decumulation users configured in getCustomerProfile
  decumulationWppWithMATPack: {
    ...accountSummaryAccumulation,
    accountHash: 'ee8ef0d96f7680b87b5839d1bffc4776271a0a5f812cba3ad1d1e93e34fcdc93',
    accountId: '2670147031',
  },
  decumulationMasterTrustWithMATPack: {
    ...accountSummaryAccumulation,
    ...accountTypeAccumulation.mt,
    accountHash: '242eb411b576ebedaa9c9e3c538edcd58dc4adea636593422dad94b5e2413f3f',
  },
  decumulationWppWithMATPackLessThan100Pot: {
    ...accountSummaryAccumulation,
    accountHash: '21312321321321321e',
    accountId: '2670147031',
    totalValuation: 100,
  },
  decumulationNoPrizeDraw: {
    ...accountSummaryAccumulation,
    accountHash: 'decumulationNoPrizeDraw',
    accountId: 'decumulationNoPrizeDraw',
    selfInvestedAccountValuation: { ...selfInvestedAccountValuation },
  },
  // configured in getCustomerProfile
  noEmailAddress: {
    ...accountSummaryAccumulation,
    accountHash: 'noEmailAddressProfile',
  },
  // configured in getPermissions
  cannotTransferIn: {
    ...accountSummaryAccumulation,
    accountHash: '8fc181f80017c5b3a92b6d9739bc2e2e4f3aed2ed03b4835f326a0e0a661c3e8',
  },
  // configured in getPermissions
  cannotNominateBeneficiaries: {
    ...accountSummaryAccumulation,
    accountHash: 'ed79dc00d63175e664a8e9c72270fdb2259549704620671272afc2b76179618a',
  },
  // configured in getPermissions
  noPensionVideo: {
    ...accountSummaryAccumulation,
    accountHash: 'noPensionVideo',
  },
  cannotSeeFundCentre: {
    ...accountSummaryAccumulation,
    accountHash: 'cannotSeeFundCentre',
  },
  noValuationUC: {
    ...accountSummaryAccumulation,
    accountHash: 'noValuationUC',
    valuationUnavailableStatus: 'UNMATCHED_CASH',
  },
  noValuationDA: {
    ...accountSummaryAccumulation,
    accountHash: 'noValuationDA',
    valuationUnavailableStatus: 'DELAYED_ALLOCATION_OF_CONTRIBUTION',
  },
  noValuationG: {
    ...accountSummaryAccumulation,
    accountHash: 'noValuationG',
    valuationUnavailableStatus: 'GENERIC',
  },
  // Accenture users configured in getAccountContributionsMock
  accentureAutoEnrolmentCategory: {
    ...accountSummaryAccumulation,
    accountId: 'ACCENTURE_AUTO_ENROLMENT',
    accountHash: 'accentureAutoEnrolmentCategory',
    groupCategory: '001',
  },
  accentureMainCategory: {
    ...accountSummaryAccumulation,
    accountId: 'ACCENTURE_MAIN_CATEGORY',
    accountHash: 'accentureMainCategory',
  },
  accentureFixedRate: {
    ...accountSummaryAccumulation,
    accountId: 'ACCENTURE_FIXED_RATE',
    accountHash: 'accentureFixedRate',
  },
  wholePot: {
    ...accountSummaryAccumulation,
    accountHash: 'wholePot',
    insuredAccountValuation: { ...wholePotInsuredAccountValuation },
  },
  regularContributionsOnlyMYI: {
    ...accountSummaryAccumulation,
    accountHash: 'regularContributionsOnlyMYI',
    insuredAccountValuation: { ...regularContributionsOnlyMYI },
  },
  regularContributionsInvestedInFundsMYI: {
    ...accountSummaryAccumulation,
    accountHash: 'regularContributionsInvestedInFundsMYI',
    insuredAccountValuation: { ...regularContributionsInvestedInFundsMYI },
  },
  fullDrawdown: {
    ...accountSummaryDrawdown,
    accountHash: 'fullDrawdown',
  },
  fullDrawdownIbm: {
    ...accountSummaryDrawdown,
    accountHash: 'fullDrawdownIbm',
  },
  fullDrawdownAccenture: {
    ...accountSummaryDrawdown,
    accountHash: 'fullDrawdownAccenture',
  },
  // Branded theme users
  tescoTheme: {
    ...accountSummaryAccumulation,
    accountId: 'TESCO',
    accountHash: 'tescoTheme',
  },
  debenhamsTheme: {
    ...accountSummaryAccumulation,
    accountId: 'DEBENHAMS',
    accountHash: 'debenhamsTheme',
  },
  emtelleTheme: {
    ...accountSummaryAccumulation,
    accountId: 'EMTELLE',
    accountHash: 'emtelleTheme',
  },
  greggsTheme: {
    ...accountSummaryAccumulation,
    accountId: 'GREGGS',
    accountHash: 'greggsTheme',
  },
  iplTheme: {
    ...accountSummaryAccumulation,
    accountId: 'IPL',
    accountHash: 'iplTheme',
  },
  marksAndSpencerAVCTheme: {
    ...accountSummaryAccumulation,
    accountId: 'MARKSANDSPENCERAVC',
    accountHash: 'marksAndSpencerAVCTheme',
  },
  norcrosTheme: {
    ...accountSummaryAccumulation,
    accountId: 'NORCROS',
    accountHash: 'norcrosTheme',
  },
  arcadiaTheme: {
    ...accountSummaryAccumulation,
    accountId: 'ARCADIA',
    accountHash: 'arcadiaTheme',
  },
  asdaTheme: {
    ...accountSummaryAccumulation,
    accountId: 'ASDA',
    accountHash: 'asdaTheme',
  },
  decumulationBarclaysTheme: {
    ...accountSummaryAccumulation,
    accountId: 'BARCLAYS',
    accountHash: 'decumulationBarclaysTheme',
  },
  barclaysTheme: {
    ...accountSummaryAccumulation,
    accountId: 'BARCLAYS',
    accountHash: 'barclaysTheme',
  },
  cityAndGuildsTheme: {
    ...accountSummaryAccumulation,
    accountId: 'CITYANDGUILDS',
    accountHash: 'cityAndGuildsTheme',
  },
  companionCareTheme: {
    ...accountSummaryAccumulation,
    accountId: 'COMPANION',
    accountHash: 'companionCareTheme',
  },
  coOpGroupTheme: {
    ...accountSummaryAccumulation,
    accountId: 'COOPGROUP',
    accountHash: 'coOpGroupTheme',
  },
  coOpBankTheme: {
    ...accountSummaryAccumulation,
    accountId: 'COOPBANK',
    accountHash: 'coOpBankTheme',
  },
  coOpBankAVCTheme: {
    ...accountSummaryAccumulation,
    accountId: 'COOPBANKAVC',
    accountHash: 'coOpBankAVCTheme',
  },
  gmgTheme: {
    ...accountSummaryAccumulation,
    accountId: 'GMG',
    accountHash: 'gmgTheme',
  },
  kingfisherTheme: {
    ...accountSummaryAccumulation,
    accountId: 'KINGFISHER',
    accountHash: 'kingfisherTheme',
  },
  marksAndSpencerTheme: {
    ...accountSummaryAccumulation,
    accountId: 'MARKSANDSPENCER',
    accountHash: 'marksAndSpencerTheme',
  },
  petsAtHomeTheme: {
    ...accountSummaryAccumulation,
    accountId: 'PETSATHOME',
    accountHash: 'petsAtHomeTheme',
  },
  natwestTheme: {
    ...accountSummaryAccumulation,
    accountId: 'NATWEST',
    accountHash: 'natwestTheme',
  },
  gknTheme: {
    ...accountSummaryAccumulation,
    accountId: 'GKN',
    accountHash: 'gknTheme',
  },
  jlpTheme: {
    ...accountSummaryAccumulation,
    accountId: 'JLP',
    accountHash: 'jlpTheme',
  },
  jlpDefferedTheme: {
    ...accountSummaryAccumulation,
    accountId: 'JLPDeffered',
    accountHash: 'jlpDefferedTheme',
  },
  airbusTheme: {
    ...accountSummaryAccumulation,
    accountId: 'AIRBUS',
    accountHash: 'airbusTheme',
  },
  concordBeisTheme: {
    ...accountSummaryAccumulation,
    accountId: 'CONCORD-BEIS',
    accountHash: 'concordBeisTheme',
  },
  concordCoTheme: {
    ...accountSummaryAccumulation,
    accountId: 'CONCORD-CO',
    accountHash: 'concordCoTheme',
  },
  concordDstlTheme: {
    ...accountSummaryAccumulation,
    accountId: 'CONCORD-DSTL',
    accountHash: 'concordDstlTheme',
  },
  concordGcoTheme: {
    ...accountSummaryAccumulation,
    accountId: 'CONCORD-GCO',
    accountHash: 'concordGcoTheme',
  },
  concordOnsTheme: {
    ...accountSummaryAccumulation,
    accountId: 'CONCORD-ONS',
    accountHash: 'concordOnsTheme',
  },
  concordSsdTheme: {
    ...accountSummaryAccumulation,
    accountId: 'CONCORD-SSD',
    accountHash: 'concordSsdTheme',
  },
  curtissWrightTheme: {
    ...accountSummaryAccumulation,
    accountId: 'CURTISS-WRIGHT',
    accountHash: 'curtissWrightTheme',
  },
  homeserveTheme: {
    ...accountSummaryAccumulation,
    accountId: 'HOMESERVE',
    accountHash: 'homeserveTheme',
  },
  rnibTheme: {
    ...accountSummaryAccumulation,
    accountId: 'RNIB',
    accountHash: 'rnibTheme',
  },
  oneStopTheme: {
    ...accountSummaryAccumulation,
    accountId: 'ONESTOP',
    accountHash: 'oneStopTheme',
  },
  unicarriersTheme: {
    ...accountSummaryAccumulation,
    accountId: 'UNICARRIERS',
    accountHash: 'unicarriersTheme',
  },
  transoceanTheme: {
    ...accountSummaryAccumulation,
    accountId: 'TRANSOCEAN',
    accountHash: 'transoceanTheme',
  },
  unipartPPTheme: {
    ...accountSummaryAccumulation,
    accountId: 'UNIPART-PP',
    accountHash: 'unipartPPTheme',
  },
  unipartMTTheme: {
    ...accountSummaryAccumulation,
    accountId: 'UNIPART-MT',
    accountHash: 'unipartMTTheme',
  },
  yellTheme: {
    ...accountSummaryAccumulation,
    accountId: 'YELL',
    accountHash: 'yellTheme',
  },
  ngBaileyMTTheme: {
    ...accountSummaryAccumulation,
    accountId: 'NG-BAILEY-MT',
    accountHash: 'ngBaileyMTTheme',
  },
  ngBaileyStakeholderTheme: {
    ...accountSummaryAccumulation,
    accountId: 'NG-BAILEY-STAKEHOLDER',
    accountHash: 'ngBaileyStakeholderTheme',
  },
  mGroupTheme: {
    ...accountSummaryAccumulation,
    accountId: 'MGROUP',
    accountHash: 'mGroupTheme',
  },
  toyotaMainTheme: {
    ...accountSummaryAccumulation,
    accountId: 'TOYOTA-MAIN',
    accountHash: 'toyotaMainTheme',
  },
  toyotaAvcTheme: {
    ...accountSummaryAccumulation,
    accountId: 'TOYOTA-AVC',
    accountHash: 'toyotaAvcTheme',
  },
  toyotaFormerDBTheme: {
    ...accountSummaryAccumulation,
    accountId: 'TOYOTA-FORMER-DB',
    accountHash: 'toyotaFormerDBTheme',
  },
  paGroupTheme: {
    ...accountSummaryAccumulation,
    accountId: 'PA-GROUP',
    accountHash: 'paGroupTheme',
  },
  ibmGroupTheme: {
    ...accountSummaryAccumulation,
    accountId: 'IBM',
    accountHash: 'ibmTheme',
  },
  ibmMPlanTheme: {
    ...accountSummaryAccumulation,
    accountId: 'IBMMPLAN',
    accountHash: 'ibmMPlanTheme',
  },
  telefonicaTheme: {
    ...accountSummaryAccumulation,
    accountId: 'TELEFONICA',
    accountHash: 'telefonicaTheme',
  },
  telefonicaOwnTrustTheme: {
    ...accountSummaryAccumulation,
    accountId: 'TELEFONICAOWN',
    accountHash: 'telefonicaOwnTrustTheme',
  },
  edfTheme: {
    ...accountSummaryAccumulation,
    accountId: 'EDF',
    accountHash: 'edfTheme',
  },
  amazonTheme: {
    ...accountSummaryAccumulation,
    accountId: 'amazon',
    accountHash: 'amazonTheme',
  },
  fordTheme: {
    ...accountSummaryAccumulation,
    accountId: 'ford',
    accountHash: 'fordTheme',
  },
  nationalGridTheme: {
    ...accountSummaryAccumulation,
    accountId: 'nationalGrid',
    accountHash: 'nationalGridTheme',
  },
  praxGroupTheme: {
    ...accountSummaryAccumulation,
    accountId: 'praxGroup',
    accountHash: 'praxGroupTheme',
  },
  eyTheme: {
    ...accountSummaryAccumulation,
    accountId: 'ey',
    accountHash: 'eyTheme',
  },
  skyBettingAndGamingTheme: {
    ...accountSummaryAccumulation,
    accountId: 'skyBettingAndGaming',
    accountHash: 'skyBettingAndGamingTheme',
  },
  agBarrTheme: {
    ...accountSummaryAccumulation,
    accountId: 'AGBARR',
    accountHash: 'agBarrTheme',
  },
  experianTheme: {
    ...accountSummaryAccumulation,
    accountId: 'experian',
    accountHash: 'experianTheme',
  },
  nextTheme: {
    ...accountSummaryAccumulation,
    accountId: 'next',
    accountHash: 'nextTheme',
  },
  sibelcoTheme: {
    ...accountSummaryAccumulation,
    accountId: 'sibelco',
    accountHash: 'sibelcoTheme',
  },
  saulStartTheme: {
    ...accountSummaryAccumulation,
    accountId: 'saul',
    accountHash: 'saulStartTheme',
  },
  wspTheme: {
    ...accountSummaryAccumulation,
    accountId: 'wsp',
    accountHash: 'wspTheme',
  },
  hymansRobertsonTheme: {
    ...accountSummaryAccumulation,
    accountId: 'hymansRobertson',
    accountHash: 'hymansRobertsonTheme',
  },
  mandbTheme: {
    ...accountSummaryAccumulation,
    accountId: 'mandb',
    accountHash: 'mandbTheme',
  },
  weatherbysTheme: {
    ...accountSummaryAccumulation,
    accountId: 'weatherbys',
    accountHash: 'weatherbysTheme',
  },
  lsegTheme: {
    ...accountSummaryAccumulation,
    accountId: 'lseg',
    accountHash: 'lsegTheme',
  },
  gePensionPlanTheme: {
    ...accountSummaryAccumulation,
    accountId: 'gePensionPlan',
    accountHash: 'gePensionPlanTheme',
  },
  geCapitalTheme: {
    ...accountSummaryAccumulation,
    accountId: 'geCapital',
    accountHash: 'geCapitalTheme',
  },
  geExSPSTheme: {
    ...accountSummaryAccumulation,
    accountId: 'geExSPS',
    accountHash: 'geExSPSTheme',
  },
  slaughterAndMayTheme: {
    ...accountSummaryAccumulation,
    accountId: 'slaughterAndMay',
    accountHash: 'slaughterAndMayTheme',
  },
  colliersTheme: {
    ...accountSummaryAccumulation,
    accountId: 'colliers',
    accountHash: 'colliersTheme',
  },
};
// Branded theme users end
