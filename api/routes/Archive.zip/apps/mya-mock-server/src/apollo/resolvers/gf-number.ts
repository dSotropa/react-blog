export function getGroupArrangementID(accountHash: string): string {
  let groupArrangementID;

  // The GF number used should match that in config.mock.json

  switch (accountHash) {
    case 'cannotSeeFundCentre':
      groupArrangementID = 'hideFundCentre';
      break;
    case 'fullDrawdownIbm':
      groupArrangementID = 'GF92937001';
      break;
    case 'fullDrawdownAccenture':
      groupArrangementID = 'GF06837001';
      break;
    case 'debenhamsTheme':
      groupArrangementID = 'GF46965001';
      break;
    case 'emtelleTheme':
      groupArrangementID = 'GF50056001';
      break;
    case 'greggsTheme':
      groupArrangementID = 'GF71095001';
      break;
    case 'iplTheme':
      groupArrangementID = 'GF69175001';
      break;
    case 'marksAndSpencerAVCTheme':
      groupArrangementID = 'GF64226000';
      break;
    case 'norcrosTheme':
      groupArrangementID = 'GF59556001';
      break;
    case 'arcadiaTheme':
      groupArrangementID = 'GF41965001';
      break;
    case 'asdaTheme':
      groupArrangementID = 'GF34965001';
      break;
    case 'barclaysTheme':
    case 'decumulationBarclaysTheme':
      groupArrangementID = 'GF63965001';
      break;
    case 'cityAndGuildsTheme':
      groupArrangementID = 'GF67637001';
      break;
    case 'saulStartTheme':
      groupArrangementID = 'GF47147001';
      break;
    case 'companionCareTheme':
      groupArrangementID = 'GF51075001';
      break;
    case 'coOpGroupTheme':
      groupArrangementID = 'GF34865001';
      break;
    case 'coOpBankTheme':
      groupArrangementID = 'GF17495001';
      break;
    case 'coOpBankAVCTheme':
      groupArrangementID = 'GF26495001';
      break;
    case 'gmgTheme':
      groupArrangementID = 'GF68796001';
      break;
    case 'kingfisherTheme':
      groupArrangementID = 'GF72027001';
      break;
    case 'marksAndSpencerTheme':
      groupArrangementID = 'GF06865001';
      break;
    case 'petsAtHomeTheme':
      groupArrangementID = 'GF81075001';
      break;
    case 'natwestTheme':
      groupArrangementID = 'GF62596001';
      break;
    case 'tescoTheme':
      groupArrangementID = 'GF10606001';
      break;
    case 'gknTheme':
      groupArrangementID = 'GF74638000';
      break;
    case 'jlpTheme':
      groupArrangementID = 'GF99395001';
      break;
    case 'jlpDefferedTheme':
      groupArrangementID = 'GF30495001';
      break;
    case 'airbusTheme':
      groupArrangementID = 'GF55475001';
      break;
    case 'concordBeisTheme':
      groupArrangementID = 'GF52147001';
      break;
    case 'concordCoTheme':
      groupArrangementID = 'GF77537001';
      break;
    case 'concordDstlTheme':
      groupArrangementID = 'GF48537001';
      break;
    case 'concordGcoTheme':
      groupArrangementID = 'GF73337001';
      break;
    case 'concordOnsTheme':
      groupArrangementID = 'GF25637001';
      break;
    case 'concordSsdTheme':
      groupArrangementID = 'GF17537001';
      break;
    case 'curtissWrightTheme':
      groupArrangementID = 'GF34037001';
      break;
    case 'homeserveTheme':
      groupArrangementID = 'GF24037001';
      break;
    case 'rnibTheme':
      groupArrangementID = 'GF02637001';
      break;
    case 'oneStopTheme':
      groupArrangementID = 'GF60837001';
      break;
    case 'unicarriersTheme':
      groupArrangementID = 'GF77437001';
      break;
    case 'transoceanTheme':
      groupArrangementID = 'GF96836001';
      break;
    case 'unipartPPTheme':
      groupArrangementID = 'GF10637001';
      break;
    case 'unipartMTTheme':
      groupArrangementID = 'GF00637001';
      break;
    case 'yellTheme':
      groupArrangementID = 'GF20137001';
      break;
    case 'ngBaileyMTTheme':
      groupArrangementID = 'GF67227001';
      break;
    case 'ngBaileyStakeholderTheme':
      groupArrangementID = 'GF95035001';
      break;
    case 'accentureAutoEnrolmentCategory':
    case 'accentureMainCategory':
    case 'accentureFixedRate':
      groupArrangementID = 'GF65737001';
      break;
    case 'mGroupTheme':
      groupArrangementID = 'GF46837001';
      break;
    case 'toyotaMainTheme':
      groupArrangementID = 'GF59537001';
      break;
    case 'toyotaAvcTheme':
      groupArrangementID = 'GF14637001';
      break;
    case 'toyotaFormerDBTheme':
      groupArrangementID = 'GF42937001';
      break;
    case 'paGroupTheme':
      groupArrangementID = 'GF79737001';
      break;
    case 'ibmTheme':
      groupArrangementID = 'GF48837001';
      break;
    case 'ibmMPlanTheme':
      groupArrangementID = 'GF28837001';
      break;
    case 'telefonicaTheme':
      groupArrangementID = 'GF00937001';
      break;
    case 'edfTheme':
      groupArrangementID = 'GF30937001';
      break;
    case 'amazonTheme':
      groupArrangementID = 'GF98248000';
      break;
    case 'nationalGridTheme':
      groupArrangementID = 'GF09248000';
      break;
    case 'eyTheme':
      groupArrangementID = 'GF07437001';
      break;
    case 'skyBettingAndGamingTheme':
      groupArrangementID = 'GF39846001';
      break;
    case 'agBarrTheme':
      groupArrangementID = 'GF37937001';
      break;
    case 'telefonicaOwnTrustTheme':
      groupArrangementID = 'GF36937001';
      break;
    case 'experianTheme':
      groupArrangementID = 'GF13047001';
      break;
    case 'nextTheme':
      groupArrangementID = 'GF55047001';
      break;
    case 'sibelcoTheme':
      groupArrangementID = 'GF33075001';
      break;
    case 'wspTheme':
      groupArrangementID = 'GF27056001';
      break;
    case 'hymansRobertsonTheme':
      groupArrangementID = 'GF75837001';
      break;
    case 'mandbTheme':
      groupArrangementID = 'GF54037001';
      break;
    case 'blackbaudTheme':
      groupArrangementID = 'GF12637001';
      break;
    case 'civilAviationTheme':
      groupArrangementID = 'GF21075001';
      break;
    case 'facilityManagementUkTheme':
      groupArrangementID = 'GF35937001';
      break;
    case 'macmillanTheme':
      groupArrangementID = 'GF86465001';
      break;
    case 'technipTheme':
      groupArrangementID = 'GF97537001';
      break;
    case 'makeLimitedTheme':
      groupArrangementID = 'GF43285001';
      break;
    case 'geTheme':
      groupArrangementID = 'GF12665001';
      break;
    case 'gePensionPlanTheme':
      groupArrangementID = 'GF92106001';
      break;
    case 'geCapitalTheme':
      groupArrangementID = 'GF04006001';
      break;
    case 'geExSPSTheme':
      groupArrangementID = 'GF64227001';
      break;
    case 'weatherbysTheme':
      groupArrangementID = 'GF40147001';
      break;
    case 'lsegTheme':
      groupArrangementID = 'GF68407001';
      break;
    case 'slaughterAndMayTheme':
      groupArrangementID = 'GF95147001';
      break;
    case 'decumulationNoPrizeDraw':
      groupArrangementID = 'GF04050001';
      break;
    case 'colliersTheme':
      groupArrangementID = 'GF81147001';
      break;
    default:
      groupArrangementID = 'GF65067000';
      break;
  }

  return groupArrangementID;
}
