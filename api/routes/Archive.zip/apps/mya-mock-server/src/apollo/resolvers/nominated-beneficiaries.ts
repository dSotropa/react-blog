import { GraphQLError } from 'graphql';

import { nominatedBeneficiariesMock } from '@libs/mya/shared/utility-data';

let counter = 0;
const MAX_RETRIES = 2;

export function getNominatedBeneficiaries(accountId: string, requestStatus?: string) {
  // &setRequestStatus=nomBenFetchingError
  if (requestStatus === 'nomBenFetchingError') {
    if (counter < MAX_RETRIES) {
      counter++;
      throw new GraphQLError(
        'Exception while fetching data (/getNominatedBeneficiaries) : Error while retrieving nominatedBeneficiaries for account',
        {
          extensions: {
            code: '200',
            errorType: 'TESTERROR',
            classification: 'DataFetchingError',
          },
        },
      );
    } else {
      counter = 0;
    }
  }

  // &setRequestStatus=nomBenEmptyList
  if (requestStatus === 'nomBenEmptyList') {
    return [];
  }

  return nominatedBeneficiariesMock;
}
