import * as moment from 'moment';
import { GraphQLError } from 'graphql';

import { getTransactions } from './transactions';
import { getAccountSummary } from './account-summary';
import { mockBase64PdfDocument } from './documents/pdf-document';
import { dynamicFunds } from './funds/dynamic-funds';
import { mockBase64PdfIllustration } from './pdf-illustration';
import { getBenefitsVideo } from './benefits-video';
import { getHistoricValuations } from './historic-valuations';
import { getAccountContributionsMock } from './get-account-contributions';
import { getAppUrls } from './get-app-urls';
import { getPensionWiseAppointmentData } from './get-pension-wise-appointment';
import { getAccentureCategoryRules } from './accenture-category-rules';
import { submitAccentureOrder } from './accenture-contributions-submit';
import { getNominatedBeneficiaries } from './nominated-beneficiaries';

export default {
  QueryType: {
    fundDetails: (root, { fundCodes }: { fundCodes: Array<string> }) => {
      return fundCodes.map(fc => dynamicFunds[fc]);
    },

    availableFunds: () => {
      return Object.values(dynamicFunds);
    },

    getAccountContributions: (root, params: { accountId: string }, context) =>
      getAccountContributionsMock(params.accountId, context.requestStatus),

    getAccountSummary: (root, params, { userType }: { userType: string }) =>
      getAccountSummary(params.hashedPolicyNumber, userType),

    getBenefitsVideo: (root, params, context) => getBenefitsVideo(context.requestStatus),

    getCustomerProfile: (root, params, { userType }: { userType: string }) => ({
      title: 'Mr',
      forename: 'Thomas',
      surname: 'Anderson',
      gender: 'M',
      dateOfBirth: userType.includes('decumulation')
        ? moment().subtract(55.8, 'years').toISOString()
        : moment().subtract(30, 'years').toISOString(),
      emailAddress: userType === 'noEmailAddress'
        ? ''
        : 'vijay.kumar@lgim.com',
      phoneNumber: '',
      address: {
        line1: '47 Argyll Street',
        line2: 'Stainton by Langworth',
        line3: '',
        line4: '',
        postcode: 'SO53 1AL',
      },
      documentDeliveryPreference: 'ONLINE',
    }),

    getDecumulationIllustration: () => mockBase64PdfIllustration,

    getDocumentContent: () => mockBase64PdfDocument,

    getHistoricValuations: (root, params: { accountId: string }, context) =>
      getHistoricValuations(context.requestStatus),

    getApplicationUrls: (root, params: { accountId: string }, context) =>
      getAppUrls(params.accountId, context.requestStatus),

    getPensionWiseAppointment: (root, params: { accountId: string }, context) =>
      getPensionWiseAppointmentData(context.requestStatus),

    getPermissions: (root, params, context) => {
      // &setMockError=getPermissionsError
      if (context.mockError === 'getPermissionsError') {
        throw new GraphQLError(
          'Variable \'accountId\' has coerced Null value for NonNull type \'String!\'',
          {
            extensions: {
              code: '200',
              errorType: 'TESTERROR',
              classification: 'ValidationError',
            },
          },
        );
      }

      return {
        manageYourDetails: false,
        applyOnline: false,
        contributionChanges: false,
        switchAndRedirect: true,
        benefitsVideo: context.userType !== 'noPensionVideo',
        statementRequest: false,
        defaultOnlineDocumentsOnly: false,
        retirementPlanner: true,
        onlineDocumentViewing: true,
        boldchat: false,
        nominateBeneficiary: context.userType !== 'cannotNominateBeneficiaries',
        transferIn: context.userType !== 'cannotTransferIn',
        maturityPackRequest: true,
        taxCertificateRequest: true,
        lumpSumJourney: true,
        drawdownJourney: false,
      };
    },

    getTransactions: (root, params, context) =>
      getTransactions(params.criteria.toDate, params.criteria.fromDate, context.userType),

    getWorkInProgress: (root, params, context) => {
      // &setMockError=getWorkInProgressError
      if (context.mockError === 'getWorkInProgressError') {
        throw new GraphQLError(
          'Variable \'accountId\' has coerced Null value for NonNull type \'String!\'',
          {
            extensions: {
              code: '200',
              errorType: 'TESTERROR',
              classification: 'ValidationError',
            },
          },
        );
      }

      return {
        hasWorkInProgress: false,
        expiryDate: '2023-12-18T00:00:00Z',
        isExpiryDateIndefinite: false,
        businessFunction: 'PNPY',
      };
    },

    getNominatedBeneficiaries: (root, params, context) =>
      getNominatedBeneficiaries(params.accountId, context.requestStatus),

    holdingsAndContributions: () => {
      // Uncomment below to simulate data fetching exception
      // throw new GraphQLError(
      //   'Exception while fetching data (/holdingsAndContributions).',
      //   {
      //     extensions: {
      //       code: '200',
      //       errorType: 'TESTERROR',
      //       classification: 'ValidationError',
      //     },
      //   },
      // );

      return {
        future: [
          {
            fundCode: 'FOO',
            name: 'FOO Fund',
            contributionPercentage: 20,
          },
          {
            fundCode: 'NEO3',
            name: 'NEO3 Fund',
            contributionPercentage: 80,
          },
        ],
      };
    },

    isSwitchRedirectAllowed: () => {
      // Uncomment below to simulate data fetching exception
      // throw new GraphQLError(
      //   'Exception while fetching data (/isSwitchRedirectAllowed).',
      //   {
      //     extensions: {
      //       code: '200',
      //       errorType: 'TESTERROR',
      //       classification: 'ValidationError',
      //     },
      //   },
      // );

      return {
        isPermittedByScheme: true,
        hasPostalAddress: true,
        hasWorkInProgress: false,
        hasIndefiniteWorkInProgressEndDate: false,
        workInProgressEndDate: '20210411',
      };
    },

    requestBenefitStatement: (root, params) => params.accountId, // echo back the account ID as backend would

    requestTaxCertificate: (root, params) => params.accountId,

    requestMaturityPack: (root, params) => ({ accountId: params.accountId }),

    getAccentureCategoryRules: (root, params: { accountId: string }, context) =>
      getAccentureCategoryRules(params.accountId, context.requestStatus),

    getSonataTransactions: (
      root,
      params: { criteria: { accountId: string; fromDate: string; toDate: string } },
      context,
    ) => {
      return [
        {
          effectiveDate: '2022-08-20T00:00:00Z',
          transactionType: 'Management charge',
          amount: 120, // Should handle integers
        },
        {
          effectiveDate: '2022-08-18T20:31:10Z',
          transactionType: 'Tax-free cash payment',
          amount: -34_290.08, // Should handle negative numbers
        },
        {
          effectiveDate: '2022-08-17T00:00:00Z',
          transactionType: 'Switch funds',
          // NB: The actual GraphQL will never return a 0, but we have some FE logic for formatting zeroes, so I've
          // included a 0.0 transaction here just to demonstrate that it would behave correctly if we ever did get a 0
          amount: 0.0,
        },
        {
          effectiveDate: '2022-08-16T00:00:00Z',
          transactionType: 'Tax-free cash payment',
          amount: 100000.0,
        },
        {
          effectiveDate: '2022-08-15T00:00:00Z',
          transactionType: 'Switch funds',
          amount: -1000000.0,
        },
        {
          effectiveDate: '2022-08-14T00:00:00Z',
          transactionType: 'Switch funds',
          amount: 1000000.0,
        },
        {
          effectiveDate: '2022-08-13T11:22:33.444Z', // Sometimes Sonata returns timestamps including milliseconds
          transactionType: 'Pension fund crystallisation',
          amount: 56_000.0,
        },
      ];
    },
  },
  MutationType: {
    workplacePensionSwitchAndRedirectOrder: () => ({
      outcome: 'SUCCESS',
    }),

    processDecumulationOrder: () => ({ orderReference: '1234' }),

    updateAccountNominatedBeneficiaries: (root, params) => {
      if (params.input.beneficiaryDetails[0].surname.toLowerCase() === 'fail') {
        throw new Error('Mock Response - Failed to update');
      }

      return { ...params.input }; // Echo input back to client
    },

    saveNominatedBeneficiaries: (root, params, context) => {
      // &setMockError=saveNominatedBeneficiariesError
      if (context.mockError === 'saveNominatedBeneficiariesError') {
        throw new GraphQLError('Exception while submitting data', {
          extensions: {
            code: '200',
            errorType: 'TESTERROR',
            classification: 'SubmitError',
          },
        });
      }

      return { ...params.input }; // Echo input back to client
    },

    updateAccountRetirementAge: () => ({
      accountId: '2884066031',
      newRetirementDate: '2023-12-18T00:00:00Z',
    }),
    submitAccentureOrder: (root, params, context) =>
      submitAccentureOrder(params, context.requestStatus),
  },
};
