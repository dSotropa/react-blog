import { GraphQLError } from 'graphql';
import * as moment from 'moment';

import DurationConstructor = moment.unitOfTime.DurationConstructor;

// The following is used by user singleContributionOnly for the visual checks
export const transactionsList = [
  {
    effectiveDate: moment().subtract(1, 'day').format('YYYY-MM-DD'),
    transactions: [
      {
        transactionName: 'Switched In',
        amountIn: 19,
        amountOut: 0,
        amountInOutUnit: 19,
        fundUnitMovements: [
          {
            fundLongName: 'L&G PMC Cash 3',
            numUnitBought: 0.09,
            numUnitSold: 0,
            unitPrice: 147.78,
          },
          {
            fundLongName: 'L&G PMC Multi-Asset 3',
            numUnitBought: 0.01,
            numUnitSold: 0,
            unitPrice: 570,
          },
        ],
      },
    ],
  },
  {
    effectiveDate: moment().subtract(3, 'months').format('YYYY-MM-DD'),
    transactions: [
      {
        transactionName: 'Switched In',
        amountIn: 62,
        amountOut: 0,
        amountInOutUnit: 62,
        fundUnitMovements: [
          {
            fundLongName: 'L&G PMC Cash 3',
            numUnitBought: 0.05,
            numUnitSold: 0,
            unitPrice: 868,
          },
          {
            fundLongName: 'L&G PMC Multi-Asset 3',
            numUnitBought: 0.07,
            numUnitSold: 0,
            unitPrice: 265.71,
          },
        ],
      },
      {
        transactionName: 'Management Charge',
        amountIn: 0,
        amountOut: 34,
        amountInOutUnit: -34,
        fundUnitMovements: [
          {
            fundLongName: 'L&G Far Eastern 3',
            numUnitBought: 0,
            numUnitSold: 0.09,
            unitPrice: 377.78,
          },
        ],
      },
    ],
  },
];

export function generateTransactions(fromDate: string, toDate: string) {
  return [
    [ 0, 'days' ],
    [ 1, 'day' ],
    [ 3, 'days' ],
    [ 1, 'month' ],
    [ 2, 'months' ],
    [ 12, 'months' ],
    [ 24, 'months' ],
    [ 25, 'months' ],
    [ 3, 'years' ],
    [ 4, 'years' ],
  ]
    .filter(([ amount, timeframe ]: [number, DurationConstructor]) => {
      return moment().subtract(amount, timeframe).isBetween(fromDate, toDate);
    })
    .map(([ amount, timeframe ]: [number, DurationConstructor], index: number) => {
      const positiveValue = Math.floor(Math.random() * 100);
      const negativeValue = Math.floor(Math.random() * 100);

      const unitsBoughtFund1 = Number((Math.random() / 10).toPrecision(1));
      const unitsBoughtFund2 = Number((Math.random() / 10).toPrecision(1));
      const unitsSold = Number((Math.random() / 10).toPrecision(1));

      const transactions = [
        {
          transTypeId: 'FPA',
          transSeqNo: '0',
          transactionName: 'Switched In',
          amountIn: positiveValue,
          amountOut: 0,
          amountInOutUnit: positiveValue,
          fundUnitMovements: [
            {
              fundLongName: 'L&G PMC Cash 3',
              numUnitBought: unitsBoughtFund1,
              numUnitSold: 0,
              unitPrice: Number(((positiveValue * 0.7) / unitsBoughtFund1).toFixed(2)),
            },
            {
              fundLongName: 'L&G PMC Multi-Asset 3',
              numUnitBought: unitsBoughtFund2,
              numUnitSold: 0,
              unitPrice: Number(((positiveValue * 0.3) / unitsBoughtFund2).toFixed(2)),
            },
          ],
        },
      ];

      if (index % 2) {
        transactions.push({
          transTypeId: 'FPA',
          transSeqNo: '1',
          transactionName: 'Management Charge',
          amountIn: 0,
          amountOut: negativeValue,
          amountInOutUnit: -negativeValue,
          fundUnitMovements: [
            {
              fundLongName: 'L&G Far Eastern 3',
              numUnitBought: 0,
              numUnitSold: unitsSold,
              unitPrice: Number((negativeValue / unitsSold).toFixed(2)),
            },
          ],
        });
      }

      return {
        effectiveDate: moment().subtract(amount, timeframe).format('YYYY-MM-DD'),
        transactions: transactions,
      };
    });
}

export function getTransactions(toDate, fromDate, userType) {
  if (moment(toDate).diff(moment(fromDate), 'years') >= 2) {
    // Return maxLimitExceeded error
    throw new GraphQLError(
      'Exception while fetching data (/getTransactions) : EXCEEDS_150_GROUPED_TRANSACTIONS',
      {
        extensions: {
          code: '200',
          errorType: 'ExceededMaxTransactionsException',
          classification: 'DataFetchingException',
        },
      },
    );
  } else {
    return userType === 'singleContributionOnly'
      ? transactionsList
      : generateTransactions(fromDate, toDate);
  }
}
