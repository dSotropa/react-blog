import { GraphQLError } from 'graphql';

import { AccentureCategoryRules } from '@libs/mya/shared/utility-data';

const autoEnrolmentCaseResponse: AccentureCategoryRules = {
  category: {
    factSheetUrl:
      'https://www.legalandgeneral.com/workplace/epiforms/a/accenture/factsheet-cat2/',
    externalReference: 'SPSTN2',
    groupCategory: '002',
    categoryRules: [
      {
        ruleType: 'FIXED_RATE',
        employeeRate: 4.0,
        employerRate: 10.0,
        minimumEmployeeRate: 4.0,
        maximumEmployeeRate: 100.0,
      },
      {
        ruleType: 'FIXED_RATE',
        employeeRate: 5.0,
        employerRate: 12.0,
        minimumEmployeeRate: 4.0,
        maximumEmployeeRate: 100.0,
      },
    ],
  },
  categorySwitchRules: [
    {
      category: {
        factSheetUrl:
          'https://www.legalandgeneral.com/workplace/epiforms/a/accenture/factsheet-cat1/',
        externalReference: 'SPSTN1',
        groupCategory: '001',
        categoryRules: [
          {
            ruleType: 'FIXED_RATE',
            employeeRate: 6.0,
            employerRate: 12.0,
            minimumEmployeeRate: 6.0,
            maximumEmployeeRate: 100.0,
          },
          {
            ruleType: 'FIXED_RATE',
            employeeRate: 8.0,
            employerRate: 14,
            minimumEmployeeRate: 6.0,
            maximumEmployeeRate: 100.0,
          },
        ],
      },
    },
  ],
};

const mainCategoryCaseResponse: AccentureCategoryRules = {
  category: {
    factSheetUrl:
      'https://www.legalandgeneral.com/workplace/epiforms/a/accenture/factsheet-cat1/',
    externalReference: 'SPSTN1',
    groupCategory: '001',
    categoryRules: [
      {
        ruleType: 'AGE_BANDED',
        employeeRate: 4.0,
        employerRate: 10.0,
        minimumEmployeeRate: 4.0,
        maximumEmployeeRate: 100.0,
      },
    ],
  },
  categorySwitchRules: [],
};

const fixedRateCaseResponse: AccentureCategoryRules = {
  category: {
    factSheetUrl:
      'https://www.legalandgeneral.com/workplace/epiforms/a/accenture/factsheet-cat19/',
    externalReference: 'SPSTN19',
    groupCategory: '0019',
    categoryRules: [
      {
        ruleType: 'FIXED_RATE',
        employeeRate: 4.0,
        employerRate: 10.0,
        minimumEmployeeRate: 4.0,
        maximumEmployeeRate: 100.0,
      },
      {
        ruleType: 'FIXED_RATE',
        employeeRate: 5.0,
        employerRate: 12.0,
        minimumEmployeeRate: 4.0,
        maximumEmployeeRate: 100.0,
      },
    ],
  },
  categorySwitchRules: [],
};

const allowedStopContributionByDefaultResponse = {
  ...autoEnrolmentCaseResponse,
  category: {
    ...autoEnrolmentCaseResponse.category,
    categoryRules: [
      {
        ruleType: 'FIXED_RATE',
        employeeRate: 0.0,
        employerRate: 6.0,
        minimumEmployeeRate: 0.0,
        maximumEmployeeRate: 100.0,
      },
      {
        ruleType: 'FIXED_RATE',
        employeeRate: 3.0,
        employerRate: 15.0,
        minimumEmployeeRate: 0.0,
        maximumEmployeeRate: 100.0,
      },
    ],
  },
};

const simplifiedFormResponse = {
  ...autoEnrolmentCaseResponse,
  category: {
    ...autoEnrolmentCaseResponse.category,
    categoryRules: [
      {
        ruleType: 'BASE_LINE',
        employeeRate: null,
        employerRate: null,
        minimumEmployeeRate: 0.01,
        maximumEmployeeRate: 100.0,
      },
    ],
  },
};

const switchCategoryRulesMissingResponse = {
  ...autoEnrolmentCaseResponse,
  categorySwitchRules: [],
};

const MAX_RETRY = 3;
// used for the scenario where the API call would fail
let requestCounterUntilSuccess = 0;

export function getAccentureCategoryRules(accountId: string, requestStatus?: string) {
  // these are all specific business cases
  switch (requestStatus) {
    // &setRequestStatus=stopEmployeeContribution
    case 'stopEmployeeContribution':
      return allowedStopContributionByDefaultResponse;
    // &setRequestStatus=simplifiedAccentureContributionForm
    case 'simplifiedAccentureContributionForm':
      return simplifiedFormResponse;
    // &setRequestStatus=switchCategoryRulesMissing
    case 'switchCategoryRulesMissing':
      return switchCategoryRulesMissingResponse;
    // &setRequestStatus=categoryRulesRetry
    case 'categoryRulesRetry':
      retryUntilSuccess();
      break;
  }

  // these are generic business cases
  switch (accountId) {
    case 'ACCENTURE_AUTO_ENROLMENT':
      return autoEnrolmentCaseResponse;

    case 'ACCENTURE_FIXED_RATE':
      return fixedRateCaseResponse;

    default:
      return mainCategoryCaseResponse;
  }
}

function retryUntilSuccess() {
  if (requestCounterUntilSuccess < MAX_RETRY) {
    requestCounterUntilSuccess += 1;

    throw new GraphQLError(
      'Exception while fetching data (/getAccentureCategoryRules): Error while retrieving the accenture category rules for the current account',
      {
        extensions: {
          code: '200',
          classification: 'DataFetchingException',
        },
      },
    );
  } else {
    requestCounterUntilSuccess = 0;
  }
}
