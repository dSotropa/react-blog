import * as express from 'express';

import { TestUser, testUsers } from '../resolvers/test-users';

export interface Context extends TestUser {
  userType: string;
}

type ContextFunction = ({ req }: { req: express.Request }) => Promise<Context>;

export function getContextFunction(): ContextFunction {
  return async ({ req }) => {
    const getQueryVariable = (variable: string): string | undefined => {
      const queryString = req.headers.referer.split('?')[1];
      const vars = queryString?.split('&');

      for (let i = 0; i < vars?.length; i++) {
        const pair = vars[i].split('=');

        if (pair[0] === variable) {
          return pair[1];
        }
      }

      return undefined;
    };

    const accountHash = getQueryVariable('productId');
    const mockError = getQueryVariable('setMockError');
    const requestStatus = getQueryVariable('setRequestStatus');

    const userType: string =
      Object.keys(testUsers).find(k => testUsers[k].accountHash === accountHash) ||
      'accumulationWpp';

    const mockUser: TestUser = {
      ...testUsers[userType],
      mockError,
      requestStatus,
    };

    let session: Context = userType && { userType, ...mockUser };

    if (!session) {
      session = (req.session as any).session as Context;
    }

    return await new Promise(res => res(session));
  };
}
