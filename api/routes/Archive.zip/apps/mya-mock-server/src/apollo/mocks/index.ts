import { faker } from '@faker-js/faker/locale/en_GB';
import { format } from 'date-fns';

import { documentList } from '../resolvers/documents/document-list';

export default {
  DocumentList: () => ({
    documents: documentList,
    hasMoreDocuments: true,
  }),

  Money: () => faker.datatype.number({ min: 1000, max: 2500 }),

  Date: () => format(faker.date.past(2), 'yyyy-mm-dd'),
};
