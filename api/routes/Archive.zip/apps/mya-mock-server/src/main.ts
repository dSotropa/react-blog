import {
  actAsProxy,
  getPort,
  getServers,
  setupListener,
  startApollo,
} from '@libs/shared/utility-mock-server';

import { setupExpressMocks } from './express';
import mocks from './apollo/mocks';
import resolvers from './apollo/resolvers';
import { getContextFunction } from './apollo/helpers';

(async () => {
  let gqlPath;
  const appRefName = 'mya';
  const servers = getServers(appRefName);
  const port: number = getPort();

  if (!actAsProxy) {
    setupExpressMocks({
      server: servers.http,
      port,
      appRefName,
    });

    gqlPath = await startApollo({
      server: servers.http,
      mocks,
      resolvers,
      context: getContextFunction(),
    });
  }

  setupListener({
    appRefName,
    servers,
    port,
    gqlPath,
  });
})();
