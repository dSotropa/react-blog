/* eslint-disable */

export default {
  displayName: 'oss',
  preset: '../../jest.preset.js',
  collectCoverage: true,
  coverageDirectory: '../../reports/unit-tests/oss',
};
