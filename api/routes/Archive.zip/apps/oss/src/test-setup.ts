import 'jest-preset-angular/setup-jest';

import { Config, environment } from '@libs/shared/utility-config-loader';
import { mock } from '@libs/oss/shared/utility-configuration';

environment.config = mock as unknown as Config;
