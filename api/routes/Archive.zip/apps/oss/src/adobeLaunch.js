const satellite = this.window._satellite;
const isLaunchThere = satellite && satellite.pageBottom;

if (isLaunchThere) {
  // eslint-disable-next-line
  _satellite.pageBottom();
}
