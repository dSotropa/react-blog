window.parent.checkPaymentStatus();
