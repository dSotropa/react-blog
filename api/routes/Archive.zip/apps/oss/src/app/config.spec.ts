import { preProd, prod, test } from '@libs/oss/shared/utility-configuration';

interface FeatureToggles {
  id: string;
  features: {
    ISA?: boolean;
    LGPP_ACCUMULATION?: boolean;
    LGPP_DECUMULATION?: boolean;
    payrollTopUp?: boolean;
    debitCardTopUp?: boolean;
    directDebit?: boolean;
    showFaqs?: boolean;
    showBanner?: boolean;
    withdrawals?: boolean;
    showBoldChat?: boolean;
    stopRegularIncome?: boolean;
    showPulse?: boolean;
    showAdvertisingTile?: boolean;
    switchFund?: boolean;
    isEsg?: boolean;
    thirdPartyPayments?: boolean;
    multiFund?: boolean;
    feedbackSurvey: boolean;
  };
}

const getProductFeatureToggles = (
  product: 'ISA' | 'LGPP_ACCUMULATION' | 'LGPP_DECUMULATION',
  features: Array<FeatureToggles>,
) => features.find((f: FeatureToggles) => f.id === product).features;

describe('config', () => {
  describe('prod', () => {
    it('should have the correct ISA feature toggles set', () => {
      const expected = {
        ISA: true,
        payrollTopUp: true,
        debitCardTopUp: true,
        directDebit: true,
        showFaqs: false,
        showBanner: true,
        withdrawals: true,
        showBoldChat: true,
        showPulse: true,
        showAdvertisingTile: true,
        showMoreActions: true,
        showTransferIn: true,
        showWisaTransferIn: true,
        switchFund: false,
        isEsg: false,
        multiFund: false,
        feedbackSurvey: false,
      };

      const toggles = getProductFeatureToggles('ISA', prod.featureToggles);

      expect(toggles).toEqual(expected);
    });

    it('should have the correct LGPP feature toggles set', () => {
      const expected = {
        LGPP_ACCUMULATION: true,
        debitCardTopUp: true,
        showFaqs: true,
        showBanner: true,
        directDebitEnabled: true,
        amendDirectDebitEnabled: true,
        showBoldChat: true,
        moveToDrawdown: true,
        showPulse: true,
        existingTransferIn: true,
        showAdvertisingTile: true,
        showMoreActions: true,
        enableMfnTracing: true,
        switchFund: true,
        isEsg: false,
        thirdPartyPayments: false,
        multiFund: false,
        feedbackSurvey: false,
      };

      const toggles = getProductFeatureToggles('LGPP_ACCUMULATION', prod.featureToggles);

      expect(toggles).toEqual(expected);
    });

    it('should have the correct Pension Decumulation feature toggles set', () => {
      const expected = {
        LGPP_DECUMULATION: true,
        showFaqs: true,
        showBanner: true,
        showBoldChat: true,
        stopRegularIncome: true,
        showPulse: true,
        showAdvertisingTile: false,
        showMoreActions: true,
        switchFund: false,
        feedbackSurvey: false,
      };

      const toggles = getProductFeatureToggles('LGPP_DECUMULATION', prod.featureToggles);

      expect(toggles).toEqual(expected);
    });

    it('should NEVER have cardPaymentAccreditationInProgress set to true', () => {
      /*
      this property should never be set to true. If it is, then it will disable important
      input validations in production
      */
      expect(prod.cardPaymentAccreditationInProgress).toEqual(false);
    });
  });

  describe('pre-prod', () => {
    it('should have the correct ISA feature toggles set', () => {
      const expected = {
        ISA: true,
        payrollTopUp: true,
        debitCardTopUp: true,
        directDebit: true,
        showFaqs: false,
        showBanner: true,
        withdrawals: true,
        showBoldChat: true,
        showPulse: true,
        showAdvertisingTile: true,
        showMoreActions: true,
        showTransferIn: true,
        showWisaTransferIn: true,
        switchFund: false,
        isEsg: false,
        multiFund: false,
        feedbackSurvey: false,
      };

      const toggles = getProductFeatureToggles('ISA', preProd.featureToggles);

      expect(toggles).toEqual(expected);
    });

    it('should have the correct LGPP feature toggles set in pre-prod', () => {
      const expected = {
        LGPP_ACCUMULATION: true,
        debitCardTopUp: true,
        showFaqs: true,
        showBanner: true,
        directDebitEnabled: true,
        amendDirectDebitEnabled: true,
        showBoldChat: true,
        moveToDrawdown: true,
        showPulse: true,
        existingTransferIn: true,
        showAdvertisingTile: true,
        showMoreActions: true,
        enableMfnTracing: true,
        switchFund: true,
        isEsg: false,
        thirdPartyPayments: false,
        multiFund: false,
        feedbackSurvey: false,
      };

      const toggles = getProductFeatureToggles(
        'LGPP_ACCUMULATION',
        preProd.featureToggles,
      );

      expect(toggles).toEqual(expected);
    });

    it('should have the correct Pension Decumulation feature toggles set', () => {
      const expected = {
        LGPP_DECUMULATION: true,
        showFaqs: true,
        showBanner: true,
        showBoldChat: true,
        stopRegularIncome: true,
        showPulse: true,
        showAdvertisingTile: false,
        showMoreActions: true,
        switchFund: false,
        feedbackSurvey: false,
      };

      const toggles = getProductFeatureToggles(
        'LGPP_DECUMULATION',
        preProd.featureToggles,
      );

      expect(toggles).toEqual(expected);
    });
  });

  describe('test', () => {
    it('should have the correct ISA feature toggles set', () => {
      const expected = {
        ISA: true,
        payrollTopUp: true,
        debitCardTopUp: true,
        directDebit: true,
        showFaqs: false,
        showBanner: true,
        withdrawals: true,
        showBoldChat: true,
        showPulse: true,
        showAdvertisingTile: true,
        showMoreActions: true,
        showTransferIn: true,
        showWisaTransferIn: true,
        switchFund: true,
        isEsg: false,
        multiFund: true,
        feedbackSurvey: true,
      };

      const toggles = getProductFeatureToggles('ISA', test.featureToggles);

      expect(toggles).toEqual(expected);
    });

    it('should have the correct LGPP feature toggles set', () => {
      const expected = {
        LGPP_ACCUMULATION: true,
        debitCardTopUp: true,
        showFaqs: true,
        showBanner: true,
        directDebitEnabled: true,
        amendDirectDebitEnabled: true,
        showBoldChat: true,
        moveToDrawdown: true,
        showPulse: true,
        existingTransferIn: true,
        showAdvertisingTile: true,
        showMoreActions: true,
        enableMfnTracing: true,
        switchFund: true,
        isEsg: false,
        thirdPartyPayments: true,
        multiFund: true,
        feedbackSurvey: true,
      };

      const toggles = getProductFeatureToggles('LGPP_ACCUMULATION', test.featureToggles);

      expect(toggles).toEqual(expected);
    });

    it('should have the correct Pension Decumulation feature toggles set', () => {
      const expected = {
        LGPP_DECUMULATION: true,
        showFaqs: true,
        showBanner: true,
        showBoldChat: true,
        stopRegularIncome: true,
        showPulse: true,
        showAdvertisingTile: false,
        showMoreActions: true,
        switchFund: true,
        feedbackSurvey: true,
      };

      const toggles = getProductFeatureToggles('LGPP_DECUMULATION', test.featureToggles);

      expect(toggles).toEqual(expected);
    });
  });
});
