import { APP_BASE_HREF } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';
import { Store, StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import {
  LgAccordionModule,
  LgButtonModule,
  LgCardModule,
  LgFeatureToggleModule,
  LgGridModule,
  LgHeaderModule,
  LgHideAtModule,
  LgMarginModule,
  LgPageModule,
  LgShowAtModule,
} from '@legal-and-general/canopy';
import { OverlayModule } from '@angular/cdk/overlay';
import { A11yModule } from '@angular/cdk/a11y';

import { AuthGuard, USE_SHARED_AUTH_TOKEN_REFRESH } from '@libs/shared/utility-auth';
import { SharedFeatureSurveyModule } from '@libs/shared/feature-survey';
import { OssSharedUiDialogModule } from '@libs/oss/shared/ui-dialog';
import { OssSharedUiModule } from '@libs/oss/shared/ui';
import { SharedUtilityDirectivesModule } from '@libs/shared/utility-directives';
import { OssSharedUtilityDirectivesModule } from '@libs/oss/shared/utility-directives';
import { environment } from '@libs/shared/utility-config-loader';
import { OssSharedUtilityPipesModule } from '@libs/oss/shared/utility-pipes';
import { AuthInterceptor } from '@oss/auth/auth.interceptor';
import { BaseModule } from '@oss/base/base.module';
import { metaReducers } from '@oss/core/reducers';
import { DisplayDisclaimerShellComponent } from '@oss/base/containers/display-disclaimer-shell/display-disclaimer-shell.component';
import { DisplayDisclaimerComponent } from '@oss/base/components/display-disclaimer/display-disclaimer.component';
import { DisplayOverviewShellComponent } from '@oss/base/containers/display-overview-shell/display-overview-shell.component';
import { getFeatureToggles } from '@oss/state/selectors';
import { SharedModule } from '@oss/shared/shared.module';
import { AccountNotificationModule } from '@oss/base/components/account-notification/account-notification.module';
import { WindowService } from '@libs/shared/utility-service-window';
import { getBaseHref } from '@libs/shared/utility-helpers';

import { GraphQLModule } from './graphql.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DisplayErrorShellComponent } from './oss/error-shell/error-shell.component';
import { DisplayErrorComponent } from './oss/error-shell/error/error.component';
import { HeaderComponent } from './oss/header/header.component';

@NgModule({
  imports: [
    BrowserModule,
    HttpClientModule,
    BaseModule,
    StoreModule.forRoot(
      {},
      {
        metaReducers,
        runtimeChecks: { strictStateImmutability: true, strictActionImmutability: true },
      },
    ),
    !environment.config.production
      ? StoreDevtoolsModule.instrument()
      : [],
    EffectsModule.forRoot([]),
    FlexLayoutModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    GraphQLModule,
    OverlayModule,
    A11yModule,
    SharedUtilityDirectivesModule,
    OssSharedUiDialogModule,
    OssSharedUiModule,
    OssSharedUtilityDirectivesModule,
    OssSharedUtilityPipesModule,
    LgFeatureToggleModule.forRoot(
      {
        deps: [ Store ],
        useFactory: (store: Store<any>) => store.select(getFeatureToggles),
      },
      {
        defaultHide: true,
      },
    ),
    SharedModule,
    LgCardModule,
    LgAccordionModule,
    LgHeaderModule,
    LgPageModule,
    LgGridModule,
    LgShowAtModule,
    LgHideAtModule,
    LgMarginModule,
    LgButtonModule,
    AccountNotificationModule,
    SharedFeatureSurveyModule,
  ],
  declarations: [
    AppComponent,
    HeaderComponent,
    DisplayDisclaimerShellComponent,
    DisplayDisclaimerComponent,
    DisplayOverviewShellComponent,
    DisplayErrorShellComponent,
    DisplayErrorComponent,
  ],
  providers: [
    AuthGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true,
    },
    { provide: 'Window', useFactory: () => window },
    {
      provide: APP_BASE_HREF,
      useFactory: getBaseHref,
      deps: [ WindowService ],
    },
    { provide: USE_SHARED_AUTH_TOKEN_REFRESH, useValue: false },
  ],
  bootstrap: [ AppComponent ],
})
export class AppModule {}
