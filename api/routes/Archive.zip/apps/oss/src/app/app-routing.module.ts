import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AuthGuard } from '@libs/shared/utility-auth';
import { DisplayMultifundOptionsShellComponent } from '@oss/base/containers/tiles/display-multifund-options-shell/display-multifund-options-shell.component';
import { MainWrapperComponent } from '@libs/oss/core/feature-main-wrapper';

import { DisplayTransfersShellComponent } from './oss/base/containers/tiles/display-transfers-shell/display-transfers-shell.component';
import { DisplayPulseShellComponent } from './oss/base/containers/tiles/display-pulse-shell/display-pulse-shell.component';
import { DisplayActivityShellComponent } from './oss/base/containers/tiles/display-activity-shell/display-activity-shell.component';
import { DisplayInvestmentShellComponent } from './oss/base/containers/tiles/display-investment-shell/display-investment-shell.component';
import { DisplayPaymentShellComponent } from './oss/base/containers/tiles/display-payment-shell/display-payment-shell.component';
import { DisplayDocumentShellComponent } from './oss/base/containers/tiles/display-document-shell/display-document-shell.component';
import { DisplayDetailShellComponent } from './oss/base/containers/tiles/display-detail-shell/display-detail-shell.component';
import { DisplayFundShellComponent } from './oss/base/containers/tiles/display-fund-shell/display-fund-shell.component';
import { DisplayErrorShellComponent } from './oss/error-shell/error-shell.component';
import { DisplayChangeInvestmentsShellComponent } from './oss/base/containers/tiles/display-change-investments-shell/display-change-investments-shell.component';
import { AppRoutingService } from './products/app-routing.service';
import { ReviewFundDetailsComponent } from './oss/base/components/tiles/review-fund-details/review-fund-details.component';

// All routes should be reflected in helper.spec.ts
// `data: { pageName: <string> }` defines a custom `pageName` to use in the analytics
export const appRoutes: Routes = [
  {
    path: '',
    component: MainWrapperComponent,
    canActivateChild: [ AuthGuard ],
    children: [
      {
        path: 'activity/:id',
        component: DisplayActivityShellComponent,
        data: { pageName: 'Summary' },
      },
      {
        path: 'fund/:id',
        component: DisplayFundShellComponent,
        data: { pageName: 'Fund detail' },
      },
      {
        path: 'investments/:id',
        component: DisplayInvestmentShellComponent,
        data: { pageName: 'Your investments' },
      },
      {
        path: 'payments/:id',
        component: DisplayPaymentShellComponent,
        data: { pageName: 'Your payments' },
      },
      {
        path: 'withdrawals/:id',
        component: DisplayPaymentShellComponent,
        data: { pageName: 'Your withdrawals' },
      },
      {
        path: 'transfers/:id',
        component: DisplayTransfersShellComponent,
        data: { pageName: 'Your transfers' },
      },
      {
        path: 'documents/:id',
        component: DisplayDocumentShellComponent,
        data: { pageName: 'Your documents' },
      },
      {
        path: 'details/:id',
        component: DisplayDetailShellComponent,
        data: { pageName: 'Your pension details' },
      },
      {
        path: 'fees-charges/:id',
        component: DisplayDetailShellComponent,
        data: { pageName: 'Your fees and charges' },
      },
      {
        path: 'pulse/:id',
        component: DisplayPulseShellComponent,
        data: { pageName: 'The pulse' },
      },
      {
        path: 'change-investments/:id',
        component: DisplayChangeInvestmentsShellComponent,
        data: { pageName: 'Change Investments' },
      },

      {
        path: 'multifund-options/:id',
        component: DisplayMultifundOptionsShellComponent,
        data: { pageName: 'Funds available to you' },
      },
      {
        path: 'review-fund-details/:fund/:id',
        component: ReviewFundDetailsComponent,
        canActivate: [ AuthGuard ],
        data: { pageName: 'Please review and confirm the details below' },
      },
      {
        path: 'direct-debit',
        loadChildren: () =>
          import('@oss/directDebit/direct-debit.module').then(m => m.DirectDebitModule),
      },
      {
        path: 'isa',
        loadChildren: () =>
          import('@oss/product/isa/journeys/journeys.module').then(
            m => m.JourneysModule,
          ),
      },
      {
        path: 'drawdown',
        loadChildren: () =>
          import('@oss/product/drawdown/journeys/journeys.module').then(
            m => m.JourneysModule,
          ),
      },
      {
        path: 'lgpp',
        loadChildren: () =>
          import('@oss/product/lgpp/journeys/journeys.module').then(
            m => m.JourneysModule,
          ),
      },
      {
        path: '**',
        component: DisplayErrorShellComponent,
        data: { pageName: 'Oops, something went wrong' },
      },
    ],
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes, {
      anchorScrolling: 'enabled',
      paramsInheritanceStrategy: 'always',
      scrollPositionRestoration: 'enabled',
    }),
  ],
  exports: [ RouterModule ],
  providers: [ AppRoutingService ],
})
export class AppRoutingModule {}
