import { TestBed } from '@angular/core/testing';
import {
  ActivatedRoute,
  ActivationEnd,
  Event,
  NavigationEnd,
  NavigationStart,
  Router,
} from '@angular/router';
import { AnimationEvent } from '@angular/animations';
import { provideMockActions } from '@ngrx/effects/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { ApolloTestingModule } from 'apollo-angular/testing';
import { Observable, of, Subject } from 'rxjs';
import { ConnectionPositionPair } from '@angular/cdk/overlay';
import { TemplateRef, ViewContainerRef } from '@angular/core';
import { CreateEffectMetadata } from '@ngrx/effects';

import { OssSharedUiDialogModule } from '@libs/oss/shared/ui-dialog';
import { JourneyName, Notification } from '@oss/shared/interfaces/oss';
import {
  PulseChecked,
  RemoveNotification,
  ResetJourneyAnimation,
  ResetTimeout,
  SetPageName,
  SetPrimaryRoute,
  SetSelectedRoute,
  UpdateJourneyAnimationPhaseIn,
} from '@oss/state/actions/oss.actions';
import { OssEffects } from '@oss/state/effects/oss.effects';
import {
  getDeviceType,
  getJourneyStatus,
  getOverviewVisible,
  getPrimaryRoute,
  getProduct,
  getSonataHashParameter,
  selectAnalyticsForCustomer,
  selectPulseNeedsChecking,
} from '@oss/state/selectors';
import { selectAccountNotificationIsOpen } from '@oss/base/components/account-notification/state/selectors/account-notification.selectors';
import { HideAccountNotification } from '@oss/base/components/account-notification/state/actions/account-notification.actions';
import { AnalyticsService } from '@oss/shared/services/analytics.service';
import { DeviceDetectionService } from '@oss/shared/services/device-detection.service';
import { AccountNotificationOverlayService } from '@oss/base/components/account-notification/service/account-notification-overlay.service';
import { AccountNotificationComponent } from '@oss/base/components/account-notification/account-notification-component/account-notification.component';
import { mock } from '@libs/oss/shared/utility-configuration';
import { Config, environment } from '@libs/shared/utility-config-loader';
import { QualtricsService } from '@libs/oss/shared/feature-survey';

import { AppComponent } from './app.component';
import { Products } from './oss/constants';

describe('AppComponent', () => {
  let component: AppComponent;
  let mockEffects: jest.MockedObject<OssEffects>;
  let store: MockStore<any>;
  let mockRouter: jest.MockedObject<Router>;
  let deviceDetectionServiceSpyObject: jest.MockedObject<DeviceDetectionService>;
  let viewContainerRefMock: jest.MockedObject<ViewContainerRef>;
  let accountNotificationMock: jest.MockedObject<AccountNotificationOverlayService>;
  let analyticsServiceMock: jest.MockedObject<AnalyticsService>;
  let activatedRouteMock: jest.MockedObject<ActivatedRoute>;
  let qualtricsServiceMock: jest.MockedObject<QualtricsService>;
  const actions$ = of();
  const routerEvents = new Subject<Event>();

  const journeyStatus = {
    active: 'active',
    phaseIn: 1,
    phaseOut: 0,
    animationDisabled: false,
    journeyName: JourneyName.isaStartRegularPayment,
    pathName: 'test-path',
  };

  beforeAll(() => {
    environment.config = mock as unknown as Config;
  });

  beforeEach(() => {
    mockRouter = {
      navigate: jest.fn(),
      events: routerEvents,
      url: 'example.com/activity/(124)',
    } as unknown as jest.MockedObject<Router>;

    TestBed.configureTestingModule({
      imports: [ ApolloTestingModule, OssSharedUiDialogModule ],
      providers: [
        { provide: Router, useValue: mockRouter },
        provideMockStore({}),
        provideMockActions(() => actions$),
        { provide: 'Window', useFactory: () => {} },
      ],
    });
  });

  const notificationAnchorPosition = {
    originY: 'bottom',
  } as ConnectionPositionPair;

  beforeEach(() => {
    deviceDetectionServiceSpyObject = {
      initialise: jest.fn(),
    } as jest.MockedObject<DeviceDetectionService>;

    viewContainerRefMock = {
      '': jest.fn(),
    } as unknown as jest.MockedObject<ViewContainerRef>;

    accountNotificationMock = {
      show: jest.fn(),
      hide: jest.fn(),
    } as jest.MockedObject<AccountNotificationOverlayService>;

    accountNotificationMock.anchorPositionChanges$ = of(notificationAnchorPosition);

    analyticsServiceMock = {
      pageTrack: jest.fn(),
      setCustomer: jest.fn(),
    } as jest.MockedObject<AnalyticsService>;

    qualtricsServiceMock = {
      init: jest.fn(),
    } as jest.MockedObject<QualtricsService>;

    activatedRouteMock = {
      firstChild: jest.fn(),
    } as unknown as jest.MockedObject<ActivatedRoute>;

    mockEffects = {
      resetTimeout$: jest.fn(),
    } as unknown as jest.MockedObject<OssEffects>;

    mockEffects.resetTimeout$ = of() as unknown as Observable<ResetTimeout> &
      CreateEffectMetadata;

    store = TestBed.inject(MockStore);

    store.overrideSelector(getSonataHashParameter, '123');
    store.overrideSelector(getDeviceType, 'mobile');
    store.overrideSelector(getOverviewVisible, false);
    store.overrideSelector(getJourneyStatus, journeyStatus);
    store.overrideSelector(getProduct, Products.LGPP);
    store.overrideSelector(selectAccountNotificationIsOpen, true);
    store.refreshState();

    component = new AppComponent(
      mockRouter,
      activatedRouteMock,
      store,
      deviceDetectionServiceSpyObject,
      mockEffects,
      viewContainerRefMock,
      accountNotificationMock,
      analyticsServiceMock,
      qualtricsServiceMock,
    );

    component.accountNotification = {
      updateAnchorPosition: jest.fn(),
    } as jest.MockedObject<AccountNotificationComponent>;
  });

  afterEach(() => {
    store.resetSelectors();
    TestBed.resetTestingModule();
  });

  it('Should listen to route changes', () => {
    const expected = new ResetTimeout();
    const spy = jest.spyOn(store, 'dispatch');

    component.resetTimerOnRouteChange();
    routerEvents.next(new ActivationEnd(null));

    expect(spy).toHaveBeenCalledWith(expected);
  });

  it('should remove specific notification from the store', () => {
    const notification: Notification = {
      text: 'test1 message',
      type: 'success',
    };

    const expected = new RemoveNotification(notification);
    const spy = jest.spyOn(store, 'dispatch');

    component.removeNotification(notification);

    expect(spy).toHaveBeenCalledWith(expected);
  });

  it('should dispatch an action to save the selected route in the store', () => {
    component.selectedRoute = 'Test Route';
    const expected = new SetSelectedRoute('Test Route');

    const spy = jest.spyOn(store, 'dispatch');

    component.saveRoute();

    expect(spy).toHaveBeenCalledWith(expected);
  });

  it('should dispatch an action to save the primary route in the store', () => {
    component.selectedRoute = 'activity';
    const expected = new SetPrimaryRoute('activity');

    const spy = jest.spyOn(store, 'dispatch');

    component.saveRoute();

    expect(spy).toHaveBeenCalledWith(expected);
    expect(spy).toHaveBeenCalledTimes(2);
  });

  it('should not dispatch an action to save a non-primary route in the store', () => {
    component.selectedRoute = 'start-regular-payment';

    const spy = jest.spyOn(store, 'dispatch');

    component.saveRoute();

    expect(spy).toHaveBeenCalledTimes(1);
  });

  it('should start animation phase correctly', () => {
    const expected = new UpdateJourneyAnimationPhaseIn(2);
    const spy = jest.spyOn(store, 'dispatch');
    const testEvent: AnimationEvent = {
      fromState: 'fromState',
      toState: 'toState',
      totalTime: 1000,
      phaseName: 'phase',
      element: 'element',
      triggerName: 'trigger',
      disabled: false,
    };

    component.startAnimationPhase2(testEvent);

    expect(spy).toHaveBeenCalledWith(expected);
  });

  it('should reset & exit the journey animation correctly', () => {
    const testEvent: AnimationEvent = {
      fromState: 'fromState',
      toState: 'toState',
      totalTime: 1000,
      phaseName: 'phase',
      element: 'element',
      triggerName: 'trigger',
      disabled: false,
    };
    const expected = new ResetJourneyAnimation();

    store.overrideSelector(getPrimaryRoute, '');

    const spy = jest.spyOn(store, 'dispatch');

    component.endExitAnimation(testEvent);

    expect(spy).toHaveBeenCalledWith(expected);
  });

  it('should get the pulse notifications in onInit', () => {
    store.overrideSelector(selectPulseNeedsChecking, true);

    component.setDefaultState();

    let actual = null;

    component.newNotification$.subscribe(m => (actual = m));

    expect(actual).toBe(true);
  });

  it('should dispatch the PulseChecked() action if navigating to the `/pulse` page', () => {
    const spy = jest.spyOn(store, 'dispatch');

    const expected = new PulseChecked();

    component.findRoute();

    (mockRouter.url as any) = '/pulse';

    routerEvents.next(
      new NavigationEnd(1, 'https://www.example.com', 'https://www.example.com'),
    );

    expect(spy).toHaveBeenCalledWith(expected);
  });

  describe('Store tests', () => {
    it('should select the sonata hash parameter from the store', () => {
      component.setDefaultState();

      let actual = null;

      component.sonataHashParameter$.subscribe(_ => (actual = _));

      expect(actual).toEqual('123');
    });

    it('should select the default device type from the store', () => {
      component.setDefaultState();

      let actual = null;

      component.deviceType$.subscribe(_ => (actual = _));

      expect(actual).toEqual('mobile');
    });

    it('should invoke the journey & set state accordingly', () => {
      component.setDefaultState();

      let actual = null;

      component.journeyStatus$.subscribe(_ => (actual = _));

      expect(actual).toEqual(journeyStatus);
      expect(component.journeyActive).toEqual('inactive');
      expect(component.journeyPhaseIntro).toEqual(0);
      expect(component.journeyPhaseExit).toEqual(0);
    });

    it('should remove the hashed parameter', () => {
      component.hash = '(124)';

      expect(component.removeHashParameter()).toBe('/example.com/activity');
    });

    it('should divert a journey url to the summary home page', () => {
      component.selectedRoute = undefined;
      component.initialExecWithJourneyRoute = true;

      expect(component.removeHashParameter()).toBe('/activity');
    });

    it('should remove the closing bracket if called with a journey url', () => {
      component.saveHashParameterAndGetData();

      expect(component.hash).toBe('(124');
      expect(component.initialExecWithJourneyRoute).toBe(true);
    });

    it('should select the product from state', () => {
      let actual = null;

      component.ngOnInit();

      component.product$.subscribe(p => (actual = p));

      expect(actual).toEqual(Products.LGPP);
    });
  });

  describe('account notification', () => {
    let accountNotificationTemplateMock: jest.MockedObject<TemplateRef<any>>;
    let accountNotificationComponentMock: jest.MockedObject<AccountNotificationComponent>;

    beforeEach(() => {
      accountNotificationTemplateMock = {
        '': jest.fn(),
      } as unknown as jest.MockedObject<TemplateRef<any>>;

      accountNotificationComponentMock = {
        updateAnchorPosition: jest.fn(),
      } as jest.MockedObject<AccountNotificationComponent>;

      component.notificationTemplate = accountNotificationTemplateMock;
      component.accountNotification = accountNotificationComponentMock;
    });

    it('should get the open status of the account notification in ngOnInit and show the notification when triggered', () => {
      component.ngOnInit();

      expect(accountNotificationMock.show).toHaveBeenCalledWith(
        viewContainerRefMock,
        accountNotificationTemplateMock,
      );
    });

    it('should get the open status of the account notification in ngOnInit and hide the notification when triggered', () => {
      store.overrideSelector(selectAccountNotificationIsOpen, false);

      store.refreshState();

      component.ngOnInit();

      expect(accountNotificationMock.hide).toHaveBeenCalledTimes(1);
    });

    it('should hide any account notification upon navigation start', () => {
      const spy = jest.spyOn(store, 'dispatch');

      component.ngOnInit();

      routerEvents.next(new NavigationStart(1, 'https://www.example.com', 'imperative'));

      expect(spy).toHaveBeenCalledWith(new HideAccountNotification());
    });

    it('should not attempt to hide any account notification upon navigation start when none is displayed', () => {
      const spy = jest.spyOn(store, 'dispatch');

      store.overrideSelector(selectAccountNotificationIsOpen, false);

      store.refreshState();

      component.ngOnInit();

      routerEvents.next(new NavigationStart(1, 'https://www.example.com', 'imperative'));

      expect(spy).not.toHaveBeenCalledTimes(1);
    });

    it('should call the updateAnchorPosition on the account notification component when the position of the anchor changes', () => {
      store.refreshState();

      component.ngOnInit();

      expect(accountNotificationComponentMock.updateAnchorPosition).toHaveBeenCalledWith(
        notificationAnchorPosition,
      );
    });
  });

  describe('Analytics tests', () => {
    beforeEach(() => {
      store.overrideSelector(selectAnalyticsForCustomer, {
        product: 'Lgpp',
        type: null,
      });

      component.setDefaultState();
    });

    it('should update state with the pageName', () => {
      const pageName = 'MOP';

      const expected = new SetPageName(pageName);
      const spy = jest.spyOn(store, 'dispatch');

      (activatedRouteMock.firstChild as unknown) = { snapshot: { data: { pageName } } };

      component.selectedRoute = 'not applicable';
      component.findRoute();

      routerEvents.next(new NavigationEnd(1, '', ''));

      expect(spy).toHaveBeenCalledWith(expected);
    });

    it('should get the pageName from the activatedRoute data if available and update the page name', () => {
      const expected = { pageName: 'MOP' };

      (activatedRouteMock.firstChild as unknown) = { snapshot: { data: expected } };

      component.selectedRoute = 'not applicable';
      component.findRoute();

      routerEvents.next(new NavigationEnd(1, '', ''));

      expect(analyticsServiceMock.pageTrack).toHaveBeenCalledWith(expected);
    });

    it('should get the pageName from the child activatedRoute data if available and update the page name', () => {
      const expected = { pageName: 'Korn' };

      (activatedRouteMock.firstChild as unknown) = {
        firstChild: { snapshot: { data: expected } },
      };

      component.selectedRoute = 'not applicable';
      component.findRoute();

      routerEvents.next(new NavigationEnd(1, '', ''));

      expect(analyticsServiceMock.pageTrack).toHaveBeenCalledWith(expected);
    });

    it('should get the pageName from the selectedRoute if the activatedRoute data is unavailable', () => {
      jest.spyOn(component, 'removeHashParameter').mockReturnValue('Dr. Dre');

      const expected = { pageName: 'Dr. Dre' };

      component.findRoute();

      routerEvents.next(new NavigationEnd(1, '', ''));

      expect(analyticsServiceMock.pageTrack).toHaveBeenCalledWith(expected);
    });

    it('should set the customer analytics data', () => {
      expect(analyticsServiceMock.setCustomer).toHaveBeenCalledWith({
        product: 'Lgpp',
        type: null,
      });
    });
  });

  describe('Qualtrics', () => {
    it('should initialise the Qualtrics survey in onInit', () => {
      spyOn(qualtricsServiceMock, 'init');

      component.ngOnInit();

      expect(qualtricsServiceMock.init).toHaveBeenCalledTimes(1);
    });
  });
});
