import {
  Component,
  OnDestroy,
  OnInit,
  TemplateRef,
  ViewChild,
  ViewContainerRef,
} from '@angular/core';
import {
  ActivatedRoute,
  ActivationEnd,
  NavigationEnd,
  NavigationStart,
  Router,
} from '@angular/router';
import { AnimationEvent } from '@angular/animations';
import { select, Store } from '@ngrx/store';
import { interval, Observable } from 'rxjs';
import { filter, takeWhile, tap } from 'rxjs/operators';

import { QualtricsService } from '@libs/oss/shared/feature-survey';
import {
  DisplayHomePage,
  PulseChecked,
  RemoveNotification,
  ResetJourneyAnimation,
  ResetTimeout,
  SetFooterAnimationStatus,
  SetPageName,
  SetPrimaryRoute,
  SetSelectedRoute,
  SetSonataHashParameter,
  ShowTimeoutModal,
  UpdateJourneyAnimationPhaseIn,
} from '@oss/state/actions/oss.actions';
import * as fromOssSelectors from '@oss/state/selectors/oss.selectors';
import { selectPulseNeedsChecking } from '@oss/state/selectors/oss.selectors';
import { environment } from '@libs/shared/utility-config-loader';
import { isValidRoute } from '@oss/shared/utils/helper';
import { selectAccountNotificationIsOpen } from '@oss/base/components/account-notification/state/selectors/account-notification.selectors';
import { AccountNotificationOverlayService } from '@oss/base/components/account-notification/service/account-notification-overlay.service';
import { AccountNotificationTemplateDirective } from '@oss/base/components/account-notification/directive/account-notification-template.directive';
import { AccountNotificationComponent } from '@oss/base/components/account-notification/account-notification-component/account-notification.component';
import { HideAccountNotification } from '@oss/base/components/account-notification/state/actions/account-notification.actions';

import { DisplayTransaction } from './oss/shared/interfaces/oss-extended';
import { Products, SurveyId } from './oss/constants';
import {
  journeyExitPhase5,
  journeyPhase1,
} from './oss/shared/utils/animations/oss-journey-animations';
import {
  fadeTransition,
  routerTransition,
} from './oss/shared/utils/animations/oss-animations';
import {
  FooterAnimationStatus,
  JourneyStatus,
  Notification,
} from './oss/shared/interfaces/oss';
import { OssEffects } from './oss/base/state/effects/oss.effects';
import { DeviceDetectionService } from './oss/shared/services/device-detection.service';
import { AccountView } from './graphql-types/generated/graphql-types';
import { AnalyticsService } from './oss/shared/services/analytics.service';

@Component({
  selector: 'lg-app-root',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.scss' ],
  animations: [ routerTransition, fadeTransition, journeyPhase1, journeyExitPhase5 ],
})
export class AppComponent implements OnInit, OnDestroy {
  @ViewChild(AccountNotificationTemplateDirective, { read: TemplateRef })
    notificationTemplate: TemplateRef<AccountNotificationComponent>;
  @ViewChild(AccountNotificationComponent)
    accountNotification: AccountNotificationComponent;

  sonataHashParameter$: Observable<string>;
  deviceType$: Observable<string>;
  notifications$: Observable<Array<Notification>>;
  footerAnimationStatus$: Observable<FooterAnimationStatus>;
  journeyStatus$: Observable<JourneyStatus>;
  newNotification$: Observable<boolean>;
  customerAccount$: Observable<AccountView>;
  destroy = false;
  secondsRemaining: number;
  interval$: Observable<number>;
  modalVisible: boolean;
  selectedRoute: string;
  route: string;
  device: string;
  status: FooterAnimationStatus;
  hash: string;
  journeyActive = 'inactive';
  journeyPhaseIntro = 0;
  journeyPhaseExit = 0;
  initialExecWithJourneyRoute: boolean;
  products = Products;
  transactions: Array<DisplayTransaction>;
  notificationOpen: boolean;
  product$: Observable<string>;
  showMoreCardInfo: boolean;
  surveyIds = Object.values(SurveyId);

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private store: Store<any>,
    private deviceDetectionService: DeviceDetectionService,
    private ossEffects: OssEffects,
    private viewContainerRef: ViewContainerRef,
    private accountNotificationOverlayService: AccountNotificationOverlayService,
    private analyticsService: AnalyticsService,
    private qualtricsService: QualtricsService,
  ) {}

  endExitAnimation(event: AnimationEvent): void {
    if (event.totalTime > 0) {
      this.store.pipe(select(fromOssSelectors.getPrimaryRoute)).subscribe(() => {
        this.store.dispatch(new ResetJourneyAnimation());
      });
    }
  }

  startAnimationPhase2(event: AnimationEvent): void {
    if (event.totalTime > 0) {
      this.store.dispatch(new UpdateJourneyAnimationPhaseIn(2));
    }
  }

  setAnimation(): void {
    this.store.dispatch(new SetFooterAnimationStatus(this.status));
  }

  updateFooterAnimationStatus(phase: string): void {
    this.status = {
      ...this.status,
      tile: phase,
    };

    this.setAnimation();
  }

  onAnimationEvent(event: AnimationEvent): void {
    // On animation start/end, update animation status, enabling disclaimer/footer display post transition
    if (event.totalTime) {
      this.updateFooterAnimationStatus(event.phaseName);
    }
  }

  setTriggerRoute(): void {
    // Trigger disclaimer/footer animation
    if (!this.status || this.selectedRoute === '/activity') {
      this.status = {
        ...this.status,
        triggerRoute: this.removePrefix(),
      };

      this.setAnimation();
      this.updateFooterAnimationStatus('done');
    }
  }

  removePrefix(): string {
    return this.selectedRoute.replace('/', '');
  }

  updateAnimationRoute(): void {
    if (this.selectedRoute && this.device) {
      if (this.status || this.selectedRoute !== '/activity') {
        this.route = this.removePrefix() + '-' + this.device;
      }
    }
  }

  removeHashParameter(): string {
    const divider = '/';
    let parm = divider;
    const pathSplit: Array<string> = this.router.url.split(divider);

    if (pathSplit?.length >= 2) {
      // OSS access with journey url -> redirect to summary home page
      if (!this.selectedRoute && this.initialExecWithJourneyRoute) {
        this.store.dispatch(new DisplayHomePage());
        parm += 'activity';
      } else {
        parm += this.extractHash(pathSplit).join(divider);
      }
    }

    return parm;
  }

  // Recognise when accessing OSS using a bookmarked "journey" url
  checkSecondaryRouteURL(): void {
    const lastChar = this.hash.slice(this.hash.length - 1);

    if (lastChar === ')') {
      this.hash = this.hash.slice(0, -1);
      this.initialExecWithJourneyRoute = true;
    }
  }

  saveHashParameterAndGetData(): void {
    const pathSplit = this.router.url.split('/');

    if (pathSplit && pathSplit.length >= 3) {
      const lastElement = pathSplit.length - 1;

      this.hash = pathSplit[lastElement];
      this.checkSecondaryRouteURL();
      this.store.dispatch(new SetSonataHashParameter(this.hash));
    }
  }

  saveRoute(): void {
    // Save selected route
    this.store.dispatch(new SetSelectedRoute(this.selectedRoute));
    // Save primary route (if applicable)
    const primaryRoute = isValidRoute(this.selectedRoute);

    if (primaryRoute) {
      this.store.dispatch(new SetPrimaryRoute(this.selectedRoute));
    }
  }

  findRoute(): void {
    this.router.events
      .pipe(
        filter(event => event instanceof NavigationEnd),
        tap(() => {
          if (!this.selectedRoute) {
            this.saveHashParameterAndGetData();
          }

          this.selectedRoute = this.removeHashParameter();
          this.updateAnimationRoute();
          this.setTriggerRoute();
          this.saveRoute();
          this.checkPulse(this.selectedRoute);
          const pageName = this.parsePageToCommonName(
            this.getPageName(this.selectedRoute, this.activatedRoute),
          );

          this.showMoreCardInfo = pageName !== 'Change Investments';

          this.store.dispatch(new SetPageName(pageName));
          this.analyticsService.pageTrack({ pageName });
        }),
        takeWhile(() => !this.destroy),
      )
      .subscribe();
  }

  setDefaultState(): void {
    this.sonataHashParameter$ = this.store.pipe(
      select(fromOssSelectors.getSonataHashParameter),
    );

    this.deviceType$ = this.store.pipe(select(fromOssSelectors.getDeviceType));
    this.notifications$ = this.store.pipe(select(fromOssSelectors.getNotifications));

    this.customerAccount$ = this.store.pipe(
      select(fromOssSelectors.selectCustomerAccount),
    );

    this.footerAnimationStatus$ = this.store.pipe(
      select(fromOssSelectors.getFooterAnimationStatus),
    );

    this.journeyStatus$ = this.store.pipe(select(fromOssSelectors.getJourneyStatus));

    this.newNotification$ = this.store.pipe(select(selectPulseNeedsChecking));

    this.store
      .pipe(select(fromOssSelectors.selectAnalyticsForCustomer))
      .pipe(takeWhile(() => !this.destroy))
      .subscribe(data => {
        if (data) {
          this.analyticsService.setCustomer(data);
        }
      });
  }

  createTimerSubscription(): void {
    this.interval$.subscribe(() => {
      this.secondsRemaining -= 60;

      if (this.secondsRemaining === 0 && !this.modalVisible) {
        this.modalVisible = true;
        this.store.dispatch(new ShowTimeoutModal());
      }
    });
  }

  resetTimer(): void {
    this.secondsRemaining = 60 * environment.config.sessionTimeoutMinutes;
    this.interval$ = interval(60000);
    this.modalVisible = false;
  }

  resetTimerOnRouteChange(): void {
    this.router.events
      .pipe(filter(event => event instanceof ActivationEnd))
      .subscribe(() => {
        this.store.dispatch(new ResetTimeout());
      });
  }

  removeNotification(index: Notification): void {
    this.store.dispatch(new RemoveNotification(index));
  }

  loadAnalytics(): void {
    if (environment.config.adobeLaunch.url) {
      const node = document.createElement('script');

      node.src = environment.config.adobeLaunch.url;
      node.type = 'text/javascript';
      node.onerror = () => false;
      document.getElementsByTagName('head')[0].appendChild(node);
    }
  }

  ngOnInit(): void {
    this.loadAnalytics();
    this.deviceDetectionService.initialise();

    this.findRoute();
    this.setDefaultState();
    this.resetTimer();
    this.createTimerSubscription();
    this.accountNotificationController();

    if (environment.config.production) {
      this.resetTimerOnRouteChange();

      this.ossEffects.resetTimeout$.subscribe(() => {
        this.resetTimer();
      });
    }

    this.deviceType$.subscribe(device => {
      this.device = device;
      this.updateAnimationRoute();
    });

    this.journeyStatus$.subscribe(journey => {
      this.journeyActive = journey.active;
      this.journeyPhaseIntro = journey.phaseIn;
      this.journeyPhaseExit = journey.phaseOut;
    });

    this.product$ = this.store.pipe(select(fromOssSelectors.getProduct));

    this.qualtricsService.init();
  }

  ngOnDestroy(): void {
    this.destroy = true;
  }

  private extractHash(pathSplit: Array<string>): Array<string> {
    return pathSplit.filter(link => link !== this.hash && link !== '');
  }

  private checkPulse(route: string): void {
    if (route === '/pulse') {
      this.store.dispatch(new PulseChecked());
    }
  }

  private notificationObserver(): void {
    this.accountNotificationOverlayService.anchorPositionChanges$.subscribe(_ => {
      this.accountNotification.updateAnchorPosition(_);
    });
  }

  private accountNotificationController(): void {
    this.store
      .select(selectAccountNotificationIsOpen)
      .pipe(takeWhile(() => !this.destroy))
      .subscribe(isOpen => {
        this.notificationOpen = isOpen;

        if (isOpen) {
          this.accountNotificationOverlayService.show(
            this.viewContainerRef,
            this.notificationTemplate,
          );

          this.notificationObserver();
        } else {
          this.accountNotificationOverlayService.hide();
        }
      });

    this.router.events
      .pipe(takeWhile(() => !this.destroy))
      .pipe(filter(event => event instanceof NavigationStart))
      .subscribe(() => {
        if (this.notificationOpen) {
          this.store.dispatch(new HideAccountNotification());
        }
      });
  }

  private getPageName(selectedRoute: string, activatedRoute: ActivatedRoute): string {
    // get the data from the child route if there are children
    let childRoute = activatedRoute.firstChild;

    while (childRoute) {
      if (childRoute.firstChild) {
        childRoute = childRoute.firstChild;
      } else if (childRoute.snapshot?.data?.pageName) {
        return childRoute.snapshot.data.pageName as string;
      } else {
        return selectedRoute;
      }
    }
  }

  private parsePageToCommonName(routeOrName: string): string {
    const pageName = routeOrName.replace('/', '');

    return pageName.charAt(0).toUpperCase() + pageName.slice(1);
  }
}
