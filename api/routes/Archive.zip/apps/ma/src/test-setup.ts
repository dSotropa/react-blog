import 'jest-preset-angular/setup-jest';
import { TestBed } from '@angular/core/testing';
import { jest } from '@jest/globals';

// Removes messages that pollute the console
window.console.error = jest.fn();
window.console.warn = jest.fn();

export type SpyObject<T> = T & {
  [Property in keyof T]?: jest.Mock<any>;
};

export const createSpyObj = <T>(
  baseName: string,
  methodNames: Array<string>,
): SpyObject<T> => {
  const obj = {};

  methodNames.forEach((element, index, arr) => {
    obj[arr[index]] = jest.fn();
  });

  return obj as SpyObject<T>;
};

/*
 This file (test-setup.ts) is used as a configuration file by the jest.config.js for all the tests
 This is where we can mock DOM related features that are missing from JSDOM
 */
type CompilerOptions = Partial<{
  providers: Array<any>;
  useJit: boolean;
  preserveWhitespaces: boolean;
}>;
export type ConfigureFn = (testBed: typeof TestBed) => void;

export const configureTests = (
  configure: ConfigureFn,
  compilerOptions: CompilerOptions = {},
) => {
  const compilerConfig: CompilerOptions = {
    preserveWhitespaces: false,
    ...compilerOptions,
  };

  const configuredTestBed = TestBed.configureCompiler(compilerConfig);

  configure(configuredTestBed);

  return configuredTestBed.compileComponents().then(() => configuredTestBed);
};
