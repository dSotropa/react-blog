import { Renderer2 } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Router } from '@angular/router';
import { MockComponents, MockModule } from 'ng-mocks';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { instance, mock, reset, verify, when } from '@typestrong/ts-mockito';
import { LgPageComponent } from '@legal-and-general/canopy';

import { SpinnerComponent } from '@libs/ma/shared/ui';
import {
  selectCustomerProfileLoading,
  selectProductsLoading,
  selectShowTimeout,
  selectTogglesLoading,
} from '@libs/ma/shared/utility-selectors';
import { AuthService } from '@libs/shared/utility-auth';
import {
  AnalyticsService,
  DomHelperService,
  LmiService,
  SyndicationService,
} from '@libs/ma/shared/utility-services';
import { WindowService } from '@libs/shared/utility-service-window';
import { SharedFeatureSurveyModule } from '@libs/shared/feature-survey';
import { SupportWidgetComponent } from '@libs/ma/support/feature-support-widget';

import { AuthModule } from './auth.module';
import { AppComponent } from './app.component';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  const mockAnalyticsService = mock(AnalyticsService);
  const mockAuthService = mock(AuthService);
  const mockSyndicationService = mock(SyndicationService);
  const windowServiceMock = mock(WindowService);
  let store: MockStore<any>;
  let routerSpy;
  const partyId = 'testPartyId';

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent,
        MockComponents(SpinnerComponent, SupportWidgetComponent, LgPageComponent),
      ],
      imports: [ AuthModule, RouterTestingModule, MockModule(SharedFeatureSurveyModule) ],
      providers: [
        { provide: AnalyticsService, useValue: instance(mockAnalyticsService) },
        { provide: AuthService, useValue: instance(mockAuthService) },
        { provide: DomHelperService, useValue: instance(mock(DomHelperService)) },
        { provide: LmiService, useValue: instance(mock(LmiService)) },
        { provide: Renderer2, useValue: instance(mock(Renderer2)) },
        { provide: SyndicationService, useValue: instance(mockSyndicationService) },
        { provide: WindowService, useValue: instance(windowServiceMock) },
        provideMockStore({}),
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;

    routerSpy = jest
      .spyOn(TestBed.inject(Router), 'navigate')
      .mockImplementation(jest.fn());

    store = TestBed.inject(MockStore);
    reset(mockAuthService);
    reset(mockAnalyticsService);
    store.overrideSelector(selectShowTimeout, false);
    store.overrideSelector(selectCustomerProfileLoading, false);
    store.overrideSelector(selectProductsLoading, false);
    store.overrideSelector(selectTogglesLoading, false);

    Object.defineProperty(global, 'setInterval', { value: jest.fn() });
  });

  it('should create', () => {
    const testFixture = TestBed.createComponent(AppComponent);
    const app = testFixture.debugElement.componentInstance;

    expect(app).toBeTruthy();
  });

  describe('OnInit', () => {
    it('should initialise the analytics service', () => {
      when(mockAnalyticsService.initialise()).thenReturn();
      fixture.detectChanges();
      verify(mockAnalyticsService.initialise()).once();
    });
  });

  describe('handleClick', () => {
    let element: HTMLElement;

    afterEach(() => {
      document.body.removeChild(element);
    });

    it('should call router.navigate when routerLink class added to an anchor tag', () => {
      element = document.createElement('a');
      element.setAttribute('href', 'someRoute');
      element.setAttribute('class', 'routerLink');
      document.body.appendChild(element);
      element.click();

      expect(routerSpy).toHaveBeenCalledWith([ '/someRoute' ]);
    });

    it('should not call router.navigate when routerLink class not added to an anchor tag', () => {
      element = document.createElement('a');
      document.body.appendChild(element);
      element.click();

      expect(routerSpy).not.toHaveBeenCalled();
    });

    it('should not call router.navigate when routerLink class added to any other tag', () => {
      element = document.createElement('p');
      element.setAttribute('class', 'routerLink');
      document.body.appendChild(element);
      element.click();

      expect(routerSpy).not.toHaveBeenCalled();
    });
  });
});
