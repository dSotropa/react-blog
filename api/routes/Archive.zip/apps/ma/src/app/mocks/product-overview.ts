import { TemplateNumberValues, ProductOverview } from '@libs/ma/shared/utility-data';

/**
 * Returns product overview item corresponding to provided template or 'undefined' if nothing is found.
 * @param productTemplate
 */
export const getMockProductOverview = (
  productTemplate: TemplateNumberValues,
): ProductOverview => {
  return productOverviewMock.find(
    (po: ProductOverview) => po.productTemplate === productTemplate,
  );
};

export const productOverviewMock: Array<ProductOverview> = [
  {
    productTemplate: TemplateNumberValues.T07SelfInvestedPersonalPension,
    content:
      '<p>Your Self Invested Personal Pension is a tax efficient way of saving money for use in your retirement' +
      ' or from age 55.<br><br>You can invest money in a range of funds, collectives and other self-invested assets.' +
      ' Self-investment gives you greater control as you make the investment decisions yourself.<br><br>' +
      ' The value of your investments can go down as well as up, the value of your fund is not guaranteed.' +
      ' It is important to remember this if you are close to taking your benefits from, or surrendering, your policy.' +
      ' Please note, if you are in the process of taking any benefits from or claiming your policy,' +
      ' the value shown may not be correct and the final value may have already been fixed.<br><br><b>' +
      'Further information:</b><br><br>Please read through our common questions.' +
      ' For full information please see your Member\'s Booklet or contact us.</p>',
  },
  {
    productTemplate: TemplateNumberValues.T10Annuity,
    content:
      '<p>Your Self Invested Personal Pension is a tax efficient way of saving money for use in your retirement' +
      ' or from age 55.<br><br>You can invest money in a range of funds, collectives and other self-invested assets.' +
      ' Self-investment gives you greater control as you make the investment decisions yourself.<br><br>' +
      ' The value of your investments can go down as well as up, the value of your fund is not guaranteed.' +
      ' It is important to remember this if you are close to taking your benefits from, or surrendering, your policy.' +
      ' Please note, if you are in the process of taking any benefits from or claiming your policy,' +
      ' the value shown may not be correct and the final value may have already been fixed.<br><br><b>' +
      'Further information:</b><br><br>Please read through our common questions.' +
      ' For full information please see your Member\'s Booklet or contact us.</p>',
  },
  {
    productTemplate: TemplateNumberValues.T14CriticalIllnessCover,
    content:
      '<p>Your Self Invested Personal Pension is a tax efficient way of saving money for use in your retirement' +
      ' or from age 55.<br><br>You can invest money in a range of funds, collectives and other self-invested assets.' +
      ' Self-investment gives you greater control as you make the investment decisions yourself.<br><br>' +
      ' The value of your investments can go down as well as up, the value of your fund is not guaranteed.' +
      ' It is important to remember this if you are close to taking your benefits from, or surrendering, your policy.' +
      ' Please note, if you are in the process of taking any benefits from or claiming your policy,' +
      ' the value shown may not be correct and the final value may have already been fixed.<br><br><b>' +
      'Further information:</b><br><br>Please read through our common questions.' +
      ' For full information please see your Member\'s Booklet or contact us.</p>',
  },
  {
    productTemplate: TemplateNumberValues.T15Over50s,
    content:
      '<p>Your Self Invested Personal Pension is a tax efficient way of saving money for use in your retirement' +
      ' or from age 55.<br><br>You can invest money in a range of funds, collectives and other self-invested assets.' +
      ' Self-investment gives you greater control as you make the investment decisions yourself.<br><br>' +
      ' The value of your investments can go down as well as up, the value of your fund is not guaranteed.' +
      ' It is important to remember this if you are close to taking your benefits from, or surrendering, your policy.' +
      ' Please note, if you are in the process of taking any benefits from or claiming your policy,' +
      ' the value shown may not be correct and the final value may have already been fixed.<br><br><b>' +
      'Further information:</b><br><br>Please read through our common questions.' +
      ' For full information please see your Member\'s Booklet or contact us.</p>',
  },
  {
    productTemplate: TemplateNumberValues.T16MortgageLife,
    content: {
      policyStartDate: 'This policy started on ',
      policyEndDate: 'This policy ends on ',
      policyOwner: 'The owner of this policy is: ',
      policySeller: 'This policy was sold by ',
      policyOriginalAmount: 'The original amount of cover for this policy was ',
      policyDetailsBenefitsBullets: 'Your cover includes the following benefits:',
      policyCostOptionPreText: 'You have the',
      policyStandardCostOption: 'standard',
      policyLowCostOption: 'low',
      policyLowCostOptionPostText: 'cost option. See your Policy Booklet for details.',
      policyDetailsNotes: 'Your cover includes the following benefits:',
      policyDetailsPostText:
        'If you are the life assured, we recommend that you share a copy of your policy details with' +
        ' your next of kin, so that they know they can make a claim in the event of your death.' +
        ' You can access a PDF version from the documents tab above.<br><br>',
      policyDaysLimit:
        'You have the right to cancel your policy' +
        ' within 30 days of buying the policy and receive a refund of any premiums paid. ',
      policyLink: 'Click here if you wish to cancel your policy.',
      policyCancellationBullets: [
        'We\'re sorry you wish to cancel your policy. We hope that you will consider your decision\
         to cancel very carefully as you will not be covered for any claims once we receive your request \
         to cancel.',
        'It will take us a few days to process your request. Once complete your policy will no longer\
         be visible in My Account.',
      ],
      policyCancellationQuestion: 'Are you sure you wish to cancel your policy?',
      cancelPolicySuccess:
        'Thank you. Your request has been received and will be\
       processed in the next few days.',
      cancelPolicyError:
        'We\'re sorry but we can’t process your request due to a\
       technical error. Please try again.',
      cancelPolicyNotice:
        'Please be aware that it can take up to 10 working days for\
        your policy details to be updated.',
      decrPolicyMsg:
        'Your amount of cover will decrease each month during the length of the policy.',
    },
  },
  {
    productTemplate: TemplateNumberValues.T17LifeCover,
    content:
      '<p>Your Self Invested Personal Pension is a tax efficient way of saving money for use in your retirement' +
      ' or from age 55.<br><br>You can invest money in a range of funds, collectives and other self-invested assets.' +
      ' Self-investment gives you greater control as you make the investment decisions yourself.<br><br>' +
      ' The value of your investments can go down as well as up, the value of your fund is not guaranteed.' +
      ' It is important to remember this if you are close to taking your benefits from, or surrendering, your policy.' +
      ' Please note, if you are in the process of taking any benefits from or claiming your policy,' +
      ' the value shown may not be correct and the final value may have already been fixed.<br><br><b>' +
      'Further information:</b><br><br>Please read through our common questions.' +
      ' For full information please see your Member\'s Booklet or contact us.</p>',
  },
];
