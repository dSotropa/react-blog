import { NotificationTypeMap, ApiNotification } from '@libs/ma/shared/utility-data';

export const getNotifications: Array<ApiNotification> = [
  {
    type: NotificationTypeMap.AAAA,
    subjectReference: '0205883184',
    details: {
      status: 'Open',
      createdDate: '2017-05-19',
      shortDescription: 'Review your increased cover for policy 0S01757234',
      longDescription: 'long desc',
      supportingInformation: [
        {
          line: 'People covered by this product: <br/><b>Mr Firaovuvyeltji Detagixxtxahbn</b>',
        },
        { line: 'Increasing Income Protection Benefit' },
      ],
      functions: [
        {
          status: 'Open',
          displayLabel: 'Review your cover',
          processType: 'url_self',
          processDestination: 'url1',
        },
      ],
    },
  },
  {
    type: NotificationTypeMap.AAAA,
    subjectReference: '0358683184',
    details: {
      status: 'Open',
      createdDate: '2017-05-19',
      shortDescription: 'Review your increased cover for policy 0S01757234',
      longDescription: '',
      supportingInformation: [
        {
          line: 'People covered by this product: <br/><b>Mr Firaovuvyeltji Detagixxtxahbn</b>',
        },
        { line: 'Increasing Income Protection Benefit' },
      ],
      functions: [
        {
          status: 'Open',
          displayLabel: 'Review your cover',
          processType: 'url_tab',
          processDestination: 'url2',
        },
      ],
    },
  },
];

export const getNotificationsWithMissingData: Array<ApiNotification> = [
  {
    type: NotificationTypeMap.AAAC,
    subjectReference: 'BBGJR83Y0',
    details: {
      status: 'Open',
      createdDate: '27/07/2015',
      longDescription: '',
      shortDescription: 'Data Migration for BBGJR83Y0',
      functions: [],
      supportingInformation: [],
      type: NotificationTypeMap.AAAC,
    },
  },
  {
    type: NotificationTypeMap.AAAA,
    subjectReference: '0358683184',
    details: {
      status: 'Open',
      createdDate: '2017-05-19',
      shortDescription: 'Review your increased cover for policy 0S01757234',
      longDescription: '',
      supportingInformation: [
        {
          line: 'People covered by this product: <br/><b>Mr Firaovuvyeltji Detagixxtxahbn</b>',
        },
        { line: 'Increasing Income Protection Benefit' },
      ],
      functions: [
        {
          status: 'Open',
          displayLabel: 'Review your cover',
          processType: 'url_tab',
          processDestination: 'url2',
        },
      ],
    },
  },
];
