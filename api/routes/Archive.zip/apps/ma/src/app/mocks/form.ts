import { AbstractControl, UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { Observable, of } from 'rxjs';

import {
  contractDetailsData as mockContractDetails,
  customerData as mockCustomerProfile,
  PortfolioSummary as portfolioSummary,
  productFormsContent,
} from '@libs/ma/shared/utility-data';

export class FormHelperMock {
  form: UntypedFormGroup;

  buildForm(formControls: any) {
    this.form = new UntypedFormBuilder().group(formControls);
  }

  getCustomerProfile(): Observable<any> {
    return of(Observable, mockCustomerProfile);
  }

  getContractSummary(): Observable<any> {
    return of(Observable, portfolioSummary.contracts[3]);
  }

  getContractDetails(): Observable<any> {
    return of(Observable, mockContractDetails.selfInvestedPersonalPension);
  }

  getCmsData(formName: string): Observable<any> {
    return of(Observable, productFormsContent[formName].form);
  }

  getForm(): UntypedFormGroup {
    return this.form;
  }

  getFormControl(controlName: string): AbstractControl {
    return this.form.get(controlName);
  }

  isSubmitting(): boolean {
    return true;
  }

  isSubmissionError(): boolean {
    return false;
  }

  onSubmit() {}
}
