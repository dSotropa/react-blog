import { ComponentFixture, discardPeriodicTasks, fakeAsync, TestBed, tick, waitForAsync } from '@angular/core/testing';
import { of } from 'rxjs';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { instance, mock } from '@typestrong/ts-mockito';
import { MockComponents } from 'ng-mocks';
import { LgCardComponent, LgCardContentComponent } from '@legal-and-general/canopy';

import { SessionLogOut } from '@libs/ma/shared/utility-actions';
import { cmsData } from '@libs/ma/shared/utility-data';
import { AuthService } from '@libs/shared/utility-auth';
import { AnalyticsService, CmsApiService, DomHelperService } from '@libs/ma/shared/utility-services';

import { TimeoutOverlayComponent } from './timeout-overlay.component';

class MockAuthService {
  logout() {
    return true;
  }
}

describe('TimeoutOverlayComponent', () => {
  let component: TimeoutOverlayComponent;
  let fixture: ComponentFixture<TimeoutOverlayComponent>;
  let cms, focusSpy;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [
        TimeoutOverlayComponent,
        MockComponents(LgCardComponent, LgCardContentComponent),
      ],
      imports: [ HttpClientTestingModule ],
      providers: [
        CmsApiService,
        { provide: AuthService, useClass: MockAuthService },
        { provide: DomHelperService, useValue: instance(mock(DomHelperService)) },
        { provide: AnalyticsService, useValue: instance(mock(AnalyticsService)) },
        provideMockStore(),
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TimeoutOverlayComponent);
    component = fixture.componentInstance;
    cms = TestBed.inject(CmsApiService);
    jest.spyOn(cms, 'getContent').mockReturnValue(of(cmsData));
    component.pageContentData = cmsData;
    focusSpy = jest.spyOn(component, 'shiftFocus');
  });

  it('should create the timeout-overlay component', () => {
    fixture.detectChanges();

    expect(component).toBeTruthy();
    expect(focusSpy).toHaveBeenCalled();
  });

  it('should call the logout service when user opts to logout', () => {
    const storeDispatch = jest
      .spyOn(TestBed.inject(MockStore), 'dispatch')
      .mockImplementation(jest.fn());
    const authLogoutSpy = jest.spyOn(TestBed.inject(AuthService), 'logout');

    fixture.detectChanges();
    component.logout();

    expect(authLogoutSpy).toHaveBeenCalled();
    expect(storeDispatch).toHaveBeenCalledWith(new SessionLogOut());
  });

  describe('Event tracking', () => {
    let spy;

    beforeEach(() => {
      spy = jest.spyOn(TestBed.inject(AnalyticsService), 'eventTrack');
      fixture.detectChanges();
    });

    it('should track the analytics for the logout event', () => {
      component.logout();

      expect(spy).toHaveBeenCalledWith({
        name: 'Logout',
        type: 'Timeout',
        position: 'Timeout overlay',
      });
    });

    it('should track the analytics for the remain logged-in event', () => {
      component.close();

      expect(spy).toHaveBeenCalledWith({
        name: 'Remain logged in',
        type: 'Timeout',
        position: 'Timeout overlay',
      });
    });
  });

  describe('Timer', () => {
    let timerSpy;

    beforeEach(() => {
      timerSpy = jest.spyOn(component, 'maintainTimer');
      fixture.detectChanges();
    });

    it('should reduce the time by 1 second using the timer function', fakeAsync(() => {
      component.timer = 33;
      component.maintainTimer();
      tick(1000);

      expect(component.timer).toBe(32);
      discardPeriodicTasks();
    }));
  });

  describe('Accessibility', () => {
    beforeEach(() => {
      fixture.detectChanges();
    });

    describe('Handling focus', () => {
      let spy, event;

      beforeEach(function() {
        spy = jest.spyOn(TestBed.inject(DomHelperService), 'shiftFocus');
        event = { keyCode: 9, preventDefault: function() {} };
      });

      it('should focus on the logout button on tab press of close button', () => {
        component.trackKeys(event, true);

        expect(spy).toHaveBeenCalledWith('btn-logout');
      });

      it('should focus on the close button on tab press of logout button', () => {
        component.trackKeys(event, false);

        expect(spy).toHaveBeenCalledWith('btn-close');
      });

      it('should focus on the close button onclick of overlay', () => {
        component.moveFocus();

        expect(spy).toHaveBeenCalledWith('btn-close');
      });
    });

    describe('Handling functionality on keyboard events', () => {
      let closeSpy, event, logoutSpy;

      beforeEach(function() {
        closeSpy = jest.spyOn(component, 'close');
        logoutSpy = jest.spyOn(component, 'logout');
        event = { keyCode: 13, preventDefault: function() {} };
      });

      it('should close the timeout when user opts to remain logged in', () => {
        component.trackKeys(event, true);

        expect(closeSpy).toHaveBeenCalled();
      });

      it('should logout the user when respective button is clicked', () => {
        component.trackKeys(event, false);

        expect(logoutSpy).toHaveBeenCalled();
      });
    });
  });
});
