import { Component, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { Subscription, tap, timer as observableTimer } from 'rxjs';
import { Store } from '@ngrx/store';

import { keyCode } from '@libs/ma/shared/utility-data';
import { AuthService } from '@libs/shared/utility-auth';
import { SessionLogOut } from '@libs/ma/shared/utility-actions';
import { AnalyticsService, CmsApiService, DomHelperService } from '@libs/ma/shared/utility-services';

@Component({
  selector: 'app-timeout-overlay',
  templateUrl: './timeout-overlay.component.html',
  styleUrls: [ './timeout-overlay.component.scss' ],
})
export class TimeoutOverlayComponent implements OnInit, OnDestroy {
  @Output() closeTimeoutModal: EventEmitter<boolean> = new EventEmitter<boolean>();
  timer = 60;
  subscription: Subscription;
  pageContentData: Record<string, any>;

  constructor(
    private cmsApiService: CmsApiService,
    private analyticsService: AnalyticsService,
    private domHelper: DomHelperService,
    private authService: AuthService,
    private store: Store,
  ) {}

  ngOnInit() {
    this.getContent();
    this.maintainTimer();
    this.shiftFocus('btn-close');
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getContent(): void {
    this.cmsApiService.getContent().subscribe(data => {
      this.pageContentData = data;
    });
  }

  close(): void {
    this.analyticsService.eventTrack({
      name: 'Remain logged in',
      type: 'Timeout',
      position: 'Timeout overlay',
    });

    this.closeTimeoutModal.emit();
  }

  logout(): void {
    this.analyticsService.eventTrack({
      name: 'Logout',
      type: 'Timeout',
      position: 'Timeout overlay',
    });

    this.store.dispatch(new SessionLogOut());
    this.authService.logout();
  }

  maintainTimer(): void {
    const timer = observableTimer(1000, 1000);

    this.subscription = timer
      .pipe(
        tap(() => {
          return this.timer === 0
            ? this.logout()
            : --this.timer;
        }),
      )
      .subscribe();
  }

  trackKeys(e, keyflag): void {
    e.preventDefault();

    if (keyflag) {
      if (e.keyCode === keyCode.KEY_TAB || e.keyCode === keyCode.KEY_SHIFT) {
        this.domHelper.shiftFocus('btn-logout');
      }

      if (e.keyCode === keyCode.KEY_RETURN || e.keyCode === keyCode.KEY_SPACE) {
        this.close();
      }
    }

    if (!keyflag) {
      if (e.keyCode === keyCode.KEY_TAB || e.keyCode === keyCode.KEY_SHIFT) {
        this.domHelper.shiftFocus('btn-close');
      }

      if (e.keyCode === keyCode.KEY_RETURN || e.keyCode === keyCode.KEY_SPACE) {
        this.logout();
      }
    }
  }

  moveFocus(): void {
    this.domHelper.shiftFocus('btn-close');
  }

  shiftFocus(className) {
    setTimeout(function() {
      const el = <HTMLScriptElement>document.getElementsByClassName(className)[0];

      if (el) {
        el.focus();
      }
    }, 400);
  }
}
