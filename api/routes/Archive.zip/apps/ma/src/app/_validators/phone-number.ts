import { ValidatorFn, ValidationErrors } from '@angular/forms';

import { isValidPhoneNumber } from '@libs/ma/shared/utility-helpers';

/**
 * Custom validator for use on a phone number input control. Confirms
 * that the value of the control (when processed and stripped of spaces,
 * brackets, etc) is in the format that our servers will accept.
 *
 * Example with FormBuilder initialisation:
 * this.form = this.fb.group({
 *   'phoneNumber': this.fb.control(null, phoneNumberValidator)
 * });
 *
 * @param {Sring} [errorKey] this becomes the key inside the error object found on control.errors, e.g. '{ invalidPhoneNumberFormat: true }'
 * @returns {ValidationErrors} standard Angular validaton error object, which gets applied to the control if used as per the example above
 */
export function phoneNumberValidator(errorKey = 'invalidPhoneNumberFormat'): ValidatorFn {
  return (control): ValidationErrors => {
    if (!isValidPhoneNumber(control.value)) {
      return {
        [errorKey]: true,
      };
    } else {
      return null;
    }
  };
}
