import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Component } from '@angular/core';
import {
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';

import { phoneNumberValidator } from './phone-number';

@Component({
  selector: 'app-test-form',
  template: `
    <form [formGroup]="form">
      <input formControlName="phoneNumber" />
    </form>
  `,
})
class TestFormComponent {
  form: UntypedFormGroup = new UntypedFormGroup({
    phoneNumber: new UntypedFormControl(''),
  });
  constructor(private fb: UntypedFormBuilder) {
    this.form = this.fb.group({
      phoneNumber: this.fb.control(null, phoneNumberValidator()),
    });
  }
}

describe('Validator function: "Phone Number"', () => {
  let component: TestFormComponent;
  let fixture: ComponentFixture<TestFormComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ TestFormComponent ],
      providers: [ UntypedFormBuilder ],
      imports: [ ReactiveFormsModule, FormsModule ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be a valid control if the value is a valid number starting with 0', () => {
    component.form.get('phoneNumber').setValue('07900123456');
    fixture.detectChanges();

    expect(component.form.valid).toBe(true);
  });

  it('should be a valid control if the value is a valid number starting with +', () => {
    component.form.get('phoneNumber').setValue('+447900123456');
    fixture.detectChanges();

    expect(component.form.valid).toBe(true);
  });

  it('should be a valid control if the value is a valid number containing spaces and brackets', () => {
    component.form.get('phoneNumber').setValue('(01273) 123 456');
    fixture.detectChanges();

    expect(component.form.valid).toBe(true);
  });

  it('should not be a valid control if the value is not a number', () => {
    component.form.get('phoneNumber').setValue('abc');
    fixture.detectChanges();

    expect(component.form.valid).toBe(false);
  });

  it('should not be a valid control if the number is too short', () => {
    component.form.get('phoneNumber').setValue('07900');
    fixture.detectChanges();

    expect(component.form.valid).toBe(false);
  });

  it('should not be a valid control if the number is too long', () => {
    component.form.get('phoneNumber').setValue('00441273123456891');
    fixture.detectChanges();

    expect(component.form.valid).toBe(false);
  });
});
