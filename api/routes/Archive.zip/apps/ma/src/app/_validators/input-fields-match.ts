import { UntypedFormGroup, ValidatorFn, ValidationErrors } from '@angular/forms';

/**
 * Custom validator for use with an Angular FormGroup. Checks the values on
 * two From Controls and sets an error on the second control if they do not match.
 *
 * Example with FormBuilder initialisation:
 * this.form = this.fb.group({
 *   'email': this.fb.control(null),
 *   'confirmEmail': this.fb.control(null)
 * }, { validator: inputFieldsMatch('email', 'confirmEmail') });
 *
 * Example with FormGroup.setValidators() function:
 * this.form.controls.emailGroup.setValidators([inputFieldsMatch])
 *
 * @see https://angular.io/api/forms/AbstractControl#setValidators
 *
 * @param {Sring} [controlOneKey] the FormGroup key for the first control
 * @param {Sring} [controlTwoKey] key for the second control
 * @param {Sring} [errorKey] override the default value of the error key, when setting the error on the second control
 * @returns {ValidatorFn} Angular validator function
 */
export function inputFieldsMatch(
  controlOneKey: string,
  controlTwoKey: string,
  errorKey = 'mismatch',
): ValidatorFn {
  return (group: UntypedFormGroup): ValidationErrors => {
    const controlOne = group.controls[controlOneKey],
      controlTwo = group.controls[controlTwoKey];

    if (controlOne.value !== controlTwo.value) {
      controlTwo.setErrors({ [errorKey]: true });
    } else {
      controlTwo.setErrors(null);
    }

    return;
  };
}
