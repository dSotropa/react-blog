import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Component } from '@angular/core';
import {
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';

import { inputFieldsMatch } from './input-fields-match';

@Component({
  selector: 'app-test-form',
  template: `
    <form [formGroup]="form">
      <input formControlName="email" />
      <input formControlName="confirmEmail" />
    </form>
  `,
})
class TestFormComponent {
  form: UntypedFormGroup = new UntypedFormGroup({
    email: new UntypedFormControl(''),
    confirmEmail: new UntypedFormControl(''),
  });
  constructor(private fb: UntypedFormBuilder) {
    this.form = this.fb.group(
      {
        email: this.fb.control(null),
        confirmEmail: this.fb.control(null),
      },
      { validator: inputFieldsMatch('email', 'confirmEmail') },
    );
  }
}

describe('Validator function: "Input Fields Match"', () => {
  let component: TestFormComponent;
  let fixture: ComponentFixture<TestFormComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ TestFormComponent ],
      providers: [ UntypedFormBuilder ],
      imports: [ ReactiveFormsModule, FormsModule ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should make the form invalid if the input values are different', () => {
    component.form.get('email').setValue('test@example.com');
    component.form.get('confirmEmail').setValue('different@example.com');
    fixture.detectChanges();

    expect(component.form.valid).toBe(false);
  });

  it('should make the form valid if the input values are the same', () => {
    component.form.get('email').setValue('test@example.com');
    component.form.get('confirmEmail').setValue('test@example.com');
    fixture.detectChanges();

    expect(component.form.valid).toBe(true);
  });
});
