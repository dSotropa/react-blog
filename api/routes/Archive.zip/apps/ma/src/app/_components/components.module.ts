import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { MaSharedUiModule } from '@libs/ma/shared/ui';
import { MaSharedUtilityPipesModule } from '@libs/ma/shared/utility-pipes';

import { AtomsModule } from '../_atoms/atoms.module';

import { CustomerProfileSummaryComponent } from './customer-profile-summary/customer-profile-summary.component';
import { ErrorPageCardComponent } from './error-page-card/error-page-card.component';
import { LinkBoxMetaComponent } from './link-box/link-box-meta/link-box-meta.component';
import { LinkBoxTextComponent } from './link-box/link-box-text/link-box-text.component';
import { LinkBoxComponent } from './link-box/link-box.component';
import { NoticeMessageComponent } from './notice-message/notice-message.component';
import { RelatedLinksComponent } from './related-links/related-links.component';
import { YouTubeVideoComponent } from './youtube-video/youtube-video.component';
import { PromoBoxComponent } from './promo-box/promo-box.component';
import { BreadcrumbV2Component } from './breadcrumb-v2/breadcrumb-v2.component';

const common = [
  CustomerProfileSummaryComponent,
  ErrorPageCardComponent,
  NoticeMessageComponent,
  RelatedLinksComponent,
  YouTubeVideoComponent,
  LinkBoxComponent,
  LinkBoxTextComponent,
  LinkBoxMetaComponent,
  PromoBoxComponent,
  BreadcrumbV2Component,
];

const declarations = [ ...common ];

@NgModule({
  declarations,
  exports: [ ...common, AtomsModule ],
  imports: [ MaSharedUtilityPipesModule, MaSharedUiModule, AtomsModule, CommonModule ],
})
export class ComponentsModule {}
