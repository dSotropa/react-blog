import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { BusinessAreaAbbreviations as ba, Routing } from '@libs/ma/shared/utility-data';
import { AuthGuard } from '@libs/shared/utility-auth';
import { SupportWidgetComponent } from '@libs/ma/support/feature-support-widget';
import { InterstitialContainerComponent } from '@libs/ma/core/feature-interstitial-container';

import { GenericContainerV2Component } from './_containers/generic-container-v2/generic-container-v2.component';
import { SimpleContainerComponent } from './_containers/simple-container/simple-container.component';
import { GenericContainerComponent } from './_containers/generic-container/generic-container.component';
import { NewContainerComponent } from './_containers/new-container/new-container.component';
import { FormJourneyContainerComponent } from './_containers/form-journey-container/form-journey-container.component';
import { SupportGuard } from './_guards/support-guard';
import { ErrorPageComponent } from './error-page/error-page.component';
import { ProductDetailsGuard } from './product-details-container/product-details.guard';
import { MainWrapperComponent } from './_modules/main-wrapper/components/main-wrapper.component';

// Route Configuration
export const routes: Routes = [
  {
    path: '',
    redirectTo: Routing.Home,
    pathMatch: 'full',
  },
  {
    path: '',
    component: MainWrapperComponent,
    canActivate: [ AuthGuard ],
    children: [
      {
        path: '',
        component: GenericContainerComponent,
        children: [
          {
            path: 'products',
            loadChildren: () =>
              import('./_modules/psp/psp.module').then(m => m.PspModule),
          },
          {
            path: 'mailbox',
            loadChildren: () =>
              import('./_modules/mailbox/mailbox.module').then(m => m.MailboxModule),
          },
          {
            path: 'rewards',
            loadChildren: () =>
              import('@libs/ma/my-rewards/feature-shell').then(
                m => m.MaMyRewardsFeatureShellModule,
              ),
          },
          {
            // This is a dummy route. The SupportWidgetComponent is not actually loaded here. Instead, the
            // SupportGuard triggers the triage widget to open and then returns false. This allows us to
            // open the triage widget using standard angular routing.
            path: 'support',
            canActivateChild: [ SupportGuard ],
            component: SupportWidgetComponent,
          },
          {
            path: 'my-account/product-details',
            canActivateChild: [ ProductDetailsGuard ],
            loadChildren: () =>
              import('./product-details-container/product-details.module').then(
                m => m.ProductDetailsModule,
              ),
          },
          {
            path: 'my-account/product-details/:productCode/:valuationClass/:productHoldingType/:uninsuredContractId/:tabName/forms',
            loadChildren: () =>
              import('./product-forms-container/product-forms.module').then(
                m => m.ProductFormsModule,
              ),
          },
        ],
      },
      {
        path: 'account-details',
        component: GenericContainerV2Component,
        children: [
          {
            path: '',
            loadChildren: () =>
              import('./_modules/account-details/account-details.module').then(
                m => m.AccountDetailsModule,
              ),
          },
        ],
      },
      {
        path: 'product-details',
        component: NewContainerComponent,
        children: [
          {
            path: ba.Retirement,
            canActivateChild: [ ProductDetailsGuard ],
            loadChildren: () =>
              import('./_modules/details-retirement/details-retirement.module').then(
                m => m.DetailsRetirementModule,
              ),
          },
          {
            path: ba.RetailProtection,
            loadChildren: () =>
              import(
                './_modules/details-retail-protection/details-retail-protection.module'
              ).then(m => m.DetailsRetailProtectionModule),
          },
        ],
      },
      {
        path: 'form',
        component: FormJourneyContainerComponent,
        children: [
          {
            path: 'change-bank-account',
            loadChildren: () =>
              import('./_modules/change-bank-account/change-bank-account.module').then(
                m => m.ChangeBankAccountModule,
              ),
          },
          {
            path: 'request-quote',
            loadChildren: () =>
              import('./_modules/request-quote/request-quote.module').then(
                m => m.RequestQuoteModule,
              ),
          },
          {
            path: 'retention',
            loadChildren: () =>
              import('./_modules/retention/retention.module').then(
                m => m.RetentionModule,
              ),
          },
          {
            path: 'claims',
            loadChildren: () =>
              import('./_modules/claims/claims.module').then(m => m.ClaimsModule),
          },
        ],
      },
      {
        path: 'welcome',
        component: InterstitialContainerComponent,
        children: [
          {
            path: 'confirm-details',
            loadChildren: () =>
              import('@libs/ma/confirm-details/feature-shell').then(
                m => m.MaConfirmDetailsFeatureShellModule,
              ),
          },
          {
            path: 'action',
            loadChildren: () =>
              import('@libs/ma/lgi-actions/feature-shell').then(
                m => m.MaLgiActionsFeatureShellModule,
              ),
          },
          {
            path: 'confirm-contact-details',
            loadChildren: () =>
              import('@libs/ma/confirm-contact-details/feature-shell').then(
                m => m.MaConfirmContactDetailsFeatureShellModule,
              ),
          },
          {
            path: 'review-address',
            loadChildren: () =>
              import('@libs/ma/review-address/feature-shell').then(
                m => m.MaReviewAddressFeatureShellModule,
              ),
          },
        ],
      },
    ],
  },
  {
    path: 'error-page',
    component: SimpleContainerComponent,
    children: [
      {
        path: '',
        component: ErrorPageComponent,
      },
    ],
  },
  {
    path: 'logout',
    component: SimpleContainerComponent,
    children: [
      {
        path: '',
        loadChildren: () =>
          import('@libs/ma/logged-out/feature-shell').then(
            m => m.MaLoggedOutFeatureShellModule,
          ),
      },
    ],
  },
  {
    path: '**',
    redirectTo: Routing.Home,
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      useHash: true,
      scrollPositionRestoration: 'enabled',
    }),
  ],
  exports: [ RouterModule ],
})
export class AppRoutingModule {}
