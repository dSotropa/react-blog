import { Injectable } from '@angular/core';
import { CanActivateChild, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { select, Store } from '@ngrx/store';
import { map, skipWhile, withLatestFrom } from 'rxjs/operators';

import { DataStatus, Routing, State } from '@libs/ma/shared/utility-data';
import {
  selectLegacyRawProductSummaryFromUrl,
  selectProductsStatus,
} from '@libs/ma/shared/utility-selectors';
import { SummaryLoad } from '@libs/ma/shared/utility-actions';
import { AuthService } from '@libs/shared/utility-auth';

@Injectable({
  providedIn: 'root',
})
export class ProductDetailsGuard implements CanActivateChild {
  constructor(
    private store: Store<State>,
    private router: Router,
    private authService: AuthService,
  ) {}

  canActivateChild(): Observable<boolean> {
    // Observable to return true while products data is still loading
    const isLoading$ = this.store.pipe(select(selectProductsStatus)).pipe(
      map(productsStatus => {
        if (!productsStatus) {
          this.store.dispatch(new SummaryLoad(this.authService.getPartyId()));
        }

        const productsLoading = productsStatus < DataStatus.transformed;

        return productsLoading;
      }),
    );

    return isLoading$.pipe(
      skipWhile(isLoading => isLoading),
      withLatestFrom(this.store.pipe(select(selectLegacyRawProductSummaryFromUrl))),
      map(([ , rawSummary ]) => {
        if (rawSummary?.isDecommissioned) {
          this.router.navigate([ Routing.Home ]);

          return false;
        }

        return true;
      }),
    );
  }
}
