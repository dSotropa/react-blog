import { productDetailsRoutes } from './product-details.routes';
import { ProductDetailsContainerComponent } from './product-details-container.component';
import { TransactionsContainerComponent } from './transactions-container/transactions-container.component';

describe('Product details router', () => {
  it('contains a route for a Product Details tab', () => {
    expect(productDetailsRoutes).toContainEqual({
      path: ':productCode/:valuationClass/:productHoldingType/:uninsuredContractId/:tabName',
      component: ProductDetailsContainerComponent,
    });
  });

  it('contains a route to view all transactions for a product', () => {
    expect(productDetailsRoutes).toContainEqual({
      path: ':productCode/:valuationClass/:productHoldingType/:uninsuredContractId/Transactions/all',
      component: TransactionsContainerComponent,
    });
  });
});
