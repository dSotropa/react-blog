import { Component, OnDestroy, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Observable, Subject } from 'rxjs';
import { filter, takeUntil, takeWhile, withLatestFrom } from 'rxjs/operators';
import { isValid, parse } from 'date-fns';
import { select, Store } from '@ngrx/store';

import {
  ApiProductSummary,
  CustomerProfile,
  needDetailsMap,
  productHoldingTypeToCategoryMapper,
  productTemplateMapper,
  State,
  valuationClassToShowDataVisualisation,
} from '@libs/ma/shared/utility-data';
import {
  selectCustomerProfile,
  selectCustomerProfileError,
  selectCustomerProfileLoaded,
  selectLegacyRawDataForAngularRedux,
  selectLegacyRawProductSummaryFromUrl,
  selectLegacySummaryError,
  selectLegacySummaryLoaded,
  selectProductParamsFromUrl,
  selectTabName,
} from '@libs/ma/shared/utility-selectors';
import {
  ProductDetailsLoadOne,
  ProductDetailsLoadOneSuccess,
} from '@libs/ma/shared/utility-actions';
import { mapValueWithDefault } from '@libs/ma/shared/utility-helpers';
import { BreadcrumbService, CmsApiService } from '@libs/ma/shared/utility-services';

@Component({
  selector: 'app-product-details-container',
  templateUrl: './product-details-container.component.html',
  styleUrls: [ './product-details-container.component.scss' ],
})
export class ProductDetailsContainerComponent implements OnDestroy, OnInit {
  private ngUnsubscribe: Subject<void> = new Subject<void>();

  productSummary: Observable<any>;
  portfolioSummaryLoaded: Observable<boolean>;
  portfolioSummaryError: Observable<boolean>;
  portfolioSummaryData: Observable<ApiProductSummary>;

  customerProfileLoaded: Observable<boolean>;
  customerProfileError: Observable<boolean>;
  customerProfileData: Observable<CustomerProfile>;

  productTemplateMapper: any;
  pageContentData: any;
  content: any;
  mapperData: any = {};
  /**
   * contractDetails
   * Warning: actually contains portfolio-summary data for one product
   */
  contractDetails: any;
  productCategory: string;
  isDecreasingLifeProduct = false;
  contractId: string;
  productSummarySubscription: any;
  selectProductParamsFromUrl$: Observable<any>;
  selectTabName$: Observable<string>;

  constructor(
    private breadcrumbService: BreadcrumbService,
    private cmsApiService: CmsApiService,
    private pageTitle: Title,
    private store: Store<State>,
  ) {}

  ngOnInit() {
    this.customerProfileLoaded = this.store.pipe(select(selectCustomerProfileLoaded));
    this.customerProfileError = this.store.pipe(select(selectCustomerProfileError));
    this.customerProfileData = this.store.pipe(select(selectCustomerProfile));
    this.productSummary = this.store.pipe(select(selectLegacyRawDataForAngularRedux));

    this.selectProductParamsFromUrl$ = this.store.pipe(
      select(selectProductParamsFromUrl),
    );

    this.portfolioSummaryLoaded = this.store.pipe(select(selectLegacySummaryLoaded));
    this.portfolioSummaryError = this.store.pipe(select(selectLegacySummaryError));

    this.portfolioSummaryData = this.store.pipe(
      select(selectLegacyRawProductSummaryFromUrl),
    );

    this.selectTabName$ = this.store.pipe(select(selectTabName));
    this.productTemplateMapper = productTemplateMapper;

    this.cmsApiService
      .getContent()
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe((data: any) => {
        this.pageContentData = data;
        this.content = data;
        this.pageTitle.setTitle(data.pageTitles.productDetails);
      });

    this.getPortfolioData();
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  setProductType(rawSummary, rawDetailsData): void {
    const { valuationClass } = rawSummary;
    const { protectionContractDetails } = rawDetailsData;

    if (protectionContractDetails) {
      const { lastPremiumDate, policyEndDate, policyCurrentAmount } =
        protectionContractDetails;

      const hasData =
        isValid(parse(lastPremiumDate, 'yyyy-MM-dd', new Date())) &&
        isValid(parse(policyEndDate, 'yyyy-MM-dd', new Date())) &&
        !!policyCurrentAmount;

      const displayDataVis = mapValueWithDefault(
        valuationClassToShowDataVisualisation,
        valuationClass,
      );

      this.isDecreasingLifeProduct = hasData && displayDataVis;
    }
  }

  getPortfolioData(): void {
    this.store
      .pipe(select(selectLegacyRawProductSummaryFromUrl))
      .pipe(
        takeUntil(this.ngUnsubscribe),
        takeWhile(data => typeof data !== 'undefined'),
        filter(({ productCode = '' }) => Boolean(productCode)),
      )
      .subscribe(rawSummary => {
        this.setSummaryData(rawSummary);
      });
  }

  setSummaryData(rawSummary: ApiProductSummary): void {
    this.contractDetails = rawSummary;
    const { productCode, productTemplate, lgProductHoldingType } = rawSummary;
    const needsDetailsCall = mapValueWithDefault(needDetailsMap, productTemplate);

    this.getMapperData(productTemplate);
    this.getProductCategory(lgProductHoldingType);
    this.setBreadcrumbs();

    if (needsDetailsCall) {
      this.getProductDetails(rawSummary);
    } else {
      this.store.dispatch(new ProductDetailsLoadOneSuccess(productCode, {}));
    }
  }

  getMapperData(productTemplate): void {
    if (this.productTemplateMapper[productTemplate]) {
      this.mapperData = this.productTemplateMapper[productTemplate];
    }
  }

  getProductDetails(rawSummary): void {
    this.selectProductParamsFromUrl$
      .pipe(
        takeUntil(this.ngUnsubscribe),
        filter(
          ({ partyId = '', productCode = '' }) =>
            Boolean(productCode) && Boolean(partyId),
        ),
        withLatestFrom(this.productSummary),
      )
      .subscribe(([ params, contractDetails = {} ]) => {
        const { data } = contractDetails;
        const { productCode } = params;

        if (!data) {
          this.store.dispatch(new ProductDetailsLoadOne(productCode, params));
        }
      });

    this.productSummarySubscription?.unsubscribe();

    this.productSummarySubscription = this.productSummary
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe(({ data }) => {
        if (data) {
          this.setProductType(rawSummary, data);
        }
      });
  }

  getProductCategory(lgProductHoldingType): void {
    this.productCategory = productHoldingTypeToCategoryMapper[lgProductHoldingType];
  }

  setBreadcrumbs() {
    this.breadcrumbService.setBreadcrumb([
      {
        label: this.contractDetails.description,
        url: null,
      },
    ]);
  }
}
