import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { Router } from '@angular/router';
import { MockProvider } from 'ng-mocks';
import { Subscription } from 'rxjs';

import { ApiProductSummary, DataStatus, Routing } from '@libs/ma/shared/utility-data';
import {
  selectLegacyRawProductSummaryFromUrl,
  selectProductsStatus,
} from '@libs/ma/shared/utility-selectors';
import { AuthService } from '@libs/shared/utility-auth';
import { SummaryLoad } from '@libs/ma/shared/utility-actions';

import { ProductDetailsGuard } from './product-details.guard';

describe('ProductDetailsGuard', () => {
  let store: MockStore<any>;
  let router: Router;
  let guard: ProductDetailsGuard;
  let mockedSummary: ApiProductSummary;
  let subscription: Subscription;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [ RouterTestingModule ],
      providers: [ MockProvider(AuthService), provideMockStore({}) ],
    }).compileComponents();
  });

  beforeEach(() => {
    store = TestBed.inject(MockStore);
    router = TestBed.inject(Router);
    guard = TestBed.inject(ProductDetailsGuard);
    mockedSummary = {} as ApiProductSummary;

    store.overrideSelector(selectLegacyRawProductSummaryFromUrl, mockedSummary);
    store.overrideSelector(selectProductsStatus, DataStatus.transformed);
  });

  afterEach(() => {
    subscription?.unsubscribe();
    jest.clearAllMocks();
  });

  describe('canActivate', () => {
    beforeEach(() => {
      jest.spyOn(store, 'dispatch').mockImplementation(jest.fn());
    });

    it('should fetch the products status if not already loaded', done => {
      store.overrideSelector(selectProductsStatus, undefined);
      const res$ = guard.canActivateChild();

      subscription = res$.subscribe(res => {
        expect(store.dispatch).toHaveBeenCalledWith(new SummaryLoad(undefined));
        expect(res).toBe(true);
        done();
      });
    });

    it('should not emit if products are not available', fakeAsync(() => {
      store.overrideSelector(selectProductsStatus, DataStatus.requested);
      let canActivateEmittedValue;
      const res$ = guard.canActivateChild();

      subscription = res$.subscribe(res => {
        canActivateEmittedValue = res;
      });

      tick(1000);

      expect(store.dispatch).not.toHaveBeenCalled();
      expect(canActivateEmittedValue).toBeUndefined();
    }));

    it('should return true if isDecommissioned is false', done => {
      mockedSummary.isDecommissioned = false;
      const res$ = guard.canActivateChild();

      subscription = res$.subscribe(res => {
        expect(store.dispatch).not.toHaveBeenCalled();
        expect(res).toBe(true);

        done();
      });
    });

    it('should return false if isDecommissioned is true and redirect to MA PSP landing page', done => {
      mockedSummary.isDecommissioned = true;
      const spy = jest.spyOn(router, 'navigate').mockImplementationOnce(jest.fn());

      const res$ = guard.canActivateChild();

      subscription = res$.subscribe(res => {
        expect(spy).toHaveBeenCalledWith([ Routing.Home ]);
        expect(res).toBe(false);

        done();
      });
    });
  });
});
