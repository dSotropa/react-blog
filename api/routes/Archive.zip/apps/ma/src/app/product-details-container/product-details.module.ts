import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { MaSharedUiModule } from '@libs/ma/shared/ui';
import { MaSharedUtilityPipesModule } from '@libs/ma/shared/utility-pipes';
import { SharedUtilityPipesModule } from '@libs/shared/utility-pipes';

import { InfoTooltipComponent } from '../info-tooltip/info-tooltip.component';
import { ProductFormsModule } from '../product-forms-container/product-forms.module';
import { SharedModule } from '../common/shared.module';
import { TransactionTypeFilter } from '../common/pipes/transactionTypeFilter.pipe';
import { WidgetsModule } from '../_components/widgets/widgets.module';
import { ComponentsModule } from '../_components/components.module';

import { DocumentsContainerComponent } from './documents-container/documents-container.component';
import { DocumentListComponent } from './documents-container/document-list/document-list.component';
import { ProductActionComponent } from './product-actions/product-action/product-action.component';
import { ProductActionsComponent } from './product-actions/product-actions.component';
import { ProductBereavementComponent } from './product-bereavement/product-bereavement.component';
import { ProductDetailsContainerComponent } from './product-details-container.component';
import { ProductDetailsRoutingModule } from './product-details.routes';
import { ProductFundsComponent } from './product-funds/product-funds.component';
import { ProductOverviewComponent } from './product-overview/product-overview.component';
import { ProductPaymentComponent } from './product-payment/product-payment.component';
import { ProductRequestsComponent } from './product-requests/product-requests.component';
import { ProductSummaryComponent } from './product-summary/product-summary.component';
import { ProductSummaryDataVisComponent } from './product-summary-data-vis/product-summary-data-vis.component';
import { ProductTabsComponent } from './product-tabs/product-tabs.component';
import { ProductTaxComponent } from './product-tax/product-tax.component';
import { ProductTransactionsComponent } from './product-transactions/product-transactions.component';
import { ProductAssetsComponent } from './product-assets/product-assets.component';
import { ListTransactionsComponent } from './list-transactions/list-transactions.component';
import { TransactionsContainerComponent } from './transactions-container/transactions-container.component';

@NgModule({
  declarations: [
    DocumentsContainerComponent,
    DocumentListComponent,
    InfoTooltipComponent,
    ProductActionComponent,
    ProductActionsComponent,
    ProductBereavementComponent,
    ProductDetailsContainerComponent,
    ProductFundsComponent,
    ProductOverviewComponent,
    ProductPaymentComponent,
    ProductRequestsComponent,
    ProductSummaryComponent,
    ProductSummaryDataVisComponent,
    ProductTabsComponent,
    ProductTaxComponent,
    ProductTransactionsComponent,
    ProductAssetsComponent,
    ListTransactionsComponent,
    TransactionsContainerComponent,
    TransactionTypeFilter,
  ],
  imports: [
    SharedModule,
    MaSharedUiModule,
    MaSharedUtilityPipesModule,
    SharedUtilityPipesModule,
    ProductFormsModule,
    ProductDetailsRoutingModule,
    WidgetsModule,
    ComponentsModule,
  ],
  providers: [],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
})
export class ProductDetailsModule {}
