import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Title } from '@angular/platform-browser';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { StoreModule } from '@ngrx/store';
import { MockComponents, MockModule } from 'ng-mocks';
import { instance, mock } from '@typestrong/ts-mockito';
import { LgCardModule } from '@legal-and-general/canopy';

import {
  cmsData,
  contractDetailsData as mockData,
  DataStatus,
  products,
  productTemplateMapperMock as productTemplateMapper,
} from '@libs/ma/shared/utility-data';
import { rootReducer } from '@libs/ma/shared/utility-state';
import { BreadcrumbService, CmsApiService } from '@libs/ma/shared/utility-services';

import { WidgetsComponent } from '../_components/widgets/widgets.component';

import { ProductSummaryDataVisComponent } from './product-summary-data-vis/product-summary-data-vis.component';
import { ProductTabsComponent } from './product-tabs/product-tabs.component';
import { ProductSummaryComponent } from './product-summary/product-summary.component';
import { ProductDetailsContainerComponent } from './product-details-container.component';

const initialState = {
  router: {},
  details: {
    status: DataStatus.loaded,
  },
};

describe('ProductDetailsContainerComponent', () => {
  let component: ProductDetailsContainerComponent;
  let fixture: ComponentFixture<ProductDetailsContainerComponent>;
  let breadcrumbService;
  let getProductDetailsSpy;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [
        ProductDetailsContainerComponent,
        MockComponents(
          ProductSummaryComponent,
          ProductSummaryDataVisComponent,
          ProductTabsComponent,
          WidgetsComponent,
        ),
      ],
      providers: [
        { provide: CmsApiService, ueValue: instance(mock(CmsApiService)) },
        { provide: BreadcrumbService, useValue: instance(mock(BreadcrumbService)) },
      ],
      imports: [
        HttpClientTestingModule,
        MockModule(LgCardModule),
        StoreModule.forRoot(rootReducer, {
          initialState,
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true,
          },
        }),
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductDetailsContainerComponent);
    component = fixture.componentInstance;
    component.productTemplateMapper = productTemplateMapper;
    breadcrumbService = TestBed.inject(BreadcrumbService);
    jest.spyOn(breadcrumbService, 'setBreadcrumb').mockImplementation(jest.fn());
    jest.spyOn(component, 'getPortfolioData').mockImplementation(jest.fn());

    getProductDetailsSpy = jest
      .spyOn(component, 'getProductDetails')
      .mockImplementation(jest.fn());
  });

  it('should create the product-details container', () => {
    expect(component).toBeTruthy();
  });

  describe('setSummaryData', () => {
    it('calls getProductDetails when product needs details', () => {
      component.setSummaryData(
        products.api.summaries.T07SelfInvestedPersonalPension as any,
      );

      fixture.detectChanges();

      expect(getProductDetailsSpy).toHaveBeenCalled();
    });

    it('does not call getProductDetails when product does not need details', () => {
      component.setSummaryData(products.api.summaries.T21Investments as any);
      fixture.detectChanges();

      expect(getProductDetailsSpy).not.toHaveBeenCalled();
    });
  });

  describe('set product type', () => {
    let setup;

    beforeEach(() => {
      setup = (template: string, data: any, valuationClass = '1234') => {
        const product = {
          ...(data || mockData[template]),
          productTemplate: template,
          valuationClass,
        };

        component.setProductType({ valuationClass }, product);
      };
    });

    it('sets isDecreasingLifeProduct to true if valid product type', () => {
      setup(
        'mortgageLife',
        {
          protectionContractDetails: {
            isDecreasingProduct: false,
            lastPremiumDate: '2018-11-11',
            policyCurrentAmount: '123.45',
            policyEndDate: '2018-11-11',
          },
        },
        3122,
      );

      expect(component.isDecreasingLifeProduct).toBeTruthy();
    });

    it('does not set isDecreasingLifeProduct if product has no end date', () => {
      setup('mortgageLife', {
        protectionContractDetails: {
          isDecreasingProduct: true,
          lastPremiumDate: '2018-11-11',
          policyCurrentAmount: '123.45',
          policyEndDate: 'NA',
        },
      });

      expect(component.isDecreasingLifeProduct).not.toBeTruthy();
    });

    it('does not set isDecreasingLifeProduct if product has no last premium date', () => {
      setup('mortgageLife', {
        protectionContractDetails: {
          isDecreasingProduct: true,
          policyCurrentAmount: '123.45',
          policyEndDate: '2018-11-11',
          lastPremiumDate: 'NA',
        },
      });

      expect(component.isDecreasingLifeProduct).not.toBeTruthy();
    });

    it('does not set isDecreasingLifeProduct if product has no current amount', () => {
      setup('mortgageLife', {
        protectionContractDetails: {
          isDecreasingProduct: true,
          lastPremiumDate: '2018-11-11',
          policyEndDate: '2018-11-11',
        },
      });

      expect(component.isDecreasingLifeProduct).not.toBeTruthy();
    });

    it('does not set isDecreasingLifeProduct if product has an invalid valuation class', () => {
      setup(
        'mortgageLife',
        {
          protectionContractDetails: {
            isDecreasingProduct: false,
            lastPremiumDate: '2018-11-11',
            policyCurrentAmount: '123.45',
            policyEndDate: '2018-11-11',
          },
        },
        '9999',
      );

      expect(component.isDecreasingLifeProduct).not.toBeTruthy();
    });

    it('does not set isDecreasingLifeProduct if product should not diplay data vis', () => {
      setup('selfInvestedPersonalPension');

      expect(component.isDecreasingLifeProduct).not.toBeTruthy();
    });
  });

  it('should assign the correct page title', () => {
    component.pageContentData = cmsData;
    const templateType = 'selfInvestedPersonalPension';

    component.getMapperData(templateType);
    const title = TestBed.inject(Title);
    const titleSpy = jest.spyOn(title, 'setTitle').mockImplementationOnce(jest.fn());
    const cms = TestBed.inject(CmsApiService);

    jest.spyOn(cms, 'getContent').mockReturnValue(of(cmsData));
    fixture.detectChanges();

    expect(titleSpy).toHaveBeenCalledWith(cmsData.pageTitles.productDetails);
  });

  it('should retrieve mapper data for selected product', () => {
    const templateType = 'selfInvestedPersonalPension';

    component.getMapperData(templateType);

    expect(component.mapperData).toEqual(
      productTemplateMapper.selfInvestedPersonalPension,
    );
  });

  it('should set the product category', () => {
    const productCategory = 'AM';

    component.getProductCategory(productCategory);

    expect(component.productCategory).toEqual('BOND');
  });

  it('sets the breadcrumbs correctly', () => {
    component.contractDetails = {
      description: 'Contract details desc',
    };

    fixture.detectChanges();

    component.setBreadcrumbs();

    expect(breadcrumbService.setBreadcrumb).toHaveBeenCalledWith([
      { label: 'Contract details desc', url: null },
    ]);
  });
});
