import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ProductDetailsContainerComponent } from './product-details-container.component';
import { TransactionsContainerComponent } from './transactions-container/transactions-container.component';

export const productDetailsRoutes: Routes = [
  {
    path: ':productCode/:valuationClass/:productHoldingType/:uninsuredContractId/:tabName',
    component: ProductDetailsContainerComponent,
  },
  {
    path: ':productCode/:valuationClass/:productHoldingType/:uninsuredContractId/Transactions/all',
    component: TransactionsContainerComponent,
  },
];

@NgModule({
  imports: [ RouterModule.forChild(productDetailsRoutes) ],
  exports: [ RouterModule ],
})
export class ProductDetailsRoutingModule {}
