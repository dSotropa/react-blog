import { Component, HostListener, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { fromEvent, Observable } from 'rxjs';
import { skip } from 'rxjs/operators';

import { AnalyticsService, SyndicationService } from '@libs/ma/shared/utility-services';
import { WindowService } from '@libs/shared/utility-service-window';
import { cookieConsentChangedEvent } from '@libs/shared/utility-data';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.scss' ],
})
export class AppComponent implements OnInit {
  mapperData: any;
  timeoutModalOpen = false;
  windowInstance: any = window;
  partyId = '';
  cookieChangedSubscription;

  // State from Store
  selectIsLoading$: Observable<boolean>;

  constructor(
    private analyticsService: AnalyticsService,
    private router: Router,
    private syndicationService: SyndicationService,
    private windowHelper: WindowService,
  ) {}

  /**
   * This allows router links to be added to dynamic content by adding a 'routerLink' class.
   * to an anchor tag and storing the route path in the href. For example:-
   * <p>Some dynamic content. Please click <a class="routerLink" href="someRoutePath">here</a></p>
   */
  @HostListener('document:click', [ '$event' ])
  public handleClick(event: Event): void {
    if (event.target instanceof HTMLAnchorElement) {
      const element = event.target;

      if (element.className === 'routerLink') {
        event.preventDefault();
        const route = element.getAttribute('href');

        if (route) {
          this.router.navigate([ `/${route}` ]);
        }
      }
    }
  }

  ngOnInit() {
    this.syndicationService.init();

    this.analyticsService.initialise();

    // everytime the cookie consent changes the app reloads to stop the chosen scripts from running
    this.cookieChangedSubscription = fromEvent(document, cookieConsentChangedEvent)
      .pipe(skip(2))
      .subscribe(() => {
        this.windowHelper.getWindow().location.reload();
      });
  }
}
