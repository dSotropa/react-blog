import { Routing } from '@libs/ma/shared/utility-data';

import { routes } from './app-routing.module';

describe('App routing module', () => {
  it('redirects to /my-account if landing on an empty route', () => {
    expect(routes[0]).toEqual(
      expect.objectContaining({
        path: '',
        redirectTo: Routing.Home,
        pathMatch: 'full',
      }),
    );
  });
});
