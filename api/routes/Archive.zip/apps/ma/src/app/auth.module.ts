import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { Store } from '@ngrx/store';

import { AuthGuard, AuthService } from '@libs/shared/utility-auth';
import { AuthInterceptor } from '@libs/ma/shared/utility-services';

export function authInterceptorFactory(
  authService: AuthService,
  store: Store,
): AuthInterceptor {
  return new AuthInterceptor(authService, store);
}

@NgModule({
  providers: [
    AuthService,
    AuthGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useFactory: authInterceptorFactory,
      multi: true,
      deps: [ AuthService, Store ],
    },
    HttpClientModule,
  ],
})
export class AuthModule {}
