import {
  Component,
  OnInit,
  Input,
  ElementRef,
  ViewChild,
  Renderer2,
  HostListener,
  AfterViewInit,
} from '@angular/core';

@Component({
  selector: 'app-info-tooltip',
  templateUrl: './info-tooltip.component.html',
  styleUrls: [ './info-tooltip.component.scss' ],
})
export class InfoTooltipComponent implements OnInit, AfterViewInit {
  dimensions = {
    tooltip: <number>null,
    trigger: <number>null,
  };
  viewportWidth: number;
  viewPortPadding = 16;

  @Input() isVisible = false;
  @Input() content: string;
  @Input() id: string;

  @ViewChild('tooltip', { static: true }) tooltip: ElementRef;
  @ViewChild('trigger', { read: ElementRef }) trigger: ElementRef;

  constructor(private renderer: Renderer2) {}

  @HostListener('window:resize', [ '$event' ])
  onResize() {
    this.initialise();
  }

  ngOnInit() {
    this.initialise();
  }

  ngAfterViewInit() {
    const tooltipComputedWidth = window.getComputedStyle(
      this.tooltip.nativeElement,
    ).width;

    this.dimensions = {
      trigger: this.trigger.nativeElement.offsetWidth,
      tooltip: parseInt(tooltipComputedWidth, 0),
    };
  }

  initialise() {
    this.viewportWidth = window.innerWidth;
    this.render();
  }

  toggle(): void {
    this.render();
    this.isVisible = !this.isVisible;
  }

  hide(): void {
    this.isVisible = false;
  }

  render() {
    if (this.trigger) {
      const iconRect: DOMRect = this.trigger.nativeElement.getBoundingClientRect();
      const intialOffset = iconRect.left + iconRect.width / 2;

      const tooltipOffset = {
        left: intialOffset - this.dimensions.tooltip / 2,
        right: intialOffset + this.dimensions.tooltip / 2,
      };

      if (tooltipOffset.right > this.viewportWidth) {
        const offsetRight =
          this.dimensions.tooltip / 2 +
          (tooltipOffset.right - this.viewportWidth) +
          this.viewPortPadding;

        this.renderer.setStyle(this.tooltip.nativeElement, 'left', `-${offsetRight}px`);
      }

      if (tooltipOffset.left < 0) {
        const offsetLeft = intialOffset - this.viewPortPadding;

        this.renderer.setStyle(this.tooltip.nativeElement, 'left', `-${offsetLeft}px`);
      }
    }
  }
}
