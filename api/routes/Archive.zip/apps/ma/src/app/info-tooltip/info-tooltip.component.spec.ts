import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, Renderer2 } from '@angular/core';
import { MockComponent, MockProvider } from 'ng-mocks';
import { LgIconComponent } from '@legal-and-general/canopy';

import { InfoTooltipComponent } from './info-tooltip.component';

describe('InfoTooltipComponent', () => {
  let component: InfoTooltipComponent;
  let fixture: ComponentFixture<InfoTooltipComponent>;
  let resizeSpy;

  const setStyleSpy = jest.fn();

  const renderer2Mock = MockProvider(Renderer2, {
    setStyle: setStyleSpy,
  });

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [ RouterTestingModule ],
      declarations: [ InfoTooltipComponent, MockComponent(LgIconComponent) ],
      providers: [ renderer2Mock ],
      schemas: [ NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InfoTooltipComponent);
    component = fixture.componentInstance;
    resizeSpy = jest.spyOn(component, 'onResize');
  });

  it('creates the info tooltip component', () => {
    fixture.detectChanges();

    expect(component).toBeTruthy();
  });

  it('calls initialise when window is resized', () => {
    fixture.detectChanges();
    spyOn(component, 'initialise');
    window.dispatchEvent(new Event('resize'));

    expect(component.initialise).toHaveBeenCalled();
  });

  describe('initialise', () => {
    beforeEach(() => {
      fixture.detectChanges();
      spyOn(component, 'render');
      component.initialise();
    });

    it('renders the tooltip', () => {
      expect(component.render).toHaveBeenCalled();
    });

    it('sets the viewport width', () => {
      expect(component.viewportWidth).toBeDefined();
    });
  });

  describe('after view init', () => {
    it('sets the dimensions', () => {
      fixture.detectChanges();

      expect(component.dimensions.tooltip).not.toBeNull();
      expect(component.dimensions.trigger).not.toBeNull();
    });
  });

  describe('toggle', () => {
    beforeEach(() => {
      spyOn(component, 'render');
      fixture.detectChanges();
      component.isVisible = true;
      component.toggle();
    });

    it('renders the tooltip', () => {
      expect(component.render).toHaveBeenCalled();
    });

    it('toggles the tooltip visibility', () => {
      expect(component.isVisible).not.toBeTruthy();
    });
  });

  describe('hide', () => {
    beforeEach(() => {
      fixture.detectChanges();
      component.isVisible = true;
      component.hide();
    });

    it('sets isVisible to false', () => {
      expect(component.isVisible).not.toBeTruthy();
    });
  });

  describe('render', () => {
    describe('when the tooltip width is less than the viewport width', () => {
      beforeEach(() => {
        fixture.detectChanges();

        component['renderer'].setStyle(
          component.trigger.nativeElement,
          'marginLeft',
          '250px',
        );

        setStyleSpy.mockClear();

        component.viewportWidth = 600;
        component.dimensions.tooltip = 100;
        component.render();
      });

      it('does not set the position', () => {
        expect(setStyleSpy).not.toHaveBeenCalled();
      });
    });
  });
});
