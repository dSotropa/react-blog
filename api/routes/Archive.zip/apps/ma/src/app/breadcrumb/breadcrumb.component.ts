import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { distinctUntilChanged } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';

import { humaniseLoginDate } from '@libs/ma/shared/utility-helpers';
import { AuthService } from '@libs/shared/utility-auth';
import { Breadcrumb, BreadcrumbConfig, Routing } from '@libs/ma/shared/utility-data';
import { BreadcrumbService } from '@libs/ma/shared/utility-services';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: [ './breadcrumb.component.scss' ],
})
export class BreadcrumbComponent implements OnInit, OnDestroy {
  lastLoggedIn: string;
  breadcrumbs: Array<Breadcrumb>;
  isVisible: boolean;
  subscription: Subscription;
  Routing = Routing;

  @Input() isAuthenticated = false;

  constructor(
    private authService: AuthService,
    private breadcrumbService: BreadcrumbService,
    private router: Router,
  ) {}

  ngOnInit() {
    this.subscription = this.breadcrumbService.breadcrumbs
      .pipe(distinctUntilChanged())
      .subscribe((data: BreadcrumbConfig) => {
        this.breadcrumbs = data.breadcrumbs;
        this.isVisible = data.isVisible;
      });

    this.lastLoggedIn = humaniseLoginDate(this.authService.getLastLogInDate());
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  isOnHomePage(): boolean {
    return this.Routing.Home === this.router.url;
  }
}
