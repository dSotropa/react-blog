import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { StoreModule } from '@ngrx/store';
import { MockComponents } from 'ng-mocks';
import { LgIconComponent } from '@legal-and-general/canopy';

import { rootReducer } from '@libs/ma/shared/utility-state';
import { AuthService } from '@libs/shared/utility-auth';
import { BreadcrumbService } from '@libs/ma/shared/utility-services';

import { BreadcrumbComponent } from './breadcrumb.component';

class MockAuthService {
  getLastLogInDate() {
    return 'Some date';
  }
}

describe('BreadcrumbComponent', () => {
  let component: BreadcrumbComponent;
  let fixture: ComponentFixture<BreadcrumbComponent>;
  let service;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        StoreModule.forRoot(rootReducer, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true,
          },
        }),
      ],
      declarations: [ BreadcrumbComponent, MockComponents(LgIconComponent) ],
      providers: [ BreadcrumbService, { provide: AuthService, useClass: MockAuthService } ],
      schemas: [ NO_ERRORS_SCHEMA ],
    }).compileComponents();

    service = TestBed.inject(BreadcrumbService);
    fixture = TestBed.createComponent(BreadcrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('is created successfully', () => {
    expect(component).toBeTruthy();
  });

  describe('breadcrumbs', () => {
    let nextValue;

    beforeEach(() => {
      component.isAuthenticated = true;

      nextValue = [
        {
          label: 'Parent page name',
          url: '/path-to-page',
        },
        {
          label: 'Page name',
          url: null,
        },
      ];

      service.setBreadcrumb(nextValue, true);

      component.ngOnInit();

      fixture.detectChanges();
    });

    it('sets the breadcrumb data', () => {
      expect(component.breadcrumbs).toEqual(nextValue);
    });

    it('sets the breadcrumb visibility', () => {
      expect(component.isVisible).toBeTruthy();
    });

    it('displays crumb as a link if url is defined', () => {
      const itemLink = fixture.debugElement.queryAll(By.css('.breadcrumb-item-link'));
      const el: HTMLElement = itemLink[1].nativeElement;

      expect(el.innerHTML).toBe('Parent page name');
    });

    it('displays crumb as a text if url is not defined', () => {
      const itemPage = fixture.debugElement.queryAll(By.css('.breadcrumb-item span'));
      const el: HTMLElement = itemPage[1].nativeElement;

      expect(el.innerHTML).toBe('Page name');
    });
  });
});
