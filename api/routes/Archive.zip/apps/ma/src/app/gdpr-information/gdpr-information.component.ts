import { Component, Input, OnInit } from '@angular/core';

import { AnalyticsService, CmsApiService } from '@libs/ma/shared/utility-services';

@Component({
  selector: 'app-gdpr-information',
  templateUrl: './gdpr-information.component.html',
  styleUrls: [ './gdpr-information.component.scss' ],
})
export class GdprInformationComponent implements OnInit {
  @Input() includeHeadingLevelTwo: boolean;
  @Input() includeHeadingLevelThree: boolean;
  @Input() pageContentData: any;

  constructor(
    private analyticsService: AnalyticsService,
    private cmsApiService: CmsApiService,
  ) {}

  ngOnInit() {
    if (!this.pageContentData) {
      this.cmsApiService.getContent().subscribe(data => {
        this.pageContentData = data;
      });
    }
  }

  trackEvent() {
    this.analyticsService.eventTrack({
      name: 'Privacy policy',
      type: 'Button click',
    });
  }
}
