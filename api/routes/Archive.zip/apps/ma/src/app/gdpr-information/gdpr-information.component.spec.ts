import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { of } from 'rxjs';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MockProvider } from 'ng-mocks';

import { cmsData } from '@libs/ma/shared/utility-data';
import { AnalyticsService, CmsApiService } from '@libs/ma/shared/utility-services';

import { GdprInformationComponent } from './gdpr-information.component';

const getContentSpy = jest.fn().mockReturnValue(of(null));

const cmsApiServiceMock = MockProvider(CmsApiService, {
  getContent: getContentSpy,
});

const analyticsServiceMock = MockProvider(AnalyticsService);

describe('GdprInformationComponent', () => {
  let component: GdprInformationComponent;
  let fixture: ComponentFixture<GdprInformationComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ GdprInformationComponent ],
      imports: [ HttpClientTestingModule ],
      providers: [ cmsApiServiceMock, analyticsServiceMock ],
      schemas: [ NO_ERRORS_SCHEMA ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GdprInformationComponent);
    component = fixture.componentInstance;

    getContentSpy.mockReturnValue(of(cmsData));
  });

  it('should create the gdpr-information component', () => {
    fixture.detectChanges();

    expect(component).toBeTruthy();
  });

  describe('when specifying "includeHeadingLevelTwo"', () => {
    beforeEach(() => {
      component.includeHeadingLevelTwo = true;
      fixture.detectChanges();
    });

    it('should show an h2', () => {
      const de = fixture.debugElement.query(By.css('h2'));

      expect(de).toBeTruthy();
    });

    it('should not show an h3', () => {
      const de = fixture.debugElement.query(By.css('h3'));

      expect(de).toBeFalsy();
    });
  });

  describe('when specifying "includeHeadingLevelThree"', () => {
    beforeEach(() => {
      component.includeHeadingLevelThree = true;
      fixture.detectChanges();
    });

    it('should show an h3', () => {
      const de = fixture.debugElement.query(By.css('h3'));

      expect(de).toBeTruthy();
    });

    it('should not show an h2', () => {
      const de = fixture.debugElement.query(By.css('h2'));

      expect(de).toBeFalsy();
    });
  });

  describe('when there is no pageContentData available', () => {
    it('should retrieve the cms data', () => {
      fixture.detectChanges();

      expect(component.pageContentData).toEqual(cmsData);
    });
  });

  describe('when there is pageContentData available', () => {
    it('should not retrieve the cms data', () => {
      component.pageContentData = cmsData;
      fixture.detectChanges();

      expect(component.pageContentData).toEqual(cmsData);
    });
  });
});
