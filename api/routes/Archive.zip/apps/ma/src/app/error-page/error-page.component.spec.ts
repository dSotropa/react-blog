import { ActivatedRoute } from '@angular/router';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By, Title } from '@angular/platform-browser';
import { of } from 'rxjs';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MockProvider } from 'ng-mocks';

import { cmsData } from '@libs/ma/shared/utility-data';
import { AnalyticsService, CmsApiService } from '@libs/ma/shared/utility-services';

import { ErrorPageComponent } from './error-page.component';

class RouteStub {
  snapshot = {
    queryParams: {
      status: '1',
    },
  };
}

const getContentSpy = jest.fn().mockReturnValue(of(null));
const trackErrorSpy = jest.fn();

const cmsApiServiceMock = MockProvider(CmsApiService, {
  getContent: getContentSpy,
});

const analyticsServiceMock = MockProvider(AnalyticsService, {
  trackError: trackErrorSpy,
});

describe('ErrorPageComponent', () => {
  let component: ErrorPageComponent;
  let fixture: ComponentFixture<ErrorPageComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      declarations: [ ErrorPageComponent ],
      providers: [
        cmsApiServiceMock,
        Title,
        analyticsServiceMock,
        { provide: ActivatedRoute, useClass: RouteStub },
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrorPageComponent);
    component = fixture.componentInstance;
  });

  it('should create the error-page component', () => {
    fixture.detectChanges();

    expect(component).toBeTruthy();
  });

  it('should not render the error wrap when cmsData cannot be retrieved', () => {
    const de = fixture.debugElement.query(By.css('.error-wrap'));

    expect(de).toBeNull();
  });

  it('should assign the correct page title', () => {
    component.pageContentData = cmsData;
    const title = TestBed.inject(Title);
    const titleSpy = jest.spyOn(title, 'setTitle');
    const cms = TestBed.inject(CmsApiService);

    getContentSpy.mockReturnValue(of(cmsData));
    fixture.detectChanges();

    expect(titleSpy).toHaveBeenCalledWith(cmsData.pageTitles.errorPage);
  });

  it('should expect to retrive the CMS data on page load', () => {
    getContentSpy.mockReturnValue(of(cmsData));

    fixture.detectChanges();

    expect(getContentSpy).toHaveBeenCalled();
    expect(component.pageContentData).toEqual(cmsData);
  });

  describe('testing the element bindings', () => {
    beforeEach(() => {
      getContentSpy.mockReturnValue(of(cmsData));
      fixture.detectChanges();
    });

    it('should bind the correct page title', () => {
      const de = fixture.debugElement.query(By.css('#error-page-title'));
      const el: HTMLElement = de.nativeElement;

      expect(el.innerHTML).toContain('Something has gone wrong');
    });

    it('should bind the correct error message', () => {
      const de = fixture.debugElement.query(By.css('#error-page-message'));
      const el: HTMLElement = de.nativeElement;

      expect(el.innerHTML).toContain('error message');
    });

    it('should bind the correct error details', () => {
      const de = fixture.debugElement.query(By.css('#error-page-details'));
      const el: HTMLElement = de.nativeElement;

      expect(el.innerHTML).toContain('Error details will go here');
    });
  });

  it('should track the error', () => {
    fixture.detectChanges();

    expect(trackErrorSpy).toHaveBeenCalledWith({
      pageName: 'My Account Error',
      type: '1',
    });
  });
});
