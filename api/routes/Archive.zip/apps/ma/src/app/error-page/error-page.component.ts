import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

import { AnalyticsService, CmsApiService } from '@libs/ma/shared/utility-services';

@Component({
  selector: 'app-error-page',
  templateUrl: './error-page.component.html',
  styleUrls: [ './error-page.component.scss' ],
})
export class ErrorPageComponent implements OnInit {
  pageContentData: any;

  constructor(
    private analyticsService: AnalyticsService,
    private cmsApiService: CmsApiService,
    private pageTitle: Title,
    private route: ActivatedRoute,
  ) {}

  ngOnInit() {
    this.cmsApiService.getContent().subscribe((data: any) => {
      this.pageContentData = data;
      this.pageTitle.setTitle(data?.pageTitles.errorPage);
    });

    this.analyticsService.trackError({
      pageName: 'My Account Error',
      type: this.route.snapshot.queryParams['status'],
    });
  }
}
