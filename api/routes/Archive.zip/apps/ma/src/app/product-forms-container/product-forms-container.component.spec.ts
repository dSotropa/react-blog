import { ComponentFixture, inject, TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute } from '@angular/router';
import { MockComponents } from 'ng-mocks';
import { of } from 'rxjs';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { StoreModule } from '@ngrx/store';

import {
  contractDetailsData as mockData,
  productFormsContent,
} from '@libs/ma/shared/utility-data';
import { SpinnerComponent } from '@libs/ma/shared/ui';
import { rootReducer } from '@libs/ma/shared/utility-state';
import {
  CmsApiService,
  ContractDetailsListenerService,
  QueryParamsAccessorService,
} from '@libs/ma/shared/utility-services';

import { SharedModule } from '../common/shared.module';

import { ProductFormsContainerComponent } from './product-forms-container.component';

class QueryParamsAccessorMock {
  setQueryParams() {
    return {};
  }
}

class ProductDetailsApiServiceMock {
  getProductDetails(payload) {
    return of(mockData.selfInvestedPersonalPension);
  }
}

class ContractDetailsListenerServiceMock {
  init(params) {}
}

class RouteStub {
  snapshot = {
    params: {
      contractId: '2844641031',
      valuationClass: 'AB',
      productHoldingType: 'AA',
      uninsuredContractId: '1234',
      tabName: 'Overview',
    },
  };
}

const initialState = {
  router: {},
};

describe('ProductFormsContainerComponent', () => {
  let component: ProductFormsContainerComponent;
  let fixture: ComponentFixture<ProductFormsContainerComponent>;
  let contractDetailsListenerService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductFormsContainerComponent, MockComponents(SpinnerComponent) ],
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        SharedModule,
        StoreModule.forRoot(rootReducer, {
          initialState,
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true,
          },
        }),
      ],
      providers: [
        CmsApiService,
        { provide: QueryParamsAccessorService, useClass: QueryParamsAccessorMock },
        {
          provide: contractDetailsListenerService,
          useClass: ContractDetailsListenerServiceMock,
        },
        { provide: ActivatedRoute, useClass: RouteStub },
      ],
    }).compileComponents();
  }));

  beforeEach(inject([ ContractDetailsListenerService ], service => {
    contractDetailsListenerService = service;
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductFormsContainerComponent);
    component = fixture.componentInstance;
    const cms = TestBed.inject(CmsApiService);

    jest.spyOn(cms, 'getFormsContent').mockReturnValue(of(productFormsContent));
    jest.spyOn(contractDetailsListenerService, 'init').mockImplementation(jest.fn());
  });

  it('should create ProductFormsComponent', () => {
    fixture.detectChanges();

    expect(component).toBeTruthy();
  });

  it('should initialise the contract Details service if no portfolio summary error', waitForAsync(() => {
    component.handleError(false);

    expect(contractDetailsListenerService.init).toHaveBeenCalledWith({
      contractId: '2844641031',
      valuationClass: 'AB',
      productHoldingType: 'AA',
      uninsuredContractId: '1234',
      tabName: 'Overview',
    });
  }));

  it('should not initialise the contract Details service if portfolio summary error', waitForAsync(() => {
    component.handleError(true);

    expect(contractDetailsListenerService.init).not.toHaveBeenCalled();
  }));

  it('should retrieve the cms data for product forms', () => {
    component.getContents();

    expect(component.pageContentData).toEqual(productFormsContent);
  });
});
