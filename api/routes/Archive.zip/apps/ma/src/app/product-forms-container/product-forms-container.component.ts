import { ActivatedRoute } from '@angular/router';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { select, Store } from '@ngrx/store';

import { State } from '@libs/ma/shared/utility-data';
import {
  selectCustomerProfileError,
  selectCustomerProfileLoaded,
  selectLegacyProductDetailsErrorFromUrl,
  selectLegacyProductDetailsLoadedFromUrl,
  selectLegacySummaryError,
  selectLegacySummaryLoaded,
  selectProductFromUrl,
  selectRouterParams,
} from '@libs/ma/shared/utility-selectors';
import {
  CmsApiService,
  ContractDetailsListenerService,
} from '@libs/ma/shared/utility-services';

@Component({
  selector: 'app-product-forms-container',
  templateUrl: './product-forms-container.component.html',
  styleUrls: [ './product-forms-container.component.scss' ],
})
export class ProductFormsContainerComponent implements OnInit, OnDestroy {
  private ngUnsubscribe: Subject<void> = new Subject<void>();

  // Customer profile
  customerDataLoaded: Observable<boolean>;
  customerDataError: Observable<boolean>;

  // Portfolio summary
  portfolioSummaryLoaded: Observable<boolean>;
  portfolioSummaryError: Observable<boolean>;

  // Contract details
  contractDetailsLoaded: Observable<boolean>;
  contractDetailsError: Observable<boolean>;

  selectProductFromUrl$: Observable<any>;
  selectRouterParams$: Observable<any>;

  queryParams: any;
  pageContentData: object;
  formsData: Array<any> = [ { contractData: {} }, { portfolioData: {} } ];

  constructor(
    private cmsApiService: CmsApiService,
    private contractDetailsListenerService: ContractDetailsListenerService,
    private route: ActivatedRoute,
    private store: Store<State>,
  ) {}

  ngOnInit() {
    this.customerDataLoaded = this.store.pipe(select(selectCustomerProfileLoaded));
    this.customerDataError = this.store.pipe(select(selectCustomerProfileError));
    this.portfolioSummaryLoaded = this.store.pipe(select(selectLegacySummaryLoaded));
    this.portfolioSummaryError = this.store.pipe(select(selectLegacySummaryError));

    this.contractDetailsLoaded = this.store.pipe(
      select(selectLegacyProductDetailsLoadedFromUrl),
    );

    this.contractDetailsError = this.store.pipe(
      select(selectLegacyProductDetailsErrorFromUrl),
    );

    this.selectProductFromUrl$ = this.store.pipe(select(selectProductFromUrl));
    this.selectRouterParams$ = this.store.pipe(select(selectRouterParams));
    this.getContents();

    this.portfolioSummaryError
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe(this.handleError);
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  getContents() {
    this.cmsApiService
      .getFormsContent()
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe(data => {
        this.pageContentData = data;
      });
  }

  handleError = error => {
    if (!error) {
      this.contractDetailsListenerService.init(this.route.snapshot.params);
    }
  };
}
