import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CollectionDayFormComponent } from './collection-day-form/collection-day-form.component';
import { ContributionFormComponent } from './contribution-form/contribution-form.component';
import { DirectDebitDetailsFormComponent } from './direct-debit-details-form/direct-debit-details-form.component';
import { FormConfirmationComponent } from './form-confirmation/form-confirmation.component';
import { NaturalIncomeFormComponent } from './natural-income-form/natural-income-form.component';
import { OptionsPackFormComponent } from './options-pack-form/options-pack-form.component';
import { ProductFormsContainerComponent } from './product-forms-container.component';
import { RetirementAgeFormComponent } from './retirement-age-form/retirement-age-form.component';
import { TransferInFormComponent } from './transfer-in-form/transfer-in-form.component';

export const productFormsRoutes: Routes = [
  {
    path: '',
    component: ProductFormsContainerComponent,
    children: [
      { path: 'change-contribution', component: ContributionFormComponent },
      { path: 'change-collection-day', component: CollectionDayFormComponent },
      { path: 'change-direct-debit', component: DirectDebitDetailsFormComponent },
      { path: ':formType/confirmation', component: FormConfirmationComponent },
      { path: 'request-natural-income', component: NaturalIncomeFormComponent },
      { path: 'request-to-change-retirement-age', component: RetirementAgeFormComponent },
      { path: 'request-an-options-pack', component: OptionsPackFormComponent },
      { path: 'request-a-transfer-in-form', component: TransferInFormComponent },
    ],
  },
];

@NgModule({
  imports: [ RouterModule.forChild(productFormsRoutes) ],
  exports: [ RouterModule ],
})
export class ProductFormsRoutingModule {}
