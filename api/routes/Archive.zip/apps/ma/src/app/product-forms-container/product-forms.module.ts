import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import {
  LgBreadcrumbModule,
  LgButtonModule,
  LgCamelCasePipe,
  LgCardModule,
  LgGridModule,
  LgHintModule,
  LgInputModule,
  LgMarginModule,
  LgPaddingModule,
  LgSelectModule,
  LgSortCodeModule,
  LgSeparatorModule,
  LgValidationModule,
  LgIconRegistry,
  lgIconChevronLeft,
  LgIconModule,
} from '@legal-and-general/canopy';

import { MaSharedUiModule } from '@libs/ma/shared/ui';

import { SharedModule } from '../common/shared.module';

import { BankAccountDetailsFormSectionComponent } from './bank-account-details-form-section/bank-account-details-form-section.component';
import { CollectionDayFormComponent } from './collection-day-form/collection-day-form.component';
import { CollectionDayFormSectionComponent } from './collection-day-form-section/collection-day-form-section.component';
import { ContributionFormComponent } from './contribution-form/contribution-form.component';
import { ContributionFormSectionComponent } from './contribution-form-section/contribution-form-section.component';
import { DirectDebitDetailsFormComponent } from './direct-debit-details-form/direct-debit-details-form.component';
import { FormButtonsComponent } from './form-buttons/form-buttons.component';
import { FormConfirmationComponent } from './form-confirmation/form-confirmation.component';
import { FormHeaderComponent } from './form-header/form-header.component';
import { FormHelperService } from './form-helper/form-helper.service';
import { FormInputComponent } from './form-input/form-input.component';
import { FormInputHelperService } from './form-input-helper/form-input-helper.service';
import { FrequencyFormSectionComponent } from './frequency-form-section/frequency-form-section.component';
import { NaturalIncomeFormComponent } from './natural-income-form/natural-income-form.component';
import { OptionsPackFormComponent } from './options-pack-form/options-pack-form.component';
import { ProductFormsContainerComponent } from './product-forms-container.component';
import { ProductFormsRoutingModule } from './product-forms.routes';
import { RetirementAgeFormComponent } from './retirement-age-form/retirement-age-form.component';
import { TransferInFormComponent } from './transfer-in-form/transfer-in-form.component';

const CanopyImports = [
  LgButtonModule,
  LgGridModule,
  LgSeparatorModule,
  LgMarginModule,
  LgPaddingModule,
  LgInputModule,
  LgSelectModule,
  LgCardModule,
  LgBreadcrumbModule,
  LgHintModule,
  LgSortCodeModule,
  LgValidationModule,
  LgIconModule,
];

@NgModule({
  declarations: [
    BankAccountDetailsFormSectionComponent,
    CollectionDayFormComponent,
    CollectionDayFormSectionComponent,
    ContributionFormComponent,
    ContributionFormSectionComponent,
    DirectDebitDetailsFormComponent,
    FormButtonsComponent,
    FormConfirmationComponent,
    FormHeaderComponent,
    FormInputComponent,
    FrequencyFormSectionComponent,
    NaturalIncomeFormComponent,
    OptionsPackFormComponent,
    ProductFormsContainerComponent,
    RetirementAgeFormComponent,
    TransferInFormComponent,
  ],
  imports: [ MaSharedUiModule, ProductFormsRoutingModule, SharedModule, ...CanopyImports ],
  providers: [ LgCamelCasePipe, FormHelperService, FormInputHelperService ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
})
export class ProductFormsModule {
  constructor(private iconRegistry: LgIconRegistry) {
    this.iconRegistry.registerIcons([ lgIconChevronLeft ]);
  }
}
