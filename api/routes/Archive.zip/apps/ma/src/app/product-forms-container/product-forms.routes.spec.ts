import { CollectionDayFormComponent } from './collection-day-form/collection-day-form.component';
import { ContributionFormComponent } from './contribution-form/contribution-form.component';
import { DirectDebitDetailsFormComponent } from './direct-debit-details-form/direct-debit-details-form.component';
import { FormConfirmationComponent } from './form-confirmation/form-confirmation.component';
import { NaturalIncomeFormComponent } from './natural-income-form/natural-income-form.component';
import { OptionsPackFormComponent } from './options-pack-form/options-pack-form.component';
import { ProductFormsContainerComponent } from './product-forms-container.component';
import { productFormsRoutes } from './product-forms.routes';
import { RetirementAgeFormComponent } from './retirement-age-form/retirement-age-form.component';
import { TransferInFormComponent } from './transfer-in-form/transfer-in-form.component';

describe('Product forms router', () => {
  it('contains an empty path at the top level route', () => {
    expect(productFormsRoutes[0].path).toBe('');
  });

  it('loads the Product Forms Container Component at the top level root', () => {
    expect(productFormsRoutes[0].component).toBe(ProductFormsContainerComponent);
  });

  it('contains child routes for all product forms', () => {
    expect(productFormsRoutes[0].children).toEqual(
      expect.arrayContaining([
        { path: 'change-contribution', component: ContributionFormComponent },
      ]),
    );

    expect(productFormsRoutes[0].children).toEqual(
      expect.arrayContaining([
        { path: 'change-collection-day', component: CollectionDayFormComponent },
      ]),
    );

    expect(productFormsRoutes[0].children).toEqual(
      expect.arrayContaining([
        { path: 'change-direct-debit', component: DirectDebitDetailsFormComponent },
      ]),
    );

    expect(productFormsRoutes[0].children).toEqual(
      expect.arrayContaining([
        { path: ':formType/confirmation', component: FormConfirmationComponent },
      ]),
    );

    expect(productFormsRoutes[0].children).toEqual(
      expect.arrayContaining([
        { path: 'request-natural-income', component: NaturalIncomeFormComponent },
      ]),
    );

    expect(productFormsRoutes[0].children).toEqual(
      expect.arrayContaining([
        {
          path: 'request-to-change-retirement-age',
          component: RetirementAgeFormComponent,
        },
      ]),
    );

    expect(productFormsRoutes[0].children).toEqual(
      expect.arrayContaining([
        { path: 'request-an-options-pack', component: OptionsPackFormComponent },
      ]),
    );

    expect(productFormsRoutes[0].children).toEqual(
      expect.arrayContaining([
        { path: 'request-a-transfer-in-form', component: TransferInFormComponent },
      ]),
    );
  });
});
