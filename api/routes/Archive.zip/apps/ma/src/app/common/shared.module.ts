import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
  CustomerRequestApiService,
  PayloadGeneratorService,
} from '@libs/ma/shared/utility-services';

import { GdprInformationComponent } from '../gdpr-information/gdpr-information.component';
import { ErrorPageComponent } from '../error-page/error-page.component';
import { AtomsModule } from '../_atoms/atoms.module';

import { SuccessErrorAlertComponent } from './success-error-alert/success-error-alert.component';

@NgModule({
  declarations: [
    ErrorPageComponent,
    GdprInformationComponent,
    SuccessErrorAlertComponent,
  ],
  exports: [
    CommonModule,
    GdprInformationComponent,
    ReactiveFormsModule,
    ErrorPageComponent,
    SuccessErrorAlertComponent,
  ],
  imports: [ CommonModule, FormsModule, AtomsModule ],
  providers: [ CustomerRequestApiService, PayloadGeneratorService ],
})
export class SharedModule {}
