import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CookieService } from 'ngx-cookie-service';
import { EffectsModule } from '@ngrx/effects';
import { MetaReducer, StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { RouterState, StoreRouterConnectingModule } from '@ngrx/router-store';
import { LocationStrategy } from '@angular/common';
import { LgFocusModule } from '@legal-and-general/canopy';

import { MaSharedUiModule } from '@libs/ma/shared/ui';
import { environment } from '@libs/shared/utility-config-loader';
import {
  AccountDetailsEffects,
  CountsEffects,
  DocumentsEffects,
  NotificationsEffects,
  PortfolioEffects,
  ProductsEffects,
  RouterEffects,
  SessionEffects,
  SupportEffects,
  TogglesEffects,
} from '@libs/ma/shared/utility-effects';
import { rootReducer } from '@libs/ma/shared/utility-state';
import { MaSharedUtilityDirectivesModule } from '@libs/ma/shared/utility-directives';
import {
  CmsApiService,
  CustomerProfileApiService,
  CustomLocationStrategy,
  DocumentsApiService,
  DomHelperService,
  NotificationsApiService,
  PortfolioSummaryApiService,
} from '@libs/ma/shared/utility-services';
import { WindowService } from '@libs/shared/utility-service-window';
import { MaSharedUtilityPipesModule } from '@libs/ma/shared/utility-pipes';
import { SharedFeatureConnectedOverlayModule } from '@libs/shared/feature-connected-overlay';
import { SharedFeatureSurveyModule } from '@libs/shared/feature-survey';
import { MaSupportFeatureSupportWidgetModule } from '@libs/ma/support/feature-support-widget';
import { MaCoreFeatureNavigationModule } from '@libs/ma/core/feature-navigation';
import { MaCoreUiModule } from '@libs/ma/core/ui';
import { MaCoreFeatureInterstitialContainerModule } from '@libs/ma/core/feature-interstitial-container';
import { MaSharedFeatureInterstitialModule } from '@libs/ma/shared/feature-interstitial';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { AuthModule } from './auth.module';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { ComponentsModule } from './_components/components.module';
import { SimpleContainerComponent } from './_containers/simple-container/simple-container.component';
import { GenericContainerComponent } from './_containers/generic-container/generic-container.component';
import { NewContainerComponent } from './_containers/new-container/new-container.component';
import { FormJourneyContainerComponent } from './_containers/form-journey-container/form-journey-container.component';
import { SharedModule } from './common/shared.module';
import { WidgetsModule } from './_components/widgets/widgets.module';
import { SupportGuard } from './_guards/support-guard';
import { PspModule } from './_modules/psp/psp.module';
import { GenericContainerV2Component } from './_containers/generic-container-v2/generic-container-v2.component';
import { MainWrapperModule } from './_modules/main-wrapper/main-wrapper.module';

export const metaReducers: Array<MetaReducer<any>> = !environment.config.production
  ? []
  : [];

const initialState = {
  router: {},
};

@NgModule({
  declarations: [
    AppComponent,
    BreadcrumbComponent,
    SimpleContainerComponent,
    GenericContainerComponent,
    NewContainerComponent,
    FormJourneyContainerComponent,
    GenericContainerV2Component,
  ],
  imports: [
    AuthModule,
    BrowserModule,
    ComponentsModule,
    HttpClientModule,
    AppRoutingModule,
    SharedFeatureConnectedOverlayModule,
    SharedModule,
    WidgetsModule,
    PspModule,
    MaSharedUiModule,
    MaSharedUtilityDirectivesModule,
    MaSharedUtilityPipesModule,
    MaSupportFeatureSupportWidgetModule,
    MaCoreFeatureNavigationModule,
    MaCoreUiModule,
    MaCoreFeatureInterstitialContainerModule,
    MaSharedFeatureInterstitialModule,
    MainWrapperModule,
    EffectsModule.forRoot([
      CountsEffects,
      PortfolioEffects,
      DocumentsEffects,
      NotificationsEffects,
      ProductsEffects,
      SessionEffects,
      TogglesEffects,
      RouterEffects,
      SupportEffects,
      AccountDetailsEffects,
    ]),
    StoreModule.forRoot(rootReducer, {
      initialState,
      metaReducers,
      runtimeChecks: {
        strictStateImmutability: true,
        strictActionImmutability: true,
      },
    }),
    StoreRouterConnectingModule.forRoot({
      routerState: RouterState.Minimal,
    }),
    StoreDevtoolsModule.instrument({
      maxAge: 30,
      name: '🌟 My Account',
    }),
    LgFocusModule,
    SharedFeatureSurveyModule,
  ],
  providers: [
    CmsApiService,
    CookieService,
    CustomerProfileApiService,
    DocumentsApiService,
    DomHelperService,
    HttpClient,
    SupportGuard,
    NotificationsApiService,
    PortfolioSummaryApiService,
    WindowService,
    { provide: LocationStrategy, useClass: CustomLocationStrategy },
  ],
  bootstrap: [ AppComponent ],
})
export class AppModule {}
