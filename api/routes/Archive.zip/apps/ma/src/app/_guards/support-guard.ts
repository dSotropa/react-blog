import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  CanActivate,
} from '@angular/router';
import { Observable, of } from 'rxjs';
import { Store } from '@ngrx/store';

import { State, SupportWidgetState } from '@libs/ma/shared/utility-data';
import { updateSupportWidgetStateAction } from '@libs/ma/shared/utility-actions';

@Injectable({
  providedIn: 'root',
})
export class SupportGuard implements CanActivate {
  constructor(private store: Store<State>) {}

  canActivate(
    // eslint-disable-next-line unused-imports/no-unused-vars
    route: ActivatedRouteSnapshot,
    // eslint-disable-next-line unused-imports/no-unused-vars
    state: RouterStateSnapshot,
  ): Observable<boolean> {
    this.store.dispatch(
      updateSupportWidgetStateAction({
        supportWidgetState: SupportWidgetState.SupportRequested,
      }),
    );

    return of(false);
  }
}
