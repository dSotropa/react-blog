import { inject, TestBed } from '@angular/core/testing';
import { Store } from '@ngrx/store';
import { RouterTestingModule } from '@angular/router/testing';
import { MockStore, provideMockStore } from '@ngrx/store/testing';

import { SupportWidgetState } from '@libs/ma/shared/utility-data';
import { updateSupportWidgetStateAction } from '@libs/ma/shared/utility-actions';

import { SupportGuard } from './support-guard';

describe('SupportGuard', () => {
  let store: MockStore<any>;
  let subject: SupportGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [ RouterTestingModule ],
      providers: [ SupportGuard, provideMockStore({}) ],
    }).compileComponents();
  });

  beforeEach(() => {
    subject = TestBed.get(SupportGuard);
    store = TestBed.get(Store);
  });

  describe('canActivate', () => {
    it('should return false and dispatch to the store', inject(
      [ SupportGuard ],
      (guard: SupportGuard) => {
        const spy = jest.spyOn(store, 'dispatch').mockImplementationOnce(jest.fn());
        const res$ = guard.canActivate(null, null);
        const action = updateSupportWidgetStateAction({
          supportWidgetState: SupportWidgetState.SupportRequested,
        });

        res$.subscribe(res => {
          expect(res).toBe(false);
          expect(spy).toHaveBeenCalledWith(action);
        });
      },
    ));
  });
});
