import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { catchError, map } from 'rxjs/operators';
import { throwError } from 'rxjs';

import { ConfigLoaderService, environment } from '@libs/shared/utility-config-loader';
import {
  AuthProvider,
  AuthService,
  CanaryReleaseService,
} from '@libs/shared/utility-auth';
import { WindowService } from '@libs/shared/utility-service-window';
import { CookieService, EpiServerService } from '@libs/shared/utility-services';

import { CheckOpenIdService } from './assets/js/openidchecker/open-id-checker';

const OUTAGE_PAGE = 'https://www.legalandgeneral.com/service-announcement.html';

export async function main(): Promise<any> {
  const windowHelper = new WindowService();
  const configLoaderService = new ConfigLoaderService(windowHelper);

  await configLoaderService
    .retrieveConfig()
    .then(config => {
      environment.config = config;
    })
    .catch(() => {
      // should never happen but if it does, redirect to the outage page
      window.location.href = OUTAGE_PAGE;
    });

  if (environment.config.production) {
    enableProdMode();
  }

  // It's important that the AppModule is imported after the environment
  // configuration is set. Moving the import at the top will cause
  // the AppModule to load before the main function is called causing
  // some instances of environment.config to be equal to {}.
  import('./app/app.module').then(({ AppModule }) => {
    const cookieService = new CookieService(document);

    const bootstrap = () => {
      return platformBrowserDynamic()
        .bootstrapModule(AppModule)
        .catch(err => {
          console.error(err);
          window.location.reload();
        });
    };

    const canaryReleaseService = new CanaryReleaseService(
      new EpiServerService(cookieService),
      cookieService,
    );

    canaryReleaseService.getAuthMechanism$().subscribe(({ provider, message }) => {
      console.info(message);
      console.info(`Using ${provider}`);

      if (provider === AuthProvider.Seal) {
        if (environment.config.production) {
          CheckOpenIdService.check({
            openId: `${environment.config.auth.keycloak.url}realms/My-Account/.well-known/openid-configuration`,
            redirect: 'https://www.legalandgeneral.com/maintenance',
            attempts: 3,
            intervalLength: 100,
          });
        }

        return AuthService.init$(AuthProvider.Seal, {
          onLoad: 'check-sso',
          checkLoginIframeInterval: 5,
        })
          .pipe(
            map(bootstrap),
            catchError(error => {
              return throwError(
                () =>
                  new Error(
                    `App initialisation auth check failed. Refusing to bootstrap: ${error}`,
                  ),
              );
            }),
          )
          .subscribe();
      } else {
        return AuthService.init$(AuthProvider.Scram)
          .pipe(
            map(bootstrap),
            catchError(error => {
              return throwError(
                () =>
                  new Error(
                    `App initialisation auth check failed. Refusing to bootstrap: ${error}`,
                  ),
              );
            }),
          )
          .subscribe();
      }
    });
  });
}

(async () => {
  await main();
})();
