/* eslint-disable */
export default {
  coverageDirectory: '../../reports/unit-tests/ma',
  preset: '../../jest.preset.js',
};
