/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */

// tslint:disable:no-console

self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(self.clients.claim());

  caches.keys().then(cacheNames => {
    for (const name of cacheNames) {
      caches.delete(name);
    }
  });

  self.registration.unregister().then(() => {
    console.warn('NGSW Safety Worker - unregistered old service worker');
  });
});
