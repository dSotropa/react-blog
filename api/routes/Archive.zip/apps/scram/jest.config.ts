/* eslint-disable */
export default {
  coverageDirectory: '../../reports/unit-tests/scram',
  preset: '../../jest.preset.js',
};
