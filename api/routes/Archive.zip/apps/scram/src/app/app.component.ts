import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { ChatService } from '@libs/scram/shared/utility-services';
import { RouteEventInterceptor } from '@scram/core/interceptors/route-event.interceptor';
import { consoleString } from '@scram/core/utilities/debug';
import { AnalyticsService } from '@scram/core/services/analytics.service';
import { PageService } from '@scram/core/services/page.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.scss' ],
})
export class AppComponent implements OnInit {
  title = 'scram';

  constructor(
    private analyticsService: AnalyticsService,
    private chatService: ChatService,
    private pageService: PageService,
    private routeEventInterceptor: RouteEventInterceptor,
    private router: Router,
  ) {
    consoleString('APP Constructor');

    if (this.pageService.isIEBrowser()) {
      consoleString('IE browser detected');
      this.router.navigate([ '', 'unsupported-browser' ]);
    }
  }

  ngOnInit(): void {
    this.chatService.init();
    this.routeEventInterceptor.watch();
    this.analyticsService.initialise();
  }
}
