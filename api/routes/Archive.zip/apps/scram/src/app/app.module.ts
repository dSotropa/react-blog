import { BrowserModule } from '@angular/platform-browser';
import { APP_BASE_HREF, LocationStrategy } from '@angular/common';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

import { AccessTokenInterceptor } from '@scram/core/interceptors/access-token.interceptor';
import { RouteEventInterceptor } from '@scram/core/interceptors/route-event.interceptor';
import { AuthEffects } from '@scram/core/store/auth.effects';
import * as fromAuth from '@scram/core/store/auth.reducers';
import { SharedModule } from '@scram/shared/shared.module';
import { URLHelper } from '@scram/core/utilities/url';
import { PreserveQuerystring } from '@scram/core/services/querystring.service';
import { AuthService } from '@scram/core/services/auth.service';
import { PageService } from '@scram/core/services/page.service';
import { TimerService } from '@scram/core/services/timer.service';
import { SuspendedUserService } from '@scram/core/services/suspendedUser.service';
import { AnalyticsService } from '@scram/core/services/analytics.service';
import { ScramLayoutModule } from '@scram/layout/scram/scram-layout.module';
import { AuthenticationModule } from '@scram/modules/authentication/authentication.module';
import { environment } from '@libs/shared/utility-config-loader';
import { WindowService } from '@libs/shared/utility-service-window';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LogoutComponent } from './modules/logout/logout.component';
import { TechnicalIssueComponent } from './modules/technical-issue/technical-issue.component';
import { UnsupportedBrowserComponent } from './modules/unsupported-browser/unsupported-browser.component';

export function getBaseHref(window: WindowService): string {
  // This is to handle the different base href in the test environment for a branch
  // where the url looks like: https://test.scram.platform.landg.com/branch/fep-123-branch-name
  if (environment.config.name === 'test') {
    const parts = window.getPathname().split('/');

    return `/${parts[1]}/${parts[2]}`;
  }

  return '/';
}

@NgModule({
  declarations: [
    AppComponent,
    LogoutComponent,
    TechnicalIssueComponent,
    UnsupportedBrowserComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    StoreModule.forRoot({
      authState: fromAuth.reducer,
    }),
    EffectsModule.forRoot([ AuthEffects ]),
    StoreDevtoolsModule.instrument({
      maxAge: 25, // Retains last 25 states
    }),
    BrowserAnimationsModule,
    SharedModule,
    AppRoutingModule,
    AuthenticationModule,
    ScramLayoutModule,
  ],
  providers: [
    AuthService,
    PageService,
    TimerService,
    SuspendedUserService,
    AnalyticsService,
    RouteEventInterceptor,
    URLHelper,
    { provide: HTTP_INTERCEPTORS, useClass: AccessTokenInterceptor, multi: true },
    { provide: LocationStrategy, useClass: PreserveQuerystring },
    {
      provide: APP_BASE_HREF,
      useFactory: getBaseHref,
      deps: [ WindowService ],
    },
  ],
  bootstrap: [ AppComponent ],
})
export class AppModule {
  constructor() {}
}
