import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ScramLayoutComponent } from '@scram/layout/scram/scram-layout.component';
import { CallbackComponent } from '@scram/modules/callback/callback.component';
import { LogoutComponent } from '@scram/modules/logout/logout.component';

import { TechnicalIssueComponent } from './modules/technical-issue/technical-issue.component';
import { UnsupportedBrowserComponent } from './modules/unsupported-browser/unsupported-browser.component';

const routes: Routes = [
  {
    path: '',
    component: ScramLayoutComponent,
    children: [
      { path: '_callback', component: CallbackComponent },
      { path: 'logout', component: LogoutComponent },
      {
        path: 'technical-issue',
        component: TechnicalIssueComponent,
      },
      {
        path: 'error',
        loadChildren: () =>
          import('@scram/modules/error/error.module').then((m: any) => m.ErrorModule),
      },
      { path: 'unsupported-browser', component: UnsupportedBrowserComponent },
      {
        path: 'forgotten-user',
        loadChildren: () =>
          import('@scram/modules/forgottenUser/forgotten-user.module').then(
            (m: any) => m.ForgottenUserModule,
          ),
      },
      {
        path: 'forgotten-password',
        loadChildren: () =>
          import('@scram/modules/forgottenPassword/forgotten-password.module').then(
            (m: any) => m.ForgottenPasswordModule,
          ),
      },
      {
        path: '',
        loadChildren: () =>
          import('@scram/modules/authentication/authentication.module').then(
            (m: any) => m.AuthenticationModule,
          ),
      },
    ],
  },
  {
    path: 'register',
    component: ScramLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () =>
          import('@scram/modules/registration/registration.module').then(
            (m: any) => m.RegistrationModule,
          ),
      },
    ],
  },
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ],
  providers: [],
})
export class AppRoutingModule {}
