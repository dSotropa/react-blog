/* istanbul ignore file */
import { CallbackType } from '@forgerock/javascript-sdk';

import {
  selectAuthState,
  selectUserDetails,
  selectUserData,
  selectIsAuthenticated,
  selectAuthTokens,
  selectError,
  selectSuspendedList,
} from '@scram/core/store/auth.selectors';

/* Data for use in tests */

export const mockUserDetails = {
  name: 'Test User',
  family_name: 'User',
  given_name: 'Test',
  sub: '5OftiekSQky9Dbq1hzl0R0BxkgrF97750J+EnqpCNQk=',
  subname: '51394e4b-3bb5-4fe5-b58b-0ea80bc0453d',
};

export const mockUserData = {
  userId: 'TU123456',
  email: 'test.user@landg.com',
  emailMasked: 'te*********dg.com',
  phone: '011 2222 3333',
  phoneMasked: '01*********33',
  dob: '10/11/2000',
  mfaChoice: 0,
};

export const mockAuthTokens = {
  accessToken:
    'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI1MTM5NGU0Yi0zYmI1LTRmZTUtYjU4Yi0wZWE4MGJjMDQ1M2QiLCJjdHMiOiJPQVVUSDJfU1RBVEVMRVNTX0dSQU5UIiwiYXV0aF9sZXZlbCI6MCwiYXVkaXRUcmFja2luZ0lkIjoiZjc4ZjUyNWItNGZmMS00Y2NmLWJjYmMtZDJjOGFiOGFiNDI2LTgzNTg4MTEiLCJzdWJuYW1lIjoiNTEzOTRlNGItM2JiNS00ZmU1LWI1OGItMGVhODBiYzA0NTNkIiwiaXNzIjoiaHR0cHM6Ly9vcGVuYW0tbGFuZGctc2FuZGJveGV1dzIuZm9yZ2VibG9ja3MuY29tOjQ0My9hbS9vYXV0aDIvcmVhbG1zL3Jvb3QvcmVhbG1zL2FscGhhIiwidG9rZW5OYW1lIjoiYWNjZXNzX3Rva2VuIiwidG9rZW5fdHlwZSI6IkJlYXJlciIsImF1dGhHcmFudElkIjoiRVFUdV9pOE85WEE0Ump2cVg3UHFjbVp6Wm9vIiwiYXVkIjoiQW5ndWxhckN1c3RvbWVyQ2xpZW50IiwibmJmIjoxNjYwMTI4OTIwLCJncmFudF90eXBlIjoiYXV0aG9yaXphdGlvbl9jb2RlIiwic2NvcGUiOlsib3BlbmlkIiwicHJvZmlsZSIsImZyOmlkbToqIl0sImF1dGhfdGltZSI6MTY2MDEyODkxOSwicmVhbG0iOiIvYWxwaGEiLCJleHAiOjE2NjAxMzI1MjAsImlhdCI6MTY2MDEyODkyMCwiZXhwaXJlc19pbiI6MzYwMCwianRpIjoidS1vUDhBenVqdEF0U2R6aGV3Yjd4bzNGbm84In0.A0R94tf1bxgYHlkL_r1DPmSzhQIfw5fuFVfM2adlj-8',
  idToken:
    'eyJ0eXAiOiJKV1QiLCJraWQiOiJOMkhxMTNRSkxFbGxIOERBVk4zQkF4Z1JnM0U9IiwiYWxnIjoiUlMyNTYifQ.eyJhdF9oYXNoIjoiZzF1ZVBsbk5xblNDemY1YzFmTTJQZyIsInN1YiI6IjVPZnRpZWtTUWt5OURicTFoemwwUjBCeGtnckY5Nzc1MEorRW5xcENOUWs9IiwiYXVkaXRUcmFja2luZ0lkIjoiZjc4ZjUyNWItNGZmMS00Y2NmLWJjYmMtZDJjOGFiOGFiNDI2LTgzNTg4MTkiLCJzdWJuYW1lIjoiNTEzOTRlNGItM2JiNS00ZmU1LWI1OGItMGVhODBiYzA0NTNkIiwiaXNzIjoiaHR0cHM6Ly9vcGVuYW0tbGFuZGctc2FuZGJveGV1dzIuZm9yZ2VibG9ja3MuY29tOjQ0My9hbS9vYXV0aDIvcmVhbG1zL3Jvb3QvcmVhbG1zL2FscGhhIiwidG9rZW5OYW1lIjoiaWRfdG9rZW4iLCJnaXZlbl9uYW1lIjoiQW5keSIsInNpZCI6ImREdG5sQlRSdEhsQlpRenJ2U05XZ1J4eGRpdTVabHFVTFhEWklKKzh3Z1E9IiwiYXVkIjoiQW5ndWxhckN1c3RvbWVyQ2xpZW50IiwiY19oYXNoIjoiT2hhaDNSZTlPcFNJSHVsZXhTaWVxUSIsImFjciI6IjAiLCJvcmcuZm9yZ2Vyb2NrLm9wZW5pZGNvbm5lY3Qub3BzIjoiQXVzbkNfREIyQVZtSTU2cVhDOG5SOFFEdDQ0Iiwic19oYXNoIjoiS29QQzJERC1vQjZfOThaQUVvak9FUSIsImF6cCI6IkFuZ3VsYXJDdXN0b21lckNsaWVudCIsImF1dGhfdGltZSI6MTY2MDEyODkxOSwibmFtZSI6IkFuZHkgSG9wa2lucyIsInJlYWxtIjoiL2FscGhhIiwiZXhwIjoxNjYwMTMyNTIwLCJ0b2tlblR5cGUiOiJKV1RUb2tlbiIsImlhdCI6MTY2MDEyODkyMCwiZmFtaWx5X25hbWUiOiJIb3BraW5zIn0.YbDjt4e1ZvBtHXWZbQIEjhraA75bkMWdArql8x68pqW0ppIVbH8pSSNp9zx5oL3D2-Cx0Yl6ow7AmHib3nr-uN9zsyVJi8WnwYzZ23YHuW07BwBb4h0Tmn9YAwLdoJJ_luzfB97pg4k9TaPLWAnd02CG7AlMK3pUHluJeB-Z2t31tpZVB4Va4kL0BeDfR5GgoxVgHDer9_g5BA30Qk3YrtBxmseyyWwmZVq0hxh7sJp7rwAZp03pct1gpC_iTjeieIcQ3ONcb9jrVKIVYeDupqV-YGM2UUO7CZDvjeNVlnnHBh19h_ToqZt_WvI02O1Fl7Ey1b3UKduZruKH6ntssw',
  refreshToken:
    'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI1MTM5NGU0Yi0zYmI1LTRmZTUtYjU4Yi0wZWE4MGJjMDQ1M2QiLCJjdHMiOiJPQVVUSDJfU1RBVEVMRVNTX0dSQU5UIiwiYXV0aF9sZXZlbCI6MCwiYXVkaXRUcmFja2luZ0lkIjoiZjc4ZjUyNWItNGZmMS00Y2NmLWJjYmMtZDJjOGFiOGFiNDI2LTgzNTg4MTIiLCJzdWJuYW1lIjoiNTEzOTRlNGItM2JiNS00ZmU1LWI1OGItMGVhODBiYzA0NTNkIiwiaXNzIjoiaHR0cHM6Ly9vcGVuYW0tbGFuZGctc2FuZGJveGV1dzIuZm9yZ2VibG9ja3MuY29tOjQ0My9hbS9vYXV0aDIvcmVhbG1zL3Jvb3QvcmVhbG1zL2FscGhhIiwidG9rZW5OYW1lIjoicmVmcmVzaF90b2tlbiIsInRva2VuX3R5cGUiOiJCZWFyZXIiLCJhdXRoR3JhbnRJZCI6IkVRVHVfaThPOVhBNFJqdnFYN1BxY21aelpvbyIsInNpZCI6ImREdG5sQlRSdEhsQlpRenJ2U05XZ1J4eGRpdTVabHFVTFhEWklKKzh3Z1E9IiwiYXVkIjoiQW5ndWxhckN1c3RvbWVyQ2xpZW50IiwiYWNyIjoiMCIsIm5iZiI6MTY2MDEyODkyMCwib3BzIjoiQXVzbkNfREIyQVZtSTU2cVhDOG5SOFFEdDQ0IiwiZ3JhbnRfdHlwZSI6ImF1dGhvcml6YXRpb25fY29kZSIsInNjb3BlIjpbIm9wZW5pZCIsInByb2ZpbGUiLCJmcjppZG06KiJdLCJhdXRoX3RpbWUiOjE2NjAxMjg5MTksInJlYWxtIjoiL2FscGhhIiwiZXhwIjoxNjYwNzMzNzIwLCJpYXQiOjE2NjAxMjg5MjAsImV4cGlyZXNfaW4iOjYwNDgwMCwianRpIjoicTJhUmdkZ2UzWjVZUkVHWWFnWGYweklWam5rIn0.dxkf_YDV7Xp9fIkDBcvBhPIrNIYSk3dB28uFFQlNze8',
  tokenExpiry: 1660132519735,
};

export const mockErrorData = {
  error: { code: 401, reason: 'Unauthorized', message: 'Login failure' },
};

export const mockStoreValue = {
  selectors: [
    {
      selector: selectAuthState,
      value: {
        isAuthenticated: true,
        userDetails: mockUserDetails,
        errorMessage: mockErrorData,
        userData: mockUserData,
        authTokens: mockAuthTokens,
      },
    },
    {
      selector: selectUserDetails,
      value: mockUserDetails,
    },
    {
      selector: selectUserData,
      value: mockUserData,
    },
    {
      selector: selectError,
      value: mockErrorData,
    },
    {
      selector: selectIsAuthenticated,
      value: {
        isAuthenticated: true,
      },
    },
    {
      selector: selectAuthTokens,
      value: mockAuthTokens,
    },
    {
      selector: selectSuspendedList,
      value: '',
    },
  ],
};

export const mockMFAChoice_Both = {
  email: 'test@landg.com',
  sms: '012 222222',
};

export const mockMFAChoice_EmailOnly = {
  email: 'test@landg.com',
  sms: '',
};

export const mockMFAChoice_SMSOnly = {
  email: '',
  sms: '012 222222',
};

export const mockVerificationCodeJson = {
  otp: '406222',
  email: 'andrew.hopkins@landg.com',
  sms: '',
};

export const mockCurrentStep = {
  payload: {
    authId: 'mockedAuthId',
    callbacks: [
      {
        type: 'MetadataCallback',
        output: [
          {
            name: 'data',
            value: {
              errorMessage: null,
            },
          },
        ],
        _id: 0,
      },
      {
        type: 'StringAttributeInputCallback',
        output: [
          {
            name: 'name',
            value: 'undefined',
          },
          {
            name: 'prompt',
            value: 'Email address or User ID',
          },
          {
            name: 'required',
            value: false,
          },
          {
            name: 'policies',
            value: [ '' ],
          },
          {
            name: 'failedPolicies',
            value: [],
          },
          {
            name: 'validateOnly',
            value: false,
          },
          {
            name: 'value',
            value: '',
          },
        ],
        input: [
          {
            name: 'IDToken1',
            value: '',
          },
          {
            name: 'IDToken1validateOnly',
            value: false,
          },
        ],
        _id: 1,
      },
    ],
    stage: 'mockStage',
    status: 200,
    ok: true,
  },
  type: 'Step',
  callbacks: [
    {
      payload: {
        type: 'StringAttributeInputCallback',
        output: [
          {
            name: 'name',
            value: 'undefined',
          },
          {
            name: 'prompt',
            value: 'Email address or User ID',
          },
          {
            name: 'required',
            value: false,
          },
          {
            name: 'policies',
            value: [ '' ],
          },
          {
            name: 'failedPolicies',
            value: [],
          },
          {
            name: 'validateOnly',
            value: false,
          },
          {
            name: 'value',
            value: '',
          },
        ],
        input: [
          {
            name: 'IDToken1',
            value: '',
          },
          {
            name: 'IDToken1validateOnly',
            value: false,
          },
        ],
        _id: 1,
      },
    },
  ],
};

export const mockFRCurrentStep = {
  payload: {
    authId: 'mockedAuthId',
    callbacks: [
      {
        type: 'MetadataCallback' as CallbackType,
        output: [
          {
            name: 'data',
            value: {
              errorMessage: null,
            },
          },
        ],
        _id: 0,
      },
      {
        type: 'NameCallback' as CallbackType,
        output: [
          {
            name: 'name',
            value: 'userName',
          },
          {
            name: 'prompt',
            value: 'Username',
          },
          {
            name: 'required',
            value: false,
          },
          {
            name: 'policies',
            value: {},
          },
          {
            name: 'failedPolicies',
            value: [],
          },
          {
            name: 'validateOnly',
            value: false,
          },
          {
            name: 'value',
            value: '',
          },
        ],
        input: [
          {
            name: 'IDToken2',
            value: '',
          },
          {
            name: 'IDToken2validateOnly',
            value: false,
          },
        ],
        _id: 1,
      },
      {
        type: 'PasswordCallback' as CallbackType,
        output: [
          {
            name: 'prompt',
            value: 'Password',
          },
        ],
        input: [
          {
            name: 'IDToken3',
            value: '',
          },
        ],
        _id: 2,
      },
    ],
    stage: 'userIdPassword',
  },
};

export const mockFRDeviceProfile = {
  payload: {
    authId: 'mockedAuthId',
    callbacks: [
      {
        type: 'DeviceProfileCallback' as CallbackType,
        output: [
          {
            name: 'metadata',
            value: true,
          },
          {
            name: 'location',
            value: false,
          },
          {
            name: 'message',
            value: '',
          },
        ],
        input: [
          {
            name: 'IDToken1',
            value: '',
          },
        ],
      },
    ],
  },
};

export const mockFRUserTerms = {
  payload: {
    authId: 'mockedAuthId',
    callbacks: [
      {
        type: 'TermsAndConditionsCallback' as CallbackType,
        output: [
          {
            name: 'version',
            value: 'consumer.2.0',
          },
          {
            name: 'terms',
            value: '<h1>Updated terms 2.0</h1><p>Hi there',
          },
          {
            name: 'createDate',
            value: '2019-10-28T04:20:11.320Z',
          },
        ],
        input: [
          {
            name: 'IDToken1',
            value: false,
          },
        ],
        _id: 3,
      },
    ],
    stage: 'userterms',
  },
};

export const mockFRUsername = {
  payload: {
    authId: 'mockedAuthId',
    callbacks: [
      {
        type: 'StringAttributeInputCallback' as CallbackType,
        output: [
          {
            name: 'name',
            value: 'undefined',
          },
          {
            name: 'prompt',
            value: 'Email address or User ID',
          },
          {
            name: 'required',
            value: false,
          },
          {
            name: 'policies',
            value: [],
          },
          {
            name: 'failedPolicies',
            value: [],
          },
          {
            name: 'validateOnly',
            value: false,
          },
          {
            name: 'value',
            value: '',
          },
        ],
        input: [
          {
            name: 'IDToken1',
            value: '',
          },
          {
            name: 'IDToken1validateOnly',
            value: false,
          },
        ],
        _id: 0,
      },
    ],
    stage: 'Username',
  },
};

export const mockFRMFAChoice = {
  payload: {
    authId: 'mockedAuthId',
    callbacks: [
      {
        type: 'ChoiceCallback' as CallbackType,
        output: [
          {
            name: 'prompt',
            value: 'OOB_OPTIONS',
          },
          {
            name: 'choices',
            value: [
              '{"id":"email","display":"k****************@landg.com"}',
              '{"id":"sms","display":"*** **** 0431"}',
            ],
          },
          {
            name: 'defaultChoice',
            value: 0,
          },
        ],
        input: [
          {
            name: 'IDToken1',
            value: 0,
          },
        ],
        _id: 6,
      },
    ],
    stage: 'selectOobChannel',
  },
};

export const mockFRPassword = {
  payload: {
    authId: 'mockedAuthId',
    callbacks: [
      {
        type: 'PasswordCallback' as CallbackType,
        output: [
          {
            name: 'prompt',
            value: 'Password',
          },
        ],
        input: [
          {
            name: 'IDToken1',
            value: '',
          },
        ],
        _id: 0,
      },
      {
        type: 'ChoiceCallback' as CallbackType,
        output: [
          {
            name: 'prompt',
            value: 'Secondary authentication method',
          },
          {
            name: 'choices',
            value: [ 'CHOICES:CHOICES', 'Next:next' ],
          },
          {
            name: 'defaultChoice',
            value: 0,
          },
        ],
        input: [
          {
            name: 'IDToken2',
            value: 0,
          },
        ],
        _id: 1,
      },
      {
        type: 'HiddenValueCallback' as CallbackType,
        output: [
          {
            name: 'value',
            value: '',
          },
          {
            name: 'id',
            value: 'OUTCOME_INPUT',
          },
          {
            name: 'failCount',
            value: '0',
          },
          {
            name: 'maxTry',
            value: '7',
          },
        ],
        input: [
          {
            name: 'IDToken3',
            value: 'OUTCOME_INPUT',
          },
        ],
        _id: 2,
      },
    ],
    stage: 'Password',
  },
};

export const mockFRUserDetails2 = {
  payload: {
    authId: 'mockedAuthId',
    callbacks: [
      {
        type: 'MetadataCallback' as CallbackType,
        output: [
          {
            name: 'data',
            value: {
              errorMessage: null,
            },
          },
        ],
        _id: 0,
      },
      {
        type: 'NameCallback' as CallbackType,
        output: [
          {
            name: 'prompt',
            value: 'User Name',
          },
        ],
        input: [
          {
            name: 'IDToken2',
            value: '',
          },
        ],
        _id: 1,
      },
      {
        type: 'StringAttributeInputCallback' as CallbackType,
        output: [
          {
            name: 'name',
            value: 'dateOfBirth',
          },
          {
            name: 'prompt',
            value: 'Date of birth',
          },
          {
            name: 'required',
            value: false,
          },
          {
            name: 'policies',
            value: [],
          },
          {
            name: 'failedPolicies',
            value: [],
          },
          {
            name: 'validateOnly',
            value: false,
          },
          {
            name: 'value',
            value: '',
          },
        ],
        input: [
          {
            name: 'IDToken3',
            value: '',
          },
          {
            name: 'IDToken3validateOnly',
            value: false,
          },
        ],
        _id: 2,
      },
    ],
    stage: 'userIdDob',
  },
};

export const mockFRUserDetails = {
  payload: {
    authId: 'mockedAuthId',
    callbacks: [
      {
        type: 'StringAttributeInputCallback' as CallbackType,
        output: [
          {
            name: 'name',
            value: 'undefined',
          },
          {
            name: 'prompt',
            value: 'Email address or User ID',
          },
          {
            name: 'required',
            value: false,
          },
          {
            name: 'policies',
            value: [],
          },
          {
            name: 'failedPolicies',
            value: [],
          },
          {
            name: 'validateOnly',
            value: false,
          },
          {
            name: 'value',
            value: '',
          },
        ],
        input: [
          {
            name: 'IDToken1',
            value: '',
          },
          {
            name: 'IDToken1validateOnly',
            value: false,
          },
        ],
        _id: 0,
      },
      {
        type: 'StringAttributeInputCallback' as CallbackType,
        output: [
          {
            name: 'name',
            value: 'frIndexedDate1',
          },
          {
            name: 'prompt',
            value: 'Date of birth (DD/MM/YYYY)',
          },
          {
            name: 'required',
            value: false,
          },
          {
            name: 'policies',
            value: [],
          },
          {
            name: 'failedPolicies',
            value: [],
          },
          {
            name: 'validateOnly',
            value: false,
          },
          {
            name: 'value',
            value: '',
          },
        ],
        input: [
          {
            name: 'IDToken2',
            value: '',
          },
          {
            name: 'IDToken2validateOnly',
            value: false,
          },
        ],
        _id: 1,
      },
    ],
    stage: 'UserDetails',
    header: 'Forgotten password?',
    description: 'To reset your password, please enter your details below.',
  },
};

/* Generate new store with passed values */
/* export function newMockStoreValue(
  userDetails = mockUserDetails,
  userData = mockUserData,
  authTokens = mockAuthTokens,
  errorData = mockErrorData,
  isAuth = true,
) {*/

export function newMockStoreValue(newStore: {
  userDetails?: {};
  errorData?: {};
  userData?: {};
  authTokens?: {};
  isAuth?: boolean;
}) {
  const newMockUserDetails = newStore.userDetails
    ? newStore.userDetails
    : mockUserDetails;
  const newMockErrorData =
    newStore.errorData !== undefined
      ? newStore.errorData
      : mockErrorData;
  const newMockUserData =
    newStore.userData !== undefined
      ? newStore.userData
      : mockUserData;
  const newMockAuthTokens =
    newStore.authTokens !== undefined
      ? newStore.authTokens
      : mockAuthTokens;
  const newIsAuthenticated = newStore.isAuth !== undefined
    ? newStore.isAuth
    : true;

  return {
    selectors: [
      {
        selector: selectAuthState,
        value: {
          isAuthenticated: newIsAuthenticated,
          userDetails: newMockUserDetails,
          errorMessage: newMockErrorData,
          userData: newMockUserData,
          authTokens: newMockAuthTokens,
        },
      },
      {
        selector: selectUserDetails,
        value: newMockUserDetails,
      },
      {
        selector: selectUserData,
        value: newMockUserData,
      },
      {
        selector: selectError,
        value: newMockErrorData,
      },
      {
        selector: selectIsAuthenticated,
        value: {
          isAuthenticated: newIsAuthenticated,
        },
      },
      {
        selector: selectAuthTokens,
        value: newMockAuthTokens,
      },
      {
        selector: selectSuspendedList,
        value: '',
      },
    ],
  };
}
