/* istanbul ignore file */
import { environment } from '@libs/shared/utility-config-loader';
import 'jest-preset-angular/setup-jest';
import { configurationMock } from '@libs/scram/shared/utility-data';

Object.defineProperty(window, 'CSS', { value: null });

Object.defineProperty(window, 'getComputedStyle', {
  value: () => {
    return {
      display: 'none',
      appearance: [ '-webkit-appearance' ],
    };
  },
});

Object.defineProperty(window, 'location', {
  value: {
    ancestorOrigins: null,
    hash: {
      endsWith: null,
      includes: null,
    },
    host: 'scram-localhost',
    port: '80',
    protocol: 'http:',
    hostname: 'scram-localhost',
    href: 'http://scram-localhost',
    origin: 'http://scram-localhost',
    pathname: null,
    search: null,
    assign: jest.fn(),
    reload: jest.fn(),
    replace: jest.fn(),
  },
  writable: true,
});

Object.defineProperty(document, 'doctype', {
  value: '<!DOCTYPE html>',
});

Object.defineProperty(document.body.style, 'transform', {
  value: () => {
    return {
      enumerable: true,
      configurable: true,
    };
  },
});

const browserStorageMock = (function() {
  let store = {};

  return {
    getItem(key) {
      return store[key];
    },

    setItem(key, value) {
      store[key] = value;
    },

    clear() {
      store = {};
    },

    removeItem(key) {
      delete store[key];
    },

    getAll() {
      return store;
    },
  };
})();

Object.defineProperty(window, 'localStorage', { value: browserStorageMock });
Object.defineProperty(window, 'sessionStorage', { value: browserStorageMock });

environment.config = { ...configurationMock };
environment.config.debug = false;
