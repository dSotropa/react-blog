const copyPlugin = require('copy-webpack-plugin');
const { composePlugins, withNx } = require('@nrwl/webpack');

// Nx plugins for webpack.
module.exports = composePlugins(withNx(), config => {
  config?.plugins.push(
    new copyPlugin({
      patterns: [
        { from: '../../libs/shared/utility-mock-server/src/assets', to: 'assets' },
      ],
    }),
  );

  // Update the webpack config as needed here.
  // e.g. `config.plugins.push(new MyPlugin())`
  return config;
});
