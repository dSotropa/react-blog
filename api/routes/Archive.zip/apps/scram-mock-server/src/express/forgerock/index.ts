import * as express from 'express';

import { FORGEROCK_JSON_BASE_URL } from '@libs/shared/utility-mock-server';

import MockFRLoginController from './controllers/mock-fr-login-controller';
import MockFRLoginOTPController from './controllers/mock-fr-login-otp-controller';
import MockFRForgottenPasswordController from './controllers/mock-fr-forgotten-password-controller';
import MockFRForgottenUseridController from './controllers/mock-fr-forgotten-userid-controller';

export function setupForgeRockMocks(server: express.Application): void {
  server.get('/am/UI/Login', (req, res) => {
    console.info('LOGIN');
    const request = {
      realm: req.query['realm'] as string,
      goto: req.query['goto'] as string,
    };

    res.status(200).send();
  });

  server.get('/am/XUI', (req, res) => {
    console.info('XUI');
    const request = {
      realm: req.query['realm'] as string,
      goto: req.query['goto'] as string,
    };

    res.status(200).send();
  });

  server.post(`${FORGEROCK_JSON_BASE_URL}/authenticate`, (req, res) => {
    console.info('AUTHENTICATE');

    const journey = [
      'Customer Log In',
      'Customer Passwordless Log In - OTP',
      'Customer Forgotten Password',
      'Customer Forgotten UserID',
    ];
    const thisRequest = {
      reauthIndexTypealm: req.query['authIndexType'] as string,
      authIndexValue: req.query['authIndexValue'] as string,
    };

    console.info(thisRequest);

    if (journey.includes(thisRequest.authIndexValue)) {
      console.info('-- FORGEROCK JOURNEY');

      if (thisRequest.authIndexValue === journey[0]) {
        MockFRLoginController.respond(req, res);
      } else if (thisRequest.authIndexValue === journey[1]) {
        MockFRLoginOTPController.respond(req, res);
      } else if (thisRequest.authIndexValue === journey[2]) {
        MockFRForgottenPasswordController.respond(req, res);
      } else if (thisRequest.authIndexValue === journey[3]) {
        MockFRForgottenUseridController.respond(req, res);
      } else {
        console.info('-- JOURNEY - Not found');

        res.status(404).send();
      }
    } else {
      console.info('-- FORGEROCK JOURNEY - Not found');

      res.status(404).send();
    }
  });
}
