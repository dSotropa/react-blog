export interface ISearchData {
  username?: string;
  password?: string;
  dob?: string;
  postcode?: string;
  family_name?: string;
  given_name?: string;
}
