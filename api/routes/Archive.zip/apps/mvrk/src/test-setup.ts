import 'jest-preset-angular/setup-jest';

import { jest } from '@jest/globals';

import { environment } from '@libs/shared/utility-config-loader';
import { configurationMock } from '@libs/mvrk/shared/utility-data';

//* ************Set of helper functions for jest**********************.

// Taken from the main FEP
// Removes messages that pollute the console
window.console.error = jest.fn();
window.console.warn = jest.fn();

export interface SpyObject {
  [key: string]: jest.Mock<undefined>;
}

export const createSpyObj = (baseName: string, methodNames: Array<string>): SpyObject => {
  const obj: Record<string, any> = {};

  methodNames.forEach((element, index, arr) => {
    obj[arr[index]] = jest.fn();
  });

  return obj;
};

const mock = () => {
  let storage = {};

  return {
    getItem: (key: string) => (key in storage
      ? storage[key]
      : null),
    setItem: (key: string | number, value: string) => (storage[key] = value || ''),
    removeItem: (key: string | number) => delete storage[key],
    clear: () => (storage = {}),
  };
};

Object.defineProperty(window, 'CSS', { value: null });
Object.defineProperty(window, 'localStorage', { value: mock() });
Object.defineProperty(window, 'sessionStorage', { value: mock() });

Object.defineProperty(document, 'doctype', {
  value: '<!DOCTYPE html>',
});

Object.defineProperty(window, 'getComputedStyle', {
  value: () => {
    return {
      display: 'none',
      appearance: [ '-webkit-appearance' ],
    };
  },
});

Object.defineProperty(document.body.style, 'transform', {
  value: () => {
    return {
      enumerable: true,
      configurable: true,
    };
  },
});

Object.defineProperty(window, 'location', {
  value: {
    ancestorOrigins: null,
    hash: {
      endsWith: null,
      includes: null,
    },
    host: 'mvrk-localhost',
    port: '80',
    protocol: 'http:',
    hostname: 'mvrk-localhost',
    href: 'http://mvrk-localhost',
    origin: 'http://mvrk-localhost',
    pathname: '/',
    search: null,
    assign: jest.fn(),
    reload: jest.fn(),
    replace: jest.fn(),
  },
  writable: true,
});

environment.config = { ...configurationMock };
