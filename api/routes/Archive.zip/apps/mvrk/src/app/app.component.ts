import { Component, OnInit } from '@angular/core';

import { consoleString } from '@mvrk/common/helpers/debug/debug';
import { RouteEventInterceptor } from '@mvrk/core/interceptors/route-event.interceptor';
import { AnalyticsService } from '@mvrk/core/services/analytics/analytics.service';
@Component({
  selector: 'mvrk-root',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.scss' ],
})
export class AppComponent implements OnInit {
  constructor(
    private routeEventInterceptor: RouteEventInterceptor,
    private analyticsService: AnalyticsService,
  ) {
    consoleString('APP Constructor');
  }

  ngOnInit(): void {
    this.routeEventInterceptor.watch();
    this.analyticsService.initialise();
  }
}
