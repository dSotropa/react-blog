import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { EffectsModule } from '@ngrx/effects';
import { StoreRouterConnectingModule } from '@ngrx/router-store';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

import { environment } from '@libs/shared/utility-config-loader';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { AnalyticsService } from './core/services/analytics/analytics.service';
import { SharedModule } from './shared/shared.module';
import { ShellComponent } from './shell/shell.component';
import { metaReducers, reducers } from './store/reducers';

@NgModule({
  declarations: [ AppComponent, ShellComponent ],
  imports: [
    BrowserModule,
    SharedModule,
    CoreModule,
    AppRoutingModule,
    StoreModule.forRoot(reducers, {
      metaReducers,
    }),
    EffectsModule.forRoot([]), // TODO:: user / auth effects etc goes here.
    StoreDevtoolsModule.instrument({
      name: 'Scram Maverick App DevTools',
      maxAge: 25,
      logOnly: environment.config.production,
    }),
    // TODO:: https://ngrx.io/guide/router-store <-- meta reducers we can possibly use with effects // ROUTER_REQUEST, ROUTER_NAVIGATION, ROUTER_NAVIGATED
    StoreRouterConnectingModule.forRoot(),
  ],
  providers: [ AnalyticsService ],
  bootstrap: [ AppComponent ],
})
export class AppModule {}
