import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AuthGuard } from '@libs/mvrk/shared/utility-guards';

import { ShellComponent } from './shell/shell.component';

const appRoutes: Routes = [
  {
    path: '',
    component: ShellComponent,
    canActivate: [ AuthGuard ],
    children: [
      {
        path: 'advisers',
        loadChildren: () =>
          import('./features/advisers/advisers.module').then(m => m.AdvisersModule),
      },
      {
        path: 'consumers',
        loadChildren: () =>
          import('./features/consumers/consumers.module').then(m => m.ConsumersModule),
      },
      {
        path: 'employees',
        loadChildren: () =>
          import('./features/employees/employees.module').then(m => m.EmployeesModule),
      },
      {
        path: 'login',
        // TODO:: possible resolver to detect already auth --> route to another place (can be a servce depending on their permissions and forward)
        loadChildren: () =>
          import('./features/user/user.module').then(m => m.UserModule),
      },
      {
        // TODO:: delete, only used by developers test some poc etc
        path: 'play-ground',
        loadChildren: () =>
          import('./features/demo/demo.module').then(m => m.DemoModule),
      },
      {
        path: '',
        redirectTo: 'advisers',
        pathMatch: 'full',
      },
    ],
  },
  { path: '**', redirectTo: '' },
];

@NgModule({
  imports: [ RouterModule.forRoot(appRoutes, { scrollPositionRestoration: 'enabled' }) ],
  exports: [ RouterModule ],
})
export class AppRoutingModule {}
