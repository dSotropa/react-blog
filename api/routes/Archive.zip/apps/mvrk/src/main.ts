import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { ConfigLoaderService, environment } from '@libs/shared/utility-config-loader';
import { WindowService } from '@libs/shared/utility-service-window';

export async function main(): Promise<any> {
  const windowService = new WindowService();
  const configLoaderService = new ConfigLoaderService(windowService);

  await configLoaderService
    .retrieveConfig()
    .then(config => {
      environment.config = config;
    })
    .catch((err: Error) => {
      console.error(err);
    });

  if (environment.config.production) {
    enableProdMode();
  }

  // It's important that the AppModule is imported after the environment
  // configuration is set. Moving the import at the top will cause
  // the AppModule to load before the main function is called causing
  // some instances of environment.config to be equal to {}.
  import('./app/app.module').then(({ AppModule }) => {
    platformBrowserDynamic()
      .bootstrapModule(AppModule)
      .catch(err => {
        console.error(err);
        window.location.reload();
      });
  });
}

(async () => {
  await main();
})();
