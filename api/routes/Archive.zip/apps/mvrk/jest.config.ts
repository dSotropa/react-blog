/* eslint-disable */
export default {
  coverageDirectory: '../../reports/unit-tests/mvrk',
  preset: '../../jest.preset.js',
};
