import test from '@playwright/test';
import { MOCK_ENV } from '@utility-e2e';

import { BasePage } from '../models/basepage';
import { AdviserSearchPage } from '../pageobjects/adviser-search.po';

test.describe('Navigate to the Maverick app', () => {
  let advisersSearchPage: AdviserSearchPage;
  let basePage: BasePage;

  test.beforeEach(async ({ page }) => {
    basePage = new BasePage(page);
    advisersSearchPage = new AdviserSearchPage(page);
    await basePage.homePage.navigate();
  });

  test('user is routed to the adviser search page @CoreTest', async ({ page }) => {
    await page.waitForURL(`${MOCK_ENV}${advisersSearchPage.route}`);
  });
});
