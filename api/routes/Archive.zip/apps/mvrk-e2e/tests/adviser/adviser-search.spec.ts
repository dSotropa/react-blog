import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { AdviserSearchPage } from '../../pageobjects/adviser-search.po';
import { BasePage } from '../../models/basepage';

test.describe('Advisers search', () => {
  let advisersSearchPage: AdviserSearchPage;
  let basePage: BasePage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ page }) => {
    advisersSearchPage = new AdviserSearchPage(page);
    basePage = new BasePage(page);

    await basePage.homePage.navigate();
    await page.waitForURL(`**/${advisersSearchPage.route}`);
    await advisersSearchPage.assertElementVisible(advisersSearchPage.searchForm);
  });

  test('Compare the Adviser search page to it\'s baseline @VisualCheck', async ({
    page,
  }) => {
    await visualFunctions.eyesCheck('Adviser search page', page);
  });

  test.describe('form validation', () => {
    test('generic error message is displayed when all inputs are empty @CoreTest', async () => {
      await advisersSearchPage.searchSubmitBtn.click();

      await advisersSearchPage.assertElementVisible(advisersSearchPage.searchFormError);
    });

    test('does not perform search when validation errors exist @CoreTest', async () => {
      await advisersSearchPage.searchSubmitBtn.click();

      await advisersSearchPage.assertElementNotVisible(advisersSearchPage.searchResults);
    });

    test.describe('user id', () => {
      test('minLength error is displayed if < 4 characters entered @CoreTest', async () => {
        await advisersSearchPage.enterUserId('123');
        await advisersSearchPage.searchSubmitBtn.click();

        await advisersSearchPage.assertElementVisible(
          advisersSearchPage.searchFormValidationErrors.userIdMinLength,
        );
      });

      test('pattern error is displayed if invalid characters are entered @CoreTest', async () => {
        await advisersSearchPage.enterUserId('12345%');
        await advisersSearchPage.searchSubmitBtn.click();

        await advisersSearchPage.assertElementVisible(
          advisersSearchPage.searchFormValidationErrors.userIdPattern,
        );
      });

      test('maxlength error is displayed if > 255 characters are entered @CoreTest', async () => {
        const maxValue = 'A'.repeat(256);

        await advisersSearchPage.enterUserId(maxValue);
        await advisersSearchPage.searchSubmitBtn.click();

        await advisersSearchPage.assertElementVisible(
          advisersSearchPage.searchFormValidationErrors.userIdMaxLength,
        );
      });
    });

    test('pattern error is displayed if invalid characters are entered for first name @CoreTest', async () => {
      await advisersSearchPage.enterFirstName('name%');
      await advisersSearchPage.searchSubmitBtn.click();

      await advisersSearchPage.assertElementVisible(
        advisersSearchPage.searchFormValidationErrors.firstNamePattern,
      );
    });

    test('pattern error is displayed if invalid characters are entered for last name @CoreTest', async () => {
      await advisersSearchPage.enterLastName('name_');
      await advisersSearchPage.searchSubmitBtn.click();

      await advisersSearchPage.assertElementVisible(
        advisersSearchPage.searchFormValidationErrors.lastNamePattern,
      );
    });

    test('minlength error is displayed if < 4 characters are entered for email @CoreTest', async () => {
      await advisersSearchPage.enterEmail('t@t');
      await advisersSearchPage.searchSubmitBtn.click();

      await advisersSearchPage.assertElementVisible(
        advisersSearchPage.searchFormValidationErrors.emailMinLength,
      );
    });

    test.describe('agency number', () => {
      test('minLength error is displayed if < 4 characters entered @CoreTest', async () => {
        await advisersSearchPage.enterAgencyNumber('123');
        await advisersSearchPage.searchSubmitBtn.click();

        await advisersSearchPage.assertElementVisible(
          advisersSearchPage.searchFormValidationErrors.agencyNumberMinLength,
        );
      });

      test('pattern error is displayed if invalid characters are entered @CoreTest', async () => {
        await advisersSearchPage.enterAgencyNumber('12345%');
        await advisersSearchPage.searchSubmitBtn.click();

        await advisersSearchPage.assertElementVisible(
          advisersSearchPage.searchFormValidationErrors.agencyNumberPattern,
        );
      });

      test('pattern error is displayed if > 7 characters are entered @CoreTest', async () => {
        await advisersSearchPage.enterAgencyNumber('12345678');
        await advisersSearchPage.searchSubmitBtn.click();

        await advisersSearchPage.assertElementVisible(
          advisersSearchPage.searchFormValidationErrors.agencyNumberPattern,
        );
      });
    });

    test.describe('mobile number', () => {
      test('minLength error is displayed if < 4 characters entered @CoreTest', async () => {
        await advisersSearchPage.enterMobile('123');
        await advisersSearchPage.searchSubmitBtn.click();

        await advisersSearchPage.assertElementVisible(
          advisersSearchPage.searchFormValidationErrors.mobileMinLength,
        );
      });

      test('pattern error is displayed if invalid characters are entered @CoreTest', async () => {
        await advisersSearchPage.enterMobile('012345A');
        await advisersSearchPage.searchSubmitBtn.click();

        await advisersSearchPage.assertElementVisible(
          advisersSearchPage.searchFormValidationErrors.mobilePattern,
        );
      });
    });

    test.describe('user uid', () => {
      test('pattern error is displayed if invalid uid entered @CoreTest', async () => {
        await advisersSearchPage.enterUserUId('c1d2711-b06b-496c-adb5-3cf15412b588');
        await advisersSearchPage.searchSubmitBtn.click();

        await advisersSearchPage.assertElementVisible(
          advisersSearchPage.searchFormValidationErrors.userUidPattern,
        );

        await advisersSearchPage.enterUserUId('c1d27119-b06-496c-adb5-3cf15412b588');
        await advisersSearchPage.searchSubmitBtn.click();

        await advisersSearchPage.assertElementVisible(
          advisersSearchPage.searchFormValidationErrors.userUidPattern,
        );

        await advisersSearchPage.enterUserUId('c1d27119-b06b-496-adb5-3cf15412b588');
        await advisersSearchPage.searchSubmitBtn.click();

        await advisersSearchPage.assertElementVisible(
          advisersSearchPage.searchFormValidationErrors.userUidPattern,
        );

        await advisersSearchPage.enterUserUId('c1d27119-b06b-496c-adb-3cf15412b588');
        await advisersSearchPage.searchSubmitBtn.click();

        await advisersSearchPage.assertElementVisible(
          advisersSearchPage.searchFormValidationErrors.userUidPattern,
        );

        await advisersSearchPage.enterUserUId('c1d27119-b06b-496c-adb5-3cf15412b58');
        await advisersSearchPage.searchSubmitBtn.click();

        await advisersSearchPage.assertElementVisible(
          advisersSearchPage.searchFormValidationErrors.userUidPattern,
        );
      });
    });
  });

  test('submits form if all fields are valid', async () => {
    await advisersSearchPage.enterUserId('1234.');
    await advisersSearchPage.enterFirstName('abc123\'');
    await advisersSearchPage.enterLastName('abc123-');
    await advisersSearchPage.enterEmail('test');
    await advisersSearchPage.enterAgencyNumber('123456');
    await advisersSearchPage.enterAgencyNumber('0123456789');
    await advisersSearchPage.enterUserUId('c1d27119-b06b-496c-adb5-3cf15412b588');

    await advisersSearchPage.assertElementVisible(advisersSearchPage.searchResults);
  });

  afterAllHook(test);
});
