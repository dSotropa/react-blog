import { test } from '@playwright/test';
import { afterAllHook, VisualFunctions } from '@utility-e2e';

import { BasePage } from '../../models/basepage';
import { AgencySearchPage } from '../../pageobjects/agency-search.po';
import { AdviserHeader } from '../../pageobjects/adviser-header.po';

test.describe('Agency search', () => {
  let agencySearchPage: AgencySearchPage;
  let adviserHeader: AdviserHeader;
  let basePage: BasePage;
  let visualFunctions: VisualFunctions;

  test.beforeAll(() => {
    visualFunctions = VisualFunctions.getInstance();
  });

  test.beforeEach(async ({ page }) => {
    agencySearchPage = new AgencySearchPage(page);
    adviserHeader = new AdviserHeader(page);
    basePage = new BasePage(page);

    await basePage.homePage.navigate();
    await adviserHeader.clickAgencySearch();
    await page.waitForURL(`**/${agencySearchPage.route}`);
    await agencySearchPage.assertElementVisible(agencySearchPage.searchForm);
  });

  test('Compare the Agency search page to it\'s baseline @VisualCheck', async ({
    page,
  }) => {
    await visualFunctions.eyesCheck('Agency search page', page);
  });

  test.describe('form validation', () => {
    test('generic error message is displayed when all inputs are empty @CoreTest', async () => {
      await agencySearchPage.searchSubmitBtn.click();

      await agencySearchPage.assertElementVisible(agencySearchPage.searchFormError);
    });

    test.describe('fca firm number', () => {
      test('minLength error is displayed if < 6 characters entered @CoreTest', async () => {
        await agencySearchPage.enterFcaFirmNumber('12345');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.fcaFirmNumberMinLength,
        );
      });

      test('pattern error is displayed if invalid characters are entered @CoreTest', async () => {
        await agencySearchPage.enterFcaFirmNumber('123456A');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.fcaFirmNumberPattern,
        );
      });

      test('pattern error is displayed if > 8 characters are entered @CoreTest', async () => {
        await agencySearchPage.enterFcaFirmNumber('123456789');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.fcaFirmNumberPattern,
        );
      });
    });

    test.describe('agency number', () => {
      test('minLength error is displayed if < 4 characters entered @CoreTest', async () => {
        await agencySearchPage.enterAgencyNumber('123');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.agencyNumberMinLength,
        );
      });

      test('pattern error is displayed if invalid characters are entered @CoreTest', async () => {
        await agencySearchPage.enterAgencyNumber('123456A');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.agencyNumberPattern,
        );
      });

      test('pattern error is displayed if > 7 characters are entered @CoreTest', async () => {
        await agencySearchPage.enterAgencyNumber('12345678');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.agencyNumberPattern,
        );
      });
    });

    test.describe('master fca firm number', () => {
      test('minLength error is displayed if < 6 characters entered @CoreTest', async () => {
        await agencySearchPage.enterMasterFcaFirmNumber('12345');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.masterFcaFirmNumberMinLength,
        );
      });

      test('pattern error is displayed if invalid characters are entered @CoreTest', async () => {
        await agencySearchPage.enterMasterFcaFirmNumber('123456A');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.masterFcaFirmNumberPattern,
        );
      });

      test('pattern error is displayed if > 8 characters are entered @CoreTest', async () => {
        await agencySearchPage.enterMasterFcaFirmNumber('123456789');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.masterFcaFirmNumberPattern,
        );
      });
    });

    test.describe('master agency number', () => {
      test('minLength error is displayed if < 4 characters entered @CoreTest', async () => {
        await agencySearchPage.enterMasterAgencyNumber('123');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.masterAgencyNumberMinLength,
        );
      });

      test('pattern error is displayed if invalid characters are entered @CoreTest', async () => {
        await agencySearchPage.enterMasterAgencyNumber('123456A');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.masterAgencyNumberPattern,
        );
      });

      test('pattern error is displayed if > 7 characters are entered @CoreTest', async () => {
        await agencySearchPage.enterMasterAgencyNumber('12345678');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.masterAgencyNumberPattern,
        );
      });
    });

    test.describe('agency name', () => {
      test('minLength error is displayed if < 4 characters entered @CoreTest', async () => {
        await agencySearchPage.enterAgencyName('123');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.agencyNameMinLength,
        );
      });

      test('pattern error is displayed if invalid characters are entered @CoreTest', async () => {
        await agencySearchPage.enterAgencyName('123456%^');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.agencyNamePattern,
        );
      });

      test('pattern error is displayed if > 35 characters are entered @CoreTest', async () => {
        const maxValue = 'A'.repeat(36);

        await agencySearchPage.enterAgencyName(maxValue);
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.agencyNamePattern,
        );
      });

      test('allows special characters ,&.\'-:  @CoreTest', async () => {
        await agencySearchPage.enterAgencyName('12345,&.\'-:');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementNotVisible(
          agencySearchPage.searchFormValidationErrors.agencyNamePattern,
        );
      });
    });

    test.describe('master agency name', () => {
      test('minLength error is displayed if < 4 characters entered @CoreTest', async () => {
        await agencySearchPage.enterMasterAgencyName('123');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.masterAgencyNameMinLength,
        );
      });

      test('pattern error is displayed if invalid characters are entered @CoreTest', async () => {
        await agencySearchPage.enterMasterAgencyName('123456%^');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.masterAgencyNamePattern,
        );
      });

      test('pattern error is displayed if > 35 characters are entered @CoreTest', async () => {
        const maxValue = 'A'.repeat(36);

        await agencySearchPage.enterMasterAgencyName(maxValue);
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.masterAgencyNamePattern,
        );
      });

      test('allows special characters ,&.\'-:  @CoreTest', async () => {
        await agencySearchPage.enterMasterAgencyName('12345,&.\'-:');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementNotVisible(
          agencySearchPage.searchFormValidationErrors.agencyNamePattern,
        );
      });
    });

    test.describe('postcode', () => {
      test('minLength error is displayed if < 2 characters entered @CoreTest', async () => {
        await agencySearchPage.enterPostcode('A');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.postcodeMinLength,
        );
      });

      test('pattern error is displayed if invalid characters are entered @CoreTest', async () => {
        await agencySearchPage.enterPostcode('BN1 2AA%');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.postcodePattern,
        );
      });

      test('pattern error is displayed if > 8 characters are entered @CoreTest', async () => {
        await agencySearchPage.enterPostcode('BN12 1AAA');
        await agencySearchPage.searchSubmitBtn.click();

        await agencySearchPage.assertElementVisible(
          agencySearchPage.searchFormValidationErrors.postcodePattern,
        );
      });
    });
  });

  afterAllHook(test);
});
