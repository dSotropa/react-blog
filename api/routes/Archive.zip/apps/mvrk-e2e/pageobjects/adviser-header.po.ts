import { PageFunctions } from '@utility-e2e';
import { Locator, Page } from '@playwright/test';

export class AdviserHeader extends PageFunctions {
  readonly page: Page;
  readonly navLinks: Record<string, Locator>;

  constructor(page: Page) {
    super(page);
    this.page = page;

    this.navLinks = {
      search: page.locator('data-testid=nav-link-adviser-search'),
      agencySearch: page.locator('data-testid=nav-link-agency-search'),
      bulkUpdate: page.locator('data-testid=nav-link-bulk-update'),
      manageIP: page.locator('data-testid=nav-link-manage-ip'),
      managementInfo: page.locator('data-testid=nav-link-management-info'),
    };
  }

  async clickAdviserSearch() {
    await this.navLinks.search.click();
  }

  async clickAgencySearch() {
    await this.navLinks.agencySearch.click();
  }

  async clickBulkUpdate() {
    await this.navLinks.bulkUpdate.click();
  }

  async clickManageIP() {
    await this.navLinks.manageIP.click();
  }

  async clickManagementInfo() {
    await this.navLinks.managementInfo.click();
  }
}
