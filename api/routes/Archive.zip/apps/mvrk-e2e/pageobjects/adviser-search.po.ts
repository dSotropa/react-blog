import { PageFunctions } from '@utility-e2e';
import { Locator, Page } from '@playwright/test';

export class AdviserSearchPage extends PageFunctions {
  readonly page: Page;
  readonly searchForm: Locator;
  readonly searchFormError: Locator;
  readonly searchSubmitBtn: Locator;
  readonly searchResults: Locator;
  readonly searchFormValidationErrors: Record<string, Locator>;
  readonly searchFormInputs: Record<string, Locator>;

  readonly route = 'advisers/search';

  constructor(page: Page) {
    super(page);
    this.page = page;

    this.searchForm = page.locator('data-testid=adviser-search-form');
    this.searchSubmitBtn = page.locator('data-testid=adviser-search-submit-btn');
    this.searchFormError = page.locator('data-testid=adviser-search-error');
    this.searchResults = page.locator('data-testid=adviser-search-results');

    this.searchFormValidationErrors = {
      userIdMinLength: page.locator('data-testid=adviser-search-error-user-id-minlength'),
      userIdPattern: page.locator('data-testid=adviser-search-error-user-id-pattern'),
      userIdMaxLength: page.locator('data-testid=adviser-search-error-user-id-maxlength'),
      firstNamePattern: page.locator(
        'data-testid=adviser-search-error-first-name-pattern',
      ),
      lastNamePattern: page.locator('data-testid=adviser-search-error-last-name-pattern'),
      emailMinLength: page.locator('data-testid=adviser-search-error-email-minlength'),
      agencyNumberMinLength: page.locator(
        'data-testid=adviser-search-error-agency-number-minlength',
      ),
      agencyNumberPattern: page.locator(
        'data-testid=adviser-search-error-agency-number-pattern',
      ),
      mobileMinLength: page.locator('data-testid=adviser-search-error-mobile-minlength'),
      mobilePattern: page.locator('data-testid=adviser-search-error-mobile-pattern'),
      userUidPattern: page.locator('data-testid=adviser-search-error-user-uid-pattern'),
    };

    this.searchFormInputs = {
      userId: page.locator('data-testid=adviser-search-input-user-id'),
      firstName: page.locator('data-testid=adviser-search-input-first-name'),
      lastName: page.locator('data-testid=adviser-search-input-last-name'),
      email: page.locator('data-testid=adviser-search-input-email'),
      agencyNumber: page.locator('data-testid=adviser-search-input-agency-number'),
      mobile: page.locator('data-testid=adviser-search-input-mobile'),
      userUId: page.locator('data-testid=adviser-search-input-user-uid'),
    };
  }

  async enterUserId(userId: string) {
    await this.searchFormInputs.userId.fill(userId);
  }

  async enterFirstName(name: string) {
    await this.searchFormInputs.firstName.fill(name);
  }

  async enterLastName(lastName: string) {
    await this.searchFormInputs.lastName.fill(lastName);
  }

  async enterEmail(email: string) {
    await this.searchFormInputs.email.fill(email);
  }

  async enterAgencyNumber(agencyNumber: string) {
    await this.searchFormInputs.agencyNumber.fill(agencyNumber);
  }

  async enterMobile(mobile: string) {
    await this.searchFormInputs.mobile.fill(mobile);
  }

  async enterUserUId(uid: string) {
    await this.searchFormInputs.userUId.fill(uid);
  }
}
