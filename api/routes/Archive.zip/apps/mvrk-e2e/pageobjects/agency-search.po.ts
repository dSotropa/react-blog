import { PageFunctions } from '@utility-e2e';
import { Locator, Page } from '@playwright/test';

export class AgencySearchPage extends PageFunctions {
  readonly page: Page;
  readonly searchForm: Locator;
  readonly searchFormError: Locator;
  readonly searchSubmitBtn: Locator;
  readonly searchResults: Locator;
  readonly searchFormValidationErrors: Record<string, Locator>;
  readonly searchFormInputs: Record<string, Locator>;

  readonly route = 'advisers/agency-search';

  constructor(page: Page) {
    super(page);
    this.page = page;

    this.searchForm = page.locator('data-testid=agency-search-form');
    this.searchSubmitBtn = page.locator('data-testid=agency-search-submit-btn');
    this.searchFormError = page.locator('data-testid=agency-search-error');

    this.searchFormValidationErrors = {
      fcaFirmNumberMinLength: page.locator(
        'data-testid=agency-search-error-fca-firm-number-minlength',
      ),
      fcaFirmNumberPattern: page.locator(
        'data-testid=agency-search-error-fca-firm-number-pattern',
      ),
      agencyNumberMinLength: page.locator(
        'data-testid=agency-search-error-agency-number-minlength',
      ),
      agencyNumberPattern: page.locator(
        'data-testid=agency-search-error-agency-number-pattern',
      ),
      masterFcaFirmNumberMinLength: page.locator(
        'data-testid=agency-search-error-master-fca-firm-number-minlength',
      ),
      masterFcaFirmNumberPattern: page.locator(
        'data-testid=agency-search-error-master-fca-firm-number-pattern',
      ),
      masterAgencyNumberMinLength: page.locator(
        'data-testid=agency-search-error-master-agency-number-minlength',
      ),
      masterAgencyNumberPattern: page.locator(
        'data-testid=agency-search-error-master-agency-number-pattern',
      ),
      agencyNameMinLength: page.locator(
        'data-testid=agency-search-error-agency-name-minlength',
      ),
      agencyNamePattern: page.locator(
        'data-testid=agency-search-error-agency-name-pattern',
      ),
      masterAgencyNameMinLength: page.locator(
        'data-testid=agency-search-error-master-agency-name-minlength',
      ),
      masterAgencyNamePattern: page.locator(
        'data-testid=agency-search-error-master-agency-name-pattern',
      ),
      postcodeMinLength: page.locator(
        'data-testid=agency-search-error-postcode-minlength',
      ),
      postcodePattern: page.locator('data-testid=agency-search-error-postcode-pattern'),
    };

    this.searchFormInputs = {
      fcaFirmNumber: page.locator('data-testid=agency-search-input-fca-firm-number'),
      agencyNumber: page.locator('data-testid=agency-search-input-agency-number'),
      masterFcaFirmNumber: page.locator(
        'data-testid=agency-search-input-master-fca-firm-number',
      ),
      masterAgencyNumber: page.locator(
        'data-testid=agency-search-input-master-agency-number',
      ),
      agencyName: page.locator('data-testid=agency-search-input-agency-name'),
      masterAgencyName: page.locator(
        'data-testid=agency-search-input-master-agency-name',
      ),
      postcode: page.locator('data-testid=agency-search-input-agency-postcode'),
    };
  }

  async enterFcaFirmNumber(fcaFirmNumber: string) {
    await this.searchFormInputs.fcaFirmNumber.fill(fcaFirmNumber);
  }

  async enterAgencyNumber(agencyNumber: string) {
    await this.searchFormInputs.agencyNumber.fill(agencyNumber);
  }

  async enterMasterFcaFirmNumber(masterFcaFirmNumber: string) {
    await this.searchFormInputs.masterFcaFirmNumber.fill(masterFcaFirmNumber);
  }

  async enterMasterAgencyNumber(masterAgencyNumber: string) {
    await this.searchFormInputs.masterAgencyNumber.fill(masterAgencyNumber);
  }

  async enterAgencyName(agencyName: string) {
    await this.searchFormInputs.agencyName.fill(agencyName);
  }

  async enterMasterAgencyName(masterAgencyName: string) {
    await this.searchFormInputs.masterAgencyName.fill(masterAgencyName);
  }

  async enterPostcode(postcode: string) {
    await this.searchFormInputs.postcode.fill(postcode);
  }
}
